<?php
?>

<div class="" id="add_cases">


    <form method="post" enctype="multipart/form-data">

        <div class="form-group">
            <label for="plan" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Select a Plan</label>
            <select required data-livesearch="true" title="Select a Plan" name="plan" id="plan" class="selectpicker form-control form-control-sm">

                <?php foreach($plans as $plan){ ?>
                    <option data-subtext="<?= $plan->type; ?>" value="<?= $plan->id; ?>"><?= $plan->title; ?></option>
                <?php } ?>

            </select>
        </div>

        <div class="form-group">
            <label for="plan" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Cases</label>
            <select multiple disabled required data-livesearch="true" title="Select a Plan" name="cases[]" id="cases" class="selectpicker form-control form-control-sm">

            </select>
        </div>

        <div class="form-group">
            <label for="env" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Test Envirements</label>
            <select multiple required data-livesearch="true" title="Select an enticement" name="env[]" id="env" class="selectpicker form-control form-control-sm">

                <?php foreach($envs as $env){ ?>
                    <option selected value="<?= $env->id; ?>"><?= $env->name; ?></option>
                <?php } ?>

            </select>
        </div>




    </form>


</div>
