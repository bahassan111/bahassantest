import Model from '../model'
export default class Bookmark extends Model {
  static schema = {
    name: 'Bookmark',
    primaryKey: 'id',
    properties: {
      id: 'int',
      title: 'string',
      content: 'string?',
      date: 'string',
      category_name: 'string',
      comment_count: 'string',
      post_view: 'string',
      source_url: 'string',
      interessant: 'int',
      pas_interessant: 'int',
      jaime: 'int',
      jaime_pas: 'int',
      nimporte_quoi: 'int',
      author_email : 'string',
      author : 'string?',
      comment_status : 'string?',

    }
  }
}