
(function () {
    var view = $('#task_form');
    if(!view.length) return;


    $(view)
        .on('change', '#time', function () {
            $('.times_list_f > span').removeClass('active').filter(`[data-tmm="${$(this).val()}"]`).addClass('active');
        })
        .on('change', '#date, #time', function () {
            var d = $('#date').val(),
                t = $('#time').val();

            log(d, t);
            if(d && t){
                if(t >= 480){
                    var days = t / 480;
                    t = days * (60 * 24);
                }
                var deadline = moment(d, 'YYYY-MM-DD').add(t, 'minutes').format('YYYY-MM-DD');
                $('#deadline').val(deadline).trigger('change');
            }
        })
        .ready(function () {
            $('#time, #date').trigger('change');
        })
})();