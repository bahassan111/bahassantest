import React, { Component } from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    ImageBackground,
    ActivityIndicator,
} from "react-native";
import * as Updates from 'expo-updates';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import i18n from 'i18n-js';
import {updateData} from "../redux/actions/dataAction";
import { CommonActions } from '@react-navigation/native';
import {colors} from "../global/GlobalStyle";
import API from "../storage/TwAPIClient";
import storage from "../storage/TwStorage";
import moment from "moment-with-locales-es6";
import {fetchCategories, fetchNewsData} from "../data/NewsData";

class introScreen extends Component {

    state = {
        isFirstTime : false,
        loader_txt : i18n.t('loading_news'),
    };


    goNext = (news, cats)=>{
        const { navigation } = this.props;

        navigation.dispatch(
            CommonActions.reset({
                index: 1,
                routes: [
                    { name: this.state.isFirstTime ? 'setup' : 'main', params : {news:news, categories : cats} },
                ],
            })
        );
    };

    goError = (err_type)=>{
        const { navigation } = this.props;
        navigation.dispatch(
            CommonActions.reset({
                index: 1,
                routes: [
                    { name: 'error', params : {err_type : err_type} },
                ],
            })
        );
    };


    checkUpdates = async ()=>{
        try {
            const update = await Updates.checkForUpdateAsync();
            if (update.isAvailable) {
                await Updates.fetchUpdateAsync();
                //alert("Nouvelle mise à jour de l'application trouvée");
                await Updates.reloadAsync();
                return true;
            }
        } catch (e) {
            //alert('Message dev : ' + e);
        }


        return false;



    };

    initData = ()=>{

        return new Promise(((resolve, reject) => {
            storage.getStorage('__data', null)
                .then((rep)=>{

                    if(rep === null){

                        let data = this.props.data || {};
                        data.initialized = moment().format('X');
                        this.props.updateData(data);
                        resolve(data);

                    }else{

                        try {
                            rep = JSON.parse(rep);
                            this.setState({isFirstTime : false});
                            rep.last_run = moment().format('X');
                        }catch (e) {
                            rep = this.props.data || {};
                            rep.initialized = moment().format('X');

                            resolve(rep);
                        }


                        this.props.updateData(rep);
                       resolve(rep);


                    }


                });
        }))

    };

    componentDidMount() {
        this.setState({loader_txt: 'Démarrage ..'});

        const { navigation } = this.props;

        console.log('p', navigation);

        this.initData()
            .then((data)=>{
                //this.setState({loader_txt: 'Vérification des mises à jour ..'});
                this.setState({loader_txt: 'Chargement des actualités ...'});
                this.goNext([], []);



                this.checkUpdates().then((updated)=>{




                });

            })



    }

    UNSAFE_componentWillMount() {



    }

    render() {
        return (

            <View style={styles.whole}>
                <ImageBackground resizeMode={'cover'} source={require('../assets/state-shape-bg.png')} style={styles.bg}>

                    <View style={styles.text_container}>
                        <Image style={styles.logo} source={require('../assets/logo.png')}/>
                        <Text style={styles.sub_text}>{this.state.loader_txt}</Text>
                        <ActivityIndicator style={styles.loader} size="large" color="#ffffff" />
                    </View>

                    <Text style={styles.footer_text}>{i18n.t('appname')}</Text>
                </ImageBackground>

            </View>

        );
    }

}

const styles = StyleSheet.create({
    bg:{
        flex:1,
        resizeMode: "center",
        justifyContent: "center"
    },
    whole: {
        display:'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height:'100%',
        backgroundColor: colors.back,
    },
    logo:{
        resizeMode : 'contain',
        height: "30%",
        marginBottom: "20%"
    },
    text_container : {
        minHeight: '80%',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        flex:1,
        paddingTop: '14%'
    },
    sub_text : {
        textAlign: 'center',
        color: '#fff',
        fontSize: 18
    },
    footer_text : {
        textAlign: 'center',
        fontSize: 14,
        color:'rgba(255,255,255,0.76)',
        marginTop: 32,
        marginBottom: 32,
    },
    loader:{
      marginBottom: 40,
      marginTop: 40,
    },
});

const mapDispatchToProps = dispatch => (
    bindActionCreators({
        updateData: updateData,
    }, dispatch)
);

const mapStateToProps = (state) => {
    const { data } = state;
    return { data }
};

export default connect(mapStateToProps, mapDispatchToProps)(introScreen);
