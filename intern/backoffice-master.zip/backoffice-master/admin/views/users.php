<?php
?>

<div id="users_view">

    <div class="dt_section">

        <div class="dt_head">
            <div class="t">
                <h3>All Users</h3>
            </div>
            <div class="a">
                <button class="button default" data-table="users_tbl" id="reload_table"><i class="fas fa-sync-alt"></i> </button>
                <button class="button primary" id="add_user">Create user <i class="fas fa-plus"></i> </button>
            </div>
        </div>

        <div class="dt_inner">
            <?= datatable('users_tbl', 5); ?>
        </div>

    </div>

</div>
