package ma.rak.ov.storage;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.Date;
import java.util.HashMap;

public class SharedPrefManager {

    private static final String SHARED_PREF_MANAGER = "MY_SHARED_PREF";
    private static SharedPrefManager mInstance;
    private Context mContext;

    private SharedPrefManager(Context mContext) {
        this.mContext = mContext;
    }

    public static synchronized SharedPrefManager getInstance(Context mContext) {
        if (mInstance == null) {
            mInstance = new SharedPrefManager(mContext);
        }
        return mInstance;
    }

    public void saveUser(String id, String token, String expires, String[] scoop, String fullName, String userName, String pwd) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_MANAGER, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String scoopToString = new Gson().toJson(scoop);

        int tsLong = (int)System.currentTimeMillis()/1000;

        editor.putString("token", token);
        editor.putString("expires", expires);
        editor.putString("scoop", scoopToString);
        editor.putString("fullName", fullName);
        editor.putString("username", userName);
        editor.putString("id", id);
        editor.putString("pwd", pwd);
        editor.putString("time", String.valueOf(tsLong));
        editor.apply();
    }

    public void operationMode(int mode) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_MANAGER, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("mode", String.valueOf(mode));
        editor.apply();
    }

    public void saveBaseUrl(String baseurl) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_MANAGER, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("baseurl", baseurl);
        editor.apply();
    }

    public String getBaseUrl() {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_MANAGER, Context.MODE_PRIVATE);
        String baseurl = sharedPreferences.getString("baseurl", null);
        return baseurl;
    }

    public void setSyncTime(String time) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_MANAGER, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("sync_time", time);
        editor.apply();
    }

    public void setPos(Float lat, Float lng) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_MANAGER, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putFloat("lat", lat);
        editor.putFloat("lng", lng);
        editor.apply();
    }

    public HashMap<String, Float> getPos() {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_MANAGER, Context.MODE_PRIVATE);
        float lat = sharedPreferences.getFloat("lat", 0);
        float lng = sharedPreferences.getFloat("lng", 0);

        if(lat == 0f) return this.getDefaultPos();

        HashMap<String, Float> result = new HashMap<String, Float>();
        result.put("lat", lat);
        result.put("lng", lng);

        return result;
    }

    public HashMap<String, Float> getDefaultPos() {

        HashMap<String, Float> result = new HashMap<String, Float>();
        result.put("lat", 34.2555732f);
        result.put("lng", -6.5846474f);

        return result;
    }

    public String getSyncTime() {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_MANAGER, Context.MODE_PRIVATE);
        return sharedPreferences.getString("sync_time", "Jamais");
    }

    public void setFetchTime(String time) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_MANAGER, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("fetch_time", time);
        editor.apply();
    }

    public String getFetchTime() {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_MANAGER, Context.MODE_PRIVATE);
        return sharedPreferences.getString("fetch_time", "");
    }

    public int getMode() {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_MANAGER, Context.MODE_PRIVATE);
        int value = 0;
        String s = sharedPreferences.getString("mode", null);
        value = s != null ? Integer.parseInt(s) : 0;
        return value;
    }

    public String getUserName() {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_MANAGER, Context.MODE_PRIVATE);
        String value = "";
        String s = sharedPreferences.getString("username", null);
        value = s != null ? s : "";
        return value;
    }

    public String getUserID() {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_MANAGER, Context.MODE_PRIVATE);
        String value = "";
        String s = sharedPreferences.getString("id", null);
        value = s != null ? s : "";
        return value;
    }

    public int getLoginTime() {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_MANAGER, Context.MODE_PRIVATE);
        String value = "";
        String s = sharedPreferences.getString("time", null);
        value = s != null ? s : "0";
        return Integer.valueOf(value);
    }


    public String getUserPassword() {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_MANAGER, Context.MODE_PRIVATE);
        String value = "";
        String s = sharedPreferences.getString("pwd", null);
        value = s != null ? s : "";
        return value;
    }

    public boolean isLogged() {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_MANAGER, Context.MODE_PRIVATE);

        return sharedPreferences.getString("token", null) != null;
    }

    public String getToken() {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_MANAGER, Context.MODE_PRIVATE);
        return sharedPreferences.getString("token", null);
    }

    public String getFullName() {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_MANAGER, Context.MODE_PRIVATE);
        String fullName = sharedPreferences.getString("fullName", "");
        return fullName;
    }

    public String getScoop() {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_MANAGER, Context.MODE_PRIVATE);
        String scoop = sharedPreferences.getString("scoop", "");

        String compteType = "Agent";

        JSONArray temp = null;
        try {
            temp = new JSONArray(scoop);

            for (int i = 0; i < temp.length(); i++) {
                if (temp.get(i).equals("affect")) {
                    compteType = "Superviseur";
                    break;
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return compteType;
    }

    public void saveSystemInfo() {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_MANAGER, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        String s = String.valueOf(new Date().getTime());
        editor.putString("lastUpdate", s);
        editor.putString("status", "Synchronisé");
        editor.apply();
    }

    public void clear() {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(SHARED_PREF_MANAGER, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
    }
}
