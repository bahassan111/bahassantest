import 'package:flutter/material.dart';
import 'package:rider_app/constants/constants.dart';
import 'package:rider_app/models/models.dart';

class CustomDropDownMenu extends StatefulWidget {
  final List<CountryModel> items;
  final Function onChange;
  final String dropDownValue;

  CustomDropDownMenu({Key key, this.items, this.onChange, this.dropDownValue})
      : super(key: key);

  @override
  _CustomDropDownMenuState createState() => _CustomDropDownMenuState();
}

class _CustomDropDownMenuState extends State<CustomDropDownMenu> {
  String selectedCountry;
  @override
  void initState() {
    selectedCountry = widget.dropDownValue;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return DropdownButton<String>(
      value: selectedCountry,
      icon: Container(
        padding: EdgeInsets.only(right: 15),
        child: Image.asset(AllImages.down),
      ),
      iconSize: 20,
      isExpanded: true,
      style: Theme.of(context).textTheme.headline5.copyWith(
            fontSize: 17,
            fontWeight: FontWeight.w700,
          ),
      underline: Container(
        height: 2,
        color: AppThemes.lightinputBorderColor,
      ),
      onChanged: (String newValue) {
        setState(() {
          selectedCountry = newValue;
          widget.onChange(newValue);
        });
      },
      items: widget.items.map<DropdownMenuItem<String>>((CountryModel country) {
        return DropdownMenuItem<String>(
          value: country.id,
          child: Text(country.countryName),
        );
      }).toList(),
    );
  }
}
