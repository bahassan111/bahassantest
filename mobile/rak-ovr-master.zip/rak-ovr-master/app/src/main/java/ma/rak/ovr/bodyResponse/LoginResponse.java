package ma.rak.ovr.bodyResponse;

import com.google.gson.annotations.SerializedName;

public class LoginResponse {

    @SerializedName("error")
    private boolean err;

    @SerializedName("message")
    private String msg;

    @SerializedName("token")
    private String token;

    @SerializedName("data")
    private loginBody data;

    public LoginResponse(boolean err, String msg, loginBody data) {
        this.err = err;
        this.msg = msg;
        this.data = data;
    }

    public boolean isErr() {
        return err;
    }

    public String getMsg() {
        return msg;
    }

    public loginBody getData() {
        return data;
    }


    public class loginBody {
        @SerializedName("token")
        public String token;
        @SerializedName("name")
        public String fullname;
        @SerializedName("expires")
        public Integer expires;
        public String[] scoop;

        public loginBody(String token, Integer expires, String[] scoop) {
            this.token = token;
            this.expires = expires;
            this.scoop = scoop;
        }
    }
}
