import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:rider_app/ui/components/error_dialog.dart';

Future<DateTime> selectDate(BuildContext context,
    {DateTime selectedDate}) async {
  final DateTime picked = await showDatePicker(
    context: context,
    initialDate: selectedDate ?? DateTime.now(),
    firstDate: DateTime.now(),
    lastDate: DateTime.now().add(
      Duration(days: 5),
    ),
  );
  return picked;
}

Future<DateTime> selectAllDate(BuildContext context,
    {DateTime selectedDate}) async {
  final DateTime picked = await showDatePicker(
    context: context,
    initialDate: selectedDate ?? DateTime.now(),
    lastDate: DateTime.now(),
    firstDate: DateTime(2020),
  );

  return picked;
}

double dateToDouble(TimeOfDay time) => time.hour + (time.minute / 60);
dynamic selectTime(BuildContext context,
    {DateTime selectedTime, DateTime selectedDate}) async {
  final pickedTime = await showTimePicker(
    context: context,
    initialTime: selectedTime ?? TimeOfDay(hour: 00, minute: 00),
  );
  if (selectedDate.difference(DateTime.now()).inSeconds > 0) {
    return pickedTime;
  }
  if (!(pickedTime == null)) if (dateToDouble(pickedTime) -
          dateToDouble(TimeOfDay.now()) <=
      0) {
    BotToast.showWidget(toastBuilder: (_) {
      return ErrorDialog(
        title: "Time Conflict",
        message: "Please Select A valid time ",
      );
    });
    return;
  }
  return pickedTime;
}

imgFromGallery() async {
  final _picker = ImagePicker();
  PickedFile image = await _picker.getImage(source: ImageSource.gallery);
  return image;
}
