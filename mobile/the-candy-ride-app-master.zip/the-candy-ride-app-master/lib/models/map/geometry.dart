import 'package:latlong/latlong.dart';

class Geometry {
  List<LatLng> coordinates;

  Geometry({this.coordinates});

  Geometry.fromJson(Map<String, dynamic> json) {
    if (json['coordinates'] != null) {
      coordinates = [];
      json['coordinates'].forEach((v) {
        coordinates.add(LatLng(v[1] + 0.0, v[0] + 0.0));
      });
    }
  }
}
