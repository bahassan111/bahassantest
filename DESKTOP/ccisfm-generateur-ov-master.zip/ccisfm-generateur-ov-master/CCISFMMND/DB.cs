﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CCISFMMND
{
    public class DB
    {
        SQLiteConnection conn;
        String dbFile = "Database_v5.db";
        String history_folder = "history";
           

        public DB()
        {

            bool create_new = !File.Exists(dbFile);

            conn = CreateConnection();

            if (!initied()) create_new = true;

            if (create_new)
            {
                try
                {
                    CreateTable();
                }
                catch (Exception ex)
                {

                }
            }

            if (!System.IO.Directory.Exists(history_folder))
            {
                try
                {
                    Directory.CreateDirectory(history_folder);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Impossible de crée le dossier d'historique!", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            
            
        }



        private SQLiteConnection CreateConnection()
      {
 
         SQLiteConnection sqlite_conn;
         // Create a new database connection:
         sqlite_conn = new SQLiteConnection("Data Source="+ dbFile +";Version=3;New=True;Compress=True;");
         // Open the connection:
         try
         {
            sqlite_conn.Open();
         }
         catch (Exception ex)
         {
 
         }
         return sqlite_conn;
      }


        private void CreateTable()
      {
 
         SQLiteCommand sqlite_cmd;
         string Createsql = "CREATE TABLE rib (nom VARCHAR(255), rib VARCHAR(255), amt VARCHAR(255), deleted INT)";
         sqlite_cmd = conn.CreateCommand();
         sqlite_cmd.CommandText = Createsql;
         sqlite_cmd.ExecuteNonQuery();

         sqlite_cmd.CommandText = "INSERT INTO rib (nom, rib, deleted) VALUES ('test', 'test', 1);";
         sqlite_cmd.ExecuteNonQuery();
      }




        public DB addRIB(String nom, String rib, string hint_amt)
        {
            rib = rib.Replace("-", "");
            SQLiteCommand sqlite_cmd;
            sqlite_cmd = conn.CreateCommand();

            sqlite_cmd.CommandText = "SELECT rib FROM rib WHERE rib = '" + rib + "'";

            bool exists = false;

            var sqlite_datareader = sqlite_cmd.ExecuteReader();
            while (sqlite_datareader.Read())
            {
                string myreader = sqlite_datareader.GetString(0);
                exists = myreader.Length > 0;

                if (exists) break;
            }

            sqlite_datareader.Close();


            if (exists)
            {
                sqlite_cmd.CommandText = "UPDATE rib SET nom = '" + nom + "', amt='" + hint_amt + "' WHERE rib = '" + rib + "';";
            }
            else
            {
                sqlite_cmd.CommandText = "INSERT INTO rib (nom, rib, amt, deleted) VALUES ('" + nom + "', '" + rib + "', '" + hint_amt + "', 0);";
            }


            sqlite_cmd.ExecuteNonQuery();

            return this;

        }

        public DB updateRIBamt(String nom, String rib, string hint_amt)
        {
            rib = rib.Replace("-", "");
            SQLiteCommand sqlite_cmd;
            sqlite_cmd = conn.CreateCommand();

            sqlite_cmd.CommandText = "SELECT rib FROM rib WHERE rib = '" + rib + "' AND nom = '" + nom + "'";

            bool exists = false;

            var sqlite_datareader = sqlite_cmd.ExecuteReader();
            while (sqlite_datareader.Read())
            {
                string myreader = sqlite_datareader.GetString(0);
                exists = myreader.Length > 0;

                if (exists) break;
            }

            sqlite_datareader.Close();


            if (exists)
            {
                sqlite_cmd.CommandText = "UPDATE rib SET nom = '" + nom + "', amt='" + hint_amt + "' WHERE rib = '" + rib + "';";
            }
            else
            {
                sqlite_cmd.CommandText = "INSERT INTO rib (nom, rib, amt, deleted) VALUES ('" + nom + "', '" + rib + "', '" + hint_amt + "', 0);";
            }


            sqlite_cmd.ExecuteNonQuery();

            return this;

        }

        public DB delRIB(String nom, String rib, string hint_amt)
        {
            rib = rib.Replace("-", "");
            SQLiteCommand sqlite_cmd;
            sqlite_cmd = conn.CreateCommand();

            sqlite_cmd.CommandText = "SELECT rib FROM rib WHERE rib = '" + rib + "' AND nom = '" + nom + "' AND amt = '"+hint_amt+"'";

            bool exists = false;

            var sqlite_datareader = sqlite_cmd.ExecuteReader();
            while (sqlite_datareader.Read())
            {
                string myreader = sqlite_datareader.GetString(0);
                exists = myreader.Length > 0;

                if (exists) break;
            }

            sqlite_datareader.Close();


            if (exists)
            {
                sqlite_cmd.CommandText = "UPDATE rib SET deleted = 1 WHERE rib = '" + rib + "' AND nom = '" + nom + "' AND amt = '" + hint_amt + "'";

                sqlite_cmd.ExecuteNonQuery();
            }
            


            return this;

        }

      private void ReadData()
      {
          SQLiteDataReader sqlite_datareader;
          SQLiteCommand sqlite_cmd;
          sqlite_cmd = conn.CreateCommand();
          sqlite_cmd.CommandText = "SELECT * FROM SampleTable";

          sqlite_datareader = sqlite_cmd.ExecuteReader();
          while (sqlite_datareader.Read())
          {
              string myreader = sqlite_datareader.GetString(0);
              Console.WriteLine(myreader);
          }

          //conn.Close();
      }

      public List<RIBClass> getRIBS()
      {
          SQLiteDataReader sqlite_datareader;
          SQLiteCommand sqlite_cmd;
          sqlite_cmd = conn.CreateCommand();
          sqlite_cmd.CommandText = "SELECT nom, rib, amt FROM rib WHERE deleted = 0";

          var list = new List<RIBClass>();

          sqlite_datareader = sqlite_cmd.ExecuteReader();
          while (sqlite_datareader.Read())
          {
              string nom = sqlite_datareader.GetString(0);
              string rib = sqlite_datareader.GetString(1);
              string hamt = sqlite_datareader.GetString(2);
              
              list.Add(new RIBClass(nom, rib, hamt));
          }

          return list;
      }

      private bool initied()
      {
          SQLiteDataReader sqlite_datareader;
          SQLiteCommand sqlite_cmd;
          sqlite_cmd = conn.CreateCommand();
          sqlite_cmd.CommandText = "SELECT * FROM rib WHERE deleted = 1";

          try
          {
              sqlite_datareader = sqlite_cmd.ExecuteReader();
              while (sqlite_datareader.Read())
              {
                  string myreader = sqlite_datareader.GetString(0);
                  return true;
              }
          }
          catch (Exception ex)
          {
              return false;
          }

          return false;
      }

      public void saveToHistory(String data, DateTime date, String remise)
      {
          var filename = date.ToString("yyyy-MM-dd") + "_" + remise + ".unl";
          var i = 0;

          while (File.Exists(history_folder + @"\" + filename) && ++i < 200)
          {
              filename = date.ToString("yyyy-MM-dd") + "_" + remise + "_" + i.ToString() + ".unl";
          }

          File.WriteAllText(history_folder + @"\" + filename, data);

      }

      public List<FileInfo> getHistory()
      {
          var list = Directory.GetFiles(history_folder);
          List<FileInfo> history = new List<FileInfo>();

          foreach (var file in list)
          {

              var f = new FileInfo(file);
              if (f.Exists)
              {
                  history.Add(f);
              }

          }


          return history;

      }
    }
}
