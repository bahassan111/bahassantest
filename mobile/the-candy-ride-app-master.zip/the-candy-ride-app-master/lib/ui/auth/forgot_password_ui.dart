import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rider_app/constants/constants.dart';
import 'package:rider_app/controllers/controllers.dart';
import 'package:rider_app/ui/components/components.dart';

class ForgotPasswordUI extends StatefulWidget {
  @override
  _ForgotPasswordUIState createState() => _ForgotPasswordUIState();
}

class _ForgotPasswordUIState extends State<ForgotPasswordUI> {
  double height, width;
  static AuthController to = Get.find();
  TextEditingController email = TextEditingController();

  @override
  Widget build(BuildContext context) {
    width = MediaQuery.of(context).size.width;
    height = MediaQuery.of(context).size.height;

    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          child: Column(
            children: [
              CustomeBackButton(),
              SizedBox(
                height: 50,
              ),
              Text(
                "recoverPassword".tr,
                style: Theme.of(context)
                    .textTheme
                    .headline2
                    .copyWith(fontSize: 20, fontWeight: FontWeight.w700),
              ),
              SizedBox(
                height: 25,
              ),
              Image.asset(
                AllImages.password,
                height: 100,
              ),
              SizedBox(
                height: 35,
              ),
              getInputForm,
              SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Text(
                  "recoverAccountSuggestion".tr,
                  textAlign: TextAlign.center,
                  style: Theme.of(context)
                      .textTheme
                      .headline3
                      .copyWith(fontSize: 16, fontWeight: FontWeight.w700),
                ),
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 35.0, vertical: 20),
                child: RoundButton(
                  onTap: () {
                    if (to.validator.email(email.text.trim())) {
                      BotToast.showWidget(
                        toastBuilder: (_) => ErrorDialog(
                          title: "error".tr,
                          message: "errorValidEmail".tr,
                        ),
                      );
                    } else {
                      to.forgotPassword(email.text.trim());
                    }
                  },
                  text: "sendPassword".tr.toUpperCase(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  get getInputForm => Container(
        padding: EdgeInsets.symmetric(horizontal: 35),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "enter".tr + ' ' + "e-mailId".tr,
              style: Theme.of(context).textTheme.headline4.copyWith(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                  ),
            ),
            FormInputField(
              controller: email,
            ),
            SizedBox(
              height: 25,
            ),
            Divider(
              color: AppThemes.lightDividerColor,
              height: 1,
              thickness: 2,
            )
          ],
        ),
      );
}
