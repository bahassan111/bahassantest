import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import DrawerNav from "./DrawerNav";
import introScreen from "../screens/introScreen";
import setupScreen from "../screens/setupScreen";
import errorScreen from "../screens/errorScreen";
const Stack = createStackNavigator();
const StackNav = (notif_id)=>{
  return (
      <Stack.Navigator initialRouteName="splash">
          <Stack.Screen name="splash" component={introScreen} options={{ headerShown:false }} initialParams={{'notif_id':notif_id}} />
          <Stack.Screen name="setup" component={setupScreen} options={{ headerShown:false }} />
          <Stack.Screen name="error" component={errorScreen} options={{ headerShown:false }} />
          <Stack.Screen name="main" component={DrawerNav} options={{ headerShown:false }} />
      </Stack.Navigator>
  );
};


export default StackNav;
