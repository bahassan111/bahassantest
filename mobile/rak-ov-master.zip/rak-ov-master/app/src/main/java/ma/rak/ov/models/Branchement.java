package ma.rak.ov.models;

import io.realm.RealmObject;

public class Branchement extends RealmObject {

    private String CODEGERA;
    private String LIBEGERA;
    private String ANNDEMDE;
    private String NUMDEMDE;
    private String CATEDEVI;
    private String NOM;
    private String LIBCATDE;
    private String ADRESDEVI;
    private String DATSAIDE;
    private String STATDEVI;
    private String LIBSTADE;
    private String CODUTIEX;
    private String NOM_UTIL;
    private String LONGITUDE;
    private String LATITUDE;
    private String NUMOPEDE;


    public Branchement() {
    }

    public Branchement(String codegera, String libegera, String anndemde, String numdemde, String catedevi, String nom, String libcatde, String adresdevi, String datsaide, String statdevi, String libstade, String codutiex, String nom_util, String longitude, String latitude, String numopede) {
        CODEGERA = codegera;
        LIBEGERA = libegera;
        ANNDEMDE = anndemde;
        NUMDEMDE = numdemde;
        CATEDEVI = catedevi;
        NOM = nom;
        LIBCATDE = libcatde;
        ADRESDEVI = adresdevi;
        DATSAIDE = datsaide;
        STATDEVI = statdevi;
        LIBSTADE = libstade;
        CODUTIEX = codutiex;
        NOM_UTIL = nom_util;
        LONGITUDE = longitude;
        LATITUDE = latitude;
        NUMOPEDE = numopede;
    }

    public String getCODEGERA() {
        return CODEGERA;
    }

    public String getLIBEGERA() {
        return LIBEGERA;
    }

    public String getANNDEMDE() {
        return ANNDEMDE;
    }

    public String getNUMDEMDE() {
        return NUMDEMDE;
    }

    public String getCATEDEVI() {
        return CATEDEVI;
    }

    public String getNOM() {
        return NOM;
    }

    public String getLIBCATDE() {
        return LIBCATDE;
    }

    public String getADRESDEVI() {
        return ADRESDEVI;
    }

    public String getDATSAIDE() {
        return DATSAIDE;
    }

    public String getSTATDEVI() {
        return STATDEVI;
    }

    public String getLIBSTADE() {
        return LIBSTADE;
    }

    public String getCODUTIEX() {
        return CODUTIEX;
    }

    public String getNOM_UTIL() {
        return NOM_UTIL;
    }

    public String getLONGITUDE() {
        return LONGITUDE;
    }

    public String getLATITUDE() {
        return LATITUDE;
    }

    public void setCODEGERA(String CODEGERA) {
        this.CODEGERA = CODEGERA;
    }

    public void setLIBEGERA(String LIBEGERA) {
        this.LIBEGERA = LIBEGERA;
    }

    public void setANNDEMDE(String ANNDEMDE) {
        this.ANNDEMDE = ANNDEMDE;
    }

    public void setNUMDEMDE(String NUMDEMDE) {
        this.NUMDEMDE = NUMDEMDE;
    }

    public void setCATEDEVI(String CATEDEVI) {
        this.CATEDEVI = CATEDEVI;
    }

    public void setNOM(String NOM) {
        this.NOM = NOM;
    }

    public void setLIBCATDE(String LIBCATDE) {
        this.LIBCATDE = LIBCATDE;
    }

    public void setADRESDEVI(String ADRESDEVI) {
        this.ADRESDEVI = ADRESDEVI;
    }

    public void setDATSAIDE(String DATSAIDE) {
        this.DATSAIDE = DATSAIDE;
    }

    public void setSTATDEVI(String STATDEVI) {
        this.STATDEVI = STATDEVI;
    }

    public void setLIBSTADE(String LIBSTADE) {
        this.LIBSTADE = LIBSTADE;
    }

    public void setCODUTIEX(String CODUTIEX) {
        this.CODUTIEX = CODUTIEX;
    }

    public void setNOM_UTIL(String NOM_UTIL) {
        this.NOM_UTIL = NOM_UTIL;
    }

    public void setLONGITUDE(String LONGITUDE) {
        this.LONGITUDE = LONGITUDE;
    }

    public void setLATITUDE(String LATITUDE) {
        this.LATITUDE = LATITUDE;
    }

    @Override
    public String toString() {
        return "Branchement{" +
                "CODEGERA='" + CODEGERA + '\'' +
                ", LIBEGERA='" + LIBEGERA + '\'' +
                ", ANNDEMDE='" + ANNDEMDE + '\'' +
                ", NUMDEMDE='" + NUMDEMDE + '\'' +
                ", CATEDEVI='" + CATEDEVI + '\'' +
                ", NOM='" + NOM + '\'' +
                ", LIBCATDE='" + LIBCATDE + '\'' +
                ", ADRESDEVI='" + ADRESDEVI + '\'' +
                ", DATSAIDE='" + DATSAIDE + '\'' +
                ", STATDEVI='" + STATDEVI + '\'' +
                ", LIBSTADE='" + LIBSTADE + '\'' +
                ", CODUTIEX='" + CODUTIEX + '\'' +
                ", NOM_UTIL='" + NOM_UTIL + '\'' +
                ", LONGITUDE='" + LONGITUDE + '\'' +
                ", LATITUDE='" + LATITUDE + '\'' +
                ", NUMOPEDE='" + NUMOPEDE + '\'' +
                '}';
    }

    public String getNUMOPEDE() {
        return NUMOPEDE;
    }

    public void setNUMOPEDE(String NUMOPEDE) {
        this.NUMOPEDE = NUMOPEDE;
    }
}
