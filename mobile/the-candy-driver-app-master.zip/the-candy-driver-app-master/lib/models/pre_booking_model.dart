class PreBookingModel {
  String fareid;
  String totalfare;
  String newprebookingdate;
  String agentfees;
  String fleetfees;
  String adminfees;
  String prebookingfees;
  String gatewayfees;
  String driverfees;
  String bookingdate;
  String prebookingdate;
  String bookingid;
  String fullname;
  String mobile;
  String pickupaddress;
  String dropaddress;
  String remark;
  String booktype;
  String carcategory;
  String vehicletype;
  String categoryCode;
  String currency;
  String waitingTime;

  PreBookingModel(
      {this.fareid,
      this.totalfare,
      this.agentfees,
      this.fleetfees,
      this.newprebookingdate,
      this.adminfees,
      this.prebookingfees,
      this.gatewayfees,
      this.driverfees,
      this.bookingdate,
      this.prebookingdate,
      this.bookingid,
      this.fullname,
      this.mobile,
      this.pickupaddress,
      this.categoryCode,
      this.dropaddress,
      this.remark,
      this.waitingTime,
      this.currency,
      this.booktype,
      this.carcategory,
      this.vehicletype});

  PreBookingModel.fromJson(Map<String, dynamic> json) {
    fareid = json['fareid'];
    totalfare = json['totalfare'];
    agentfees = json['agentfees'];
    fleetfees = json['fleetfees'];
    newprebookingdate = json['newprebookingdate'];
    adminfees = json['adminfees'];
    prebookingfees = json['prebookingfees'];
    gatewayfees = json['gatewayfees'];
    driverfees = json['driverfees'];
    bookingdate = json['bookingdate'];
    prebookingdate = json['prebookingdate'];
    bookingid = json['bookingid'];
    fullname = json['fullname'];
    mobile = json['mobile'];
    pickupaddress = json['pickupaddress'];
    dropaddress = json['dropaddress'];
    remark = json['remark'];
    booktype = json['booktype'];
    carcategory = json['carcategory'];
    vehicletype = json['vehicletype'];
    categoryCode = json['category_code'];
    currency = json['currency'];
    waitingTime = json['waiting_time'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['fareid'] = this.fareid;
    data['totalfare'] = this.totalfare;
    data['agentfees'] = this.agentfees;
    data['fleetfees'] = this.fleetfees;
    data['adminfees'] = this.adminfees;
    data['prebookingdate'] = this.prebookingdate;
    data['prebookingfees'] = this.prebookingfees;
    data['gatewayfees'] = this.gatewayfees;
    data['driverfees'] = this.driverfees;
    data['bookingdate'] = this.bookingdate;
    data['prebookingdate'] = this.prebookingdate;
    data['bookingid'] = this.bookingid;
    data['fullname'] = this.fullname;
    data['mobile'] = this.mobile;
    data['pickupaddress'] = this.pickupaddress;
    data['dropaddress'] = this.dropaddress;
    data['remark'] = this.remark;
    data['booktype'] = this.booktype;
    data['carcategory'] = this.carcategory;
    data['vehicletype'] = this.vehicletype;
    data['category_code'] = this.categoryCode;
    data['currency'] = this.currency;
    data['waiting_time'] = this.waitingTime;
    return data;
  }
}
