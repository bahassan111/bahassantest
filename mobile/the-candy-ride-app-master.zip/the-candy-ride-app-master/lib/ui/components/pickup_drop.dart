import 'package:flutter/material.dart';
import 'package:flutter_dash/flutter_dash.dart';
import 'package:rider_app/constants/app_themes.dart';
import 'package:get/get.dart';
import 'package:rider_app/models/models.dart';
import 'package:rider_app/ui/components/components.dart';

class PickUpDrop extends StatefulWidget {
  PickUpDrop(
      {this.dropAtController,
      this.pickUpController,
      this.prebook,
      this.onPickUpSuggestionSelected,
      this.onDropAtSuggestionSelected,
      this.pickUpFocusNode});

  final TextEditingController pickUpController;
  final TextEditingController dropAtController;
  final FocusNode pickUpFocusNode;
  final Function prebook;
  final Function(Features) onPickUpSuggestionSelected;
  final Function(Features) onDropAtSuggestionSelected;

  @override
  _PickUpDropState createState() => _PickUpDropState();
}

class _PickUpDropState extends State<PickUpDrop> {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(left: 20, top: 20, right: 20),
      padding: EdgeInsets.only(left: 20, top: 20, right: 20),
      decoration: BoxDecoration(
          color: AppThemes.lightWhitebackGroundColor,
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: AppThemes.shadowColor.withOpacity(0.2),
              blurRadius: 15,
              spreadRadius: 1,
            ),
          ]),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              SizedBox(height: 8),
              Container(
                height: 10,
                width: 10,
                decoration: BoxDecoration(
                  color: AppThemes.lightPinkBackGroundColor,
                  shape: BoxShape.circle,
                ),
              ),
              SizedBox(height: 8),
              Dash(
                direction: Axis.vertical,
                length: 55,
                dashLength: 5,
                dashGap: 6,
                dashColor: AppThemes.lightCircularDividerColor,
                dashBorderRadius: 4,
                dashThickness: 5,
              ),
              SizedBox(height: 8),
              Container(
                height: 10,
                width: 10,
                decoration: BoxDecoration(
                  color: AppThemes.lightGreenbackGroundColor,
                  shape: BoxShape.circle,
                ),
              )
            ],
          ),
          SizedBox(
            width: 20,
          ),
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "pickupFrom".tr,
                  style: Theme.of(context)
                      .textTheme
                      .subtitle2
                      .copyWith(fontSize: 13, fontWeight: FontWeight.w500),
                ),
                SizedBox(height: 5),
                GestureDetector(
                  child: Container(
                    decoration: BoxDecoration(
                        border: Border(
                      bottom: BorderSide(color: AppThemes.lightBorderColor),
                    )),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            widget.pickUpController.text.trim(),
                            maxLines: 1,
                            style:
                                Theme.of(context).textTheme.headline2.copyWith(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w700,
                                      height: 1,
                                    ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (context) => PickUpDropInputBox(
                        focusNode: widget.pickUpFocusNode,
                        controller: widget.pickUpController,
                        onSuggestionSelected: widget.onPickUpSuggestionSelected,
                        iconSuffix: GestureDetector(
                          onTap: () {
                            widget.pickUpController.clear();
                          },
                          child: Icon(Icons.close),
                        ),
                      ),
                    );
                  },
                ),
                SizedBox(height: 10),
                IntrinsicHeight(
                  child: Row(
                    children: [
                      Expanded(
                        child: GestureDetector(
                          onTap: () {
                            showDialog(
                                context: context,
                                builder: (context) => PickUpDropInputBox(
                                      controller: widget.dropAtController,
                                      onSuggestionSelected:
                                          widget.onDropAtSuggestionSelected,
                                      iconSuffix: GestureDetector(
                                        onTap: () {
                                          widget.dropAtController.clear();
                                        },
                                        child: Icon(Icons.close),
                                      ),
                                    ));
                          },
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(height: 10),
                              Text(
                                "dropAt".tr,
                                style: Theme.of(context)
                                    .textTheme
                                    .subtitle2
                                    .copyWith(
                                        fontSize: 13,
                                        fontWeight: FontWeight.w500),
                              ),
                              SizedBox(height: 5),
                              Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                        bottom: BorderSide(
                                            color:
                                                AppThemes.lightBorderColor))),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        widget.dropAtController.text.trim(),
                                        maxLines: 1,
                                        style: Theme.of(context)
                                            .textTheme
                                            .headline2
                                            .copyWith(
                                              fontSize: 16,
                                              fontWeight: FontWeight.w700,
                                              height: 1,
                                            ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: 15),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      decoration: BoxDecoration(
                          color: Color(0xff0B0158),
                          borderRadius: BorderRadius.all(Radius.circular(10))),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            GestureDetector(
                              onTap: widget.prebook,
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                children: [
                                  Icon(
                                    Icons.calendar_today,
                                    size: 20,
                                    color: Colors.white,
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Text(
                                    "prebook".tr,
                                    style: Theme.of(context)
                                        .textTheme
                                        .headline2
                                        .copyWith(
                                          color: Colors.white,
                                          fontSize: 16,
                                          fontWeight: FontWeight.w700,
                                          height: 1,
                                        ),
                                  )
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 20,
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
