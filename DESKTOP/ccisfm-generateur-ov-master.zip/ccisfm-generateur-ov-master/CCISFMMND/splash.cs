﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CCISFMMND
{
    public partial class splash : Form
    {
        public splash()
        {
            InitializeComponent();
        }

        private void splash_Load(object sender, EventArgs e)
        {
            this.Top = Screen.GetWorkingArea(this).Height - Height;
            this.Left = (Screen.GetWorkingArea(this).Width / 2) - this.Width;


            
        }

        private void splash_Shown(object sender, EventArgs e)
        {
            Task t = new Task(() =>
            {

                Invoke(new MethodInvoker(() =>
                {
                    MainNew m = new MainNew();
                    m.Show();
                    Hide();
                }));
            });

            t.Wait(1000);
            t.Start();
        }
    }
}
