import React, { Component } from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    ImageBackground,
    ActivityIndicator,
} from "react-native";
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {updateData} from "../redux/actions/dataAction";
import TopHeader from "../componants/TopHeader";

class blankScreen extends Component {

    state = {

    };


    componentDidMount() {
    }

    menuClick = () => {
        const {navigation} = this.props;


    };

    userClick = () => {
        const {navigation} = this.props;

    };

    render() {
        return (

            <View style={styles.whole}>
                <ImageBackground source={require('../assets/bg_deco.png')} style={styles.bg}>
                    <TopHeader semi_transparent={true} floatable={this.state.map} title={''} onMenu={this.menuClick} onUser={this.userClick}/>
                </ImageBackground>

            </View>

        );
    }

}

const styles = StyleSheet.create({
    bg:{
        flex:1,
        resizeMode: "center",
        justifyContent: "center"
    },
    whole: {
        display:'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height:'100%',
        backgroundColor: '#fff',
    },

});

const mapDispatchToProps = dispatch => (
    bindActionCreators({
        updateData: updateData,
    }, dispatch)
);

const mapStateToProps = (state) => {
    const { data } = state;
    return { data }
};

export default connect(mapStateToProps, mapDispatchToProps)(blankScreen);
