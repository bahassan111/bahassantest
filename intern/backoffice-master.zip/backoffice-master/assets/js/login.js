(function () {

    var view = $('#login');

    if(!view.length) return;

    $(document)
        .ready(function () {
            endLoader();
        })

        .on('click', '.lgf_error > i', function () {
            $(this).closest('.lgf_error_holder').fadeOut(function () {
                $(this).remove();
            })
        })

        .on('submit', 'form', function (e) {
            e.preventDefault();
            var form = $(this),
                btn = form.find('button[type="submit"]'),
                email = form.find('#login_email'),
                password = form.find('#login_password')
            ;

            hideErrors(form);

            form.find('input, button').prop('disabled', true);


            btn.html('Login in ..');

            if(email.val() && password.val()){

                $.post(ifes.url + '/?c=login&page=login', {
                    ajax : true,
                    email : email.val(),
                    password : password.val(),
                }, (rep)=>{

                    if(rep.status === 'OK'){

                        startLoader("Please wait while we redirect you.");
                        window.location.href = ifes.url;



                    }else{
                        showError(rep.message || 'The login informations you have provided are invalid.', form);
                    }

                })
                    .always(()=>{
                        btn.html('Log in <i class="fa fa-angle-right"></i>');
                        form.find('input, button').prop('disabled', false);
                    })
                    .fail(()=>{
                        showError('Unable to connect to the server, try again later.', form);
                    })


            }else{
                showError('Please type your email and password to continue.', form);
            }

        })
    ;


    function endLoader() {
        $('.loading').fadeOut(function () {
            $(this).remove();
        })
    }

    function startLoader(txt) {
        txt = txt || 'Loading ..';

        $('body').append(`<div class="loading"><div class="loader"><span><i></i></span> <b>${txt}</b></div></div>`)
    }

    function showError(msg, container) {
        container = $(container || view);

        container.append('<div class="lgf_error_holder"><div class="lgf_error"><i class="fas fa-times"></i> <p>'+msg+'</p></div></div>');
    }

    function hideErrors(container) {
        container = $(container || view);
        container.find('.lgf_error_holder').remove();
    }
})();