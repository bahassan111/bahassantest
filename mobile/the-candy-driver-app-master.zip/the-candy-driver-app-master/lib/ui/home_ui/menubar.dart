import 'package:driver/constants/images.dart';
import 'package:flutter/material.dart';

class MenuBar extends StatefulWidget {
  final Function updateMenuPosition;
  final bool isMenuShow;
  const MenuBar({
    Key key,
    this.updateMenuPosition,
    this.isMenuShow,
  }) : super(key: key);

  @override
  _MenuBarState createState() => _MenuBarState();
}

class _MenuBarState extends State<MenuBar> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 25, vertical: 25),
        child: GestureDetector(
          onTap: widget.updateMenuPosition,
          child: Image.asset(
            AllImages.menu,
            height: 20,
            width: 20,
            color: Colors.black,
          ),
        ),
      ),
    );
  }
}
