import 'package:bot_toast/bot_toast.dart';
import 'package:driver/constants/constants.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:driver/ui/components/components.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'finish_trip_detail.dart';

class PaymentMode extends StatefulWidget {
  const PaymentMode({Key key}) : super(key: key);

  @override
  _PaymentModeState createState() => _PaymentModeState();
}

class _PaymentModeState extends State<PaymentMode> {
  HomeController to = Get.find();
  bool isCash = false;
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black12.withOpacity(0.5),
      child: Center(
        child: Container(
          //color: Colors.red,
          margin: EdgeInsets.symmetric(horizontal: 20),
          child: Material(
            color: Colors.transparent,
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(color: Colors.black, width: 4),
                borderRadius: BorderRadius.circular(10),
                color: Colors.white,
              ),
              child: Container(
                margin: EdgeInsets.all(5),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black, width: 1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Center(
                        child: Text(
                          "choose_your_payment_mode".tr,
                          style:
                              AppThemes.lightTheme.textTheme.subtitle1.copyWith(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          Radio(
                            value: true,
                            groupValue: isCash,
                            onChanged: (value) {
                              setState(() {
                                isCash = value;
                              });
                            },
                          ),
                          Text(
                            "cash/pilot_pay".tr,
                            style: AppThemes.lightTheme.textTheme.headline1
                                .copyWith(
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Container(
                        width: 120,
                        child: RoundButton(
                          text: "pay".tr,
                          verticalPadding: 10,
                          onTap: () async {
                            try {
                              if (isCash) {
                                BotToast?.cleanAll();
                                await to.driverRideDetail();
                                BotToast.showWidget(
                                  toastBuilder: (ctx) {
                                    return FinishTripDetail();
                                  },
                                );
                              }
                            } catch (e) {}
                          },
                          backgroundColor:
                              AppThemes.lightdeepPinkDropDownIconColor,
                          textStyle: AppThemes.lightTheme.textTheme.headline6
                              .copyWith(
                                  fontWeight: FontWeight.bold, fontSize: 15),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
