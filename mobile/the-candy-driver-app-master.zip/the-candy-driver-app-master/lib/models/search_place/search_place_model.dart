import 'package:driver/models/models.dart';

class SearchPlaceModel {
  String type;
  List<String> query;
  List<Features> features;
  String attribution;

  SearchPlaceModel({this.type, this.query, this.features, this.attribution});

  SearchPlaceModel.fromJson(Map<String, dynamic> json) {
    type = json['type'];
    query = json['query'].cast<String>();
    if (json['features'] != null) {
      features = [];
      json['features'].forEach((v) {
        features.add(new Features.fromJson(v));
      });
    }
    attribution = json['attribution'];
  }
}
