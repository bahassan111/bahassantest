import React, { Component,useRef, useEffect } from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    ImageBackground,
    ActivityIndicator,
    Button,
    TouchableOpacity,
    Animated, Dimensions
} from "react-native";

import { connect } from 'react-redux';
import i18n from 'i18n-js';
import {AntDesign, Entypo, FontAwesome5, Ionicons} from "@expo/vector-icons";
import { StatusBar } from 'expo-status-bar';

const win = Dimensions.get('screen');
const ofHeight = (p)=> p * win.height / 100;
const ofWidth = (p)=> p * win.width / 100;



function SliderIndicator(props) {

    const anim = new Animated.Value(0);
    const wAnim = useRef(anim).current;
    const pr = Animated.timing(
        wAnim,
        {
            toValue: ofWidth(100),
            duration: props.duration || 3000,
            useNativeDriver:false,
        }
    );

    React.useEffect(() => {pr.start(()=>{
            (props.onEnd || function(){})(anim, pr);
        });
    }, [wAnim]);

    return (
        <Animated.View style={[styles.timer]}>
            <Animated.View style={[styles.timer_inner, {width: wAnim}]}/>
        </Animated.View>
    )
}

const styles = StyleSheet.create({
    timer : {
        position:'absolute',
        left : 0,
        top:0,
        width: ofWidth(100),
        height: ofHeight(0.3),
        backgroundColor: 'transparent',
        zIndex: 999,
    },
    timer_inner : {
        height: '100%',
        width: '30%',
        backgroundColor: '#fff'
    },
});


const mapStateToProps = (state) => {
    const { data } = state;
    return { data }
};

export default connect(mapStateToProps)(SliderIndicator);
