import React, { Component } from "react";
import { View, Button, Text, Constants, Image,TextInput,TouchableOpacity } from "react-native-ui-lib";
import {
    Alert,
    Dimensions,
    ImageBackground,
    ScrollView,
    StyleSheet,
    TouchableHighlight,
    ListItem,
    FlatList,
    ActivityIndicator
} from "react-native";
import { NavigationActions, StackActions } from "react-navigation";

import { Google } from "expo-google-app-auth";
import {Audio, Video} from "expo-av";
import VideoPlayer from "@expo/videoplayer";
import {AsyncStorage} from 'react-native';

import {
    fetchFontSize,
    changeFont,
    changeLanguage,
    editLanguageFr,
    editLanguageAr,
} from "../Redux/actions/FontSizeActions";

import { fetchArticleDetails, saveInfo } from "../Redux/actions/ChapitresActions";
import { fetchBanners } from "../Redux/actions/BannersActions";

import { connect } from "react-redux";
import I18n from "../commons/i18n";

import Config from "../constants/Config";
import Colors from "../constants/Colors";
import Icon from "../constants/Icons";
import {CHANGE_LANG_SUCCESS} from "../Redux/actions/types";
import * as Facebook from 'expo-facebook';
import { SocialIcon } from 'react-native-elements'

class ScreenCountries extends Component {
    constructor(props) {
        super(props);
        this._isMounted = true;
    }
    static navigationOptions = ({ navigation }) => ({
        header: null
    });

    state = {
        itemsCount: this.props.fontSizeValue.fontSize,
        shouldPlay: false,
        data: [],
        result: null,
        userID:'',
        userName:'',
        userEmail:'',
        userImage:'',
        fetchDataCountries:[],
        isLoadingCountries:true,
        lang_index:'',
        id_lang:'',
    };
    componentDidMount() {
        AsyncStorage.multiGet(['id', 'name','email', 'image','lang','id_country']).then((data) => {
            let id = data[0][1];
            let name = data[1][1];
            let email = data[2][1];
            let image = data[3][1];
            let lang=data[4][1];
            let id_country=data[5][1];

            if(id_country)
                this.redirect_Tolang();

            this.setState({ userID: id, userName: name,userEmail: email,userImage: image });
            console.log(this.state.userID + ' ' + this.state.userEmail,'ha detailss');
            Audio.setAudioModeAsync({
                allowsRecordingIOS: false,
                interruptionModeIOS: Audio.INTERRUPTION_MODE_IOS_DO_NOT_MIX,
                playsInSilentModeIOS: true,
                shouldDuckAndroid: true,
                interruptionModeAndroid: Audio.INTERRUPTION_MODE_ANDROID_DO_NOT_MIX,
                playThroughEarpieceAndroid: false
            });
            this.props.fetchFontSize();

            this.fetchCountries();

        });

    }
    componentDidUpdate(nextProps) {
        if (nextProps.hasIntro !== this.props.hasIntro) {
            if (this.props.hasIntro == 500) {
                // this.resetStack();
            }
        }
    }

    resetStack = async () => {

        let  user_id=this.state.userID;
        await fetch(
            Config.API_URL+"includes/encode/index.php", {
                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    post: 'save_langueUser',
                    user_id: user_id,
                    lang: 'ar',

                }),
            }
        )
            .then(res => res.json())
            .then(responseJson => {

                if(responseJson.lang){
                    AsyncStorage.multiSet([
                        ["lang", responseJson.lang]
                    ]);

                }
            })
            .catch(error => {
                console.log("error save Save Lang ", error);
            });
        this.props.fetchArticleDetails('ar');
        this.props.fetchBanners();

        this.props.changeFont(this.props.fontSizeValue.fontSize, 500);
        this.props.navigation.dispatch(
            StackActions.reset({
                index: 0,
                key: null,
                actions: [
                    NavigationActions.navigate({
                        routeName: "Main",
                    })
                ]
            })
        );

        this.props.fetchFontSize('ar');
        this.props.editLanguageAr();

    };
    resetStackFr = async () => {

        let  user_id=this.state.userID;
        await fetch(
            Config.API_URL+"includes/encode/index.php", {
                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    post: 'save_langueUser',
                    user_id: user_id,
                    lang: 'fr',

                }),
            }
        )
            .then(res => res.json())
            .then(responseJson => {

                if(responseJson.lang){
                    AsyncStorage.multiSet([
                        ["lang", responseJson.lang]
                    ]);

                }
            })
            .catch(error => {
                console.log("error save Save Lang ", error);
            });

        this.props.fetchArticleDetails('fr');
        this.props.fetchBanners();

        this.props.changeFont(this.props.fontSizeValue.fontSize, 500);
        this.props.navigation.dispatch(
            StackActions.reset({
                index: 0,
                key: null,
                actions: [
                    NavigationActions.navigate({
                        routeName: "Main",
                    }),
                ]
            })
        );

        this.props.fetchFontSize('fr');
        this.props.editLanguageFr();
    };




    check_langUser= async (user_id) => {

        await fetch(
            Config.API_URL+"includes/encode/index.php",{
                method: 'post',
                body:  JSON.stringify({
                    post: 'check_langue',
                    user_id: user_id

                }),

                headers: {
                    'Accept': 'application/json',
                    'content-type': 'multipart/form-data',
                },
            }
        )
            .then(res => res.json())
            .then(responseJson => {

                console.log('lang iss',responseJson);
                AsyncStorage.multiSet([
                    ["lang", responseJson.lang]

                ]);

                if(responseJson.lang==='fr' || responseJson.lang==='ar')
                    this.redirect_Tolang(responseJson.lang);


            })
            .catch(error => {

            });
    };

    redirect_Tolang = async() => {

            let id_country= await AsyncStorage.getItem('id_country');
            let id_lang=await AsyncStorage.getItem('id_lang');
            let lang_index=await AsyncStorage.getItem('lang_index');
            let lang_index2=await AsyncStorage.getItem('lang_index2');
            let lang=await AsyncStorage.getItem('lang');
            let rtl=await AsyncStorage.getItem('rtl');


            this.props.fetchArticleDetails(id_country,lang_index);
            this.props.fetchBanners();
            this.props.changeFont(this.props.fontSizeValue.fontSize, 500);
            this.props.navigation.dispatch(
                StackActions.reset({
                    index: 0,
                    key: null,
                    actions: [
                        NavigationActions.navigate({
                            routeName: "Main",
                        }),
                    ]
                })
            );
            this.props.fetchFontSize(lang,id);

        if(rtl===1)
            this.props.editLanguageAr();
        else
            this.props.editLanguageFr();
    };

    fetchCountries(){

        fetch(
            "http://ifes-esll.com/new/api/includes/encode/index.php/?get=fetchCountries"
        )
            .then(res => res.json())
            .then(responseJson => {
                console.log('fetchCountries',responseJson);

                this.setState({
                    fetchDataCountries:responseJson.countries,
                    isLoadingCountries:false
                });

            })
            .catch(error => {
                console.log("error", error);
            });
    }
    async chooseCountry(id_country){

        fetch(
            "http://ifes-esll.com/new/api/includes/encode/index.php",{
                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    post: 'addCountry',
                    user_id: this.state.userID,
                    id_country: id_country,
                }),
            }
        )
            .then(res => res.json())
            .then(responseJson => {

                AsyncStorage.setItem("id_country", id_country);
                AsyncStorage.setItem("id_lang", responseJson.id_lang);
                AsyncStorage.setItem("lang_index", responseJson.lang_index);
                AsyncStorage.setItem("rtl", responseJson.rtl);
                AsyncStorage.setItem("lang", responseJson.lang2);
                AsyncStorage.setItem("lang_index2", responseJson.lang_index2);
                AsyncStorage.setItem("rtl2", responseJson.rtl2);
                AsyncStorage.setItem("lang2", responseJson.lang);
                AsyncStorage.setItem("fields", responseJson.fields);
                AsyncStorage.setItem("see_more", responseJson.see_more);
                AsyncStorage.setItem("search", responseJson.search);
                AsyncStorage.setItem("see_less", responseJson.see_less);
                AsyncStorage.setItem("homeScreen", responseJson.homeScreen);
                AsyncStorage.setItem("settingScreen", responseJson.settingScreen);
                AsyncStorage.setItem("countries", responseJson.countries);
                AsyncStorage.setItem("count_languages", responseJson.count_languages);
                AsyncStorage.setItem("name_country", responseJson.name_country);
                AsyncStorage.setItem("iso_country", responseJson.iso_country);
                AsyncStorage.setItem("change_country", responseJson.change_country);

                this.redirect_Tolang();
            })
            .catch(error => {
                console.log("error", error);
            });
    }
    render() {

        return (

            <View
                style={styles.container}

            >
                <ScrollView

                    ref={ref => {this.scrollview_ref = ref; }}
                >

                <Text style={{fontWeight: "bold",fontSize:16}} center>Choose your country</Text>

                {this.state.isLoadingCountries ? <ActivityIndicator size="large" color="#0000ff" style={{ flex: 1,
                    justifyContent: 'center',
                    alignItems: 'center',
                    paddingVertical:20,
                }} /> : null}


                <View style={styles.root}>
                    {
                        this.state.fetchDataCountries ?
                            this.state.fetchDataCountries.map((data) => {

                              return (
                                  <TouchableOpacity style={styles.Card_Container}
                                                    onPress={() => {
                                                        this.chooseCountry(data.id) }}
                                  >

                                      <Image style={styles.image_countries} source={{uri: Config.IMAGE+'images/flags/'+data.iso+'.png'}}/>

                                      <Text style={styles.title}> {data.name}</Text>


                                  </TouchableOpacity>
                              );

                            })
                            : null
                    }
                </View>

                </ScrollView>



            </View>
        );
    }
}

const mapStateToProps = state => {
    const fontSizeValue = state.fontSize;
    const hasIntro = state.fontSize.hasIntro;
    const lang = state.fontSize.lang;

    const data = state.searchAll.data;
    const isLoadingData = state.searchAll.isLoadingData;

    return {
        lang,
        fontSizeValue,
        hasIntro,
        isLoadingData,
        data,
    };
};


const colors = {
    bg : '#f2f2f2',
    bg_darker : '#ececec',
    white : '#fff',
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent : 'center',
        paddingTop:40,

        backgroundColor: '#f2f2f2',

    },

    inner_countries:{
        paddingLeft: 2,
        paddingRight: 10,
        paddingVertical: 12,
        flexDirection: 'row',
        alignItems: 'flex-start'
    },
    image_countries:{
        width:20,
        height:20,
        borderRadius:20,

    },
    contentHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 6,
        marginLeft:10
    },
    icon_right:{
        fontSize:11,
        color:"#808080",
        alignItems: 'flex-end',

    },
    name:{
        fontSize:12,
        fontWeight:"bold",
    },
    root: {

        paddingTop:10,
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'row',
        flexWrap: 'wrap',
        flex:1,
        width:'100%'

    },


    Card_Container: {

        backgroundColor:'#fff',
        padding: 15,
        margin: 1.4,
        borderRadius: 4,
        borderWidth: 1,
        borderColor: '#96a4ab',
        width:110,
        height:110,
        alignItems: 'center',
        justifyContent: 'center',
        marginTop:15,
        marginRight:2,
        elevation:4
    },

    title: {
        fontSize: 15,
        fontWeight: 'bold',
        color:"#000",
        marginTop: 8
    },

});

export default connect(
    mapStateToProps,
    {
        fetchFontSize,
        changeLanguage,
        editLanguageAr,
        editLanguageFr,
        fetchBanners,
        changeFont,
        fetchArticleDetails,
        saveInfo
    }
)(ScreenCountries);
