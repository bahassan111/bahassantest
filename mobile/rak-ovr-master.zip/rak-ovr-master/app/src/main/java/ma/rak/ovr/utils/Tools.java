package ma.rak.ovr.utils;

import android.app.Activity;

import java.text.DecimalFormat;

import io.realm.Realm;
import io.realm.RealmResults;
import io.realm.Sort;
import ma.rak.ovr.R;
import ma.rak.ovr.models.PendingAffectation;
import ma.rak.ovr.models.PendingOperation;
import ma.rak.ovr.storage.SharedPrefManager;
import ma.rak.ovr.ui.main.DropDownAlert;

public class Tools {

    static Realm realm = null;
    static DropDownAlert downAlertNoImage;
    static int nbrOperation, nbrAffectation, total = 0;
    static String messageResponse = "";
    static String messageType = "";

    static boolean error = false;


    public static String getFileSize(long size) {
        if (size <= 0)
            return "0";
        final String[] units = new String[]{"B", "KB", "MB", "GB", "TB"};
        int digitGroups = (int) (Math.log10(size) / Math.log10(1024));
        return new DecimalFormat("#,##0.#").format(size / Math.pow(1024, digitGroups)) + " " + units[digitGroups];
    }

    public static void synchronizeRealmData(Activity activity) {
        downAlertNoImage = new DropDownAlert(activity, activity.getWindow().getContext(), false);

        realm = Realm.getDefaultInstance();
        String token = SharedPrefManager.getInstance(activity).getToken();
        RealmResults<PendingOperation> pendingOperation = realm.where(PendingOperation.class).sort("date", Sort.ASCENDING).findAll();
        RealmResults<PendingAffectation> pendingAffectations = realm.where(PendingAffectation.class).sort("date", Sort.ASCENDING).findAll();

        total = pendingOperation.size() + pendingAffectations.size();

        for (PendingOperation obj : pendingOperation) {
            /*Call<OperationResponse> call = RetrofitClient.getApi(token).executer(*//*"XDEBUG_SESSION=XDEBUG_ECLIPSE",*//* obj.getStatus(), obj.getObservation(), obj.getDate(), obj.getNature_install(), obj.getEmplacement(), obj.getEtage(), obj.getDoss_annee(), obj.getDoss_numm(), obj.getNum_operation(), obj.getGerance(), obj.getNature_lot(), "0",obj.getMotif(), obj.getPhoto());
            call.enqueue(new Callback<OperationResponse>() {
                @Override
                public void onResponse(Call<OperationResponse> call, Response<OperationResponse> response) {
                    if (response.code() == 200) {
                        messageResponse = response.body().getMsg();
                        messageType = activity.getString(R.string.dropdown_info);
                        nbrOperation = nbrOperation + 1;
                        error = true;
                        realm.executeTransaction(realm -> {
                            if (obj != null && !realm.isClosed()) {
                                obj.deleteFromRealm();
//                                    pendingOperation.deleteFromRealm(i);
                            }
                        });
                    }

                    if (response.code() == 500) {
                        messageResponse = response.body().getMsg();
                        messageType = activity.getString(R.string.dropdown_error);
                        error = true;
                    }
                }

                @Override
                public void onFailure(Call<OperationResponse> call, Throwable t) {
                    messageResponse = t.getMessage();
                    messageType = activity.getString(R.string.dropdown_error);
                    error = true;
                }

            });*/
        }

       /* for (PendingAffectation obj : pendingAffectations) {
            Call<OperationResponse> call = RetrofitClient.getApi(token).reaffecter(obj.getCurrentAgent(), obj.getNewAgent(), obj.getGerance(), obj.getDate());
            call.enqueue(new Callback<OperationResponse>() {
                @Override
                public void onResponse(Call<OperationResponse> call, Response<OperationResponse> response) {
                    if (response.code() == 200) {
                        messageResponse = response.body().getMsg();
                        messageType = activity.getString(R.string.dropdown_info);
                        nbrAffectation = nbrAffectation + 1;
                        error = false;
                        realm.executeTransaction(realm -> {
                            if (obj != null && !realm.isClosed()) {
                                obj.deleteFromRealm();
//                                    pendingOperation.deleteFromRealm(i);
                            }
                        });
                    }

                    if (response.code() == 500) {
                        messageResponse = response.body().getMsg();
                        messageType = activity.getString(R.string.dropdown_error);
                        error = true;
                    }
                }

                @Override
                public void onFailure(Call<OperationResponse> call, Throwable t) {
                    messageResponse = t.getMessage();
                    messageType = activity.getString(R.string.dropdown_error);
                    error = true;
                }
            });
        }*/


        if (error == true) {
            downAlertNoImage.setContent("Les modifications que vous avez apportées ne seront peut-être pas enregistrées  ");
            downAlertNoImage.setTitle(activity.getString(R.string.dropdown_error));
        } else {
            if (total > 0) {
                downAlertNoImage.setContent(total + " ligne(s) d'opération(s) synchroniser");
            } else {
                downAlertNoImage.setContent("Aucune données a synchroniser");
            }
            downAlertNoImage.setTitle(activity.getString(R.string.dropdown_info));
            error = false;
        }

        downAlertNoImage.show();

    }
}

