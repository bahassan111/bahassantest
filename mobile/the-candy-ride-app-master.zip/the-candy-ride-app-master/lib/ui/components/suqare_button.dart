import 'package:flutter/material.dart';
import 'package:rider_app/constants/app_themes.dart';

class SquareButton extends StatelessWidget {
  final String text;
  final Function onTap;
  final Color buttonColor;
  SquareButton(
      {this.text,
      this.onTap,
      this.buttonColor = AppThemes.lightpauaBackGroundColor});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 10),
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
          color: buttonColor,
        ),
        child: Center(
          child: Text(
            text,
            style: Theme.of(context).textTheme.subtitle1.copyWith(
                color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700),
          ),
        ),
      ),
    );
  }
}
