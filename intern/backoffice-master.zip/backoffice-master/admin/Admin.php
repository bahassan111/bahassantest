<?php

class Admin{

    public $db;
    public $lang;
    public function __construct()
    {
        $this->db = new Database(config()->db_host, config()->db_user, config()->db_password, config()->db_name, config()->port);
        $this->lang = currentLanguage();
        if(!isConnected()){
            header("Location: ?c=login&page=login");
        }
    }

    public function upload_file($video){

        $date = date('Y-m-d H:i:s');
        $name_file = time().'_'.mt_rand(0,999999);
        $file = __($_FILES)->first();
        $rep = (object)['status' => 'NO'];

        if($file){
            $destination = "../uploads";
            $check = move_uploaded_file($file['temp_name'], $destination);

            if($check){
                $rep->status = 'OK';
            }
        }


        responseJSON($rep);
    }

    function doDatatable($query, $callback = null)
    {
        $callback = $callback ?: function () {};
        $input = __($_GET);
        $length = $input->length ?: 10;
        $page = ($input->start ?: 0) * $length;
        $order = $input->columns[intval($input->order[0]['column'])]['name'];
        $dir = $input->order[0]['dir'];
        $search = $input->search['value'] ?: '';
        $sfilter = '';
        foreach ($input->columns as $col) {
            $col = (object)$col;
            if ($col->searchable === "false") continue;
            $sfilter .= ($sfilter ? ' OR ' : ' ') . "{$col->name} like '%$search%' ";
        }
        $query_str = "SELECT * FROM ($query) t WHERE 1=1 AND $sfilter";
        $query = $this->db->query($query_str . " ORDER BY $order $dir LIMIT $page, $length");
        $total = $this->db->query("SELECT COUNT(*) total FROM ($query_str) t");
        $total = $total ? $total[0]->total : 0;
        foreach ($query as $i => $row) {

            $callback($i, $row, $query);

        }

        $return = array(
            'draw' => $input->draw ?: 0,
            'recordsTotal' => $total,
            'recordsFiltered' => $total,
            'data' => $query,
        );
        return ((object)$return);

    }

    public function dashboard(){

        $data = [
            'title' => 'Tableau de bord',
            'page' => 'dashboard',
        ];

        load_view('dashboard', $data);
    }

    public function regions(){
        $data = [
            'title' => 'Les régions',
            'page' => 'regions',
            'countries' => $this->db->query("SELECT * FROM regions WHERE deleted = 0")
        ];

        load_view('regions', $data);
    }

    public function add_region(){
        $get = __($_GET);
        $one=$this->db->get('regions',array('id'=>$get->id));
        $data = [
            'title' => 'Ajouter région',
            'page' => 'add_region',
            'one' => count($one) > 0 ? $one[0] : null ,
        ];
        load_view('add_region', $data,false);
    }

    public function save_region()
    {
        $rep = (object)['status' => 'NO', 'message' => "Veuillez vérifier les informations"];
        $data = (object)$_POST;
        $edit = !!__($_POST)->id;

        $query = $edit ? $this->db->update('regions', $data, ['id' => $data->id]) : $this->db->insert('regions', $data);
        if ($query) {
            $rep->status = 'OK';
        } else {
            $rep->message = mysqli_error($this->db->get_context()) ?: "Impossible d'enregistrer les données";
        }
        responseJSON($rep);
    }

    public function dt_regions(){

        $get = __($_GET);

        $result = $this->doDatatable("SELECT * FROM regions WHERE deleted = 0", function($i, $row){
            $row->action = "<div class='button-group'>" .
                "<button type='button' class='button primary'>Actions <i class='fas fa-caret-down'></i></button><div>" .
                "<a href='javascript:void(0)' class='edit_region' data-edit='".$row->id."'><i class='fas fa-edit'></i> Modifier</a>" .
                "<a href='javascript:void(0)' class='delete_region' data-delete='".$row->id."'><i class='far fa-trash-alt'></i> Supprimer</a>" .
                "</div></div>";

        });

        responseJSON($result);
    }

    public function delete_region(){
        $id = __($_POST)->id;
        $rep = (object)['status' => 'NO', 'message' => "Sélectionnez les données à supprimer"];
        $query = null;

        if($id){
            $query = $this->db->update('regions', ['deleted' => 1], ['id' => $id]);
        }

        $rep->status = $query ? 'OK' : 'ERROR';
        $rep->message = $query ? "Data deleted successfully" : "Impossible de supprimer cet élément";

        responseJSON($rep);
    }



    public function files(){
        $data = [
            'title' => 'Les fichiers',
            'page' => 'files',
            'countries' => $this->db->query("SELECT * FROM files WHERE deleted = 0")
        ];

        load_view('files', $data);
    }

    public function add_file(){
        $get = __($_GET);
        $one=$this->db->get('files',array('id'=>$get->id));
        $cats_fr = $this->db->query("SELECT cat as name FROM files WHERE deleted = 0 AND lang = 'fr' GROUP BY cat");
        $cats_ar = $this->db->query("SELECT cat as name FROM files WHERE deleted = 0 AND lang = 'ar' GROUP BY cat");
        $data = [
            'title' => 'Ajouter fichier',
            'page' => 'add_file',
            'one' => count($one) > 0 ? $one[0] : null ,
            'cats_fr' => $cats_fr,
            'cats_ar' => $cats_ar,
        ];
        load_view('add_file', $data,false);
    }

    public function save_file()
    {
        $rep = (object)['status' => 'NO', 'message' => "Veuillez vérifier les informations"];
        $data = (object)$_POST;
        $edit = !!__($_POST)->id;

        $doup = isset($_FILES['file']) && $_FILES['file']['name'];

        if($doup){

            $file = $_FILES['file']['name'];
            $inf = pathinfo($file);

            $ext = $inf['extension'];
            $base = str_replace(".".$ext, '', $inf['basename']);

            $fname = $base . rand(0, 9999999). ".$ext";
            $destination = ROOT . "\uploads\\". $fname;
            $or = $_FILES['file']['tmp_name'];
            $check = move_uploaded_file($or, $destination);

            if($check){
                $data->file = $fname;
            }

        }

        $query = $edit ? $this->db->update('files', $data, ['id' => $data->id]) : $this->db->insert('files', $data);
        if ($query) {
            $rep->status = 'OK';
        } else {
            $rep->message = mysqli_error($this->db->get_context()) ?: "Impossible d'enregistrer les données";
        }
        responseJSON($rep);
    }

    public function dt_files(){

        $get = __($_GET);

        $result = $this->doDatatable("SELECT * FROM files WHERE deleted = 0", function($i, $row){
            $row->action = "<div class='button-group'>" .
                "<button type='button' class='button primary'>Actions <i class='fas fa-caret-down'></i></button><div>" .
                "<a href='javascript:void(0)' class='edit_file' data-edit='".$row->id."'><i class='fas fa-edit'></i> Modifier</a>" .
                "<a href='javascript:void(0)' class='delete_file' data-delete='".$row->id."'><i class='far fa-trash-alt'></i> Supprimer</a>" .
                "</div></div>";

        });

        responseJSON($result);
    }

    public function delete_file(){
        $id = __($_POST)->id;
        $rep = (object)['status' => 'NO', 'message' => "Sélectionnez les données à supprimer"];
        $query = null;

        if($id){
            $query = $this->db->update('files', ['deleted' => 1], ['id' => $id]);
        }

        $rep->status = $query ? 'OK' : 'ERROR';
        $rep->message = $query ? "Data deleted successfully" : "Impossible de supprimer cet élément";

        responseJSON($rep);
    }














}