import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

final numberFormating = NumberFormat("##0.00", "en_US");

String formateDateToDDMMYYYY(DateTime dateTime) {
  return DateFormat('dd-MM-yyyy').format(dateTime);
}

String formateDateToYYYYMMDD(DateTime dateTime) {
  return DateFormat('yyyy-MM-dd').format(dateTime);
}

getFileName(String path) {
  if (path == null) {
    return null;
  }
  File file = new File(path);
  String fileName = file.path.split('/').last;
  return fileName;
}

String formatehhmmss(DateTime dateTime) {
  if (dateTime == null) {
    return null;
  }
  return DateFormat('hh:mm:ss').format(dateTime);
}

String formateddmmyyyyhhmmssampm(DateTime dateTime) {
  if (dateTime == null) {
    return null;
  }
  return DateFormat('dd-MM-yyyy hh:mm:ss a').format(dateTime);
}

String formateyyyymmddhhmmssampm(DateTime dateTime) {
  if (dateTime == null) {
    return null;
  }
  return DateFormat('yyyy-MM-dd hh:mm:ss a').format(dateTime);
}

String datedayddMMMyyyyhhMMss(DateTime date) {
  return DateFormat('EEEE, dd MMM yyyy HH:mm').format(date); //
}

String datedayddMMMyyyyhhMMssWithSpace(String date) {
  return DateFormat('dd-MM-yyyy').parse(date).toString().split(' ')[0] +
      "        " +
      DateFormat('dd-MM-yyyy hh:mm:ss')
          .parse(date)
          .toString()
          .split(' ')[1]
          .split('.')[0];
}

String datedayddMMMyyyy(DateTime date) {
  return DateFormat('EEEE, dd MMM yyyy').format(date); //
}

DateTime strinToDateTime(String date) {
  if (date == null) {
    return null;
  }
  DateTime parseDate = new DateFormat("dd-MM-yyyy HH:mm:ss").parse(date);
  return parseDate;
}

DateTime strinToTime(String date) {
  if (date == null) {
    return null;
  }
  DateTime parseDate = new DateFormat("HH:mm:ss").parse(date);
  return parseDate;
}

String ddmmyyhhmmss(DateTime date) {
  if (date == null) {
    return null;
  }
  return DateFormat('dd/MM/yy HH:mm:ss').format(date); //
}

TimeOfDay minutesToDateTime(String time) {
  if (time == null) {
    return null;
  }

  Duration duration = Duration(minutes: double.parse(time).toInt());
  List<String> parts = duration.toString().split(':');
  return TimeOfDay(hour: int.parse(parts[0]), minute: int.parse(parts[1]));
}

TimeOfDay hoursToDateTime(String hours) {
  if (hours == null) return null;
  Duration duration = Duration(hours: int.parse(hours));
  List<String> parts = duration.toString().split(':');
  return TimeOfDay(hour: int.parse(parts[0]), minute: int.parse(parts[1]));
}

getBookType(String bookType) {
  if (bookType == '1') {
    return "IB";
  } else {
    return "PB";
  }
}

double getNumber(double input, {int precision = 2}) {
  try {
    return double.parse(
        '$input'.substring(0, '$input'.indexOf('.') + precision + 1));
  } catch (e) {
    return input;
  }
}

TimeOfDay stringtoTimeOfDay(String dateTime) {
  print("staaaart" + dateTime);
  if (dateTime == null) {
    return null;
  }
  return TimeOfDay(
      hour: int.parse(dateTime.split(":")[0]),
      minute: int.parse(dateTime.split(":")[1]));
}

int getTimeDifferenceInSeconds(String time, String chartTime) {
  print("how e jawwww");
  print(time);
  if (time == null) {
    return null;
  }

  return DateTime.parse(time)
      .add(Duration(hours: int.parse(chartTime)))
      .difference(DateTime.now())
      .inSeconds;
  ;
}

// above is used

String timeFormate(TimeOfDay timeOfDay) {
  if (timeOfDay.hour >= 12) {
    return "${(timeOfDay.hour % 12).toString().padLeft(2, '0')} : ${(timeOfDay.minute).toString().padLeft(2, '0')} PM";
  } else {
    return "${(timeOfDay.hour).toString().padLeft(2, '0')} : ${(timeOfDay.minute).toString().padLeft(2, '0')} AM";
  }
}

getddMMyyyyHHMMSS({TimeOfDay timeOfDay, DateTime dateTime}) {
  if (timeOfDay != null && dateTime != null) {
    return formateDateToDDMMYYYY(dateTime) + " " + timeFormate(timeOfDay);
  }
  return;
}

getTimeInHHMM(TimeOfDay timeOfDay) {
  if (timeOfDay != null) {
    return "${timeOfDay.hour}:${timeOfDay.minute}";
  }
  return;
}

getTimeInMinutes(TimeOfDay timeOfDay) {
  if (timeOfDay != null) {
    return "${timeOfDay.hour}.${timeOfDay.minute}";
  }
}

getddMMyyyyHHMMSSInDateTime({TimeOfDay timeOfDay, DateTime dateTime}) {
  if (timeOfDay != null && dateTime != null) {
    return DateTime(
      dateTime.year,
      dateTime.month,
      dateTime.day,
      timeOfDay.hour,
      timeOfDay.minute,
      00,
    );
  }
  return;
}

DateTime stringToDate(String date) {
  return DateFormat('dd-MM-yyyy').parse(date);
}

DateTime stringToDateOnlyYear(String date) {
  return DateFormat('yyyy').parse(date);
}

DateTime stringToDateTime(String date) {
  return DateFormat('dd-MM-yyyy hh:mm:ss').parse(date);
}

DateTime historystringToDateTime(String date) {
  DateTime time;
  try {
    time = DateFormat('dd-MM-yyyy hh:mm:ss').parse(date);
  } catch (e) {
    try {
      time = DateFormat('yyyy-MM-dd hh:mm').parse(date);
    } catch (e) {
      time = DateTime.now().subtract(Duration(days: 9999999));
    }
  }

  return time;
}

DateTime stringToDateTime2(String date) {
  if (date == null) {
    return null;
  }
  String newDate = "";
  List<String> elements = date.split(" ");
  print("date $date}");
  newDate =
      elements[2] + "-" + elements[1] + "-" + elements[0] + " " + elements[4];
  print("newDate $newDate");
  return DateFormat('yyyy-MM-dd hh:mm:ss').parse(newDate);
}

stringToDateTimeFromDateTime(DateTime date) {
  if (date == null) {
    return;
  }
  return DateFormat('dd-MM-yyyy hh:mm:ss aaa').format(date);
}

String dateddMMMyyyy(DateTime date) {
  return DateFormat('dd MMM yyyy').format(date);
}

bool isSameDate(DateTime first, DateTime second) {
  return first.year == second.year &&
      first.month == second.month &&
      first.day == second.day;
}
