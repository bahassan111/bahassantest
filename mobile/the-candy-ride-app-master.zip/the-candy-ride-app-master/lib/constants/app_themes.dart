import 'package:flutter/material.dart';

class AppThemes {
  AppThemes._();
  static const _deepPink = Color(0xffFF0782); //FF0082
  static const _paua = Color(0xff1B1B48);
  static const _grey = Color(0xff7F7F7F);
  static const _ebonyClay = Color(0xff282F39);
  static const _comet = Color(0xff515C6F);
  static const _doveGray = Color(0xff707070);
  static const _raven = Color(0xff727C8E);
  static const _athensGray = Color(0xffE7EAF0);
  static const _mineShaft = Color(0xff303030);
  static const _concrete = Color(0xffF2F2F2);
  static const _loblolly = Color(0xffC0C9D1);
  static const _iron = Color(0xffCFD1D3);
  static const _gallery = Color(0xffEFEFEF);
  static const _emperor = Color(0xff585454);
  static const _green = Color(0xff1AFF07);
  static const _nobel = Color(0xffB4B0B0);
  static const _yellowSea = Color(0xffFFB000);

  //BackGround Colors
  static const Color lightPinkBackGroundColor = _deepPink;
  static Color lightravenBackGroundColor = _raven.withOpacity(0.2);
  static const Color lightpauaBackGroundColor = _paua;
  static const Color lightGreenbackGroundColor = _green;
  static const Color lightWhitebackGroundColor = Colors.white;
  static const Color lightBlackbackGroundColor = Colors.black;
  static const Color lightStarColor = _mineShaft;

  //Border Color
  static const Color lightBorderColor = _grey;
  static const Color lightinputBorderColor = _concrete;
  static const Color lightAthensGrayBorderColor = _athensGray;
  static const Color lightActiveInputBorder = _deepPink;
  static const Color lightMenuIconBorder = _iron;
  static const Color lightCardBorder = _nobel;
  static const Color lightHistoryCardBorder = _yellowSea;

  //Divide Color
  static const Color lightDividerColor = _doveGray;
  static const Color lightCircularDividerColor = _gallery;

  // shadow color
  static const Color shadowColor = _athensGray;
  static const Color lightMenuIconShadow = _loblolly;
  static const Color lightBoxshadow = _mineShaft;

  //Icon Colors
  static Color lightravenIconColor = _raven;

  static ThemeData lightTheme = ThemeData(
    fontFamily: 'Poppins',
    textTheme: TextTheme(
      headline1: TextStyle(color: _ebonyClay),
      headline2: TextStyle(color: _mineShaft),
      headline3: TextStyle(color: _grey),
      headline4: TextStyle(color: _paua),
      headline5: TextStyle(color: _deepPink),
      headline6: TextStyle(color: _comet),
      subtitle1: TextStyle(color: Colors.white),
      subtitle2: TextStyle(color: _emperor),
    ),
  );
}
