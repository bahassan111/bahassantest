import React, { Component } from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    ImageBackground,
    ActivityIndicator,
    SafeAreaView,
    TouchableOpacity,
    ScrollView, Dimensions, Alert, Share, Platform
} from "react-native";
import * as Linking from 'expo-linking';
import css, {sizes, colors} from "../global/GlobalStyle";
import { connect } from 'react-redux';
import i18n from 'i18n-js';
import {AntDesign, FontAwesome, FontAwesome5, Feather, MaterialIcons} from "@expo/vector-icons";
import news from "../data/newsDemo";
import Loader from "../screens/_loader";
import storage from "../storage/TwStorage";
import Helper from "../global/Helper";
import { CommonActions } from '@react-navigation/native';
import {updateData} from "../redux/actions/dataAction";
import {bindActionCreators} from 'redux';
import {fetchCategories} from "../data/NewsData";

const win = Dimensions.get('screen');
const ofHeight = (p)=> p * win.height / 100;
const ofWidth = (p)=> p * win.width / 100;

class MenuDrawer extends Component {

    state = {
        cats : null,
        openCat : null,
    };

    componentDidMount() {
        const {navigation} = this.props;

        const {data} = this.props;
        this.props.updateData(data);


        i18n.locale = data.language;

        storage.getStorage('cats', []).then(cats => {
            try {
                cats = JSON.parse(cats);

            }catch (e) {
                cats = [];
            }

            this.setState({cats : cats})
        });

        fetchCategories(data.language, false).then((cats) =>{
            this.setState({cats : cats});
        }).catch((e)=>{

            const {navigation} = this.props;
            navigation.dispatch(
                CommonActions.reset({
                    index: 1,
                    routes: [
                        { name: 'error', params : {err_type : 'net'} },
                    ],
                })
            );

        });
    }

    gotoMenu = (item)=>{
        const {navigation} = this.props;

        navigation.navigate(item);

    };

    gotoSettings = ()=>{
        const { navigation } = this.props;

        navigation.navigate('settings');

    };

    gotoAbout = ()=>{
        const { navigation } = this.props;

        navigation.navigate('about');

    };

    shareApp = async ()=>{

        let url = Platform.OS === 'ios' ? `https://apps.apple.com/fr/app/dib-news/id1546450046?l=fr` : `https://play.google.com/store/apps/details?id=ma.map.dibnews`;



        const result = await Share.share({
            message: `Découvrez la nouvelle application DIB NEWS : ${url}`,
            url: url,
        });

        if (result.action === Share.sharedAction) {
            // Partagé
        }else if(result.action === Share.dismissedAction){
            // matpartajatch
        }

    };

    gotoCat = (item)=>{
        const {navigation} = this.props;

        navigation.navigate('category', {name : item.name, item:item});

    };


    isCatOpen = id => this.state.openCat === id;
    openCat = id => this.setState({openCat : id});
    closeCat = id => this.setState({openCat : null});

    _renderCats = ()=>{

        const {cats} = this.state;

        if(!cats) return null;


        let list = [], _cats = [];


        cats.forEach((item, i)=>{

            if(item.parent === 0) _cats.push(item);

        });

        _cats.forEach((item, i)=>{
            item.childs = [];

            cats.forEach((ch, i)=>{
                if(ch.parent === item.id) item.childs.push(ch);
            })

        });

        _cats.forEach((item, i)=>{

            if((item.id * 1) === 1) return;

            let withChilds = item.childs.length > 0,
                col = item.color || Helper.randomColor();


            list.push((
                <View key={'holder_' + item.id}>
                    <TouchableOpacity key={item.id} onPress={()=>{

                        if(withChilds){
                            if(this.isCatOpen(item.id)) this.closeCat(); else this.openCat(item.id);
                        }else{
                            this.gotoCat(item);
                        }

                    }} style={[css.dr_menu_item]}>
                        <View style={[css.dr_menu_ind, {backgroundColor: col, height : this.isCatOpen(item.id) ? '100%' : 18}]}/>
                        {/*<View style={[css.dr_mi_ic]}><MaterialIcons style={[css.dr_mi_icon]} name={Helper.catIcon(item.name)} size={24} /></View>*/}
                        <View style={[css.dr_mi_txt]}><Text style={[css.dr_mi_text, {fontSize:sizes.md}]}>{Helper.escapeHtml(item.name)}</Text></View>

                        {!withChilds ? (null) : (<View style={[css.dr_f_ic]}><MaterialIcons style={[css.dr_fi_icon]} name={`keyboard-arrow-${this.isCatOpen(item.id) ? 'down' : 'right'}`} size={24} /></View>)}
                    </TouchableOpacity>

                    {(!withChilds) ? (null) : (

                        <View style={[css.dr_menu_child, {borderLeftColor: col, display : this.isCatOpen(item.id) ? 'flex' : 'none'}]}>

                            {(()=>{
                                return item.childs.map((child, i)=>{

                                    return (
                                        <TouchableOpacity key={child.id} onPress={()=>{this.gotoCat(child)}} style={[css.dr_menu_item]}>
                                            <View style={[css.dr_menu_ind_c, {backgroundColor: '#ccc', width: 4,}]}/>
                                            <View style={[css.dr_mi_txt]}><Text style={[css.dr_mi_text, {fontSize:sizes.md}]}>{Helper.escapeHtml(child.name)}</Text></View>
                                        </TouchableOpacity>
                                    );

                                });
                            })()}

                        </View>

                    )}
                </View>
            ));
        });


        return list;

    };

    render() {

        i18n.locale = this.props.language;
        let onMenu = ('onMenu' in this.props) ? this.props.onMenu : ()=>{};
        let onUser = ('onUser' in this.props) ? this.props.onUser : ()=>{};
        let title = ('title' in this.props) ? this.props.title : '';
        let floatable = ('floatable' in this.props) ? this.props.floatable : false;
        let transparent = ('transparent' in this.props) ? this.props.transparent : false;


        return (

            <ScrollView style={css.dr_scroll}>
                <SafeAreaView style={css.dr_whole}>

                    <View style={css.dr_logo}>
                        <View style={css.dr_logo_top}>
                            <Text style={css.dr_l_dib}>DIB</Text>
                            <View style={css.dr_l_news}>
                                <Text style={css.dr_ln_text}>NEWS</Text>
                                <View style={css.dr_l_tags}>
                                    <View  style={[css.dr_l_tag, {backgroundColor : colors.primary1}]}/>
                                    <View  style={[css.dr_l_tag, {backgroundColor : colors.primary2}]}/>
                                    <View  style={[css.dr_l_tag, {backgroundColor : colors.primary3}]}/>
                                </View>
                            </View>
                        </View>
                        <Text style={css.dr_ln_sub}>DIGITAL INFORMATION BROADCAST</Text>
                    </View>


                    {this.state.cats === null ? (<Loader/>) : (
                        <View style={[css.dr_menu]}>

                            <TouchableOpacity onPress={()=>{this.gotoMenu('news')}} style={[css.dr_menu_item]}>
                                <View style={[css.dr_menu_ind, {backgroundColor: '#00ffac'}]}/>
                                {/*<View style={[css.dr_mi_ic]}><MaterialIcons style={[css.dr_mi_icon]} name="amp-stories" size={24} /></View>*/}
                                <View style={[css.dr_mi_txt]}><Text style={[css.dr_mi_text, {fontSize:sizes.md}]}>Accueil</Text></View>
                            </TouchableOpacity>
                            {this._renderCats()}
                        </View>
                    )}

                    <View style={[css.dr_foot]}>
                        <View style={[css.dr_menu]}>

                            <TouchableOpacity onPress={()=>{this.shareApp()}} style={[css.dr_menu_item]}>
                                <View style={[css.dr_menu_ind, {backgroundColor: '#000000'}]}/>
                                <View style={[css.dr_mi_ic]}><MaterialIcons style={[css.dr_mi_icon]} name="share" size={24} /></View>
                                <View style={[css.dr_mi_txt]}><Text style={[css.dr_mi_text]}>Partager avec des amis</Text></View>
                            </TouchableOpacity>

                            <TouchableOpacity onPress={()=>{this.gotoSettings()}} style={[css.dr_menu_item]}>
                                <View style={[css.dr_menu_ind, {backgroundColor: '#000000'}]}/>
                                <View style={[css.dr_mi_ic]}><MaterialIcons style={[css.dr_mi_icon]} name="settings" size={24} /></View>
                                <View style={[css.dr_mi_txt]}><Text style={[css.dr_mi_text]}>Options</Text></View>
                            </TouchableOpacity>

                            <TouchableOpacity onPress={()=>{this.gotoAbout()}} style={[css.dr_menu_item]}>
                                <View style={[css.dr_menu_ind, {backgroundColor: '#000000'}]}/>
                                <View style={[css.dr_mi_ic]}><MaterialIcons style={[css.dr_mi_icon]} name="info-outline" size={24} /></View>
                                <View style={[css.dr_mi_txt]}><Text style={[css.dr_mi_text]}>À propos de l'APP</Text></View>
                            </TouchableOpacity>
                        </View>

                        <View style={[css.dr_foot_soc]}>
                            <Text style={[css.dr_soc_text]}>Suivez nous</Text>
                            <View style={[css.dr_soc_items]}>
                                <TouchableOpacity onPress={()=>{Linking.openURL('https://www.facebook.com/dibnews.maroc');}} style={[css.dr_soc_item]}><AntDesign name="facebook-square" size={30} color={'#1254cc'} /></TouchableOpacity>
                                <TouchableOpacity onPress={()=>{Linking.openURL('https://twitter.com/dibnews_maroc');}} style={[css.dr_soc_item]}><AntDesign name="twitter" size={30} color={'#00d6fc'} /></TouchableOpacity>
                                <TouchableOpacity onPress={()=>{Linking.openURL('https://www.youtube.com/channel/UCZ_CY-3t7lIIXvj48N3YKbw');}} style={[css.dr_soc_item]}><AntDesign name="youtube" size={30} color={'#fc403b'} /></TouchableOpacity>
                                <TouchableOpacity onPress={()=>{Linking.openURL('https://www.instagram.com/dibnews.maroc/');}} style={[css.dr_soc_item]}><AntDesign name="instagram" size={30} color={'#cc1e60'} /></TouchableOpacity>
                            </View>
                        </View>
                        <Text style={[css.dr_foot_text]}>© DIB NEWS - MAP</Text>
                    </View>



                </SafeAreaView>
            </ScrollView>


        );
    }

}

const styles = StyleSheet.create({});

const mapDispatchToProps = dispatch => (
    bindActionCreators({
        updateData: updateData,
    }, dispatch)
);

const mapStateToProps = (state) => {
    const { data } = state;
    return { data }
};

export default connect(mapStateToProps, mapDispatchToProps)(MenuDrawer);
