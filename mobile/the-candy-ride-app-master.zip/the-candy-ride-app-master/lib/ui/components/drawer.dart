import 'package:flutter/material.dart';
import 'package:rider_app/constants/constants.dart';
import 'package:rider_app/controllers/controllers.dart';
import 'package:rider_app/models/models.dart';
import 'package:get/get.dart';
import 'components.dart';

class CustomDrawer extends StatefulWidget {
  final bool isMenuShow;
  final Function updateMenuPosition;
  CustomDrawer({Key key, this.isMenuShow, this.updateMenuPosition})
      : super(key: key);

  @override
  _CustomDrawerState createState() => _CustomDrawerState();
}

class _CustomDrawerState extends State<CustomDrawer> {
  double height, width;
  static AuthController to = Get.find();

  List<MenuItemModel> menuItems = [
    MenuItemModel(
      image: AllImages.profileIcon,
      onTap: () => Get.toNamed('/ProfileUI'),
      title: "profile",
    ),
    MenuItemModel(
        image: AllImages.currentTrip,
        onTap: () => Get.toNamed('/TripAceeptUI'),
        title: "currentTrip"),
    MenuItemModel(
        image: AllImages.tripHistory,
        onTap: () => Get.toNamed('/TripHistoryUI'),
        title: "tripHistory"),
    MenuItemModel(
        image: AllImages.myRating,
        onTap: () => Get.toNamed('/RatingUI'),
        title: "myRatings"),
    MenuItemModel(
        image: AllImages.calender,
        onTap: () => Get.toNamed('/PreBookingUI'),
        title: "Pre Bookings"),
    MenuItemModel(
        image: AllImages.logout,
        onTap: () {
          to.logout();
        },
        title: "logout"),
  ];
  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return AnimatedPositioned(
      duration: Duration(milliseconds: 250),
      left: widget.isMenuShow ? 0 : -width,
      width: width,
      child: Container(
        child: Row(
          children: [
            Container(
              color: AppThemes.lightWhitebackGroundColor,
              height: height,
              width: (3.5 * width / 5),
              child: Column(
                children: [
                  Container(
                    child: Stack(
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            SizedBox(
                              height: 40,
                            ),
                            ProfilePicture(
                              size: 75,
                              image: to.userModel.userImage,
                            ),
                            SizedBox(height: 10),
                            Text(
                              to.userModel.fullname,
                              style: Theme.of(context)
                                  .textTheme
                                  .headline5
                                  .copyWith(
                                      fontSize: 18,
                                      fontWeight: FontWeight.w700),
                              textAlign: TextAlign.center,
                            ),
                            SizedBox(height: 10),
                          ],
                        ),
                        Align(
                          alignment: Alignment.topRight,
                          child: GestureDetector(
                            onTap: () => widget.updateMenuPosition(),
                            child: Container(
                              padding: EdgeInsets.only(right: 20, top: 20),
                              child: Image.asset(
                                AllImages.backIcon,
                                height: 25,
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  Divider(
                    thickness: 2,
                    height: 2,
                    color: AppThemes.lightpauaBackGroundColor,
                  ),
                  ListView.builder(
                    shrinkWrap: true,
                    itemCount: menuItems.length,
                    itemBuilder: (context, index) {
                      return GestureDetector(
                        onTap: () {
                          menuItems[index].onTap();
                          widget.updateMenuPosition();
                        },
                        child: Container(
                          padding: EdgeInsets.symmetric(vertical: 5),
                          child: Row(
                            children: [
                              SizedBox(
                                width: 20,
                              ),
                              Image.asset(
                                menuItems[index].image,
                                height: 35,
                                width: 35,
                              ),
                              SizedBox(
                                width: 10,
                              ),
                              Text(
                                menuItems[index].title.tr,
                                style: Theme.of(context)
                                    .textTheme
                                    .headline4
                                    .copyWith(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w700),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  )
                ],
              ),
            ),
            GestureDetector(
              onTap: () {
                widget.updateMenuPosition();
              },
              child: Container(
                color: Colors.transparent,
                height: height,
                width: (1.5 * width / 5),
              ),
            )
          ],
        ),
      ),
    );
  }
}
