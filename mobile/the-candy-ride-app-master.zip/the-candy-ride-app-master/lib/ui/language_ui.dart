import 'package:flutter/material.dart';
import 'package:rider_app/constants/constants.dart';
import 'package:get/get.dart';
import 'package:rider_app/controllers/controllers.dart';
import 'package:rider_app/helpers/helpers.dart';
import 'package:rider_app/home.dart';
import 'package:rider_app/models/models.dart';
import 'package:location_permissions/location_permissions.dart';
//import 'package:rider_app/home.dart';

class LanguageUI extends StatefulWidget {
  @override
  _LanguageUIState createState() => _LanguageUIState();
}

class _LanguageUIState extends State<LanguageUI> {
  double height, width;
  final LanguageController languageController = LanguageController.to;
  locationPermitCheck() async {
    return await LocationPermissions().checkPermissionStatus();
  }

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    PermissionStatus permission;
    return Scaffold(
      body: SafeArea(
          child: Stack(
        children: <Widget>[
          Column(
            children: [
              SizedBox(
                height: 30,
              ),
              //permission = locationPermitCheck(),
              if (locationPermitCheck() != PermissionStatus.granted) Home(),
              Image.asset(
                'assets/images/the_candy.png',
                width: (3 * width) / 4,
              ),
              Text(
                "chooseLanguage".tr,
                style: Theme.of(context)
                    .textTheme
                    .headline1
                    .copyWith(fontSize: 20),
              ),
              SizedBox(
                height: 10,
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: languageController.languages.length,
                  itemBuilder: (context, index) {
                    return languageItem(
                        languageController.languages[index], index);
                  },
                ),
              ),
            ],
          ),
          Container(
            alignment: Alignment.bottomCenter,
            padding: EdgeInsets.only(
              left: 10.0,
              right: 10.0,
              bottom: 100.0,
            ),
            // child: Text(
            //   'Note: The Candy Rider app collects location data to indentify nearby customers and drivers, even when the app is closed or not in use',
            //   style: TextStyle(
            //       color: Colors.pink,
            //       fontWeight: FontWeight.normal,
            //       fontFamily: 'assets/fonts/nunito_sans/NunitoSans-Light.ttf',
            //       fontSize: 22.0),
            // ),
          ),
        ],
      )),
    );
  }

  languageItem(LanguageModel languageModel, int index) {
    return Container(
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(
            color: AppThemes.lightAthensGrayBorderColor,
          ),
          bottom: index == languageController.languages.length - 1
              ? BorderSide(
                  color: AppThemes.lightAthensGrayBorderColor,
                )
              : BorderSide(color: Colors.transparent),
        ),
      ),
      padding: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
      child: Row(
        children: [
          Text(
            languageModel.name,
            style: Theme.of(context).textTheme.headline6.copyWith(
                  fontSize: 15,
                ),
          ),
          Spacer(),
          GestureDetector(
            onTap: () async {
              await languageController.setDefaultLanguage(
                languageModel.language,
                languageModel.country,
              );
              Get.offNamed('/IntroUI');
            },
            child: Container(
              padding: EdgeInsets.all(5),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppThemes.lightravenBackGroundColor,
              ),
              child: Center(
                child: Icon(
                  Icons.arrow_forward_ios,
                  size: 11,
                  color: AppThemes.lightravenIconColor,
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
