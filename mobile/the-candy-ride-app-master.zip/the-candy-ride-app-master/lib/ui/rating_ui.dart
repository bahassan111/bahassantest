import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:rider_app/constants/constants.dart';
import 'package:get/get.dart';
import 'package:rider_app/controllers/controllers.dart';
import 'components/components.dart';

class RatingUI extends StatefulWidget {
  @override
  _RatingUIState createState() => _RatingUIState();
}

class _RatingUIState extends State<RatingUI> {
  var data = Get.arguments;
  double rating = 0;
  TextEditingController comment = TextEditingController();
  static RatingController to = Get.find();
  static AuthController authTo = Get.find();
  static HomeController homeTo = Get.find();

  @override
  void initState() {
    to.ride = null;
    to.imagedetails = null;
    to.riderRetrieveFeedback().then((value) {
      print("to.rideId ${to.rideId}");
      if (to.rideId != null) {
        to.getRideDetail().then((value) {
          if (to.ride != null) {
            if (mounted)
              setState(() {
                print("to.imagedetails ${to.imagedetails}");
                print("to.ride.pickupTime ${to.ride.pickupTime}");
              });
          }
        });
      }
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    print("rider id ${authTo.userModel.riderid}");
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            SizedBox(height: 10),
            getAppbar(context),
            SizedBox(height: 10),
            getDriverDetail(context),
            SizedBox(height: 10),
            getTripDetail(context),
            SizedBox(height: 10),
            getRatingBox(context),
          ],
        ),
      ),
    );
  }

  getRatingBox(context) => Container(
        padding: EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          children: [
            Text(
              "Please Rate you trip".tr,
              style: Theme.of(context).textTheme.headline4.copyWith(
                  fontSize: 18, fontWeight: FontWeight.w700, height: 1.2),
            ),
            SizedBox(height: 10),
            RatingBar(
              initialRating: rating,
              direction: Axis.horizontal,
              itemCount: 5,
              itemSize: 30,
              minRating: 1,
              ratingWidget: RatingWidget(
                full: Icon(
                  Icons.star,
                  color: AppThemes.lightPinkBackGroundColor,
                ),
                half: Icon(
                  Icons.star_half,
                  color: AppThemes.lightPinkBackGroundColor,
                ),
                empty: Icon(
                  Icons.star_border,
                  color: AppThemes.lightPinkBackGroundColor,
                ),
              ),
              glow: false,
              itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
              onRatingUpdate: (rate) {
                setState(() {
                  rating = rate;
                });
              },
            ),
            SizedBox(height: 10),
            AdditionalComment(
              controller: comment,
              hintText: "additionalComment".tr,
            ),
            SizedBox(height: 15),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  "submit".tr,
                  style: Theme.of(context)
                      .textTheme
                      .headline5
                      .copyWith(fontSize: 18, fontWeight: FontWeight.w700),
                ),
                SizedBox(width: 10),
                GestureDetector(
                  onTap: () async {
                    await to.riderFeedBack(rating, comment.text.trim());
                    BotToast.showWidget(
                      toastBuilder: (_) => SuccessDialog(
                        message: "Thank you ! have a nice day".tr,
                        ontap: () {
                          BotToast.cleanAll();
                          Get.offAllNamed('/HomeUI');
                        },
                      ),
                    );
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: AppThemes.lightPinkBackGroundColor,
                      shape: BoxShape.circle,
                    ),
                    padding: EdgeInsets.all(10),
                    child: Icon(
                      Icons.arrow_forward,
                      size: 23,
                      color: AppThemes.lightWhitebackGroundColor,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 15),
          ],
        ),
      );

  getTripDetail(context) => Container(
        child: Column(
          children: [
            Divider(
              color: AppThemes.lightDividerColor,
            ),
            SizedBox(height: 5),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                getTripDetailItem(
                  context,
                  "time".tr + ":",
                  to.ride == null
                      ? "0 mins"
                      : "${double.parse(to.ride.duration).toPrecision(2)} mins",
                ),
                Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "ride_fare".tr + ":",
                        style: Theme.of(context)
                            .textTheme
                            .headline4
                            .copyWith(fontSize: 13),
                      ),
                      Text(
                        to.ride == null
                            ? "${authTo.currency} 0"
                            : "${authTo.currency} ${(double.parse(to.ride.totalfare)).toPrecision(2)}",
                        style: Theme.of(context).textTheme.headline4.copyWith(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            height: 1.3),
                      ),
                      Text(
                        "toll_charges".tr,
                        style: Theme.of(context)
                            .textTheme
                            .headline4
                            .copyWith(fontSize: 11),
                      ),
                    ],
                  ),
                ),
                getTripDetailItem(
                  context,
                  "distance".tr + ":",
                  to.ride == null
                      ? "0 km"
                      : "${double.parse(to.ride.distance).toPrecision(2)} km",
                ),
              ],
            ),
            SizedBox(height: 5),
            Divider(
              color: AppThemes.lightDividerColor,
            ),
          ],
        ),
      );

  getTripDetailItem(context, String title, String description) => Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style:
                  Theme.of(context).textTheme.headline4.copyWith(fontSize: 13),
            ),
            Text(
              description,
              style: Theme.of(context).textTheme.headline4.copyWith(
                  fontSize: 18, fontWeight: FontWeight.w700, height: 1.3),
            ),
          ],
        ),
      );

  getDriverDetail(context) => Container(
        child: Column(
          children: [
            Container(
              height: 110,
              width: 110,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: to.imagedetails != null &&
                          to.imagedetails != Urls.baseDriverImageUrl
                      ? NetworkImage(to.imagedetails)
                      : AssetImage(AllImages.adddp),
                ),
                boxShadow: [
                  BoxShadow(
                      color:
                          AppThemes.lightBlackbackGroundColor.withOpacity(.15),
                      offset: Offset(0, 3),
                      blurRadius: 3,
                      spreadRadius: 3)
                ],
                shape: BoxShape.circle,
              ),
            ),
            SizedBox(height: 35),
            Text(
              "yourDriver".tr + ":",
              style:
                  Theme.of(context).textTheme.headline4.copyWith(fontSize: 13),
            ),
            Text(
              to.ride == null ? "" : (to.ride.fname + ' ' + to.ride.lname),
              style: Theme.of(context).textTheme.headline4.copyWith(
                  fontSize: 18, fontWeight: FontWeight.w700, height: 1.3),
            ),
            SizedBox(
              height: 10,
            ),
            Text(
              "bookingId".tr + ":",
              style:
                  Theme.of(context).textTheme.headline4.copyWith(fontSize: 13),
            ),
            Text(
              to.ride == null
                  ? ""
                  : homeTo.tripId(
                      id: to.ride.id,
                      bookingType: to.ride.bookType,
                      type: to.ride.carCategory,
                    ),
              style: Theme.of(context).textTheme.headline4.copyWith(
                  fontSize: 18, fontWeight: FontWeight.w700, height: 1.3),
            )
          ],
        ),
      );

  getAppbar(context) => Row(
        children: [
          SizedBox(width: 15),
          GestureDetector(
            onTap: () => Get.offAndToNamed('/HomeUI'),
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(color: AppThemes.lightPinkBackGroundColor),
                shape: BoxShape.circle,
              ),
              padding: EdgeInsets.all(10),
              child: Icon(
                Icons.arrow_back,
                size: 20,
                color: AppThemes.lightPinkBackGroundColor,
              ),
            ),
          ),
          SizedBox(width: 10),
          Flexible(
            child: Text(
              "thankYouForRidingWithUs".tr,
              textAlign: TextAlign.center,
              style: Theme.of(context)
                  .textTheme
                  .headline4
                  .copyWith(fontSize: 18, fontWeight: FontWeight.w700),
            ),
          )
        ],
      );
}
