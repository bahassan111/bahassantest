import {

    PENDING_FETCH_COMMENTS,
    SET_COMMENTS,
    SUCCESS_FETCH_COMMENTS

} from "../actions/types";

export default function(
    state = { isLoadingData: false, isDoSearch: false, data: [], keyword: null },
    action
) {

    console.log("Log_action_Comments => ", action.type);

    switch (action.type) {
        case PENDING_FETCH_COMMENTS:
            return {
                ...state,
                isLoadingData: true
            };

        case SET_COMMENTS:
            return { ...state, data: action.payload };

        case SUCCESS_FETCH_COMMENTS:
            return {
                ...state,
                isLoadingData: false
            };

        default:
            return state;
    }

}
