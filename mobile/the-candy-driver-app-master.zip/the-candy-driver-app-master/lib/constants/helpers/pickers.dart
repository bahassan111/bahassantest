import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

Future<DateTime> selectDate(BuildContext context,
    {DateTime selectedDate, DateTime intialDate, DateTime endDate}) async {
  final DateTime picked = await showDatePicker(
    context: context,
    initialDate: selectedDate ?? DateTime.now(),
    firstDate: intialDate ?? DateTime.now(),
    lastDate: endDate ?? DateTime.now().add(Duration(days: 1111111)),
  );
  return picked;
}

Future<DateTime> selectAllDate(BuildContext context,
    {DateTime selectedDate}) async {
  final DateTime picked = await showDatePicker(
    context: context,
    initialDate: selectedDate ?? DateTime.now(),
    lastDate: DateTime.now(),
    firstDate: DateTime(2020),
  );

  return picked;
}

Future<TimeOfDay> selectTime(BuildContext context,
    {DateTime selectedTime}) async {
  final pickedTime = await showTimePicker(
    context: context,
    initialTime: selectedTime ?? TimeOfDay(hour: 00, minute: 00),
  );
  return pickedTime;
}

imgFromGallery(BuildContext context) async {
  final _picker = ImagePicker();
  PickedFile image = await _picker.getImage(source: ImageSource.gallery);
  return image;
}

imagePickerToString(PickedFile file) {
  String base64Image;
  if (file != null) {
    List<int> imageBytes = File(file.path).readAsBytesSync();
    base64Image = base64Encode(imageBytes);
  }
  return base64Image;
}
