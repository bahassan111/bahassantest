create table admin
(
    id          int auto_increment
      
        primary key,
    id_country  int           null,
    id_user     int           null,
    username    text          null,
    fullname    text          null,
    email       text          null,
    password    text          null,
    role        int default 0 not null,
    status      int default 0 not null,
    image       text          null,
    date_added  datetime      null,
    last_update datetime      null,
    deleted     int default 0 not null
)
    engine = InnoDB
    charset = utf8;

create table config
(
    id    int auto_increment
       
        primary key,
    `key` text null,
    value text null
)
    engine = InnoDB
    charset = utf8;

create table files
(
    id          int auto_increment
       
        primary key,
    title       text             null,
    cat         text             null,
    description text             null,
    file        text             null,
    deleted     int(1) default 0 null,
    lang        text             null
)charset = utf8;;

create table regions
(
    id          int auto_increment
       
        primary key,
    name        text             null,
    director    text             null,
    phone       text             null,
    phone2      text             null,
    fax         text             null,
    fax2        text             null,
    email       text             null,
    address     text             null,
    city        text             null,
    region      text             null,
    lat         text             null,
    lng         text             null,
    deleted     int(1) default 0 not null,
    name_ar     text             null,
    director_ar text             null,
    address_ar  text             null,
    city_ar     text             null,
    region_ar   text             null
)charset = utf8;;


INSERT INTO tw_bo.admin (id, id_country, id_user, username, fullname, email, password, role, status, image, date_added, last_update, deleted) VALUES (1, 20, 1, 'admin', 'Hamza El Founassi', 'admin@com', '123456', -1, 0, 'images/users/user.jpg', null, '2020-03-10 13:03:07', 0);
INSERT INTO tw_bo.admin (id, id_country, id_user, username, fullname, email, password, role, status, image, date_added, last_update, deleted) VALUES (9, null, 1, 'morani', 'morjani', 'morjani@gmail.com', '123456', 0, 0, 'images/users/user.jpg', '2020-02-27 15:02:29', '2020-02-27 18:02:29', 0);
INSERT INTO tw_bo.admin (id, id_country, id_user, username, fullname, email, password, role, status, image, date_added, last_update, deleted) VALUES (14, null, 1, 'ahmed', 'ahmed', 'ahmed@gmail.com', '123456', 0, 0, 'images/users/user.jpg', '2020-02-27 18:02:16', '2020-02-27 18:02:16', 0);
INSERT INTO tw_bo.config (id, `key`, value) VALUES (1, 'lang', 'ar');
INSERT INTO tw_bo.config (id, `key`, value) VALUES (2, 'user_lang', '[{"user_id":"2556048664483028","lang":"fr"},{"user_id":"114080040571347230994","lang":"ar"}]');
INSERT INTO tw_bo.files (id, title, cat, description, file, deleted, lang) VALUES (1, 'dqsfqsf', 'qsdqsd', 'qsdqsd', 'bg5390451.jpg', 1, null);
INSERT INTO tw_bo.files (id, title, cat, description, file, deleted, lang) VALUES (2, 'qsd', 'qsd', 'qsd', 'Screenshot_16074395282264727.png', 0, null);
INSERT INTO tw_bo.files (id, title, cat, description, file, deleted, lang) VALUES (3, 'qsd---', 'qsd---', 'qsd', null, 0, null);
INSERT INTO tw_bo.files (id, title, cat, description, file, deleted, lang) VALUES (4, 'q', 'qsd', 'qsd', null, 1, null);
INSERT INTO tw_bo.files (id, title, cat, description, file, deleted, lang) VALUES (5, 'q', 'qsd', 'qsd', null, 1, null);
INSERT INTO tw_bo.files (id, title, cat, description, file, deleted, lang) VALUES (6, 'Test', 'fr x', 'qsddqsd', null, 0, 'fr');
INSERT INTO tw_bo.files (id, title, cat, description, file, deleted, lang) VALUES (7, 'qsdqDQDQSD', 'AR F', 'QSD', null, 0, 'ar');
INSERT INTO tw_bo.files (id, title, cat, description, file, deleted, lang) VALUES (8, 'qsd', null, 'dsqdqsd', 'bg9030680.jpg', 0, 'ar');
INSERT INTO tw_bo.files (id, title, cat, description, file, deleted, lang) VALUES (9, 'sd', 'fr x', 'wxc', null, 0, 'fr');
INSERT INTO tw_bo.files (id, title, cat, description, file, deleted, lang) VALUES (10, 'TEST', 'TEST', 'qsdqsd', 'user8218000.jpg', 0, 'ar');
INSERT INTO tw_bo.files (id, title, cat, description, file, deleted, lang) VALUES (11, 'sdfsdfsdf', '?????', '?????????', 'slide_ann_5608560472867.jpg', 0, 'ar');
INSERT INTO tw_bo.regions (id, name, director, phone, phone2, fax, fax2, email, address, city, region, lat, lng, deleted, name_ar, director_ar, address_ar, city_ar, region_ar) VALUES (1, 'Direction Reg. Anfa', 'Mr Mohammed El Aimani', '0522258660', null, '0522250218', null, 'dre.casaanfa@emploi.gov.ma', 'Siège de la DRTIP de Casa Anfa Casablanca
Rue Ben Jilali Taj Eddine, N°48 Mâarif  ', 'Casablanca', null, '33.5800743', '-7.639004399999999', 0, null, null, null, null, null);
INSERT INTO tw_bo.regions (id, name, director, phone, phone2, fax, fax2, email, address, city, region, lat, lng, deleted, name_ar, director_ar, address_ar, city_ar, region_ar) VALUES (2, 'Direction Aïn Chock Hay Hassani', 'Mme Amal Ghazi', '0522217156', null, '0522217157', null, 'dpe.ainchok@emploi.gov.ma', 'Aïn Chock Hay Hassani Casablanca', 'Casablanca', null, '33.5731104', '-7.589843399999999', 0, null, null, null, null, null);
INSERT INTO tw_bo.regions (id, name, director, phone, phone2, fax, fax2, email, address, city, region, lat, lng, deleted, name_ar, director_ar, address_ar, city_ar, region_ar) VALUES (3, 'e', '', '', null, '', null, '', '', '', null, '0.00000000000000000000', '0.00000000000000000000', 1, null, null, null, null, null);
INSERT INTO tw_bo.regions (id, name, director, phone, phone2, fax, fax2, email, address, city, region, lat, lng, deleted, name_ar, director_ar, address_ar, city_ar, region_ar) VALUES (4, 'sdqsd', 'qsdqsd', 'qqsd', null, 'qsd', null, 'qsd', 'Siège de la DRTIP de Casa Anfa Casablanca
Rue Ben Jilali Taj Eddine, N°48 Mâarif  ', 'Casablanca', null, '33.571043725178406', '-7.700336138807573', 1, null, null, null, null, null);
INSERT INTO tw_bo.regions (id, name, director, phone, phone2, fax, fax2, email, address, city, region, lat, lng, deleted, name_ar, director_ar, address_ar, city_ar, region_ar) VALUES (5, 'Direction Reg. de Rabat', '', '0537708202', null, '0537705125', null, 'dre.rabat@emploi.gov.ma', 'Siège de la DPTIP de Kénitra (2 locaux)
N°8 Rue Ibn Rochd', '', null, '33.973392376188045', '-6.856808085428803', 0, null, null, null, null, null);
INSERT INTO tw_bo.regions (id, name, director, phone, phone2, fax, fax2, email, address, city, region, lat, lng, deleted, name_ar, director_ar, address_ar, city_ar, region_ar) VALUES (6, 'Direction de Kénitra', 'Mr Benmbarka Abdennacer', '0537379903', null, '0537379903', null, 'dpe.kenitra@emploi.gov.ma', 'Siège de la DPTIP de Kénitra (2 locaux)
N°8 Rue Ibn Rochd', '', null, '34.2455813', '-6.603946', 0, null, null, null, null, null);
INSERT INTO tw_bo.regions (id, name, director, phone, phone2, fax, fax2, email, address, city, region, lat, lng, deleted, name_ar, director_ar, address_ar, city_ar, region_ar) VALUES (7, 'Direction de Sidi Kacem', 'Mr Nassif Abdelmajid', '0537596752', null, '0537596752', null, 'dpe.sidikacem@emploi.gov.ma', '', '', null, '34.2260172', '-5.7129164', 0, null, null, null, null, null);