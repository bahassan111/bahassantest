import "react-native-gesture-handler";
import React from "react";
import { View } from "react-native-ui-lib";
import { AppLoading } from "expo";
import { StatusBar, LogBox, NativeModules, Platform } from "react-native";
import * as Font from "expo-font";
import RootStackNavigator from "./App/navigation/_navigationStack";

import { Provider } from "react-redux";
import { createStore, applyMiddleware } from "redux";
import apiMiddleware from "./App/Redux/middleware/api";
import reducers from "@redux/reducers";
import thunk from "redux-thunk";
import * as Ionicons from "@expo/vector-icons";

import * as SQLite from "expo-sqlite";
import * as Asset from "expo-asset";

const db = SQLite.openDatabase("ifes.db");
// Ignore all log notifications:
LogBox.ignoreAllLogs();

if (Platform.OS === "android") {
  const { UIManager } = NativeModules;
  if (UIManager) {
    // Add gesture specific events to genericDirectEventTypes object exported from UIManager native module.
    // Once new event types are registered with react it is possible to dispatch these events to all kind of native views.
    UIManager.genericDirectEventTypes = {
      ...UIManager.genericDirectEventTypes,
      onGestureHandlerEvent: { registrationName: "onGestureHandlerEvent" },
      onGestureHandlerStateChange: {
        registrationName: "onGestureHandlerStateChange",
      },
    };
  }
}

export default class App extends React.Component {
  state = {
    isLoadingComplete: false,
    fontLoaded: false,
  };

  componentDidMount() {
    // this.dbClear();
    this.dbInit();
    Font.loadAsync({
      // This is the font that we are using for our tab bar
      ...Ionicons.font,
      FriIcon: require("./App/assets/fontello/font/fontello.ttf"),

      // We include SpaceMono because we use it in HomeScreen.js. Feel free
      // to remove this if you are not using it in your app
      "space-mono": require("./App/assets/fonts/SpaceMono-Regular.ttf"),
      "bw-seido-round": require("./App/assets/fonts/BwSeidoRound-Light.otf"),
      "ge-thameen-book": require("./App/assets/fonts/GE-Thameen-Book.otf"),
    }).then(() => console.log("OK ##########################"));
  }

  dbInit() {
    db.transaction((tx) => {
      tx.executeSql(
        "create table if not exists parametres (id integer primary key not null, fontSize int, fontWeight int, lang text);",
        [],
        () => console.log("creeeated"),
        (a, b) => console.log(b)
      );
      tx.executeSql(
        "insert into parametres (fontSize , FontWeight, lang) values (?,?,?)",
        [14, 400, "fr"],
        () => console.log("creeeated table parametres"),
        (a, b) => console.log(b)
      );
    });
  }

  dbClear() {
    db.transaction((tx) => {
      tx.executeSql(
        "drop  parametres",
        [],
        () => console.log("deleted"),
        (a, b) => console.log(b)
      );
    });
  }

  render() {
    let store = createStore(reducers, {}, applyMiddleware(thunk));
    const { navigation } = this.props;

    if (!this.state.isLoadingComplete && !this.props.skipLoadingScreen) {
      return (
        <AppLoading
          startAsync={this._loadResourcesAsync}
          onError={this._handleLoadingError}
          onFinish={this._handleFinishLoading}
        />
      );
    } else {
      return (
        <View bg-white flex>
          <StatusBar />
          <Provider store={store}>
            <RootStackNavigator navigation={navigation} />
          </Provider>
        </View>
      );
    }
  }

  _loadResourcesAsync = async () => {
    let loaded;

    return Promise.all([
      Asset.loadAsync([
        require("./App/assets/images/menuLogo.png"),
        require("./App/assets/images/banners.png"),
        require("./App/assets/images/bgMenu.png"),
        require("./App/assets/images/intro.png"),
        require("./App/assets/images/Video.png"),
        require("./App/assets/images/intro.mp4"),
      ]),

      /*[loaded] = useFonts({
      FriIcon: require("./App/assets/fontello/font/fontello.ttf"),
      "space-mono": require("./App/assets/fonts/SpaceMono-Regular.ttf"),
      "bw-seido-round": require("./App/assets/fonts/BwSeidoRound-Light.otf"),
      "ge-thameen-book": require("./App/assets/fonts/GE-Thameen-Book.otf")
    })*/

      /*     */
      this.setState({ fontLoaded: true }),
    ]);
  };

  _handleLoadingError = (error) => {
    // In this case, you might want to report the error to your error
    // reporting service, for example Sentry
    console.warn(error);
  };

  _handleFinishLoading = () => {
    this.setState({ isLoadingComplete: true });
  };
}
