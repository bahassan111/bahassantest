<?php
defined('BASE') OR die('Direct access is not allowed');
?>
</div>
</div>

<footer>



</footer>

<script src="<?= site_url('assets/js/vendor/modernizr-3.7.1.min.js'); ?>"></script>
<script src="<?= site_url('assets/js/vendor/jquery-3.4.1.min.js'); ?>"></script>
<script src="<?= site_url('assets/js/vendor/bootsraap/bootsraap.min.js') ?>"></script>
<script src="<?= site_url('assets/js/vendor/bootstrap-select/dist/js/bootstrap-select.js') ?>"></script>
<script src="<?= site_url('assets/js/vendor/dropify/dist/js/dropify.js') ?>"></script>
<script src="<?= site_url('assets/js/vendor/jquery.validate.min.js') ?>"></script>
<script src="<?= site_url('assets/js/vendor/toastr/toastr.min.js') ?>"></script>
<script src="<?= site_url('assets/js/vendor/sweetalert/sweetalert.min.js') ?>"></script>
<script src="<?= site_url('assets/js/vendor/file_input_master/fileinput.js') ?>"></script>
<script src="<?= site_url('assets/js/vendor/file_input_master/themes/explorer-fa/theme.js') ?>"></script>
<script src="<?= site_url('assets/js/vendor/file_input_master/themes/fa/theme.js') ?>"></script>
<script src="<?= site_url('assets/js/vendor/Tocca.min.js'); ?>"></script>
<script src="<?= site_url('assets/js/plugins.js'); ?>"></script>
<script src="<?= site_url('assets/js/vendor/datatables/datatables.min.js'); ?>"></script>
<script src="<?= site_url('assets/js/vendor/datatables/Responsive-2.2.1/js/dataTables.responsive.min.js'); ?>"></script>
<script src="<?= site_url('assets/js/ajax.js?v='.rand(0,99999)); ?>"></script>
<script src="<?= site_url('assets/js/app.back.js?v='.rand(0,99999)); ?>"></script>

</body>

</html>
