(function () {
    var view = $('#tasks_view');
    if (!view.length) return;

    var table = $('.tasks_list');

    $(view)


        .on('click', '.add_run', function () {
            oneTask();
        })
        .ready(function () {

            table.twTable({

                url     : site_url + 'tasks/get_list/' + project_id,
                key     : 'id',
                dblclick : function(id, tr){
                    loadView(site_url + 'project/' + project_id + '/run/' + id);
                },
                columns : [
                    {name : 'id', data : 'ref', title : 'ID', orderable : true, searchable : false},
                    {name : 'title', data : 'title', title : 'Title', orderable : true, searchable : true},
                    {name : 'date', data : 'date', title : 'Date', orderable : true, searchable : true},
                    {name : 'deadline', data : 'deadline', title : 'Deadline', orderable : true, searchable : true},
                    {name : 'affected_to', data : 'affected_to', title : 'affected_to', orderable : true, searchable : true},
                    {name : 'date_updated', data : 'date_updated', title : 'Last Update', orderable : false, searchable : false},
                ],

                buttons : [
                    {
                        text : 'Create',
                        icon : 'fas fa-plus',
                        color : 'primary',
                        global : true,
                        action : function(){
                            oneTask();
                        },
                    },
                    {
                        separator : true,
                    },

                    {
                        text : 'RUN',
                        icon : 'fas fa-play',
                        color : 'success',
                        global : false,
                        action : function(id){
                            loadView(site_url + 'project/' + project_id + '/run/' + id);
                        },
                    },
                    {
                        separator : true,
                    },
                    {
                        title : 'View Test Cases',
                        icon : 'fas fa-eye',
                        global : false,
                        action : function(id){
                            openRun(id);
                        },
                    },
                    {
                        title : 'Edit infos',
                        icon : 'fas fa-pencil-alt',
                        global : false,
                        action : function(id){
                            oneTask(id);
                        },
                    },
                    {
                        title : 'Delete the test run',
                        icon : 'fas fa-times',
                        global : false,
                        action : function(id){
                            deleteRun(id)
                        },
                    },
                    {
                        title : 'Copy the test run',
                        icon : 'far fa-copy',
                        global : false,
                        action : function(){},
                    },
                    {separator: true},
                    {
                        title : 'Mark as finished and close',
                        icon : 'fas fa-check',
                        global : false,
                        condition : function(row){
                            return row.status < 3 && row.status >= 1;
                        },
                        action : function(id){
                            changeRunStatus(id, 3);
                        },
                    },
                    {
                        title : 'Mark as Open',
                        icon : 'far fa-folder-open',
                        global : false,
                        condition : function(row){
                            return row.status === '0';
                        },
                        action : function(id){
                            changeRunStatus(id, 1);
                        },
                    },
                    {
                        title : 'Reopen the Test RUN',
                        icon : 'fas fa-undo',
                        global : false,
                        condition : function(row){
                            return row.status === '3';
                        },
                        action : function(id){
                            changeRunStatus(id, 1);
                        },
                    },

                ],

            });





            /*initDatatable(table, [

                {name : 'id', data : 'id', title : 'ID', orderable:true, searchable:true},
                {name : 'title', data : 'title', title : 'Title', orderable:true, searchable:true},
                {name : 'status', data : 'status', title : 'Status', orderable:false, searchable:false},
                {name : 'username', data : 'username', title : 'Assigned to', orderable:true, searchable:true},
                {name : 'date', data : 'date_added', title : 'Date', orderable:true, searchable:true},
                {name : 'last_run', data : 'last_run', title : 'Last run', orderable:true, searchable:true},

            ], {ajax : site_url + 'project/dt_runs'})*/
        })
    ;


    function oneTask(id) {

        ajaxSideModal('tasks/one_task/' + (id || ''), (id ? 'Edit' : 'Create')  + ' a Task', 'far fa-paper-plane', {
            close_text : 'Cancel',
            confirm_text : 'Save',
            size: 'md',
            post_data : {id_project : project_id},
            whenLoaded : function(modal, data){
                handleInits(modal);

                modal.find('form')
                    .validate({
                        rules : {
                            title : {required : true},
                            id_release : {required : true},
                        }
                    });
                modal
                    .on('submit', 'form', function (e) {
                        e.preventDefault();
                        var btn = modal.find('.confirm').prop('disabled', true);

                        var form = $(this);

                        if(form.valid()){
                            post(form.attr('action'), form.serialize(), function (rep) {
                                if(rep.status === 'OK'){
                                    toastr_('The task was successfully added', 'success', 'success', 6000);
                                    modal.sideModal('hide');
                                    table.twTable('refresh');
                                }else{
                                    toastr_(rep.message || 'Error while saving the data', 'error', 'danger', 9000);
                                }
                            })
                        }



                    })
            },
            whenConfirm : function(modal, data){
                modal.find('form').submit();
            },
            whenError : function(modal, error){},
            whenClosed : function(modal){},

        });
    }
    function deleteRun(id) {
        ask('Are you sure?', 'Do you really want to delete this Test Run?, this action will clear all the records.', function (yes) {

            if(yes){

                post('project/delete_run/' + id, {}, function (rep) {
                    if(rep.status === 'OK'){
                        toastr_('The Test Run was successfully deleted!', 'success', 'success');
                        table.twTable('refresh');
                    }else{
                        toastr_("We couldn't remove the selected Test Run", 'error', 'danger');
                    }
                })

            }else{

            }

        }, 'Yes', 'Cancel', true);
    }
    function changeRunStatus(id, status) {
        ask('Are you sure?', 'Do you really want to change the status of this Test Run?!', function (yes) {

            if(yes){

                post('project/change_run_status/', {id : id, status : status}, function (rep) {
                    if(rep.status === 'OK'){
                        toastr_('The Test Run was successfully updated!', 'success', 'success');
                        table.twTable('refresh');
                    }else{
                        toastr_("We couldn't update the selected Test Run", 'error', 'danger');
                    }
                })

            }else{

            }

        }, 'Yes', 'No', true);
    }
    function openRun(id) {
        log(id);
        loadView(site_url + 'project/' + project_id + '/runs/' + id);
    }

})();

(function () {
    var view = $('#task_form');
    if(!view.length) return;


    $(view)
        .on('change', '#date, #time', function () {
            var d = $('#date').val(),
                t = $('#time').val();

            log(d, t);
            if(d && t){
                var deadline = moment(d, 'YYYY-MM-DD').add(t, 'minutes').format('YYYY-MM-DD');
                $('#deadline').val(deadline).trigger('change');
            }
        })
})();