import {
  PENDING_FETCH_FILE,
  SET_FILE,
  SUCCESS_FETCH_FILE,
} from "../actions/types";

export default function (
  state = { isLoadingData: false, isDoSearch: false, data: [], keyword: null },
  action
) {
  switch (action.type) {
    case PENDING_FETCH_FILE:
      return {
        ...state,
        isLoadingData: true,
      };
    case SET_FILE:
      return { ...state, data: action.payload };
    case SUCCESS_FETCH_FILE:
      return {
        ...state,
        isLoadingData: false,
      };
    default:
      return state;
  }
}
