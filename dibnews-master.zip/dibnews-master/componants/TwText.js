import React, { Component } from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    ImageBackground,
    ActivityIndicator,
} from "react-native";
import { connect } from 'react-redux';

class TwText extends Component {

    state = {
        fontSize: 14,
    };


    render() {
        let style = ('style' in this.props.style) ? this.props.style : {};

        style.fontSize = this.state.fontSize;


        return (
            <Text style={style}>{this.props.text}</Text>
        );
    }

}

const styles = StyleSheet.create({

});


const mapStateToProps = (state) => {
    const { fontSize } = state;
    return { fontSize }
};

export default connect(mapStateToProps)(TwText);
