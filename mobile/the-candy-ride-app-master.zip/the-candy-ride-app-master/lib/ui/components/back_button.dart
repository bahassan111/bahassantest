import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rider_app/constants/constants.dart';

class CustomeBackButton extends StatelessWidget {
  const CustomeBackButton({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: SafeArea(
        child: Container(
          padding: EdgeInsets.only(left: 20, top: 20),
          child: GestureDetector(
            onTap: () => Get.back(),
            child: Image.asset(
              AllImages.backIcon,
              height: 25,
            ),
          ),
        ),
      ),
    );
  }
}
