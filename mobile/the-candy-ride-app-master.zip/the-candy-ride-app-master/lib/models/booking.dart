class Booking {
  String id;
  String dispatchId;
  String userId;
  String driverId;
  String rideStatus;
  String countryId;
  String pickupAddress;
  String dropAddress;
  String bookingDate;

  Booking({
    this.id,
    this.dispatchId,
    this.userId,
    this.driverId,
    this.rideStatus,
    this.countryId,
    this.pickupAddress,
    this.dropAddress,
    this.bookingDate,
  });
}
