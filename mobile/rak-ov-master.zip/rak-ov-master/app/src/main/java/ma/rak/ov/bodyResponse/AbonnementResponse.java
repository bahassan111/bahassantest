package ma.rak.ov.bodyResponse;

import com.google.gson.annotations.SerializedName;

import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;
import ma.rak.ov.models.Abonnement;

public class AbonnementResponse extends RealmObject {

    @PrimaryKey
    @SerializedName("id")
    private String id;

    @SerializedName("status")
    private String status;

    @SerializedName("last_date")
    private String lastDate;

    @SerializedName("total_operations")
    private int totalOperations;

    @SerializedName("total_page")
    private int totalPage;

    @SerializedName("total")
    private int total;

    @SerializedName("page")
    private int page;

    @SerializedName("pages")
    private int pages;

    @SerializedName("data")
    private RealmList<Abonnement> data;

    public AbonnementResponse() {
    }

    ;

    public AbonnementResponse(String status, String lastDate, int totalOperations, int totalPage, int total, int page, int pages, RealmList<Abonnement> data) {
        this.status = status;
        this.lastDate = lastDate;
        this.totalOperations = totalOperations;
        this.totalPage = totalPage;
        this.total = total;
        this.page = page;
        this.pages = pages;
        this.data = data;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLastDate() {
        return lastDate;
    }

    public void setLastDate(String lastDate) {
        this.lastDate = lastDate;
    }

    public int getTotalOperations() {
        return totalOperations;
    }

    public void setTotalOperations(int totalOperations) {
        this.totalOperations = totalOperations;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    public RealmList<Abonnement> getData() {
        return data;
    }

    public void setData(RealmList<Abonnement> data) {
        this.data = data;
    }
}
