package ma.rak.ovr.models;

import io.realm.RealmObject;

public class Statuses extends RealmObject {
    private String CODSTARE;
    private String LIBSTAAB;

    public Statuses() {
    }

    public Statuses(String codstare, String libstaab) {

        CODSTARE = codstare;
        LIBSTAAB = libstaab;
    }

    public String getCODSTARE() {
        return CODSTARE;
    }

    public void setCODSTARE(String CODSTARE) {
        this.CODSTARE = CODSTARE;
    }

    public String getLIBSTAAB() {
        return LIBSTAAB;
    }

    public void setLIBSTAAB(String LIBSTAAB) {
        this.LIBSTAAB = LIBSTAAB;
    }

    @Override
    public String toString() {
        return "Statuses{" +
                "CODSTARE='" + CODSTARE + '\'' +
                ", LIBSTAAB='" + LIBSTAAB + '\'' +
                '}';
    }
}

