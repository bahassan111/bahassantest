import 'package:flutter/material.dart';
import 'package:rider_app/constants/app_themes.dart';

class RoundButton extends StatelessWidget {
  final String text;
  final Function onTap;
  RoundButton({this.text, this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 12),
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          color: AppThemes.lightpauaBackGroundColor,
        ),
        child: Center(
          child: Text(
            text,
            style: Theme.of(context).textTheme.subtitle1.copyWith(
                fontFamily: 'NunitoSans',
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w700),
          ),
        ),
      ),
    );
  }
}
