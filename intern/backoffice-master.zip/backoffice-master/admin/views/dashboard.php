<div id="dashboard">

    <div class="dashboard_intro">
        <h3>Bienvenue dans l'espace d'administration de l'application mobile MTIP.</h3>
        <p>Commencez à gérer l'application en utilisant cet espace et les sections ci-dessous sont disponibles pour vous</p>
    </div>

    <div class="dashboard_cards">


        <?php foreach(config()->admin_menu as $name => $menu){

            if($name!='dashboard' && in_array($name,$sections_actifs)){

                $menu['url'] = $menu['url'] != '#' ? site_url($menu['url']) : '#';
                ?>

                <a href="<?= $menu['url']; ?>" class="dashboard_card">
                    <i class="<?= $menu['icon']; ?>"></i>
                    <b><?= $menu['text']; ?></b>
                    <span><?= isset($menu['description']) ? $menu['description'] : ''; ?></span>
                    <?php if(false && isset($menu['items'])){?>
                        <span class="d tr"><i class="fa fa-angle-down"></i></span>
                    <?php } ?>
                </a>


            <?php } } ?>

    </div>





</div>