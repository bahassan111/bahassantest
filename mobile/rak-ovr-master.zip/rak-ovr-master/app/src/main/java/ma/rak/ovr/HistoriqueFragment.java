package ma.rak.ovr;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.PopupMenu;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import java.util.List;

import io.realm.Realm;
import ma.rak.ovr.adapter.DemandesAdapter;
import ma.rak.ovr.bodyResponse.HistoriqueAbonnementResponse;
import ma.rak.ovr.bodyResponse.HistoriqueBranchementResponse;
import ma.rak.ovr.models.Abonnement;
import ma.rak.ovr.models.Branchement;
import ma.rak.ovr.storage.SharedPrefManager;
import ma.rak.ovr.ui.main.DemandViewModel;


public class HistoriqueFragment extends Fragment implements
        AdapterView.OnItemSelectedListener {

    public RecyclerView recyclerView;
    private SwipeRefreshLayout swipeContainer;
    private FrameLayout progressOverlay;
    private List<Branchement> branchementsList = null;
    private List<Abonnement> abonnementList = null;

    String[] status = {"Exécutées", "Rejetées"};
    int archivePosition = 2;
    int spinnerPosition = 0;

    private TextView listTitle, notFoundMsg;
    private Spinner spinner;
    TextView hamMenu;
    private DemandViewModel demandViewModel;

    DemandesAdapter demandeAdapter = null;

    Realm realm;

    HistoriqueBranchementResponse newHistoriqueBrResponse = null;
    HistoriqueAbonnementResponse newHistoriqueAbResponse = null;
    private String token = "";

    public HistoriqueFragment() {
        // Required empty public constructor
    }

    public static HistoriqueFragment newInstance(String param1, String param2) {
        HistoriqueFragment fragment = new HistoriqueFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_historique, container, false);

        token = SharedPrefManager.getInstance(getActivity()).getToken();
        listTitle = (TextView) rootView.findViewById(R.id.listTitle);
        notFoundMsg = (TextView) rootView.findViewById(R.id.not_found_msg);

        progressOverlay = rootView.findViewById(R.id.progress_overlay);
        progressOverlay.setVisibility(View.VISIBLE);

        spinner = (Spinner) rootView.findViewById(R.id.status_spinner);
        spinner.setOnItemSelectedListener(this);
        if (SharedPrefManager.getInstance(getActivity()).getMode() == 1) {
            spinner.setVisibility(View.INVISIBLE);
        } else {
            spinner.setVisibility(View.VISIBLE);
            progressOverlay.setVisibility(View.VISIBLE);
        }

//        TextView hamMenu = getActivity().findViewById(R.id.toolbarUserMenu);
//        hamMenu.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                showPopup(v);
//            }
//        });

        recyclerView = rootView.findViewById(R.id.list);
        swipeContainer = rootView.findViewById(R.id.swipeContainer);
        swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                fetchData(0, token);
                swipeContainer.setRefreshing(false);

            }
        });
        swipeContainer.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light);

        ArrayAdapter aa = new ArrayAdapter(getActivity(), android.R.layout.simple_spinner_item, status);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        aa.notifyDataSetChanged();
        spinner.setAdapter(aa);
//        spinner.setSelection(spinnerPosition);

        return rootView;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        realm.close();
    }

    public void showPopup(View v) {
        PopupMenu popup = new PopupMenu(getActivity(), v);
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {

                    case R.id.action_branchement:
                        if (SharedPrefManager.getInstance(getActivity()).isLogged()) {
                            SharedPrefManager.getInstance(getActivity()).operationMode(1);
                            Toast.makeText(getActivity(), R.string.mode_branchement, Toast.LENGTH_SHORT).show();
                            fetchData(0, token);
                            spinner.setVisibility(View.INVISIBLE);
                            hamMenu.setText("Branchement");
                            getActivity().finish();
                            startActivity(getActivity().getIntent());
                        }
                        return true;
                    case R.id.action_abonnements:
                        if (SharedPrefManager.getInstance(getActivity()).isLogged()) {
                            SharedPrefManager.getInstance(getActivity()).operationMode(2);
                            Toast.makeText(getActivity(), R.string.mode_abonnement, Toast.LENGTH_SHORT).show();
                            fetchData(0, token);
                            spinner.setVisibility(View.VISIBLE);
                            hamMenu.setText("Abonnement");
                            getActivity().finish();
                            startActivity(getActivity().getIntent());
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });
        popup.inflate(R.menu.toolbar_menu);
        popup.show();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        realm = Realm.getDefaultInstance();
        demandViewModel = ViewModelProviders.of(this).get(DemandViewModel.class);
//        if (SharedPrefManager.getInstance(getActivity()).getMode() == 1) {
//            demandViewModel.getHistoriquesBr(token);
//        } else {
//            demandViewModel.getHistoriquesAb(token, 0);
//        }
        fetchData(0, token);
    }

    public void fetchData(int status, String token) {
        progressOverlay.setVisibility(View.VISIBLE);
        /*demandeAdapter = new DemandesAdapter(getActivity(), branchementsList, abonnementList);
        if (SharedPrefManager.getInstance(getActivity()).getMode() == 1) {
            listTitle.setText(getString(R.string.operationHistoryBr));

            demandViewModel.getHistoriquesBr(token);
            newHistoriqueBrResponse = new HistoriqueBranchementResponse();
            demandViewModel.HistoriqueBrResponseMutableLiveData.observe(getActivity(), new Observer<HistoriqueBranchementResponse>() {
                @Override
                public void onChanged(HistoriqueBranchementResponse branchementResponse) {
                    newHistoriqueBrResponse = branchementResponse;
                    demandeAdapter.setList(branchementResponse.getData(), null);
                }

            });

        } else {
            listTitle.setText(getString(R.string.operationHistoryAb));
            demandViewModel.getHistoriquesAb(token, status);
            newHistoriqueAbResponse = new HistoriqueAbonnementResponse();
            demandViewModel.HistoriqueAbResponseMutableLiveData.observe(getActivity(), new Observer<HistoriqueAbonnementResponse>() {
                @Override
                public void onChanged(HistoriqueAbonnementResponse abonnementResponse) {
                    demandeAdapter.setList(null, abonnementResponse.getData());
                    newHistoriqueAbResponse = abonnementResponse;

                }
            });

        }*/
        progressOverlay.setVisibility(View.INVISIBLE);
        recyclerView.setAdapter(demandeAdapter);

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        spinnerPosition = position;

        if (position == 0) {
            archivePosition = 2;
        } else if (position == 1) {
            archivePosition = 3;
        }

        fetchData(archivePosition, token);

        Toast.makeText(getActivity(), "" + archivePosition, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}