(function () {
    var view = $('#login_body');
    if(!view.length) return;

    $(document)
        .on('mouse', '.tw_checkbox input, .tw_checkbox label', function () {

            var checked = $(this).parent().find('input').attr('checked');
            console.log(checked);
            $(this).parent().find('input').attr('checked', !checked);
        })

        .on('submit', 'form', function (e) {
            console.log('a');
            var form = $(this);

            e.preventDefault();
            var holder = $('.login_holder').addClass('loading');

            $('.lgi_error').fadeOut(function () {
                $(this).remove();
            });
            $
                .post('', form.serialize(), function (rep) {
                    if(rep.status === 'OK'){
                        holder.addClass('entring');
                        location.href = site_url;
                    }else{
                        $('.lgi_text').append(`<div class="lgi_error">${rep.message || 'Error while login in ..'}</div>`);
                        $('.lgi_error').html();
                    }
                })
                .fail(function () {

                })
                .always(function () {
                    holder.removeClass('loading');
                })

        })
        .ready(function () {
            $('.login_holder').removeClass('entring');
        })
    ;


})();