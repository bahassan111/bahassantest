class VehicleCategorytype {
  String id;
  String name;

  VehicleCategorytype({this.id, this.name});

  VehicleCategorytype.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }
}
