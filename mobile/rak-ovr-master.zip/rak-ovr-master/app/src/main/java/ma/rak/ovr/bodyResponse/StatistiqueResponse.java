package ma.rak.ovr.bodyResponse;

import com.google.gson.annotations.SerializedName;

import java.util.Date;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class StatistiqueResponse extends RealmObject {

    @PrimaryKey
    private String id;

    private Date createdAt = new Date();

    @SerializedName("total")
    private String total;

    @SerializedName("rejetees")
    private String rejetees;

    @SerializedName("en_cours")
    private String en_cours;

    @SerializedName("executees")
    private String executees;

    @SerializedName("annulees")
    private String annulees;

    public StatistiqueResponse() {
    }


    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getRejetees() {
        return rejetees;
    }

    public void setRejetees(String rejetees) {
        this.rejetees = rejetees;
    }

    public String getEn_cours() {
        return en_cours;
    }

    public void setEn_cours(String en_cours) {
        this.en_cours = en_cours;
    }

    public String getExecutees() {
        return executees;
    }

    public void setExecutees(String executees) {
        this.executees = executees;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "StatistiqueResponse{" +
                "id='" + id + '\'' +
                ", createdAt=" + createdAt +
                ", total='" + total + '\'' +
                ", rejetees='" + rejetees + '\'' +
                ", en_cours='" + en_cours + '\'' +
                ", executees='" + executees + '\'' +
                ", annulees='" + annulees + '\'' +
                '}';
    }

    public String getAnnulees() {
        return annulees;
    }

    public void setAnnulees(String annulees) {
        this.annulees = annulees;
    }
}
