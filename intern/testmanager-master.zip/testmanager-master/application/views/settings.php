<?php

addJS([
    'assets/js/views/settings.js',
]);



viewHeader(
        'System settings',
        '',
        [
            (object) ['name' => 'Dashboard', 'url' => site_url()],
            (object) ['name' => 'Settings', 'url' => ''],
        ], true);

projectMenu('dashboard', $project);
?>





<div class="project_body n_menu">



    <div class="project_quicknav_container">
        <div class="project_quicknav">
            <a href="#">
                <span class="i"><i class="fas fa-tasks"></i></span>
                <span class="n">Taks</span>
            </a>
            <a href="#">
                <span class="i"><i class="fas fa-signal"></i></span>
                <span class="n">Grant</span>
            </a>
            <a href="<?= getProjectUrl($project, 'tests'); ?>">
                <span class="i"><i class="fas fa-sitemap"></i></span>
                <span class="n">Test Plans</span>
            </a>
            <a href="<?= getProjectUrl($project, 'runs'); ?>">
                <span class="i"><i class="fas fa-cogs"></i></span>
                <span class="n">Test Runs</span>
            </a>
            <a href="#">
                <span class="i"><i class="far fa-hdd"></i></span>
                <span class="n">Files</span>
            </a>
        </div>
    </div>

    <div class="hidden project_actions_overview">

        <div class="paction_item b">
            <div class="h">
                <label>Tasks</label>
                <i></i>
                <p><b>50</b> Tasks in total </p>
                <div class="i"><i class="fas fa-tasks"></i></div>
            </div>
            <div class="d">
                <p><span>Tasks are awaiting affectation</span> <b>50</b></p>
                <p><span>Tasks done today</span> <b>4</b></p>
                <p><span>Opened tasks</span> <b>3</b></p>

                <a href="#">View all tasks</a>
            </div>
        </div>

        <div class="paction_item r">
            <div class="h">
                <label>Test Plans</label>
                <i></i>
                <p><b>50</b> Plans in total </p>
                <div class="i"><i class="fas fa-cogs"></i></div>
            </div>
            <div class="d">
                <p><span>Finished plans</span> <b>50</b></p>
                <p><span>Plans created today</span> <b>4</b></p>
                <p><span>Open plans</span> <b>3</b></p>

                <a href="#">View all Test Plans</a>
            </div>
        </div>

        <div class="paction_item g">
            <div class="h">
                <label>Test Runs</label>
                <i></i>
                <p><b>50</b> Run in total </p>
                <div class="i"><i class="fas fa-cogs"></i></div>
            </div>
            <div class="d">
                <p><span>Successed runs</span> <b>50</b></p>
                <p><span>Failed runs</span> <b>4</b></p>
                <p><span>Planified runs</span> <b>3</b></p>
                <p><span>Pending runs</span> <b>3</b></p>

                <a href="#">View all Test Plans</a>
            </div>
        </div>

        <div class="paction_item y">
            <div class="h">
                <label>Test Runs</label>
                <i></i>
                <p><b>50</b> Run in total </p>
                <div class="i"><i class="fas fa-cogs"></i></div>
            </div>
            <div class="d">
                <p><span>Successed runs</span> <b>50</b></p>
                <p><span>Failed runs</span> <b>4</b></p>
                <p><span>Planified runs</span> <b>3</b></p>
                <p><span>Pending runs</span> <b>3</b></p>

                <a href="#">View all Test Plans</a>
            </div>
        </div>

    </div>


</div>


<div class="hidden container-fluid hide">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb breadcrumb-style1 mg-b-10">
                    <li class="breadcrumb-item"><a href="<?= site_url(); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?= site_url('projects'); ?>">Projects</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?= $project->name; ?></li>
                </ol>
            </nav>
            <h4 class="mg-b-0 tx-spacing--1"><?= $project->name; ?></h4>
        </div>
        <div class="d-none d-md-block">
            <button class="btn btn-sm pd-x-15 btn-white btn-uppercase"><i class="fas fa-pencil"></i> Edit</button>
            <button class="btn btn-sm pd-x-15 btn-white btn-uppercase mg-l-5"><i class="fas fa-trash"></i> Remove</button>
            <button id="create_project" class="btn btn-sm pd-x-15 btn-primary btn-uppercase mg-l-5"><i class="fas fa-lock"></i> Close Project</button>
            <button class="btn btn-sm pd-x-15 btn-white btn-uppercase mg-l-5 refresproject"><i class="fas fa-sync-alt"></i></button>
        </div>
    </div>






    <div class="card">
        <div class="card-footer pd-y-15 pd-x-20">
            <div class="row row-sm">
                <div class="col-6 col-sm-4 col-md-3 col-lg">
                    <h4 class="tx-normal tx-rubik mg-b-10">0</h4>
                    <div class="progress ht-2 mg-b-10">
                        <div class="progress-bar wd-100p bg-df-2" role="progressbar" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <h6 class="tx-uppercase tx-spacing-1 tx-semibold tx-10 tx-color-02 mg-b-2">Total Functions</h6>
                    <p class="tx-10 tx-color-03 mg-b-0"><span class="tx-medium tx-success">1.2% <i class="icon ion-md-arrow-down"></i></span> compared to the average</p>
                </div><!-- col -->
                <div class="col-6 col-sm-4 col-md-3 col-lg">
                    <h4 class="tx-normal tx-rubik mg-b-10">0</h4>
                    <div class="progress ht-2 mg-b-10">
                        <div class="progress-bar wd-85p bg-df-2" role="progressbar" aria-valuenow="6" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <h6 class="tx-uppercase tx-spacing-1 tx-semibold tx-10 tx-color-02 mg-b-2">Test Cases</h6>
                    <p class="tx-10 tx-color-03 mg-b-0"><span class="tx-medium tx-danger">-0.6% <i class="icon ion-md-arrow-down"></i></span> Passed</p>
                </div><!-- col -->
                <div class="col-6 col-sm-4 col-md-3 col-lg mg-t-20 mg-sm-t-0">
                    <h4 class="tx-normal tx-rubik mg-b-10">0</h4>
                    <div class="progress ht-2 mg-b-10">
                        <div class="progress-bar wd-25p bg-df-2" role="progressbar" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <h6 class="tx-uppercase tx-spacing-1 tx-semibold tx-10 tx-color-02 mg-b-2">Passes</h6>
                    <p class="tx-10 tx-color-03 mg-b-0"><span class="tx-medium tx-success">0.3% <i class="icon ion-md-arrow-down"></i></span> compared to average</p>
                </div><!-- col -->
                <div class="col-6 col-sm-4 col-md-3 col-lg mg-t-20 mg-md-t-0">
                    <h4 class="tx-normal tx-rubik mg-b-10">0</h4>
                    <div class="progress ht-2 mg-b-10">
                        <div class="progress-bar wd-45p bg-df-2" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <h6 class="tx-uppercase tx-spacing-1 tx-semibold tx-10 tx-color-02 mg-b-2">Bugs</h6>
                    <p class="tx-10 tx-color-03 mg-b-0"><span class="tx-medium tx-success">0.3% <i class="icon ion-md-arrow-down"></i></span> compared to average</p>
                </div><!-- col -->
                <div class="col-6 col-sm-4 col-md-3 col-lg mg-t-20 mg-lg-t-0">
                    <h4 class="tx-normal tx-rubik mg-b-10">0</h4>
                    <div class="progress ht-2 mg-b-10">
                        <div class="progress-bar wd-30p bg-df-2" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <h6 class="tx-uppercase tx-spacing-1 tx-semibold tx-10 tx-color-02 mg-b-2">Team members</h6>
                    <p class="tx-10 tx-color-03 mg-b-0"><span class="tx-medium tx-success">0.3% <i class="icon ion-md-arrow-down"></i></span> compared to average</p>
                </div><!-- col -->
            </div>
        </div>
    </div>



    <div class="row row-sm mt-3">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header pd-b-0 pd-x-20 bd-b-0">
                    <div class="d-sm-flex align-items-center justify-content-between">
                        <h6 class="mg-b-0">Recent Activities</h6>
                        <p class="tx-12 tx-color-03 mg-b-0 lastone"></p>
                    </div>
                </div><!-- card-header -->
                <div class="card-body pd-20 factivity">
                    <ul class="activity tx-13">
                        <li class="nodata">No activity yet</li>
                    </ul>

                </div><!-- card-body -->
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header pd-b-0 pd-t-20 bd-b-0">
                    <h6 class="mg-b-0">Customer Satisfaction</h6>
                </div><!-- card-header -->
                <div class="card-body pd-y-10">
                    <div class="d-flex align-items-baseline tx-rubik">
                        <h1 class="tx-40 lh-1 tx-normal tx-spacing--2 mg-b-5 mg-r-5">9.8</h1>
                        <p class="tx-11 tx-color-03 mg-b-0"><span class="tx-medium tx-success">1.6% <i class="icon ion-md-arrow-up"></i></span></p>
                    </div>
                    <h6 class="tx-uppercase tx-spacing-1 tx-semibold tx-10 tx-color-02 mg-b-15">Performance Score</h6>

                    <div class="progress bg-transparent op-7 ht-10 mg-b-15">
                        <div class="progress-bar bg-primary wd-50p" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
                        <div class="progress-bar bg-success wd-25p bd-l bd-white" role="progressbar" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div>
                        <div class="progress-bar bg-warning wd-5p bd-l bd-white" role="progressbar" aria-valuenow="5" aria-valuemin="0" aria-valuemax="100"></div>
                        <div class="progress-bar bg-pink wd-5p bd-l bd-white" role="progressbar" aria-valuenow="5" aria-valuemin="0" aria-valuemax="100"></div>
                        <div class="progress-bar bg-teal wd-10p bd-l bd-white" role="progressbar" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>
                        <div class="progress-bar bg-purple wd-5p bd-l bd-white" role="progressbar" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>

                    <table class="table-dashboard-two" style="width: 100%">
                        <tbody>
                        <tr>
                            <td><div class="wd-12 ht-12 rounded-circle bd bd-3 bd-primary"></div></td>
                            <td class="tx-medium">Excellent</td>
                            <td class="text-right">3,007</td>
                            <td class="text-right">50%</td>
                        </tr>
                        <tr>
                            <td><div class="wd-12 ht-12 rounded-circle bd bd-3 bd-success"></div></td>
                            <td class="tx-medium">Very Good</td>
                            <td class="text-right">1,674</td>
                            <td class="text-right">25%</td>
                        </tr>
                        <tr>
                            <td><div class="wd-12 ht-12 rounded-circle bd bd-3 bd-warning"></div></td>
                            <td class="tx-medium">Good</td>
                            <td class="text-right">125</td>
                            <td class="text-right">6%</td>
                        </tr>
                        <tr>
                            <td><div class="wd-12 ht-12 rounded-circle bd bd-3 bd-pink"></div></td>
                            <td class="tx-medium">Fair</td>
                            <td class="text-right">98</td>
                            <td class="text-right">5%</td>
                        </tr>
                        <tr>
                            <td><div class="wd-12 ht-12 rounded-circle bd bd-3 bd-teal"></div></td>
                            <td class="tx-medium">Poor</td>
                            <td class="text-right">512</td>
                            <td class="text-right">10%</td>
                        </tr>
                        <tr>
                            <td><div class="wd-12 ht-12 rounded-circle bd bd-3 bd-purple"></div></td>
                            <td class="tx-medium">Very Poor</td>
                            <td class="text-right">81</td>
                            <td class="text-right">4%</td>
                        </tr>
                        </tbody>
                    </table>
                </div><!-- card-body -->
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <h6 class="mg-b-0">Transaction History</h6>
                    <div class="d-flex tx-18">
                        <a href="" class="link-03 lh-0"><i class="icon ion-md-refresh"></i></a>
                        <a href="" class="link-03 lh-0 mg-l-10"><i class="icon ion-md-more"></i></a>
                    </div>
                </div>
                <ul class="list-group list-group-flush tx-13">
                    <li class="list-group-item d-flex pd-sm-x-20">
                        <div class="avatar d-none d-sm-block"><span class="avatar-initial rounded-circle bg-indigo op-5"><i class="icon ion-md-return-left"></i></span></div>
                        <div class="pd-sm-l-10">
                            <p class="tx-medium mg-b-2">Process refund to #00910</p>
                            <small class="tx-12 tx-color-03 mg-b-0">Mar 21, 2019, 1:00pm</small>
                        </div>
                        <div class="mg-l-auto text-right">
                            <p class="tx-medium mg-b-2">-$16.50</p>
                            <small class="tx-12 tx-success mg-b-0">Completed</small>
                        </div>
                    </li>
                    <li class="list-group-item d-flex pd-sm-x-20">
                        <div class="avatar d-none d-sm-block"><span class="avatar-initial rounded-circle bg-orange op-5"><i class="icon ion-md-bus"></i></span></div>
                        <div class="pd-sm-l-10">
                            <p class="tx-medium mg-b-2">Process delivery to #44333</p>
                            <small class="tx-12 tx-color-03 mg-b-0">Mar 20, 2019, 11:40am</small>
                        </div>
                        <div class="mg-l-auto text-right">
                            <p class="tx-medium mg-b-2">3 Items</p>
                            <small class="tx-12 tx-info mg-b-0">For pickup</small>
                        </div>
                    </li>
                    <li class="list-group-item d-flex pd-sm-x-20">
                        <div class="avatar d-none d-sm-block"><span class="avatar-initial rounded-circle bg-teal"><i class="icon ion-md-checkmark"></i></span></div>
                        <div class="pd-sm-l-10">
                            <p class="tx-medium mg-b-0">Payment from #023328</p>
                            <small class="tx-12 tx-color-03 mg-b-0">Mar 20, 2019, 10:30pm</small>
                        </div>
                        <div class="mg-l-auto text-right">
                            <p class="tx-medium mg-b-0">+ $129.50</p>
                            <small class="tx-12 tx-success mg-b-0">Completed</small>
                        </div>
                    </li>
                    <li class="list-group-item d-flex pd-sm-x-20">
                        <div class="avatar d-none d-sm-block"><span class="avatar-initial rounded-circle bg-gray-400"><i class="icon ion-md-close"></i></span></div>
                        <div class="pd-sm-l-10">
                            <p class="tx-medium mg-b-0">Payment failed from #087651</p>
                            <small class="tx-12 tx-color-03 mg-b-0">Mar 19, 2019, 12:54pm</small>
                        </div>
                        <div class="mg-l-auto text-right">
                            <p class="tx-medium mg-b-0">$150.00</p>
                            <small class="tx-12 tx-danger mg-b-0">Declined</small>
                        </div>
                    </li>
                </ul>
                <div class="card-footer text-center tx-13">
                    <a href="" class="link-03">View All Transactions <i class="icon ion-md-arrow-down mg-l-5"></i></a>
                </div><!-- card-footer -->
            </div>
        </div>
    </div>

    <hr class="mg-y-40">

    <div class="row-sm">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header d-flex align-items-center justify-content-between">
                    <h6 class="mg-b-0">Test Plans</h6>
                    <div class="d-flex tx-18">
                        <a href="javascript:void(0);" class="link-03 lh-0 mr-3 search_list"><i class="icon ion-md-search"></i></a>
                        <a id="add_plan" href="javascript:void(0);" class="link-03 lh-0"><i class="icon ion-md-add"></i></a>
                    </div>
                </div>
                <div class="flist_scroll">
                    <ul class="list-group list-group-flush tx-13 plans_list">
                        <p class="nodata">No plans yet.</p>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div data-label="" class="pb-5">

    </div>


    <script>
        var project_id = <?= $project->id ?: 0 ?>;
    </script>