﻿namespace CCISFMMND
{
    partial class DbExplore
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.WinControls.UI.ListViewDetailColumn listViewDetailColumn1 = new Telerik.WinControls.UI.ListViewDetailColumn("Column 0", "NOM & Prénom");
            Telerik.WinControls.UI.ListViewDetailColumn listViewDetailColumn2 = new Telerik.WinControls.UI.ListViewDetailColumn("Column 1", "RIB");
            this.list = new Telerik.WinControls.UI.RadListView();
            this.nom = new Telerik.WinControls.UI.RadTextBox();
            this.del = new Telerik.WinControls.UI.RadButton();
            ((System.ComponentModel.ISupportInitialize)(this.list)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.del)).BeginInit();
            this.SuspendLayout();
            // 
            // list
            // 
            this.list.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            listViewDetailColumn1.HeaderText = "NOM & Prénom";
            listViewDetailColumn2.HeaderText = "RIB";
            this.list.Columns.AddRange(new Telerik.WinControls.UI.ListViewDetailColumn[] {
            listViewDetailColumn1,
            listViewDetailColumn2});
            this.list.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.list.ItemSpacing = -1;
            this.list.Location = new System.Drawing.Point(12, 46);
            this.list.MultiSelect = true;
            this.list.Name = "list";
            this.list.ShowGridLines = true;
            this.list.Size = new System.Drawing.Size(766, 468);
            this.list.TabIndex = 1;
            this.list.ViewType = Telerik.WinControls.UI.ListViewType.DetailsView;
            this.list.SelectedItemChanged += new System.EventHandler(this.list_SelectedItemChanged);
            this.list.ItemMouseClick += new Telerik.WinControls.UI.ListViewItemEventHandler(this.list_ItemMouseClick);
            this.list.ItemMouseDoubleClick += new Telerik.WinControls.UI.ListViewItemEventHandler(this.list_ItemMouseDoubleClick);
            // 
            // nom
            // 
            this.nom.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nom.Location = new System.Drawing.Point(12, 10);
            this.nom.Name = "nom";
            this.nom.NullText = "Rechercher par Nom our par RIB ..";
            this.nom.Padding = new System.Windows.Forms.Padding(4);
            this.nom.Size = new System.Drawing.Size(794, 30);
            this.nom.TabIndex = 2;
            this.nom.TextChanged += new System.EventHandler(this.nom_TextChanged);
            // 
            // del
            // 
            this.del.Enabled = false;
            this.del.Location = new System.Drawing.Point(784, 46);
            this.del.Name = "del";
            this.del.Size = new System.Drawing.Size(22, 38);
            this.del.TabIndex = 3;
            this.del.Text = "x";
            this.del.Click += new System.EventHandler(this.del_Click);
            // 
            // DbExplore
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(815, 526);
            this.Controls.Add(this.del);
            this.Controls.Add(this.nom);
            this.Controls.Add(this.list);
            this.Name = "DbExplore";
            this.Text = "DbExplore";
            this.Load += new System.EventHandler(this.DbExplore_Load);
            this.Resize += new System.EventHandler(this.DbExplore_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.list)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.del)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Telerik.WinControls.UI.RadListView list;
        private Telerik.WinControls.UI.RadTextBox nom;
        private Telerik.WinControls.UI.RadButton del;

    }
}