package ma.rak.ovr.models;

public class Statistique {
}
