<?php
function hasPermission($page_name, $action = Pages::ACTION_ANY){
    $that =& get_instance();
    if(!isset($that->_pages)) $that->_pages = $that->db->get_where('__pages', ['deleted' => 0])->result();


    $page = new Page(null, $page_name);

    return $page->hasPermission($action);





}

class Pages {
    public const ACTION_ANY = 'any';
    public const ACTION_ADD = 'add';
    public const ACTION_READ = 'read';
    public const ACTION_EDIT = 'edit';
    public const ACTION_DELETE = 'delete';
    public const ACTION_EXTRA = 'extra';


    public static function get_permissions($page_name){
        return (new Page(null, $page_name))->get_permissions();
    }

}

class Page {

    protected $ci;
    public $info;
    public $actions;

    public function __construct($id, $name = FALSE, $title = FALSE)
    {
        $this->ci =& get_instance();
        $page = null;

        if(!$id && $name){
            $exists = $this->ci->db->get_where('__pages', ['name' => $name]);
            if($exists && $exists->num_rows() > 0){
                $page = $exists->row();
            }else{
                $title = $title ?: $name;
                $q = $this->ci->db->insert('__pages',
                    [
                        'name' => $name,
                        'title' => str_replace('_', ' ', ucfirst($name)),
                        'actions' => json_encode([
                            (object)['name' => Pages::ACTION_ADD, 'title' => 'Add'],
                            (object)['name' => Pages::ACTION_EDIT, 'title' => 'Edit'],
                            (object)['name' => Pages::ACTION_DELETE, 'title' => 'Delete'],
                            (object)['name' => Pages::ACTION_READ, 'title' => 'View'],
                        ]),
                    ]);

                $page = $this->ci->db->get_where('__pages', ['name' => $name])->row();
            }
        }else{
            $page = $this->ci->db->get_where('__pages', ['id' => $id])->row();

        }

        if(!$page){
            echo "ERROR";die;
        }else{
            $this->actions = json_decode($page->actions);
            $this->info = $page;
        }
    }

    public function get_permissions(){
        if(userInfo()->is_admin){
            $p = $this->actions;
        }else{
            $p = $this->ci->db->get_where('__permissions', ['id_page' => $this->info->id, 'id_group' => userInfo()->group_id])->result();
        }

        $list = [];
        foreach ($p as $item) {
            if(userInfo()->is_admin){
                $list[] = $item->name;
            }else{
                $list[] = $item->action;
            }
        };
        return $list;
    }

    public function hasPermission($action = Pages::ACTION_ANY){
        $id = userInfo()->id;
        $group = userInfo()->group_id;

        $action_exisits = FALSE;
        foreach ($this->actions as $ax){
            if($ax->name === $action) {
                $action_exisits = TRUE;
                break;
            }
        }

        if(!$action_exisits && $action !== Pages::ACTION_ANY){
            $this->actions[] = (object)['name' => $action, 'title' => ucfirst($action)];
            $this->ci->db->update('__pages', ['actions' => json_encode($this->actions)], ['id' => $this->info->id]);
        }

        if(userInfo()->is_admin) return TRUE;

        $filter = ['id_page' => $this->info->id, 'id_group' => $group];

        if($action !== Pages::ACTION_ANY){
            $filter['action'] = $action;
        }

        $q = $this->ci->db->get_where('__permissions', $filter);

        return $q->num_rows() > 0;
    }
}