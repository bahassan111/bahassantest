<?php
define('BASE', __DIR__.'/');

require_once "../includes/helper.php";
require_once "../includes/Session.php";
require_once "../includes/Database.php";


$page       = __($_GET)->page;
$c          = __($_GET)->c ?: 'admin';

if(isset($_GET['404'])){
    include "../404.html";
    die;
}

if($page){
    $c = ucfirst($c);
    if(file_exists($c).".php"){

        define('ROOT', str_replace('\admin', '', __DIR__));
        include_once $c.".php";
        $controller = new $c();

        if(method_exists($controller, $page)){
            $controller->{$page}();
        }else{
            include "../404.html";
        }

    }else{
        include "../404.html";
    }



}else{
    Header("Location: ?page=dashboard");
}




