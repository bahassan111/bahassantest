(function () {
    var view = $('#runs_view');
    if (!view.length) return;

    var table = $('.runs_list');

    $(view)


        .on('click', '.add_run', function () {
            createRun();
        })
        .ready(function () {

            table.twTable({

                url     : site_url + 'project/get_runs/' + project_id,
                key     : 'id',
                dblclick : function(id, tr){
                    loadView(site_url + 'project/' + project_id + '/run/' + id);
                },
                columns : [
                    {name : 'id', data : 'ref', title : 'ID', orderable : true, searchable : false},
                    {name : 'title', data : 'title', title : 'Name', orderable : true, searchable : true},
                    {name : 'release', data : 'release', title : 'Release', orderable : true, searchable : true},
                    {name : 'assigned', data : 'assigned', title : 'Assigned To', orderable : true, searchable : true},
                    {name : 'status', data : 'st', title : 'Status', orderable : true, searchable : true},
                    {name : 'cases', data : 'cases', title : 'Test Cases', orderable : false, searchable : false},
                    {name : 'stat', data : 'stat', title : 'Status', orderable : false, searchable : false},
                    {name : 'date', data : 'date', title : 'Date', orderable : true, searchable : true},
                ],

                buttons : [
                    {
                        text : 'Create',
                        icon : 'fas fa-plus',
                        color : 'primary',
                        global : true,
                        remote : 'add',
                        action : function(){
                            createRun();
                        },
                    },
                    {
                        separator : true,
                    },

                    {
                        text : 'RUN',
                        icon : 'fas fa-play',
                        color : 'success',
                        remote : 'run',
                        global : false,
                        action : function(id){
                            loadView(site_url + 'project/' + project_id + '/run/' + id);
                        },
                    },
                    {
                        separator : true,
                    },
                    {
                        title : 'View Test Cases',
                        icon : 'fas fa-eye',
                        global : false,
                        remote : 'manage_cases',
                        action : function(id){
                            openRun(id);
                        },
                    },
                    {
                        title : 'Edit infos',
                        icon : 'fas fa-pencil-alt',
                        global : false,
                        remote : 'edit',
                        action : function(id){
                            createRun(id);
                        },
                    },
                    {
                        title : 'Delete the test run',
                        icon : 'fas fa-times',
                        global : false,
                        remote : 'delete',
                        action : function(id){
                            deleteRun(id)
                        },
                    },
                    {
                        title : 'Copy the test run',
                        icon : 'far fa-copy',
                        global : false,
                        remote : 'add',
                        action : function(){},
                    },
                    {separator: true},
                    {
                        title : 'Mark as finished and close',
                        icon : 'fas fa-check',
                        global : false,
                        remote : 'edit',
                        condition : function(row){
                            return row.status < 3 && row.status >= 1;
                        },
                        action : function(id){
                            changeRunStatus(id, 3);
                        },
                    },
                    {
                        title : 'Mark as Open',
                        icon : 'far fa-folder-open',
                        global : false,
                        remote : 'edit',
                        condition : function(row){
                            return row.status === '0';
                        },
                        action : function(id){
                            changeRunStatus(id, 1);
                        },
                    },
                    {
                        title : 'Reopen the Test RUN',
                        icon : 'fas fa-undo',
                        remote : 'edit',
                        global : false,
                        condition : function(row){
                            return row.status === '3';
                        },
                        action : function(id){
                            changeRunStatus(id, 1);
                        },
                    },

                ],

            });





            /*initDatatable(table, [

                {name : 'id', data : 'id', title : 'ID', orderable:true, searchable:true},
                {name : 'title', data : 'title', title : 'Title', orderable:true, searchable:true},
                {name : 'status', data : 'status', title : 'Status', orderable:false, searchable:false},
                {name : 'username', data : 'username', title : 'Assigned to', orderable:true, searchable:true},
                {name : 'date', data : 'date_added', title : 'Date', orderable:true, searchable:true},
                {name : 'last_run', data : 'last_run', title : 'Last run', orderable:true, searchable:true},

            ], {ajax : site_url + 'project/dt_runs'})*/
        })
    ;


    function createRun(id) {

        ajaxSideModal('project/one_run/' + project_id + '/' + (id || ''), (id ? 'Edit' : 'Create')  + ' a Test Run', 'far fa-paper-plane', {
            close_text : 'Cancel',
            confirm_text : 'Save',
            size: 'md',
            whenLoaded : function(modal, data){
                handleInits(modal);

                modal.find('form')
                    .validate({
                        rules : {
                            title : {required : true},
                            id_release : {required : true},
                        }
                    });
                modal
                    .on('submit', 'form', function (e) {
                        e.preventDefault();
                        var btn = modal.find('.confirm').prop('disabled', true);

                        var form = $(this);

                        if(form.valid()){
                            post('project/save_run/' + (id || ''), form.serialize(), function (rep) {
                                if(rep.status === 'OK'){
                                    toastr_('The test run was successfully added', 'success', 'success', 6000);
                                    modal.sideModal('hide');
                                    table.twTable('refresh');
                                }else{
                                    toastr_(rep.message || 'Error while saving the data', 'error', 'danger', 9000);
                                }
                            })
                        }



                    })
            },
            whenConfirm : function(modal, data){
                modal.find('form').submit();
            },
            whenError : function(modal, error){},
            whenClosed : function(modal){},

        });
    }
    function deleteRun(id) {
        ask('Are you sure?', 'Do you really want to delete this Test Run?, this action will clear all the records.', function (yes) {

            if(yes){

                post('project/delete_run/' + id, {}, function (rep) {
                    if(rep.status === 'OK'){
                        toastr_('The Test Run was successfully deleted!', 'success', 'success');
                        table.twTable('refresh');
                    }else{
                        toastr_("We couldn't remove the selected Test Run", 'error', 'danger');
                    }
                })

            }else{

            }

        }, 'Yes', 'Cancel', true);
    }
    function changeRunStatus(id, status) {
        ask('Are you sure?', 'Do you really want to change the status of this Test Run?!', function (yes) {

            if(yes){

                post('project/change_run_status/', {id : id, status : status}, function (rep) {
                    if(rep.status === 'OK'){
                        toastr_('The Test Run was successfully updated!', 'success', 'success');
                        table.twTable('refresh');
                    }else{
                        toastr_("We couldn't update the selected Test Run", 'error', 'danger');
                    }
                })

            }else{

            }

        }, 'Yes', 'No', true);
    }
    function openRun(id) {
        log(id);
        loadView(site_url + 'project/' + project_id + '/runs/' + id);
    }

})();