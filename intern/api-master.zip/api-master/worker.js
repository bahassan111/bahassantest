/**
 * Created by HAMZA on 14/02/2018.
 */
self.addEventListener('install', function(event) {
    console.log('now istalling', event);
});