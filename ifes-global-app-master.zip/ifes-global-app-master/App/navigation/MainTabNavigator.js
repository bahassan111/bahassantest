import "react-native-gesture-handler";
import React, { Component } from "react";
import { Platform, View, TouchableOpacity, Image } from "react-native";
import {
  createDrawerNavigator,
  createStackNavigator,
  createBottomTabNavigator,
} from "react-navigation";

import TabBarIcon from "../components/TabBarIcon";
import HomeScreen from "../screens/HomeScreen";
import LinksScreen from "../screens/LinksScreen";
import SettingsScreen from "../screens/SettingsScreen";
import Icon from "../constants/Icons";
import Colors from "../constants/Colors";

const HomeStack = createStackNavigator({
  Home: HomeScreen,
  // navigationOptions: ({ navigation }) => ({
  //   title: "Demo Screen 1",
  //   headerLeft: <NavigationDrawerStructure navigationProps={navigation} />,
  //   headerStyle: {
  //     backgroundColor: "#FF9800"
  //   },
  //   headerTintColor: "#fff"
  // })
});

HomeStack.navigationOptions = {
  tabBarIcon: ({ focused }) => (
    <Icon
      focused={focused}
      name={"home"}
      iconSize={45}
      color={focused ? Colors.white : Colors.gray}
    />
  ),
  header: null,
};

const LinksStack = createStackNavigator({
  Links: { screen: LinksScreen, path: "event/:id" },
});

LinksStack.navigationOptions = {
  tabBarIcon: ({ focused }) => (
    <Icon
      focused={focused}
      name={"parameters"}
      iconSize={45}
      color={focused ? Colors.white : Colors.gray}
    />
  ),
};

const SettingsStack = createStackNavigator({
  Settings: SettingsScreen,
});

SettingsStack.navigationOptions = {
  tabBarLabel: "Settings",
  tabBarIcon: ({ focused }) => (
    <TabBarIcon
      focused={focused}
      name={Platform.OS === "ios" ? "ios-options" : "md-options"}
    />
  ),
  tabBarOptions: { showLabel: false },
};

//For React Navigation 2.+ need to export App only
//export default DrawerNavigatorExample;
//For React Navigation 3.+

// export default createAppContainer(DrawerNavigatorExample, buttomTab);
