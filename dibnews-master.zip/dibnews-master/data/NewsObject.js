import moment from "moment-with-locales-es6";
import Helper from "../global/Helper";

export default class NewsObject {

    title           = "";
    content         = "";
    excerpt         = "";
    photo           = "";
    video_url       = "";
    video_id        = "";
    video_type      = "";
    video_frame     = "";
    date            = "";
    category        = "";
    web             = "";

    image_uri;


    constructor(obj){



        this.title = Helper.escapeHtml(obj.title.rendered);
        this.content = obj.content.rendered;
        this.excerpt = obj.excerpt.rendered;
        //console.log('c=>', obj);
        this.category = Helper.escapeHtml(obj.category_name); //obj._embedded['wp:term'][0].name;

        this.web = obj.link;

        this.photo = obj.featured_image_src;
        this.image_uri = {uri: obj.featured_image_src};
        this.video_url = obj.featured_video_src;

        this.date = moment(obj.modified_gmt);

        this.init();

    }

    init = ()=>{

        let url = this.video_url;

        if(url){

            let yt_parts = url.match(/(?:https?:\/{2})?(?:w{3}\.)?youtu(?:be)?\.(?:com|be)(?:\/watch\?v=|\/)([^\s&]+)/);
            if(yt_parts && yt_parts.length > 1){
                this.video_type = 'youtube';
                this.video_id = yt_parts[1];
            }else if(url.substr(url.length - 4).toLowerCase().indexOf('.mp4') >= 0){
                this.video_type = 'local';
            }else{
                this.video_type = 'image';
            }

        }

    }

}
