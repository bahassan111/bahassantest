import Model from '../model'
export default class Topic extends Model {
  static schema = {
    name: 'Topic',
    primaryKey: 'id',
    properties: {
      id: 'int',
      name: 'string'
    }
  }
}