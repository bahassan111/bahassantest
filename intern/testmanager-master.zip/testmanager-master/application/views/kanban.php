<?php
addJS([
    'assets/js/views/tasks_kanban.js',
]);

viewHeader(
    '',
    '',
    [
        (object) ['name' => 'Dashboard', 'url' => site_url()],
        (object) ['name' => 'Projects', 'url' => site_url('projects')],
        (object) ['name' => $project->name, 'url' => getProjectUrl($project)],
        (object) ['name' => 'Tasks Kanban', 'url' => ''],
    ], true);

projectMenu('tasks_kanban', $project);
?>



<div class="project_taks_body n_menu">

    <div class="kanban_view">
        <div class="kanban_row">
            <div class="kbr_head">
                <span><i class="fas fa-globe"></i></span>
                <h3>In Progress</h3>
                <a href="javascript:void(0);"><i class="fas fa-ellipsis-v"></i></a>
            </div>

            <div class="kbr_body">
                <div class="kbr_item">
                    <div class="kbri_head">
                        <span class="badge badge-success">TAG 1</span>
                        <span class="badge badge-primary">TAG 2</span>
                        <span class="badge badge-warning">TAG 3</span>
                    </div>
                    <div class="kbri_body">
                        <p>Lorem ipsum dolor sit amet.</p>
                    </div>
                    <div class="kbri_footer">
                        <div class="kbrif_notifs">
                            <span><i class="far fa-comment-alt"></i> <b>2</b></span>
                            <span><i class="fas fa-paperclip"></i> <b>1</b></span>
                        </div>
                        <div class="kbrif_users">
                            <a href="javascript:void(0);" class="a"><i class="fas fa-plus"></i></a>
                            <a href="javascript:void(0);" class="o">HS</a>
                            <a href="javascript:void(0);" class="o">H</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                        </div>
                    </div>
                </div>
                <div class="kbr_item">
                    <div class="kbri_head">
                        <span class="badge badge-success">TAG 1</span>
                        <span class="badge badge-primary">TAG 2</span>
                        <span class="badge badge-warning">TAG 3</span>
                    </div>
                    <div class="kbri_body">
                        <p>Lorem ipsum dolor sit amet.</p>
                    </div>
                    <div class="kbri_footer">
                        <div class="kbrif_notifs">
                            <span><i class="far fa-comment-alt"></i> <b>2</b></span>
                            <span><i class="fas fa-paperclip"></i> <b>1</b></span>
                        </div>
                        <div class="kbrif_users">
                            <a href="javascript:void(0);" class="a"><i class="fas fa-plus"></i></a>
                            <a href="javascript:void(0);" class="o">HS</a>
                            <a href="javascript:void(0);" class="o">H</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                        </div>
                    </div>
                </div>
                <div class="kbr_item">
                    <div class="kbri_head">
                        <span class="badge badge-success">TAG 1</span>
                        <span class="badge badge-primary">TAG 2</span>
                        <span class="badge badge-warning">TAG 3</span>
                    </div>
                    <div class="kbri_body">
                        <p>Lorem ipsum dolor sit amet.</p>
                    </div>
                    <div class="kbri_footer">
                        <div class="kbrif_notifs">
                            <span><i class="far fa-comment-alt"></i> <b>2</b></span>
                            <span><i class="fas fa-paperclip"></i> <b>1</b></span>
                        </div>
                        <div class="kbrif_users">
                            <a href="javascript:void(0);" class="a"><i class="fas fa-plus"></i></a>
                            <a href="javascript:void(0);" class="o">HS</a>
                            <a href="javascript:void(0);" class="o">H</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                        </div>
                    </div>
                </div>
                <div class="kbr_item">
                    <div class="kbri_head">
                        <span class="badge badge-success">TAG 1</span>
                        <span class="badge badge-primary">TAG 2</span>
                        <span class="badge badge-warning">TAG 3</span>
                    </div>
                    <div class="kbri_body">
                        <p>Lorem ipsum dolor sit amet.</p>
                    </div>
                    <div class="kbri_footer">
                        <div class="kbrif_notifs">
                            <span><i class="far fa-comment-alt"></i> <b>2</b></span>
                            <span><i class="fas fa-paperclip"></i> <b>1</b></span>
                        </div>
                        <div class="kbrif_users">
                            <a href="javascript:void(0);" class="a"><i class="fas fa-plus"></i></a>
                            <a href="javascript:void(0);" class="o">HS</a>
                            <a href="javascript:void(0);" class="o">H</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                        </div>
                    </div>
                </div>
                <div class="kbr_item">
                    <div class="kbri_head">
                        <span class="badge badge-success">TAG 1</span>
                        <span class="badge badge-primary">TAG 2</span>
                        <span class="badge badge-warning">TAG 3</span>
                    </div>
                    <div class="kbri_body">
                        <p>Lorem ipsum dolor sit amet.</p>
                    </div>
                    <div class="kbri_footer">
                        <div class="kbrif_notifs">
                            <span><i class="far fa-comment-alt"></i> <b>2</b></span>
                            <span><i class="fas fa-paperclip"></i> <b>1</b></span>
                        </div>
                        <div class="kbrif_users">
                            <a href="javascript:void(0);" class="a"><i class="fas fa-plus"></i></a>
                            <a href="javascript:void(0);" class="o">HS</a>
                            <a href="javascript:void(0);" class="o">H</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                        </div>
                    </div>
                </div>
                <div class="kbr_item">
                    <div class="kbri_head">
                        <span class="badge badge-success">TAG 1</span>
                        <span class="badge badge-primary">TAG 2</span>
                        <span class="badge badge-warning">TAG 3</span>
                    </div>
                    <div class="kbri_body">
                        <p>Lorem ipsum dolor sit amet.</p>
                    </div>
                    <div class="kbri_footer">
                        <div class="kbrif_notifs">
                            <span><i class="far fa-comment-alt"></i> <b>2</b></span>
                            <span><i class="fas fa-paperclip"></i> <b>1</b></span>
                        </div>
                        <div class="kbrif_users">
                            <a href="javascript:void(0);" class="a"><i class="fas fa-plus"></i></a>
                            <a href="javascript:void(0);" class="o">HS</a>
                            <a href="javascript:void(0);" class="o">H</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                        </div>
                    </div>
                </div>
                <div class="kbr_item">
                    <div class="kbri_head">
                        <span class="badge badge-success">TAG 1</span>
                        <span class="badge badge-primary">TAG 2</span>
                        <span class="badge badge-warning">TAG 3</span>
                    </div>
                    <div class="kbri_body">
                        <p>Lorem ipsum dolor sit amet.</p>
                    </div>
                    <div class="kbri_footer">
                        <div class="kbrif_notifs">
                            <span><i class="far fa-comment-alt"></i> <b>2</b></span>
                            <span><i class="fas fa-paperclip"></i> <b>1</b></span>
                        </div>
                        <div class="kbrif_users">
                            <a href="javascript:void(0);" class="a"><i class="fas fa-plus"></i></a>
                            <a href="javascript:void(0);" class="o">HS</a>
                            <a href="javascript:void(0);" class="o">H</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                        </div>
                    </div>
                </div>

            </div>


        </div>
        <div class="kanban_row">
            <div class="kbr_head">
                <span><i class="fas fa-globe"></i></span>
                <h3>In Progress</h3>
                <a href="javascript:void(0);"><i class="fas fa-ellipsis-v"></i></a>
            </div>

            <div class="kbr_body">

                <div class="kbr_item">
                    <div class="kbri_head">
                        <span class="badge badge-success">TAG 1</span>
                        <span class="badge badge-primary">TAG 2</span>
                        <span class="badge badge-warning">TAG 3</span>
                    </div>
                    <div class="kbri_body">
                        <p>Lorem ipsum dolor sit amet.</p>
                    </div>
                    <div class="kbri_footer">
                        <div class="kbrif_notifs">
                            <span><i class="far fa-comment-alt"></i> <b>2</b></span>
                            <span><i class="fas fa-paperclip"></i> <b>1</b></span>
                        </div>
                        <div class="kbrif_users">
                            <a href="javascript:void(0);" class="a"><i class="fas fa-plus"></i></a>
                            <a href="javascript:void(0);" class="o">HS</a>
                            <a href="javascript:void(0);" class="o">H</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                        </div>
                    </div>
                </div>
                <div class="kbr_item">
                    <div class="kbri_head">
                        <span class="badge badge-success">TAG 1</span>
                        <span class="badge badge-primary">TAG 2</span>
                        <span class="badge badge-warning">TAG 3</span>
                    </div>
                    <div class="kbri_body">
                        <p>Lorem ipsum dolor sit amet.</p>
                    </div>
                    <div class="kbri_footer">
                        <div class="kbrif_notifs">
                            <span><i class="far fa-comment-alt"></i> <b>2</b></span>
                            <span><i class="fas fa-paperclip"></i> <b>1</b></span>
                        </div>
                        <div class="kbrif_users">
                            <a href="javascript:void(0);" class="a"><i class="fas fa-plus"></i></a>
                            <a href="javascript:void(0);" class="o">HS</a>
                            <a href="javascript:void(0);" class="o">H</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                        </div>
                    </div>
                </div>
                <div class="kbr_item">
                    <div class="kbri_head">
                        <span class="badge badge-success">TAG 1</span>
                        <span class="badge badge-primary">TAG 2</span>
                        <span class="badge badge-warning">TAG 3</span>
                    </div>
                    <div class="kbri_body">
                        <p>Lorem ipsum dolor sit amet.</p>
                    </div>
                    <div class="kbri_footer">
                        <div class="kbrif_notifs">
                            <span><i class="far fa-comment-alt"></i> <b>2</b></span>
                            <span><i class="fas fa-paperclip"></i> <b>1</b></span>
                        </div>
                        <div class="kbrif_users">
                            <a href="javascript:void(0);" class="a"><i class="fas fa-plus"></i></a>
                            <a href="javascript:void(0);" class="o">HS</a>
                            <a href="javascript:void(0);" class="o">H</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                        </div>
                    </div>
                </div>
                <div class="kbr_item">
                    <div class="kbri_head">
                        <span class="badge badge-success">TAG 1</span>
                        <span class="badge badge-primary">TAG 2</span>
                        <span class="badge badge-warning">TAG 3</span>
                    </div>
                    <div class="kbri_body">
                        <p>Lorem ipsum dolor sit amet.</p>
                    </div>
                    <div class="kbri_footer">
                        <div class="kbrif_notifs">
                            <span><i class="far fa-comment-alt"></i> <b>2</b></span>
                            <span><i class="fas fa-paperclip"></i> <b>1</b></span>
                        </div>
                        <div class="kbrif_users">
                            <a href="javascript:void(0);" class="a"><i class="fas fa-plus"></i></a>
                            <a href="javascript:void(0);" class="o">HS</a>
                            <a href="javascript:void(0);" class="o">H</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                        </div>
                    </div>
                </div>
                <div class="kbr_item">
                    <div class="kbri_head">
                        <span class="badge badge-success">TAG 1</span>
                        <span class="badge badge-primary">TAG 2</span>
                        <span class="badge badge-warning">TAG 3</span>
                    </div>
                    <div class="kbri_body">
                        <p>Lorem ipsum dolor sit amet.</p>
                    </div>
                    <div class="kbri_footer">
                        <div class="kbrif_notifs">
                            <span><i class="far fa-comment-alt"></i> <b>2</b></span>
                            <span><i class="fas fa-paperclip"></i> <b>1</b></span>
                        </div>
                        <div class="kbrif_users">
                            <a href="javascript:void(0);" class="a"><i class="fas fa-plus"></i></a>
                            <a href="javascript:void(0);" class="o">HS</a>
                            <a href="javascript:void(0);" class="o">H</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                        </div>
                    </div>
                </div>
                <div class="kbr_item">
                    <div class="kbri_head">
                        <span class="badge badge-success">TAG 1</span>
                        <span class="badge badge-primary">TAG 2</span>
                        <span class="badge badge-warning">TAG 3</span>
                    </div>
                    <div class="kbri_body">
                        <p>Lorem ipsum dolor sit amet.</p>
                    </div>
                    <div class="kbri_footer">
                        <div class="kbrif_notifs">
                            <span><i class="far fa-comment-alt"></i> <b>2</b></span>
                            <span><i class="fas fa-paperclip"></i> <b>1</b></span>
                        </div>
                        <div class="kbrif_users">
                            <a href="javascript:void(0);" class="a"><i class="fas fa-plus"></i></a>
                            <a href="javascript:void(0);" class="o">HS</a>
                            <a href="javascript:void(0);" class="o">H</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                        </div>
                    </div>
                </div>
                <div class="kbr_item">
                    <div class="kbri_head">
                        <span class="badge badge-success">TAG 1</span>
                        <span class="badge badge-primary">TAG 2</span>
                        <span class="badge badge-warning">TAG 3</span>
                    </div>
                    <div class="kbri_body">
                        <p>Lorem ipsum dolor sit amet.</p>
                    </div>
                    <div class="kbri_footer">
                        <div class="kbrif_notifs">
                            <span><i class="far fa-comment-alt"></i> <b>2</b></span>
                            <span><i class="fas fa-paperclip"></i> <b>1</b></span>
                        </div>
                        <div class="kbrif_users">
                            <a href="javascript:void(0);" class="a"><i class="fas fa-plus"></i></a>
                            <a href="javascript:void(0);" class="o">HS</a>
                            <a href="javascript:void(0);" class="o">H</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                            <a href="javascript:void(0);" class="o">DS</a>
                        </div>
                    </div>
                </div>

            </div>


        </div>
    </div>

</div>



<script>
    var project_id = <?= $project->id ?: 0; ?>;
</script>
