<?php
addJS([
    'assets/js/views/tasks.js',
]);

viewHeader(
    'Tasks',
    'Manage Project Tasks',
    [
        (object) ['name' => 'Dashboard', 'url' => site_url()],
        (object) ['name' => 'Projects', 'url' => site_url('projects')],
        (object) ['name' => $project->name, 'url' => getProjectUrl($project)],
        (object) ['name' => 'Tasks List', 'url' => ''],
    ], true);

projectMenu('tasks', $project);
?>



<div class="project_taks_body n_menu">

    <div class="tasks_list">

    </div>



</div>



<script>
    var project_id = <?= $project->id ?: 0; ?>;
</script>
