import React, { Component } from "react";
import { Dimensions, ActivityIndicator } from "react-native";
import { Card, View, Constants, Image } from "react-native-ui-lib";
import MyCustomCarousel from "./MyCustomCarousel";
import Config from "../constants/Config";
const CARD_MAX_HEIGHT = (Dimensions.get("window").height - 220) / 2;
const CARD_MAX_HEIGHT_SMALL = CARD_MAX_HEIGHT * 0.66;

export default class Banners extends Component {
  renderItem(item, id) {
    return (
      <Card style={{ marginBottom: 0 }} enableShadow={false} key={id}>
        <Image
          height={160}
          source={{
            uri: Config.BANNERS_IMAGE + item.image
          }}
          style={{ borderRadius: 50 }}
          resizeMode="cover"
          borderRadius={0}
        />
      </Card>
    );
  }

  renderFooter = () => {
    if (!this.props.banners.isLoadingData) return null;

    return (
      <View
        style={{
          paddingVertical: 20,
          borderTopWidth: 1,
          borderColor: "#CED0CE"
        }}
      >
        <ActivityIndicator animating size="large" />
      </View>
    );
  };

  render() {
    return (
      <View flex bg-white marginT-0>
        <MyCustomCarousel
          style={{
            flex: 1,
            minHeight: CARD_MAX_HEIGHT_SMALL
          }}
          loop
          autoplay
          itemWidth={Constants.screenWidth}
          horizontal
          data={this.props.banners.data}
          isFetching={this.props.banners.isLoadingData}
          renderItem={({ item, index }) => this.renderItem(item, index)}
          ListFooterComponent={this.renderFooter}
        />
      </View>
    );
  }
}
