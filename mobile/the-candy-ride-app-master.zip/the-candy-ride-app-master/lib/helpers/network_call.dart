import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:logger/logger.dart';
import 'package:dartz/dartz.dart';
import 'package:rider_app/models/models.dart';

class NetWorkCall {
  Dio _dio;
  Logger _logger = Logger();
  NetWorkCall() {
    _dio = Dio();

    if (kDebugMode) {
      _dio.interceptors.add(LogInterceptor(
        responseBody: true,
        requestHeader: false,
        responseHeader: false,
        request: false,
      ));
    }
  }
  Future<Either<String, dynamic>> getRequest({@required String url}) async {
    Response response;
    try {
      response = await _dio.get(url);
      _logger.i(response);
      if (response.statusCode == 200) {
        return Right(response);
      } else {
        _logger.w(response.statusCode);
        return Left(response.statusMessage);
      }
    } catch (e) {
      _logger.e(e);
      return Left(e.toString());
    }
  }

  Future<Either<String, dynamic>> postRequest({String url, Map json}) async {
    try {
      Response response =
          await _dio.post(url, data: jsonEncode(json)).catchError((e) {
        print("Network call error $e");

        _logger.e(e);
      });
      _logger.i(response);
      if (response.statusCode == 200) {
        return Right(ResponseModel.fromJson(response.data));
      } else {
        _logger.w(response.statusCode);
        return Left(response.statusMessage);
      }
    } catch (e) {
      _logger.e(e);
      return Left(e.toString());
    }
  }

  Future<Either<String, dynamic>> postRequestUsingFormData(
      {String url, FormData data}) async {
    try {
      Response response = await _dio.post(url, data: data).catchError((e) {
        print("Network call error $e");
        _logger.e(e);
      });
      _logger.i(response);
      if (response.statusCode == 200) {
        return Right(ResponseModel.fromJson(response.data));
      } else {
        _logger.w(response.statusCode);

        return Left(response.statusMessage);
      }
    } catch (e) {
      _logger.e(e);
      return Left(e.toString());
    }
  }

  Future<Either<String, dynamic>> postRequestWithResponse(
      {String url, Map json}) async {
    try {
      Response response =
          await _dio.post(url, data: jsonEncode(json)).catchError((e) {
        print("Network call error $e");
        _logger.e(e);
      });
      _logger.i(response);
      print("response  " + response.toString());
      if (response.statusCode == 200) {
        return Right(response);
      } else {
        _logger.w(response.statusCode);
        return Left(response.statusMessage);
      }
    } catch (e) {
      _logger.e(e);
      return Left(e.toString());
    }
  }
}
