import 'package:rider_app/models/models.dart';

class Routes {
  String weightName;
  var weight;
  var duration;
  var distance;
  List<Legs> legs;
  String geometry;

  Routes(
      {this.weightName,
      this.weight,
      this.duration,
      this.distance,
      this.legs,
      this.geometry});

  Routes.fromJson(Map<String, dynamic> json) {
    weightName = json['weight_name'];
    weight = json['weight'];
    duration = json['duration'];
    distance = json['distance'];
    if (json['legs'] != null) {
      legs =[];
      json['legs'].forEach((v) {
        legs.add(Legs.fromJson(v));
      });
    }
    geometry = json['geometry'];
  }
}
