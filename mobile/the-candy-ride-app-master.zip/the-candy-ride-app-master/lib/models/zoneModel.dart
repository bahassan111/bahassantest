import 'package:rider_app/models/models.dart';

class ZoneModel {
  String id;
  String zonename;
  String address;
  List<LatlngModel> latlng;

  ZoneModel({this.id, this.zonename, this.address, this.latlng});

  ZoneModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    zonename = json['zonename'];
    address = json['address'];
    if (json['latlng'] != null) {
      latlng = [];
      json['latlng'].forEach((v) {
        latlng.add(LatlngModel.fromJson(v));
      });
    }
  }
}
