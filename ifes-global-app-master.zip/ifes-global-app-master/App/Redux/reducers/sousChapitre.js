import {
  SET_ARTICLE_SUBCHAPITRE,
  PENDING_FETCH_SUBCHAPITRE,
  SUCCESS_FETCH_SUBCHAPITRE,
  SEARCH_ARTICLE,
  SUCCESS_SEARCH_ARTICLE,
  PENDING_SEARCH_ARTICLE
} from "../actions/types";

export default function(
  state = { isLoadingData: false, isDoSearch: false, data: [], keyword: null },
  action
) {
  switch (action.type) {
    case PENDING_FETCH_SUBCHAPITRE:
      return {
        ...state,
        isLoadingData: true
      };
    case PENDING_SEARCH_ARTICLE:
      return {
        ...state,
        isDoSearch: true
      };
    case SET_ARTICLE_SUBCHAPITRE:
      return { ...state, data: action.payload };

    case SEARCH_ARTICLE:
      return {
        ...state,
        keyword: action.keyword
      };
    case SUCCESS_FETCH_SUBCHAPITRE:
      return {
        ...state,
        isLoadingData: false
      };
    case SUCCESS_SEARCH_ARTICLE:
      return {
        ...state,
        isDoSearch: false
      };
    default:
      return state;
  }
}
