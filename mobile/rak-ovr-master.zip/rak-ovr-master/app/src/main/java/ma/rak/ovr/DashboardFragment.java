package ma.rak.ovr;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.github.curioustechizen.ago.RelativeTimeTextView;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.pnikosis.materialishprogress.ProgressWheel;

import io.realm.Realm;
import ma.rak.ovr.api.TwDatabase;
import ma.rak.ovr.bodyResponse.StatistiqueResponse;
import ma.rak.ovr.storage.SharedPrefManager;
import ma.rak.ovr.ui.main.DemandViewModel;
import ma.rak.ovr.ui.main.MainActivity;

public class DashboardFragment extends Fragment implements LocationListener {

    private DemandViewModel demandViewModel;

    private MapView mMapView;
    private View mViewOverMap;
    private TextView txtLat;
    private ProgressWheel progressWheel;

    protected Double latitude, longitude;

    private GoogleMap mGoogleMap;

    private StatistiqueResponse newStatistiqueResponse;

    LinearLayout cardsholder;

    private TextView total, instances, rejetees, executees, userName, userScoop, mapNbrDemande, lastUpdate;

//    private RelativeTimeTextView lastUpdate;

    Realm realm;

    MapsFragment mapsFragment = null;

    private View saveButton;

    protected LocationManager locationManager;

    private OnMapReadyCallback callback = new OnMapReadyCallback() {

        @Override
        public void onMapReady(GoogleMap googleMap) {
            mGoogleMap = googleMap;
            if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            mGoogleMap.setMyLocationEnabled(true);

        }
    };


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_dashboard, container, false);


        total = (TextView) rootView.findViewById(R.id.txtTotal);
        instances = (TextView) rootView.findViewById(R.id.totalInstance);
        executees = (TextView) rootView.findViewById(R.id.totalExecutees);
        rejetees = (TextView) rootView.findViewById(R.id.txtRejetees);
        userName = (TextView) rootView.findViewById(R.id.userFullName);
        userScoop = (TextView) rootView.findViewById(R.id.userScoop);
        lastUpdate =  rootView.findViewById(R.id.lastUpdate);
        mapNbrDemande = (TextView) rootView.findViewById(R.id.mapNbrDemande);
        View dmd = rootView.findViewById(R.id.c_total);

        mMapView = (MapView) rootView.findViewById(R.id.mapDashboard);
        mViewOverMap = (View) rootView.findViewById(R.id.viewOverMap);
        progressWheel = rootView.findViewById(R.id.progress_wheel);
        progressWheel.setVisibility(View.VISIBLE);
        mMapView.onCreate(savedInstanceState);
        saveButton = rootView.findViewById(R.id.save_button);

        cardsholder = rootView.findViewById(R.id.Cards);

        cardsholder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity act = ((MainActivity)getActivity());
                act.showFragment(act.listDemandeFragment);
            }
        });


        userName.setText("Compte : " + SharedPrefManager.getInstance(getActivity()).getFullName().toString() + " | " + SharedPrefManager.getInstance(getActivity()).getUserName().toString());


        lastUpdate.setText("Dérniere synchronisation : " + SharedPrefManager.getInstance(getActivity()).getSyncTime());
        //lastUpdate.setReferenceTime(Long.parseLong(SharedPrefManager.getInstance(getActivity()).getSyncTime()));

        int displaywidth = getResources().getDisplayMetrics().widthPixels;
        int displayHeight = getResources().getDisplayMetrics().heightPixels;
        MapView.LayoutParams params = new MapView.LayoutParams(displaywidth, displayHeight / 3);
        MapView.LayoutParams paramsV = new MapView.LayoutParams(displaywidth, displayHeight / 9);
        mMapView.setLayoutParams(params);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity) getActivity()).syncIt();
            }
        });



        mViewOverMap.setLayoutParams(paramsV);

        mViewOverMap.setOnClickListener(v -> {
            mapsFragment = new MapsFragment();
            showFragment(mapsFragment);
        });


        dmd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });



        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.


            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);

        mMapView.getMapAsync(callback);
    }


    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        realm = Realm.getDefaultInstance();

        String token = SharedPrefManager.getInstance(getActivity()).getToken();

        String scoop = SharedPrefManager.getInstance(getActivity()).getScoop();

        userName.setText("Compte: " + SharedPrefManager.getInstance(getActivity()).getFullName());
        userScoop.setText("Type de Compte: " + scoop);

        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(getContext());

        StatistiqueResponse stats = dbh.getStats();

        total.setText(stats.getTotal());
        instances.setText(stats.getEn_cours());
        rejetees.setText(stats.getRejetees());
        executees.setText(stats.getExecutees());
        mapNbrDemande.setText(" / "+stats.getEn_cours());

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        realm.close();
        mMapView.onDestroy();
    }


    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mMapView.onLowMemory();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        mMapView.onSaveInstanceState(outState);
    }

    @Override
    public void onLocationChanged(Location location) {
        try {
            txtLat = (TextView) getActivity().findViewById(R.id.mapTitle);
            txtLat.setText("Demandes à proximité");
            this.latitude = location.getLatitude();
            this.longitude = location.getLongitude();

            if (location.getLatitude() != 0 && location.getLongitude() != 0) {
                SharedPrefManager.getInstance(getContext()).setPos((float)location.getLatitude(), (float)location.getLongitude());
                LatLng firstMarker = new LatLng(location.getLatitude(), location.getLongitude());
                Log.i("position", firstMarker.toString());
                mGoogleMap.addMarker(new MarkerOptions().position(firstMarker).title(getString(R.string.myPostion)));

                mGoogleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(firstMarker, 18f));
                progressWheel.setVisibility(View.INVISIBLE);
            }
        } catch (Exception e) {
            Log.e("GoogleMapException", e.getMessage());
        }

    }

    @Override
    public void onResume() {
        super.onResume();
        progressWheel.setVisibility(View.VISIBLE);
    }

    @Override
    public void onProviderDisabled(String provider) {
        Log.d("Latitude", "disable");
    }

    @Override
    public void onProviderEnabled(String provider) {
        Log.d("Latitude", "enable");
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        Log.d("Latitude", "status");
    }

    public void showFragment(Fragment fragmentToShow) {
        // Create transactionns
        FragmentTransaction transaction = getActivity().getSupportFragmentManager()
                .beginTransaction()
                .setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.slide_out_right);

        // Hide all of the fragments
        for (Fragment fragment : getActivity().getSupportFragmentManager().getFragments()) {
            transaction.hide(fragment);
        }

        if (fragmentToShow.isAdded()) {
            // When fragment was previously added - show it
            transaction.show(fragmentToShow);
        } else {
            // When fragment is adding first time - add it
            transaction.add(R.id.frame, fragmentToShow);

        }

        transaction.commit();
    }
}