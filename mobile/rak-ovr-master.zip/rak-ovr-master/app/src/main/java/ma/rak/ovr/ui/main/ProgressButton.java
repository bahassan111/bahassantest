package ma.rak.ovr.ui.main;

import android.app.Activity;
import android.view.View;
import android.view.animation.Animation;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;

import ma.rak.ovr.R;

public class ProgressButton {

    private ConstraintLayout btn_constaintLayout;
    private CardView btn_cardView;
    private TextView btn_label;
    private ProgressBar btn_progressbar;

    Animation fade_id;

    public ProgressButton(Activity context, int label, String txt) {
        btn_constaintLayout = context.findViewById(R.id.btn_constraint_layout);
        btn_cardView = context.findViewById(R.id.btn_cardView);
        btn_label = context.findViewById(R.id.btn_label);
        btn_label.setText(txt);
        btn_progressbar = context.findViewById(R.id.btn_progressbar);
    }

    public void buttonActivated() {
        btn_progressbar.setVisibility(View.VISIBLE);
        btn_label.setText(R.string.operation_start);
    }

    public void buttonFinished() {
        btn_constaintLayout.setBackground(btn_cardView.getResources().getDrawable(R.drawable.button_done));
        btn_progressbar.setVisibility(View.GONE);
        btn_label.setText(R.string.operation_done);
    }

    public void buttonCancled(int text) {
        btn_constaintLayout.setBackground(btn_cardView.getResources().getDrawable(R.drawable.item_button_bg));
        btn_progressbar.setVisibility(View.GONE);
        btn_label.setText(text);
    }


}
