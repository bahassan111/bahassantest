package ma.rak.ov;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import java.util.ArrayList;
import java.util.HashMap;

import ma.rak.ov.api.ABListAdapter;
import ma.rak.ov.api.TwDatabase;
import ma.rak.ov.ui.main.SectionsPagerAdapter;


public class AllDemandes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_demandes);
        SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager());
        ViewPager viewPager = findViewById(R.id.view_pager);
        viewPager.setAdapter(sectionsPagerAdapter);
        TabLayout tabs = findViewById(R.id.tabs);
        tabs.setupWithViewPager(viewPager);
        FloatingActionButton fab = findViewById(R.id.fab);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });



        RecyclerView dlist = (RecyclerView) findViewById(R.id.all_demandes_list);
        ArrayList<HashMap<String, String>> list = null;

        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(this);

        ArrayList demandes = dbh.query(TwDatabase.ABDemandes.TABLE_NAME, "STATOPER = ?", new String[]{String.valueOf(1)}, TwDatabase.ABDemandes.DATCREAB + " DESC");

        ABListAdapter adapter = new ABListAdapter(demandes);
        dlist.setAdapter(adapter);
        dlist.setLayoutManager(new LinearLayoutManager(this));
    }
}