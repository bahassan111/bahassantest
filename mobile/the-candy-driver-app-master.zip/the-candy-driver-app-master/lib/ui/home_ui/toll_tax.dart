import 'package:driver/constants/constants.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:driver/ui/components/components.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class TollTax extends StatefulWidget {
  const TollTax({Key key}) : super(key: key);

  @override
  _TollTaxState createState() => _TollTaxState();
}

class _TollTaxState extends State<TollTax> {
  HomeController to = Get.find();
  AuthController authTo = Get.find();

  TextEditingController _controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black12.withOpacity(0.5),
      child: Center(
        child: Container(
          //color: Colors.red,
          margin: EdgeInsets.symmetric(horizontal: 20),
          child: Material(
            color: Colors.transparent,
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(color: Colors.black, width: 4),
                borderRadius: BorderRadius.circular(10),
                color: Colors.white,
              ),
              child: Container(
                margin: EdgeInsets.all(5),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black, width: 1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Center(
                        child: Text(
                          "enter_additional_charges_on_journey".tr,
                          style:
                              AppThemes.lightTheme.textTheme.subtitle1.copyWith(
                            color: Colors.black,
                            fontSize: 15,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 30),
                        child: TextFormField(
                          controller: _controller,
                          keyboardType: TextInputType.number,
                          style: AppThemes.lightTheme.textTheme.headline1,
                          decoration: InputDecoration(
                            hintText: "${authTo.userModel.currency} 0.00",
                            border: OutlineInputBorder(),
                            hintStyle: AppThemes.lightTheme.textTheme.headline3,
                            contentPadding:
                                EdgeInsets.symmetric(horizontal: 10),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Container(
                        width: 150,
                        child: RoundButton(
                          text: "submit".tr,
                          verticalPadding: 10,
                          onTap: () {
                            try {
                              int tax;
                              if (_controller.text.trim() == "") {
                                _controller.text = "0";
                              }
                              tax = int.tryParse(_controller.text.trim());
                              to.addTollTax(
                                amount: tax,
                                rideId: int.tryParse(to.rideDetail.id),
                              );
                            } catch (e) {}
                          },
                          backgroundColor:
                              AppThemes.lightdeepPinkDropDownIconColor,
                          textStyle: AppThemes.lightTheme.textTheme.headline6
                              .copyWith(
                                  fontWeight: FontWeight.bold, fontSize: 15),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
