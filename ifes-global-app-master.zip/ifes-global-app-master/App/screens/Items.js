import React from "react";
import { StyleSheet } from "react-native";
import {
  Colors as uiColors,
  ListItem,
  View,
  ThemeManager,
  Text
} from "react-native-ui-lib";
import I18n from "../commons/i18n";

import TextHelper from "../components/CustomText";

import * as Animatable from "react-native-animatable";
import Colors from "../constants/Colors";
import Icon from "../constants/Icons";

const Items = ({
                 row,
                 imageChapitre,
                 onPress,
                 animationProps,
                 imageAnimationProps,
                 lang,
                 see_more,
                 rtl
               }) => (
    <Animatable.View {...animationProps}>
      <ListItem
          activeBackgroundColor={uiColors.dark90}
          activeOpacity={0.3}
          height={"100%"}
          style={{ width: "95%" }}
          containerStyle={{
            flex: 1,
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "stretch",
            paddingVertical: 5
          }}
          onPress={onPress}
      >
        <ListItem.Part left>
          <Animatable.Image
              source={{
                uri: imageChapitre
              }}
              style={styles.image}
              {...imageAnimationProps}
          />
        </ListItem.Part>
        <ListItem.Part
            middle
            row
            containerStyle={[styles.border, { paddingRight: 17 }]}
        >
          <ListItem.Part row right containerStyle={{ marginBottom: 3 }}>
            <View flex column marginR-10 right={rtl === "1"}>
              <TextHelper
                  dark10
                  flexShrink
                  numberOfLines={1}
                  style={{ fontWeight: "bold" }}
              >
                {row.titre}
              </TextHelper>
              <TextHelper
                  dark40
                  numberOfLines={1}
                  flexShrink
                  style={{
                    fontWeight: "bold",
                    textAlign: lang == "ar" ? "right" : "left"
                  }}
                  text80
                  small
              >
                {see_more}
              </TextHelper>
            </View>
          </ListItem.Part>
          <Icon
              name="ion-chevron-right"
              iconSize={20}
              color={Colors.arrowColor}
          />
        </ListItem.Part>
      </ListItem>
    </Animatable.View>
);
export default Items;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center"
  },

  image: {
    width: 80,
    height: 80,
    marginHorizontal: 14
  },
  border: {
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderColor: ThemeManager.dividerColor,
    height: "100%"
  },
  textRight: {
    textAlign: "right"
  }
});
