package ma.rak.ovr.models;

import io.realm.RealmObject;

public class Stade extends RealmObject {
    private String STATDOSS;
    private String LIBSTADO;

    public Stade() {
    }

    public Stade(String statdoss, String libstado) {

        STATDOSS = statdoss;
        LIBSTADO = libstado;
    }

    public String getSTATDOSS() {
        return STATDOSS;
    }

    public void setSTATDOSS(String STATDOSS) {
        this.STATDOSS = STATDOSS;
    }

    public String getLIBSTADO() {
        return LIBSTADO;
    }

    public void setLIBSTADO(String LIBSTADO) {
        this.LIBSTADO = LIBSTADO;
    }

    @Override
    public String toString() {
        return "Statuses{" +
                "LIBRESRE='" + STATDOSS + '\'' +
                ", LIBSTADO='" + LIBSTADO + '\'' +
                '}';
    }
}

