class DriverStatistics {
  String myRating;
  String mycancellation;
  String myacceptance;

  DriverStatistics({this.myRating, this.myacceptance, this.mycancellation});
}
