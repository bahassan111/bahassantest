import React, { Component, useState, useEffect, useRef  } from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    ImageBackground,
    ActivityIndicator,
    Button, Dimensions,
    TouchableOpacity,
    Animated, AppState, SafeAreaView,ScrollView,
    BackHandler,Alert, Switch, CheckBox
} from "react-native";

import HTMLView from 'react-native-htmlview';
import YoutubePlayer from "react-native-youtube-iframe";
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {updateData} from "../redux/actions/dataAction";
import TopHeader from "../componants/TopHeader";
import css from "../global/GlobalStyle";
import Carousel from 'react-native-snap-carousel';
import GestureRecognizer from 'react-native-swipe-gestures';
import Loader from "./_loader";
import { AntDesign, FontAwesome5 } from '@expo/vector-icons';
import news from "../data/newsDemo";
import storage from "../storage/TwStorage";
import {fetchNewsData} from "../data/NewsData";
import NewsObject from "../data/NewsObject";
import SliderIndicator from "../componants/SliderIndicator";
import modernHome from "../componants/views/modernHome"
import NewsSlider from "../componants/NewsSlider";
import i18n from 'i18n-js';
import TwButton from "../componants/TwButton";
import { CommonActions } from '@react-navigation/native';
import {updateNotifCategoryStatus, updateNotifStatus} from "../data/NewsData";

const win = Dimensions.get('window');
const ofHeight = (p)=> p * win.height / 100;
const ofWidth = (p)=> p * win.width / 100;




class settingsScreen extends Component {


    state = {
        theme : this.props.data.theme,
        language : this.props.data.language,
        notif : this.props.data.notifications,
        cats_notif : this.props.data.cats_notif || [],
        cats:[],
    };




    componentDidUpdate(nextProps, nextState, nextContext) {

    }

    componentDidMount() {

        let data = this.props.data;
        this.props.updateData(data);

        this.setState({theme : data.theme,language : data.language,});


        storage.getStorage('cats', []).then(cats => {
            try {
                cats = JSON.parse(cats);

            }catch (e) {
                cats = [];
            }

            this.setState({cats : cats})
        });
    }

    logoPressed = ()=>{
        const {navigation} = this.props;

        navigation.navigate('news');
    };
    menuPressed = ()=>{
        const {navigation} = this.props;

        navigation.toggleDrawer();
    };

    _changeTheme = (theme)=>{

        let data = this.props.data;
        data.theme = theme;
        this.props.updateData(data);
        this.setState({theme : theme});

    };

    _changeLanguage = (lang)=>{

        let data = this.props.data;
        data.language = lang;
        this.props.updateData(data);
        i18n.locale = lang;
        this.setState({language : lang});

    };

    _reset = ()=>{



        storage.setStorage('__data', '"').then(()=>{
            this.saveIT();
        })

    };

    tcolor(){
        return this.props.data.theme === 'dark' ? {color : '#e1e1e1'} : {color : '#373737'};
    }

    saveIT = ()=>{
        const { navigation } = this.props;

        navigation.dispatch(
            CommonActions.reset({
                index: 1,
                routes: [
                    { name: 'splash'},
                ],
            })
        );
    };

    saveCatsNotif =(cat, val)=>{

        let data = this.props.data;
        let catsnotif = this.state.cats_notif;
        let done = false;

        catsnotif.forEach((catt)=>{
            if(cat.id === catt){
                cat.value = val;
                done=true;
                return false;
            }
        });

        if(!done){
            catsnotif.push({
                id : cat,
                value : val
            });
        }

        data.cats_notif = catsnotif;
        this.props.updateData(data);
        this.setState({cats_notif : catsnotif});

        updateNotifCategoryStatus(cat, val);
        //console.log(catsnotif);

    };

    getCatNotif = (catt)=>{
        let value = true;
        this.state.cats_notif.forEach((cat, i)=>{

            //console.log(cat.id, catt, cat.value);
            if(cat.id === catt) {
                value = cat.value;
                return false;
            }

        });


        //console.log('asked for ' + cat + ' GOT ' + (value ? 'true' : 'false'));

        return value;

    };


    renderCatsOpt() {

        let cats = this.state.cats;


        return cats.map((cat, i)=>{

            let n = this.getCatNotif(cat.id);
            return (<View key={i} style={styles.opt2}>
                <CheckBox
                    disabled={!this.state.notif}
                    style={[styles.opt_o, {opacity : !this.state.notif ? 0.2 : 1}]}
                    tintColors={{ false: '#c6c6c7', true: '#5bbaff' }}
                    thumbColor={n ? '#ffffff' : '#ffffff'}
                    ios_backgroundColor="#3e3e3e"
                    onValueChange={(e)=>{
                        this.saveCatsNotif(cat.id, e);
                    }}
                    value={n}
                />
                <Text style={styles.opt_label}>{cat.name}</Text>
            </View>)

        });

    }

    render() {


        return (

            <View style={[this.props.data.theme === 'dark' ? css.background : css.background_fordark]}>
                <TopHeader transparent={false} floatable={false} title="Options" onMenu={this.menuPressed} onUser={this.logoPressed}/>


                <ScrollView style={{height: ofHeight(90)}}>

                    {true ? (null) : (<View style={[styles.set_row]}>
                        <Text style={[styles.set_title, this.props.data.theme === 'dark' ? {color : '#fff'} : {}]}>Theme</Text>

                        <TouchableOpacity onPress={()=>{this._changeLanguage('fr')}} style={[styles.row_sel, this.state.language === 'fr' ? styles.row_sel_a : {}]}>
                            <View style={[styles.row_sel_icon]}>
                                <AntDesign style={this.tcolor()} name={this.state.language === 'fr' ? 'checkcircle' : 'checkcircleo'} size={24} color="black" />
                            </View>
                            <View style={[styles.row_sel_detail]}>
                                <Text style={[styles.row_sel_text, this.tcolor()]}>Français</Text>
                            </View>
                        </TouchableOpacity>


                        <TouchableOpacity onPress={()=>{this._changeLanguage('en')}} style={[styles.row_sel, this.state.language === 'en' ? styles.row_sel_a : {}]}>
                            <View style={[styles.row_sel_icon]}>
                                <AntDesign style={this.tcolor()} name={this.state.language === 'en' ? 'checkcircle' : 'checkcircleo'} size={24} color="black" />
                            </View>
                            <View style={[styles.row_sel_detail]}>
                                <Text style={[styles.row_sel_text, this.tcolor()]}>Anglais (English)</Text>
                            </View>
                        </TouchableOpacity>

                    </View>)}



                    {(false ? (<View style={[styles.set_row]}>
                        <Text style={[styles.set_title, this.tcolor()]}>Schéma de couleurs</Text>
                        <View style={[styles.lsels]}>
                            <TouchableOpacity onPress={()=>{this._changeTheme('light')}} style={[styles.lsel, this.state.theme === 'light' ? styles.lsel_a : {}]}>

                                <Image style={[styles.lsel_image]} source={require('../assets/LAYOUT1_LIGHT.png')}/>

                                <View style={[styles.lsel_details]}>
                                    <AntDesign style={[styles.lsel_icon, this.state.theme === 'light' ? styles.lsel_ai : {}]} name="checkcircleo" size={24} color="black" />
                                    <Text style={[styles.lsel_text, this.props.data.theme === 'dark' ? {color : '#fff'} : {}]}>Claire</Text>
                                </View>


                            </TouchableOpacity>



                            <TouchableOpacity onPress={()=>{this._changeTheme('dark')}} style={[styles.lsel, this.state.theme === 'dark' ? styles.lsel_a : {}]}>

                                <Image style={[styles.lsel_image]} source={require('../assets/LAYOUT1_DARK.png')}/>

                                <View style={[styles.lsel_details]}>
                                    <AntDesign style={[styles.lsel_icon, this.state.theme === 'dark' ? styles.lsel_ai : {}]} name="checkcircleo" size={24} color="black" />
                                    <Text style={[styles.lsel_text, this.props.data.theme === 'dark' ? {color : '#fff'} : {}]}>Foncé</Text>
                                </View>


                            </TouchableOpacity>
                        </View>
                    </View>) : null)}

                    <View style={[styles.set_row]}>
                        <Text style={[styles.set_title, this.tcolor()]}>Notifications</Text>

                        <View style={styles.opt}>
                            <Switch
                                style={styles.opt_o}
                                trackColor={{ false: '#c6c6c7', true: '#5bbaff' }}
                                thumbColor={this.props.data.notifications ? '#ffffff' : '#ffffff'}
                                ios_backgroundColor="#3e3e3e"
                                onValueChange={(e)=>{
                                    let data = this.props.data;
                                    data.notifications = e;
                                    this.props.updateData(data);
                                    this.setState({notif : e});

                                    updateNotifStatus(e);
                                }}
                                value={this.state.notif}
                            />
                            <Text style={[styles.opt_label, {fontWeight: 'bold'}]}>Activer les notifications</Text>
                        </View>

                        {this.renderCatsOpt()}
                    </View>




                    <View style={[styles.set_row_q]}>
                        <TwButton onPress={this.saveIT} style={{minWidth: 280}} title='Enregistrer'/>
                        {/*<TwButton full={false} onPress={this._reset} style={{minWidth: 280, marginTop: 12,}} title={i18n.t('reset')}/>*/}
                    </View>

                    <View style={{marginVertical: 22,}}/>


                </ScrollView>


            </View>

        );
    }
}

const styles = StyleSheet.create({

    set_row: {
        paddingHorizontal: 8,
        paddingVertical: 12,
        margin: 12,
        marginBottom: 18,
        alignItems: 'center',
        borderWidth: 1,
        borderColor: '#ccc',

    },
    opt:{
      flexDirection: 'row-reverse',
        alignItems:'center',
        justifyContent:'center',
    },
    opt2:{
      flexDirection: 'row-reverse',
        alignItems:'center',
        justifyContent:'center',
        borderTopWidth: 1,
        paddingTop: 10,
        borderTopColor: '#ccc'
    },
    opt_label:{
      flex: 1,
        marginBottom: 16,
        fontSize:16,
    },
    opt_o:{
      marginRight: 22,
    },
    set_row_q: {
        paddingHorizontal: 8,
        paddingVertical: 12,
        margin: 12,
        marginBottom: 18,
        alignItems: 'center',

    },
    set_title: {
        color : '#000',
        padding: 8,
        textAlign: 'center',
        marginBottom: 18,
    },

    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    box: {
        backgroundColor: '#61dafb',
        width: 80,
        height: 80,
        borderRadius: 4,
    },

    lsels : {
        flexDirection: 'row',
        //flex: 2,
        //backgroundColor: 'rgba(3,178,255,0.25)',
    },
    lsel : {
        paddingHorizontal: 12,
        paddingVertical: 4,
        margin: 8,
        alignItems: 'center',
        borderRadius: 8,
        flex: 1,
        maxWidth: 280,

    },
    lsel_a : {
        backgroundColor: 'rgba(3,178,255,0.25)',
    },
    lsel_ai : {
        opacity: 1,
        color: '#03b2ff',
    },
    lsel_icon : {
        opacity: .2,
        marginBottom: 12,
    },
    lsel_image : {
        width: 60,
        height: 100,
        resizeMode: 'contain',
    },
    lsel_text : {
        paddingTop: 6,
        color : '#343434'
        //backgroundColor: '#ccc',
    },
    lsel_details : {
        //flexDirection: 'row',
        alignItems: 'center',
        padding: 8,
        marginVertical: 12,
    },
    row_sel: {
        flexDirection: 'row',
        borderColor : '#4b4b4b',
        borderWidth: 2,
        borderRadius : 8,
        height: 42,
        width: 320,
        marginVertical: 12,
    },
    row_sel_a: {
        borderColor: '#03b2ff',
        backgroundColor: "rgba(3,178,255,0.09)",
        //color : "#fff",
    },
    row_sel_icon: {
        height: 40,
        width: 64,
        alignItems: 'center',
        justifyContent: 'center',
    },
    row_sel_detail: {
        //height : 46,
        flex: 1,
        height: "100%",
        justifyContent : 'center',
        alignItems : 'center',
        //backgroundColor: '#ccc',
    },
    row_sel_text: {
        width: "100%",
        paddingHorizontal: 12,
    },
});

const mapDispatchToProps = dispatch => (
    bindActionCreators({
        updateData: updateData,
    }, dispatch)
);

const mapStateToProps = (state) => {
    const { data } = state;
    return { data }
};

export default connect(mapStateToProps, mapDispatchToProps)(settingsScreen);
