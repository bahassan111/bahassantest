import 'dart:convert';
import 'dart:io';

import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:rider_app/constants/constants.dart';
import 'package:rider_app/controllers/controllers.dart';
import 'package:rider_app/helpers/helpers.dart';
import 'package:rider_app/ui/components/components.dart';

class SignUpUI extends StatefulWidget {
  SignUpUI({Key key}) : super(key: key);

  @override
  _SignUpUIState createState() => _SignUpUIState();
}

class _SignUpUIState extends State<SignUpUI> {
  double height, width;
  static AuthController to = Get.find();
  GlobalKey<FormState> formKey = GlobalKey();

  // form variables
  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController confirmPassword = TextEditingController();
  TextEditingController fullName = TextEditingController();
  TextEditingController mobileNo = TextEditingController();
  String country;
  bool isPasswordReadOnly = true;
  bool isConfirmPasswordReadOnly = true;
  bool termsAndCondition = false;
  FocusNode passwordFocusNode = FocusNode();
  FocusNode confirmPasswordFocusNode = FocusNode();
  PickedFile profileImage;
  get getSpacer => const SizedBox(
        height: 20,
      );

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      body: SingleChildScrollView(
        child: Form(
          key: formKey,
          child: Container(
            child: Column(
              children: [
                CustomeBackButton(),
                RichText(
                  text: TextSpan(
                    text: "rideWithThe".tr,
                    style: Theme.of(context)
                        .textTheme
                        .headline2
                        .copyWith(fontSize: 22, fontWeight: FontWeight.w700),
                    children: [
                      TextSpan(
                        text: ' ' + "candy".tr,
                        style: Theme.of(context).textTheme.headline5.copyWith(
                            fontSize: 24, fontWeight: FontWeight.w700),
                      )
                    ],
                  ),
                ),
                SizedBox(
                  height: 15,
                ),
                GestureDetector(
                  onTap: () async {
                    PickedFile newPickedImage = await imgFromGallery();
                    if (newPickedImage != null) {
                      setState(() {
                        profileImage = newPickedImage;
                      });
                    }
                  },
                  child: profileImage != null
                      ? Container(
                          height: 110,
                          width: 110,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            image: DecorationImage(
                              image: FileImage(
                                File(profileImage.path),
                              ),
                              fit: BoxFit.cover,
                            ),
                          ),
                        )
                      : Image.asset(
                          AllImages.adddp,
                          height: 110,
                          width: 110,
                        ),
                ),
                getSpacer,
                getInputFields(context),
                SizedBox(
                  height: 25,
                ),
                getTermsAndCondition(),
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 35.0, vertical: 20),
                  child: RoundButton(
                    onTap: () {
                      if (fullName.text.trim() == '') {
                        BotToast.showWidget(
                          toastBuilder: (_) => ErrorDialog(
                            title: "error".tr,
                            message: "errorFullName".tr,
                          ),
                        );
                      } else if (mobileNo.text.trim() == '') {
                        BotToast.showWidget(
                          toastBuilder: (_) => ErrorDialog(
                            title: "error".tr,
                            message: "errorMobileNo".tr,
                          ),
                        );
                      } else if (country == null) {
                        BotToast.showWidget(
                          toastBuilder: (_) => ErrorDialog(
                            title: "error".tr,
                            message: "errorCountry".tr,
                          ),
                        );
                      } else if (email.text.trim() == '') {
                        BotToast.showWidget(
                          toastBuilder: (_) => ErrorDialog(
                            title: "error".tr,
                            message: "errorEmail".tr,
                          ),
                        );
                      } else if (to.validator.email(email.text.trim())) {
                        BotToast.showWidget(
                          toastBuilder: (_) => ErrorDialog(
                            title: "error".tr,
                            message: "errorValidEmail".tr,
                          ),
                        );
                      } else if (password.text.trim() == '') {
                        BotToast.showWidget(
                          toastBuilder: (_) => ErrorDialog(
                            title: "error".tr,
                            message: "errorPassword".tr,
                          ),
                        );
                      } else if (password.text.trim().length < 8) {
                        BotToast.showWidget(
                          toastBuilder: (_) => ErrorDialog(
                            title: "error".tr,
                            message: "errorValidPassword".tr,
                          ),
                        );
                      } else if (confirmPassword.text.trim() !=
                          password.text.trim()) {
                        BotToast.showWidget(
                          toastBuilder: (_) => ErrorDialog(
                            title: "error".tr,
                            message: "errorValidConfirmPassword".tr,
                          ),
                        );
                      } else if (!termsAndCondition) {
                        BotToast.showWidget(
                          toastBuilder: (_) => ErrorDialog(
                            title: "error".tr,
                            message: "errorselectTermsAndCondition".tr,
                          ),
                        );
                      } else {
                        String base64Image;
                        if (profileImage != null) {
                          List<int> imageBytes =
                              File(profileImage.path).readAsBytesSync();
                          base64Image = base64Encode(imageBytes);
                        }
                        to.singUp(
                          countryId: int.parse(country),
                          mobileNo: int.parse(mobileNo.text.trim()),
                          email: email.text.trim(),
                          fullName: fullName.text.trim(),
                          password: password.text.trim(),
                          base64Image: base64Image,
                        );
                      }
                    },
                    text: "register".tr.toUpperCase(),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  getInputFields(context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 35),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "fullName".tr,
            style: Theme.of(context).textTheme.headline2.copyWith(fontSize: 15),
          ),
          FormInputField(
            controller: fullName,
          ),
          SizedBox(
            height: 20,
          ),
          Text(
            "mobileNo".tr,
            style: Theme.of(context).textTheme.headline2.copyWith(fontSize: 15),
          ),
          FormInputField(
            controller: mobileNo,
            keyboardType: TextInputType.number,
          ),
          getSpacer,
          Text(
            "country".tr,
            style: Theme.of(context).textTheme.headline2.copyWith(fontSize: 15),
          ),
          CustomDropDownMenu(
            items: to.countries,
            onChange: (String count) {
              country = count;
            },
          ),
          SizedBox(
            height: 20,
          ),
          Text(
            "e-mailId".tr,
            style: Theme.of(context).textTheme.headline2.copyWith(fontSize: 15),
          ),
          FormInputField(
            controller: email,
            keyboardType: TextInputType.emailAddress,
          ),
          getSpacer,
          Text(
            "password".tr,
            style: Theme.of(context).textTheme.headline2.copyWith(fontSize: 15),
          ),
          FormInputField(
            controller: password,
            obscureText: isPasswordReadOnly,
            focusNode: passwordFocusNode,
            iconSuffix: GestureDetector(
              onTap: () {
                if (!passwordFocusNode.hasFocus) {
                  passwordFocusNode.unfocus();
                  passwordFocusNode.canRequestFocus = false;
                }
                setState(() {
                  isPasswordReadOnly = !isPasswordReadOnly;
                });
              },
              child: Image.asset(
                AllImages.showPassword,
                height: 10,
                width: 10,
              ),
            ),
          ),
          getSpacer,
          Text(
            "confirmPassword".tr,
            style: Theme.of(context).textTheme.headline2.copyWith(fontSize: 15),
          ),
          FormInputField(
            controller: confirmPassword,
            obscureText: isConfirmPasswordReadOnly,
            focusNode: confirmPasswordFocusNode,
            iconSuffix: GestureDetector(
              onTap: () {
                if (!confirmPasswordFocusNode.hasFocus) {
                  confirmPasswordFocusNode.unfocus();
                  confirmPasswordFocusNode.canRequestFocus = false;
                }
                setState(() {
                  isConfirmPasswordReadOnly = !isConfirmPasswordReadOnly;
                });
              },
              child: Image.asset(
                AllImages.showPassword,
                height: 10,
                width: 10,
              ),
            ),
          ),
        ],
      ),
    );
  }

  getTermsAndCondition() {
    return Container(
      padding: EdgeInsets.only(left: 10, right: 25),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Theme(
            data: ThemeData(
                unselectedWidgetColor: AppThemes.lightpauaBackGroundColor),
            child: Checkbox(
              value: termsAndCondition,
              onChanged: (value) {
                setState(() {
                  termsAndCondition = value;
                });
              },
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                "byContinuing".tr,
                overflow: TextOverflow.fade,
                maxLines: 1,
                softWrap: false,
                style: Theme.of(context)
                    .textTheme
                    .headline3
                    .copyWith(fontSize: 12, fontWeight: FontWeight.w700),
              ),
              Text(
                "readAgree".tr,
                overflow: TextOverflow.fade,
                maxLines: 1,
                softWrap: false,
                style: Theme.of(context)
                    .textTheme
                    .headline3
                    .copyWith(fontSize: 12, fontWeight: FontWeight.w700),
              ),
              RichText(
                text: TextSpan(
                  text: "termCondition".tr,
                  style: Theme.of(context)
                      .textTheme
                      .headline1
                      .copyWith(fontSize: 12, fontWeight: FontWeight.w700),
                  children: [
                    TextSpan(
                      text: ' ' + "and".tr,
                      style: Theme.of(context)
                          .textTheme
                          .headline3
                          .copyWith(fontSize: 12, fontWeight: FontWeight.w700),
                    ),
                    TextSpan(
                      text: ' ' + "privacyPolicy".tr,
                      style: Theme.of(context)
                          .textTheme
                          .headline1
                          .copyWith(fontSize: 12, fontWeight: FontWeight.w700),
                    )
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
