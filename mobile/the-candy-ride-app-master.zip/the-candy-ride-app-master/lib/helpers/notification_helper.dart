import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';
import 'package:rider_app/models/models.dart';

FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

Future<dynamic> myBackgroundMessageHandler(Map<String, dynamic> message) async {
  showNotificationWithDefaultSound(message);
  Get.snackbar("myBackgroundMessageHandler", "$message");

  if (message.containsKey('data')) {
    final dynamic data = message['data'];
    print("data $data");
  }

  if (message.containsKey('notification')) {
    final dynamic notification = message['notification'];
    print("data $notification");
  }
}

Future showNotificationWithDefaultSound(Map<dynamic, dynamic> message) async {
  //tone.mp3
  NotificationResponse notificationResponse = NotificationResponse.fromJsonMap(
    jsonDecode(
      jsonEncode(message),
    ),
  );

  var androidPlatformChannelSpecifics = AndroidNotificationDetails(
    'your channel id',
    'your channel name',
    'your channel description',
    color:
        notificationResponse.notificationDataModel?.color ?? Colors.transparent,
    importance: Importance.high,
    icon: "logo",
    timeoutAfter: 1000,
    priority: Priority.high,
    playSound: true,
    sound: RawResourceAndroidNotificationSound('tone'),
  );
  var iOSPlatformChannelSpecifics = IOSNotificationDetails(
    sound: 'tone',
  );
  var platformChannelSpecifics = NotificationDetails(
    android: androidPlatformChannelSpecifics,
    iOS: iOSPlatformChannelSpecifics,
  );
  if (flutterLocalNotificationsPlugin != null)
    await flutterLocalNotificationsPlugin.show(
      0,
      notificationResponse.notification != null
          ? notificationResponse.notificationDataModel.title
          : "New Notification",
      notificationResponse.notification != null
          ? notificationResponse.notificationDataModel.body
          : "",
      platformChannelSpecifics,
      payload: "Custom_Sound",
    );
}

Future notificationOnMessage(Map<String, dynamic> message) async {
  print("notificationOnMessage $message");
}
