<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tests extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!isLoggedIn()) {
            callback_whenNotLoggedIn();
        }
    }

    public function index()
    {

    }

    public function show($id, $name = '')
    {
        if(!$id) callback_whenNotFound();
        $query = $this->db->get_where('projects', ['id' => $id, 'deleted' => 0]);
        $project = $query ? $query->row() : null;

        if(!$project) callback_whenNotFound();

        $data = [
            '_page' => 'project',
            '_title' => 'Project ' . $project->name,
            'project' => $project,
        ];

        loadView('project', $data);
    }
}
