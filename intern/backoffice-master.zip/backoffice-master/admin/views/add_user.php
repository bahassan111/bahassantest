<div class="row">
    <form id="form_save_user" enctype="multipart/form-data" method="post">
        <div class="col-sm-6">
            <div class="form-group">
                <label for="Country">Country</label>
                <select  name="id_country[]" class="form-control" id="id_country" data-live-search="true" title="Select country" multiple>
                    <?php foreach ($countries as $country){
                        $data_content="<img src='".site_url('images/flags/'.$country->iso.'.png')."' > ".$country->name ;
                        ?>
                        <option <?= $country->selected ?>  data-content="<?= $data_content ?>"  data-cname="<?= $country->name ?>" value="<?= $country->id ?>">
                            <?= $country->name ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label for="Full name">Full name</label>
                <input type="hidden" id="id_edit"  name="id_edit" value="<?= $one_user && $one_user->id ? $one_user->id  : '' ?>">
                <input type="text" name="fullname" id="fullname" class="form-control" value="<?= $one_user && $one_user->fullname ? $one_user->fullname  : '' ?>" >
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label for="Username">Username</label>
                <input type="text" name="username" id="username" class="form-control" value="<?= $one_user && $one_user->username ? $one_user->username  : '' ?>" >
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label for="Email">Email</label>
                <input type="email" name="email" id="email" class="form-control" value="<?= $one_user && $one_user->email ? $one_user->email  : '' ?>" >
            </div>
        </div>
        <?php if(!$one_user){?>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="Password">Password</label>
                    <input type="password" name="password" id="password" class="form-control" >
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="Repeat password">Confirm password</label>
                    <input type="password" name="password_confirm" id="password_confirm" class="form-control" >
                </div>
            </div>
        <?php }  ?>

        <div class="col-sm-6">
            <div class="card">

                <div class="card-header">
                    <label for="Sections">Sections</label>
                </div>

                <ul class="list-group list-group-flush" id="sections_user">

                    <?php foreach ($sections as $key=>$section){  ?>

                    <li class="list-group-item">
                        <div class="form-group">
                            <label for="Bootstrap Switch Info"><?= $section->text ?></label>
                            <label class="switch ">
                                <input type="checkbox" class="info" name="sections[]" <?= $section->checked ?>  value="<?= $key ?>">
                                <span class="slider round"></span>
                            </label>
                        </div>
                    </li>
                    <?php } ?>

                </ul>
            </div>
        </div>

        <div class="col-sm-6">
            <div class="form-group">
                <div class="form-group">
                    <label for="Image">Image</label>
                    <input type="file" id="image_user" name="image_user"  class="dropify"  accept="image/*"  data-default-file="<?= $one_user ?  site_url($one_user->image) : '' ?>"/>
                </div>
            </div>
        </div>

    </form>

</div>
