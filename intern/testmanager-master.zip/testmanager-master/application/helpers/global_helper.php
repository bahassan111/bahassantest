<?php
require_once 'simple_html_dom.php';

class utils
{
    public const METHOD_ADD = 1;
    public const METHOD_EDIT = 2;
    public const METHOD_DELETE = 3;
}

function userInfo($id = null)
{
    $that =& get_instance();
    $id = $id ?: $that->session->userdata('user_id');
    if (isset($that->_users[$id])) return $that->_user[$id];
    $that->_user[$id] = $that->db
        ->select('users.*, users_groups.group_id')
        ->join('users_groups', "users.id = users_groups.user_id", 'left')
        ->get_where('users', ['users.id' => $id])
        ->row();
    $that->_user[$id]->is_admin = $that->_user[$id]->group_id === '1';


    return $that->_user[$id];
}

function log_action($project_id, $type, $text, $key = null, $val = null, $user = FALSE)
{
    $that =& get_instance();
    $that->db->insert('projects_log', [
        'id_project' => $project_id,
        'id_user' => $user ?: userInfo()->id,
        'method' => $type,
        'action' => $text,
        'key' => $key,
        'value' => $val,
        'date' => time(),
    ]);
}

function asserts($index = FALSE)
{
    $asserts = [
        1 => (object)[
            'render' => 'HTTP Code equals %s',
            'title' => 'HTTP Code equals to',
            'values' => [
                (object)['title' => 'HTTP Code', 'type' => 'number'],
            ],
            'handler' => function ($rep, $value) {
                $given = $rep->code;

                $result = $given === intval($value);
                return (object)['result' => $result, 'given' => $given, 'requested' => $value];
            },
        ],
        2 => (object)[
            'title' => 'Header has key',
            'values' => [
                (object)['title' => 'Header key', 'type' => 'text'],
            ],
            'handler' => function ($rep, $value) {
                $given = $rep->headers;
                $result = isset($given->{$value});

                return (object)['result' => $result, 'given' => $given, 'requested' => $value];
            },
        ],
        3 => (object)[
            'title' => "Header value equals to",
            'values' => [
                (object)['title' => 'Header Key', 'type' => 'text'],
                (object)['title' => 'Header Value', 'type' => 'text'],
            ],
            'handler' => function ($rep, $value, $value2) {
                $given = isset($rep->headers->{$value}) ? $rep->headers->{$value} : null;
                $result = $given == $value2;

                return (object)['result' => $result, 'given' => $given, 'requested' => $value];
            },
        ],
        4 => (object)[
            'title' => "Header Contains",
            'values' => [
                (object)['title' => 'Header', 'type' => 'text'],
            ],
            'handler' => function ($rep, $value) {
                $result = strpos($rep->header_str, $value) !== FALSE;
                return (object)['result' => $result, 'given' => $rep->header_str, 'requested' => $value];
            },
        ],
        5 => (object)[
            'title' => "Content type",
            'values' => [
                (object)['title' => 'Content type', 'type' => 'list', 'values' => ['application/json', 'text/html']],
            ],
            'handler' => function ($rep, $value) {
                $result = $rep->headers->{'Content-Type'} == $value;
                return (object)['result' => $result, 'given' => $rep->headers->{'Content-Type'}, 'requested' => $value];
            },
        ],
        6 => (object)[
            'title' => "Response Body equals to",
            'values' => [
                (object)['title' => 'Body', 'type' => 'text'],
            ],
            'handler' => function ($rep, $value) {
                $result = $rep->body == $value;
                return (object)['result' => $result, 'given' => $rep->body, 'requested' => $value];
            },
        ],
        7 => (object)[
            'title' => "Response Body contains",
            'values' => [
                (object)['title' => 'Text', 'type' => 'text'],
            ],
            'handler' => function ($rep, $value) {
                $result = strpos($rep->body, $value) !== FALSE;
                return (object)['result' => $result, 'given' => '', 'requested' => $value];
            },
        ],
        8 => (object)[
            'title' => "HTML Body has element ID",
            'values' => [
                (object)['title' => 'Element ID', 'type' => 'text'],
            ],
            'handler' => function ($rep, $value) {

                $html = str_get_html($rep->body);

                $items = $html->find('#' . $value);



                return (object)['result' => count($items) > 0, 'given' => '', 'requested' => $value];
            },
        ],
        9 => (object)[
            'title' => "HTML Body has elements with Class",
            'values' => [
                (object)['title' => 'CSS Class', 'type' => 'text'],
            ],
            'handler' => function ($rep, $value) {
                $html = str_get_html($rep->body);
                $items = $html->find('.' . $value);
                return (object)['result' => count($items) > 0, 'given' => '', 'requested' => $value];
            },
        ],
        12 => (object)[
            'title' => "HTML Body has elements with selector",
            'values' => [
                (object)['title' => 'Selector', 'type' => 'text'],
            ],
            'handler' => function ($rep, $value) {
                $html = str_get_html($rep->body);
                $items = $html ? $html->find($value) : [];
                return (object)['result' => count($items) > 0, 'given' => '', 'requested' => $value];
            },
        ],
        13 => (object)[
            'title' => "HTML elements has inner text (value OR text)",
            'values' => [
                (object)['title' => 'Element Selector', 'type' => 'text'],
                (object)['title' => 'Value', 'type' => 'text'],
            ],
            'handler' => function ($rep, $value, $value2) {
                $html = str_get_html($rep->body);
                $items = $html ? $html->find($value) : [];
                $result = false;
                $given = '';

                foreach ($items as $item){
                    $given = trim($item->text());
                    if(strpos($given, $value2) !== FALSE){
                        $result = TRUE;
                        break;
                    }
                }

                return (object)['result' => $result > 0, 'given' => $given, 'requested' => $value];
            },
        ],
        10 => (object)[
            'title' => "JSON Body has prop",
            'values' => [
                (object)['title' => 'Propriety name', 'type' => 'text'],
            ],
            'handler' => function ($rep, $value) {
                $json = json_decode($rep->body);
                $result = isset($json->{$value});
                return (object)['result' => $result, 'given' => $json, 'requested' => $value];
            },
        ],
        11 => (object)[
            'title' => "JSON Body Prop has Value",
            'values' => [
                (object)['title' => 'Propriety Name', 'type' => 'text'],
                (object)['title' => 'Propriety Value', 'type' => 'text'],
            ],
            'handler' => function ($rep, $value, $value2) {
                $json = json_decode($rep->body);
                $result = isset($json->{$value}) && $json->{$value} == $value2;
                return (object)['result' => $result, 'given' => $json, 'requested' => $value];
            },
        ],
        14 => (object)[
            'title' => "JSON Array Length equals to",
            'values' => [
                (object)['title' => 'Propriety Name (Leave blank for root)', 'type' => 'text'],
                (object)['title' => 'Array Length', 'type' => 'number'],
            ],
            'handler' => function ($rep, $value, $value2) {
                $json = json_decode($rep->body);
                if($value){
                    $result = isset($json->{$value}) && count($json->{$value}) == $value2 ;
                }else{
                    $result = count($json) == $value2;
                }

                return (object)['result' => $result, 'given' => $json, 'requested' => $value];
            },
        ],
        15 => (object)[
            'title' => "JSON Array Length Greater than",
            'values' => [
                (object)['title' => 'Propriety Name (Leave blank for root)', 'type' => 'text'],
                (object)['title' => 'Length', 'type' => 'number'],
            ],
            'handler' => function ($rep, $value, $value2) {
                $json = json_decode($rep->body);
                if($value){
                    $result = isset($json->{$value}) && count($json->{$value}) > $value2 ;
                }else{
                    $result = count($json) > $value2;
                }

                return (object)['result' => $result, 'given' => $json, 'requested' => $value];
            },
        ],
        16 => (object)[
            'title' => "JSON Array Length Smaller than",
            'values' => [
                (object)['title' => 'Propriety Name (Leave blank for root)', 'type' => 'text'],
                (object)['title' => 'Length', 'type' => 'number'],
            ],
            'handler' => function ($rep, $value, $value2) {
                $json = json_decode($rep->body);
                if($value){
                    $result = isset($json->{$value}) && count($json->{$value}) < $value2 ;
                }else{
                    $result = count($json) < $value2;
                }

                return (object)['result' => $result, 'given' => $json, 'requested' => $value];
            },
        ],
    ];
    return $index !== FALSE && isset($asserts[$index]) ? $asserts[$index] : $asserts;
}

function doDatatable($query, $callback = null)
{
    $callback = $callback ?: function () {
    };
    $that =& get_instance();
    $input = (object)$that->input->post();
    $length = $input->length ?: 10;
    $page = ($input->page - 1) * $length;
    $order = $input->columns[intval($input->order[0]['column'])]['name'];
    $dir = $input->order[0]['dir'];
    $search = $input->search['value'] ?: '';
    $sfilter = '';
    foreach ($that->input->get('columns') as $col) {
        $col = (object)$col;
        if ($col->searchable === "false") continue;
        $sfilter .= ($sfilter ? ' OR ' : ' ') . "{$col->name} like '%$search%' ";
    }
    $query_str = "SELECT * FROM ($query) t WHERE 1=1 AND $sfilter";
    $query = $that->db->query($query_str . " ORDER BY $order $dir LIMIT $page, $length")->result();
    $total = $that->db->query("SELECT COUNT(*) total FROM ($query_str) t");
    $total = $total ? $total->row()->total : 0;
    foreach ($query as $i => $row) {

        $callback($i, $row, $query);

    }
    $return = array(
        'draw' => $input->draw ?: 0,
        'recordsTotal' => $total,
        'recordsFiltered' => $total,
        'data' => $query,
    );
    return ((object)$return);

}

function doTwtable($query_string, $callback = null)
{
    $callback = $callback ?: function () {
    };
    $that =& get_instance();
    $search = $that->input->post('search') ?: '';
    $order = $that->input->post('order');
    $dir = $that->input->post('dir') ?: 'ASC';
    $page = $that->input->post('page') ?: 1;
    $length = $that->input->post('length') ?: 10;
    $columns = $that->input->post('columns');
    $offset = ($page - 1) * $length;
    $ts = microtime(TRUE);
    $s = "'%$search%'";
    $filter = "";
    $cols = "";
    foreach ($columns as $i => $column) {
        if ($order !== null && $order == $i) $order = $column['name'];
        if ($column['searchable'] != 'false') {
            $filter .= ($filter ? ' OR' : '') . " `" . $column['name'] . "` like $s ";
        }

    }
    $qresult = "SELECT * FROM ($query_string) t WHERE $filter " . ($order ? "ORDER BY `$order` $dir" : '') . " LIMIT $offset, $length";
    $qtotal = "SELECT COUNT(*) total FROM ($query_string) t ";
    $qtotal_filter = $qtotal . " WHERE $filter";
    $query = $that->db->query($qresult)->result();
    $total = $that->db->query($qtotal);
    $total = $total && $total->num_rows() ? $total->row()->total : 0;
    $total_filter = $that->db->query($qtotal_filter);
    $total_filter = $total_filter && $total_filter->num_rows() ? $total_filter->row()->total : 0;
    foreach ($query as $row) {
        $callback($row);
    }
    return (object)[
        'time' => round(microtime(TRUE) - $ts, 2),
        'data' => $query ?: [],
        'total' => $total,
        'total_filter' => $total_filter,
        'page' => $page,
        'rest' => $total_filter - $offset - count($query),
    ];

}

function name_abbr($name, $name2 = "")
{
    $name = trim($name) . ' ' . trim($name2);
    $name = explode(' ', trim($name));
    $abr = count($name) > 1 ? substr($name[0], 0, 1) . substr($name[1], 0, 1) : substr($name[0], 0, 1) . substr($name[0], strlen($name[0]) - 1, 1);
    return trim(strtoupper($abr));
}

function viewHeader($view_title, $desc, $crum, $hasMenu = FALSE)
{
    get_instance()->load->view('segments/view_header', [
        'view' => $view_title,
        'crumb' => $crum,
        'desc' => $desc,
        'hasMenu' => $hasMenu,
    ]);
}

function projectMenu($current, $project)
{
    get_instance()->load->view('segments/project_menu', ['active' => $current, 'project' => $project]);
}
function settingsMenu($current)
{
    get_instance()->load->view('segments/settings_menu', ['active' => $current]);
}





