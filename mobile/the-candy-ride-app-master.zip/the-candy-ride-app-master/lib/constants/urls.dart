import 'package:rider_app/constants/project_keys.dart';

class Urls {
  static String imageBaseUrl = "https://thecandytech.com/dms/uploads/rider/";
  static String baseRiderUrl = "https://thecandytech.com/dms/api/riderapi/";
  static String baseDriverUrl = 'https://thecandytech.com/dms/api/driverapi/';
  static String baseDriverImageUrl =
      "https://dms.thecandytech.com/uploads/driver/profile_photo";
  static String currency = baseDriverUrl + 'currency';
  static String country = baseRiderUrl + 'rider_country';
  static String signUp = baseRiderUrl + 'rider_signup';
  static String login = baseRiderUrl + 'rider_login';
  static String updateprofile = baseRiderUrl + 'rider_updateprofile';
  static String forgotPassword = baseRiderUrl + 'rider_forgotpassword';
  static String logout = baseRiderUrl + 'rider_logoutdata';
  static String vehicleCategory = baseRiderUrl + 'rider_vehicle_category';
  static String vehicleSubtype = baseRiderUrl + 'rider_vehicle_subtype';
  static String fleetShow = baseRiderUrl + 'rider_fleet_show';
  static String zoneRide = baseRiderUrl + 'rider_zoneride';
  static String ridebook = baseRiderUrl + 'rider_ridebook';
  static String cancelride = baseRiderUrl + 'rider_cancelride';
  static String complaint = baseRiderUrl + 'rider_complaint';
  static String feedbackride = baseRiderUrl + 'rider_feedbackride';
  static String rideInstant = baseRiderUrl + 'rider_ride_instant';
  static String ridePrebooking = baseRiderUrl + 'rider_ride_prebooking';
  static String rideDetail = baseRiderUrl + 'rider_ride_detail';
  static String rideRetrieveRide = baseRiderUrl + 'rider_retrieve_ride';
  static String riderRideHistory = baseRiderUrl + 'rider_ride_history';
  static String riderSetfeedback = baseRiderUrl + 'rider_setfeedback';
  static String riderRetrieveFeedback =
      baseRiderUrl + 'rider_retrieve_feedback';
  static String riderCurrentride = baseRiderUrl + "rider_currentride";
  static String riderRideRebook = baseRiderUrl + "rider_ride_rebook";
  static String riderUninstallapp = baseRiderUrl + "rider_uninstallapp";

  // map related APIs
  static String mapBoxThirPartyUrl =
      "https://api.mapbox.com/styles/v1/thecandy/ckj6xb7nwewvw19qmx8iywiq5/tiles/256/{z}/{x}/{y}@2x?access_token=${ProjectKeys.mapBoxKey}";
  static String getRoute =
      "https://api.mapbox.com/directions/v5/mapbox/driving/";
  static String searchPlacesUrl(String searchText) =>
      'https://api.mapbox.com/geocoding/v5/mapbox.places/$searchText.json?access_token=${ProjectKeys.mapBoxKey}';
  static String getNavigationUrl(String points) =>
      'https://api.mapbox.com/directions/v5/mapbox/driving/$points?alternatives=true&geometries=polyline&steps=true&access_token=${ProjectKeys.mapBoxKey}';
  static String getMapMatchingUrl(String points) =>
      'https://api.mapbox.com/matching/v5/mapbox/driving/$points?overview=full&geometries=geojson&access_token=${ProjectKeys.mapBoxKey}';
}
