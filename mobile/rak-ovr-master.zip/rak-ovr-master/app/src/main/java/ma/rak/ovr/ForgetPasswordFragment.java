package ma.rak.ovr;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import ma.rak.ovr.api.RetrofitClient;
import ma.rak.ovr.bodyResponse.LoginResponse;
import ma.rak.ovr.storage.SharedPrefManager;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ForgetPasswordFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ForgetPasswordFragment extends Fragment {


    Button saveButton, cancelButton;

    EditText currentPassword, newPassword, confirmPassword;

    DrawerLayout drawerLayout;
    Fragment dashboard;
    DashboardFragment dashboardFragment = null;

    public ForgetPasswordFragment() {
        // Required empty public constructor
    }


    public static ForgetPasswordFragment newInstance(String param1, String param2) {
        ForgetPasswordFragment fragment = new ForgetPasswordFragment();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }


    public void showFragment(Fragment fragmentToShow) {
        // Create transactionns
        FragmentTransaction transaction = getActivity().getSupportFragmentManager()
                .beginTransaction()
                .setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.slide_out_right);

        // Hide all of the fragments
        for (Fragment fragment : getActivity().getSupportFragmentManager().getFragments()) {
            transaction.hide(fragment);
        }

        if (fragmentToShow.isAdded()) {
            // When fragment was previously added - show it
            transaction.show(fragmentToShow);
        } else {
            // When fragment is adding first time - add it
            transaction.add(R.id.frame, fragmentToShow);

        }

        transaction.commit();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_forget_password, container, false);

        saveButton = (Button) rootView.findViewById(R.id.save_button);
        cancelButton = (Button) rootView.findViewById(R.id.cancel_button);

        drawerLayout = rootView.findViewById(R.id.drawer_layout);

        currentPassword = (EditText) rootView.findViewById(R.id.currentPassword);
        newPassword = (EditText) rootView.findViewById(R.id.newPassword);
        confirmPassword = (EditText) rootView.findViewById(R.id.confirmPassword);

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentPassword.setText("");
                newPassword.setText("");
                confirmPassword.setText("");
                currentPassword.requestFocus();
                if (dashboardFragment == null)
                    dashboard = new DashboardFragment();
                //loadFragment(dashboard, FRAGMENT_TAG);
                showFragment(dashboard);
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String currentPwd = currentPassword.getText().toString().trim();
                String newPsw = newPassword.getText().toString().trim();
                String confirmPwd = confirmPassword.getText().toString().trim();

                if (currentPwd.isEmpty()) {
                    currentPassword.setError("Veuillez remplir le champs mot de passe actuel");
                    currentPassword.requestFocus();
                    return;
                }

                if (newPsw.isEmpty()) {
                    newPassword.setError("Veuillez remplir le champs nouveau mot de passe");
                    newPassword.requestFocus();
                    return;
                }
//                if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
//                    loginEmail.setError("Email not valide");
//                    loginEmail.requestFocus();
//                    return;
//                }
                if (confirmPwd.isEmpty()) {
                    confirmPassword.setError("Veuillez remplir le champs confirmer le mot de passe");
                    confirmPassword.requestFocus();
                    return;
                }

                if (!newPsw.equals(confirmPwd)) {
                    confirmPassword.setError("Veuillez saisair un mot de passe identique");
                    confirmPassword.requestFocus();
                    return;
                }

                String userName = SharedPrefManager.getInstance(getActivity()).getUserName();

                Call<LoginResponse> call = RetrofitClient
                        .getApi(SharedPrefManager.getInstance(getActivity()).getToken())
                        .change_password(userName, currentPwd, newPsw);

                call.enqueue(new Callback<LoginResponse>() {
                    @Override
                    public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                        LoginResponse s = null;
                        if (response.code() == 200) {
                            s = response.body();
                            //Toast.makeText(LoginActivity.this, s.getMsg(), Toast.LENGTH_LONG).show();
                            SharedPrefManager.getInstance(getActivity()).saveUser(SharedPrefManager.getInstance(getActivity()).getUserID(), s.getData().token, s.getData().expires.toString(), s.getData().scoop, s.getData().fullname, userName, newPsw);
                            MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(getContext())
                                    .setTitle(getResources().getString(R.string.title))
                                    .setNegativeButton(getResources().getString(R.string.cancel), (dialog, which) -> {

                                    })
                                    .setPositiveButton(getResources().getString(R.string.ok), (dialog, which) -> {

                                    })
                                    .setMessage(getResources().getString(R.string.success_message));

                            builder.show();


                        } else {
                            //Toast.makeText(getActivity(), "Utilisateur no trouvé", Toast.LENGTH_LONG).show();

                            MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(getContext())
                                    .setTitle(getResources().getString(R.string.title))
                                    .setNegativeButton(getResources().getString(R.string.decline), (dialog, which) -> {

                                    })
                                    .setPositiveButton(getResources().getString(R.string.accept), (dialog, which) -> {

                                    })
                                    .setMessage(getResources().getString(R.string.error_message));

                            builder.show();
                        }
                    }

                    @Override
                    public void onFailure(Call<LoginResponse> call, Throwable t) {

                    }
                });
            }
        });

        return rootView;
    }
}