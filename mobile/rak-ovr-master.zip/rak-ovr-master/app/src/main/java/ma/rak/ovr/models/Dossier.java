package ma.rak.ovr.models;

import android.os.Parcel;
import android.os.Parcelable;

import io.realm.RealmObject;


public class Dossier extends RealmObject implements Parcelable {

    private String GERANCE;
    private String NUM;
    private String ADRESSE;

    public Dossier(){}

    public Dossier(String GERANCE, String NUM, String ADRESSE) {
        this.GERANCE = GERANCE;
        this.NUM = NUM;
        this.ADRESSE = ADRESSE;
    }

    protected Dossier(Parcel in) {
        GERANCE = in.readString();
        NUM = in.readString();
        ADRESSE = in.readString();
    }

    public static final Creator<Dossier> CREATOR = new Creator<Dossier>() {
        @Override
        public Dossier createFromParcel(Parcel in) {
            return new Dossier(in);
        }

        @Override
        public Dossier[] newArray(int size) {
            return new Dossier[size];
        }
    };

    public String getGERANCE() {
        return GERANCE;
    }

    public void setGERANCE(String GERANCE) {
        this.GERANCE = GERANCE;
    }

    public String getNUM() {
        return NUM;
    }

    public void setNUM(String NUM) {
        this.NUM = NUM;
    }

    public String getADRESSE() {
        return ADRESSE;
    }

    public void setADRESSE(String ADRESSE) {
        this.ADRESSE = ADRESSE;
    }

    @Override
    public String toString() {
        return "Dossier{" +
                "GERANCE=" + GERANCE +
                ", NUM='" + NUM + '\'' +
                ", ADRESSE='" + ADRESSE + '\'' +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(GERANCE);
        dest.writeString(NUM);
        dest.writeString(ADRESSE);
    }


    public String json(){
        return "{\"GERANCE\": \""+GERANCE+"\", \"NUM\": \""+NUM+"\", \"ADRESSE\":\""+ADRESSE+"\"}";
    }
}
