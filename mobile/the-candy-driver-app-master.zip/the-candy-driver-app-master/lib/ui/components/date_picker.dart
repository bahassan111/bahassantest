import 'package:driver/constants/app_themes.dart';
import 'package:driver/constants/helpers/helpers.dart';
import 'package:flutter/material.dart';

class CustomPicker extends StatefulWidget {
  final String label;
  final Function onDateSelect;
  final DateTime intialDate;
  final DateTime endDate;
  final DateTime selectedDate;
  final bool isClickAble;
  CustomPicker({
    Key key,
    this.onDateSelect,
    this.label,
    this.endDate,
    this.intialDate,
    this.selectedDate,
    this.isClickAble = true,
  }) : super(key: key);

  @override
  _CustomPickerState createState() => _CustomPickerState();
}

class _CustomPickerState extends State<CustomPicker> {
  DateTime dateTime;

  @override
  void initState() {
    super.initState();
    dateTime = widget.selectedDate;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          Text(
            widget.label,
            style: Theme.of(context).textTheme.headline2.copyWith(
                  fontSize: 12,
                ),
          ),
          GestureDetector(
            onTap: () async {
              if (widget.isClickAble) {
                DateTime dt = await selectDate(
                  context,
                  endDate: widget.endDate,
                  intialDate: widget.intialDate,
                  selectedDate: widget.selectedDate,
                );
                widget.onDateSelect(dt);
                setState(() {
                  dateTime = dt;
                });
              }
            },
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                border: Border.all(
                  color: AppThemes.lightAthensGrayBorderColor,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    dateTime != null
                        ? formateDateToDDMMYYYY(dateTime)
                        : "dd/mm/yyyy",
                    style: Theme.of(context).textTheme.headline2.copyWith(
                          fontSize: 15,
                        ),
                  ),
                  if (widget.isClickAble)
                    Icon(
                      Icons.calendar_today,
                      size: 18,
                    )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
