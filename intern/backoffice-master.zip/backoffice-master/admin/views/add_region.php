<style type="text/css">
    #map {
        height: 320px;
    }
    #map.loading {
        position : relative;
    }
    #map.loading:after {
        content: 'Chargement';
        position: absolute;
        width: 100%;
        height: 100%;
        left: 0;
        top: 0;
        display: flex;
        align-content: center;
        justify-content: center;
        z-index: 999999;
        background: #00000091;
        padding: 22px;
        color: #fff;
    }
</style>


<div class="row">
    <form id="form_save_region" enctype="multipart/form-data" method="post" class="container-fluid">

        <div class="row">

            <div class="col-sm-12">
                <div class="col-sm-6 no_padding_l">
                    <div class="form-group">
                        <label for="name">Nom</label>
                        <input type="text" name="name" id="name" class="form-control" value="<?= $one ?  $one->name : '' ?>">
                    </div>
                </div>
                <div class="col-sm-6 no_padding_l">
                    <div class="form-group">
                        <label for="name_ar">إسم الجهة</label>
                        <input type="text" name="name_ar" id="name_ar" class="form-control" value="<?= $one ?  $one->name_ar : '' ?>">
                    </div>
                </div>
            </div>

            <div class="col-sm-12">
                <div class="col-sm-6 no_padding_l">
                    <div class="form-group">
                        <label for="director">Responsable</label>
                        <input type="text" name="director" id="director" class="form-control" value="<?= $one ?  $one->director : '' ?>">
                    </div>
                </div>
                <div class="col-sm-6 no_padding_l">
                    <div class="form-group">
                        <label for="director_ar">المسؤول</label>
                        <input type="text" name="director_ar" id="director_ar" class="form-control" value="<?= $one ?  $one->director_ar : '' ?>">
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="col-sm-6 no_padding_l">
                    <div class="form-group">
                        <label for="phone">Tél</label>
                        <input type="text" name="phone" id="phone" class="form-control" value="<?= $one ?  $one->phone : '' ?>">
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="col-sm-6 no_padding_l">
                    <div class="form-group">
                        <label for="phone">Fax</label>
                        <input type="text" name="fax" id="fax" class="form-control" value="<?= $one ?  $one->fax : '' ?>">
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="col-sm-6 no_padding_l">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="text" name="email" id="email" class="form-control" value="<?= $one ?  $one->email : '' ?>">
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="col-sm-6 no_padding_l">
                    <div class="form-group">
                        <label for="city">Ville</label>
                        <input type="text" name="city" id="city" class="form-control" value="<?= $one ?  $one->city : '' ?>">
                    </div>
                </div>
                <div class="col-sm-6 no_padding_l">
                    <div class="form-group">
                        <label for="city_ar">المدينة</label>
                        <input type="text" name="city_ar" id="city_ar" class="form-control" value="<?= $one ?  $one->city_ar : '' ?>">
                    </div>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="col-sm-6 no_padding_l">
                    <div class="form-group">
                        <label for="address">Adresse</label>
                        <textarea type="text" name="address" id="address" class="form-control"><?= $one ?  $one->address : '' ?></textarea>
                    </div>
                </div>
                <div class="col-sm-6 no_padding_l">
                    <div class="form-group">
                        <label for="address_ar">العنوان</label>
                        <textarea type="text" name="address_ar" id="address_ar" class="form-control"><?= $one ?  $one->address_ar : '' ?></textarea>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">



                <div class="col-sm-12 no_padding_l">
                    <div class="form-group">
                        <label>Recherche</label>
                        <textarea type="text" id="rech" class="form-control"></textarea>
                    </div>
                </div>

                <div class="col-sm-12 no_padding_l">
                    <div class="form-group">
                        <label for="lat">Carte</label>
                        <div id="map"></div>
                        <input type="hidden" name="lat" id="lat" class="form-control" value="<?= $one ?  $one->lat : '' ?>">
                        <input type="hidden" name="lng" id="lng" class="form-control" value="<?= $one ?  $one->lng : '' ?>">
                        <input type="hidden" name="id" id="id" class="form-control" value="<?= $one ?  $one->id : '' ?>">
                    </div>
                </div>



            </div>
        </div>


    </form>

</div>
