import 'dart:async';
import 'dart:typed_data';
import 'dart:ui';

import 'package:audioplayers/audio_cache.dart';
import 'package:bot_toast/bot_toast.dart';
import 'package:esys_flutter_share/esys_flutter_share.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:vector_math/vector_math.dart' as vm;
import 'package:flutter/rendering.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:logger/logger.dart';
import 'package:rider_app/constants/constants.dart';
import 'package:rider_app/constants/urls.dart';
import 'package:rider_app/controllers/controllers.dart';
import 'components/components.dart';
import "package:latlong/latlong.dart";

class TripStart extends StatefulWidget {
  @override
  _TripStartState createState() => _TripStartState();
}

class _TripStartState extends State<TripStart> {
  bool isMenuShow = false;
  bool isTripEnd = false;
  double height, width;
  LatLng previousLtnLng;
  final MapController mapController = MapController();
  static TripAcceptController to = AuthController.tripTo;
  static HomeController homeTo = Get.find();
  GlobalKey globalKey = GlobalKey();

  var _firebaseRef = FirebaseDatabase().reference();
  Timer _timerForGettingUpdatedStatus;

  @override
  void initState() {
    print("init state");

    _timerForGettingUpdatedStatus = Timer.periodic(Duration(seconds: 5), (_) {
      to.getRideDetail().then((value) {
        if (to.ride != null) {
          if (to.ride.rideStatus == '4') {
            _timerForGettingUpdatedStatus?.cancel();
            setState(() {
              isTripEnd = true;
            });
            Future.delayed(Duration(seconds: 3), () {
              to.ride = null;
              Get.offAndToNamed(
                '/RatingUI',
                arguments: {'tripId': to.tripId},
              );
            });
          }
        } else {
          _timerForGettingUpdatedStatus?.cancel();
        }
      });
    });
    super.initState();
  }

  @override
  void dispose() {
    _timerForGettingUpdatedStatus?.cancel();
    super.dispose();
  }

  shareImage() async {
    BotToast.showLoading();
    var pngBytes = await _capturePng();
    print("pngBytes $pngBytes");
    try {
      await Share.file(
        'Trip detail',
        'tripdetail.png',
        pngBytes,
        'image/png',
        text:
            "Driver name: ${to.ride.fname + " " + to.ride.lname}\n Vehicle Registration No: ${to.ride.plateNo}\n Trip ID: ${homeTo.tripId(
          id: to.ride.id,
          bookingType: to.ride.bookType,
          type: to.carType,
        )}\n Driver Number: ${to.ride.driverMobile}",
      );
    } catch (e) {
      BotToast.showText(text: "shareImage $e");
    }
    BotToast.cleanAll();
  }

  Future<Uint8List> _capturePng() async {
    RenderRepaintBoundary boundary;
    try {
      boundary = globalKey.currentContext.findRenderObject();
    } catch (e) {}
    if (boundary == null) {
      await Future.delayed(const Duration(milliseconds: 20));
      return _capturePng();
    }
    try {
      var image = await boundary.toImage(pixelRatio: 3.0);
      var byteData = await image.toByteData(format: ImageByteFormat.png);

      return byteData.buffer.asUint8List();
    } catch (e) {}

    return null;
  }

  reCenterMapPosition({double currentZoom}) async {
    mapController.move(to.currentLocation, currentZoom ?? 17);
    mapController.rotate(0);
  }

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return RepaintBoundary(
      key: globalKey,
      child: Scaffold(
        body: Container(
          child: Column(
            children: [
              CustomeAppBar(
                updateMenuPosition: () => setState(() {
                  isMenuShow = !isMenuShow;
                }),
                isMenuShow: isMenuShow,
                title: isTripEnd
                    ? "destinationArrived".tr
                    : "yourRideHasStarted".tr,
              ),
              Expanded(
                child: Stack(
                  children: [
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Expanded(
                          child: Stack(
                            children: [
                              StreamBuilder<Position>(
                                stream:
                                    Geolocator.getCurrentPosition().asStream(),
                                builder: (context, snapshot) {
                                  return Container(
                                    child: to?.ride != null
                                        ? StreamBuilder(
                                            stream: _firebaseRef
                                                .child(to?.ride?.driverId
                                                        .toString() ??
                                                    -1)
                                                .onValue,
                                            builder: (context, snapshot) {
                                              if (!snapshot.hasData ||
                                                  snapshot.data == null) {
                                                return Center(
                                                  child:
                                                      CircularProgressIndicator(),
                                                );
                                              }
                                              if (previousLtnLng != null &&
                                                  (to?.ride?.rideStatus ==
                                                      RideStatus.started) &&
                                                  snapshot?.data?.snapshot
                                                          ?.value !=
                                                      null) {
                                                if ((previousLtnLng.latitude -
                                                                (snapshot
                                                                            ?.data
                                                                            ?.snapshot
                                                                            ?.value[
                                                                        'lat'] ??
                                                                    0.0))
                                                            .abs() >
                                                        0.00001000 &&
                                                    (previousLtnLng.longitude -
                                                                (snapshot
                                                                        ?.data
                                                                        ?.snapshot
                                                                        ?.value['lng'] ??
                                                                    0.0))
                                                            .abs() >
                                                        0.00001000) {
                                                  reCenterMapPosition(
                                                      currentZoom:
                                                          mapController.zoom);
                                                }
                                              }
                                              previousLtnLng =
                                                  to.currentLocation;
                                              if (snapshot
                                                      ?.data?.snapshot?.value !=
                                                  null)
                                                to.currentLocation = LatLng(
                                                    snapshot?.data?.snapshot
                                                            ?.value['lat'] ??
                                                        0.0,
                                                    snapshot?.data?.snapshot
                                                            ?.value['lng'] ??
                                                        0.0);
                                              print("snapshot" +
                                                  snapshot.data.toString());
                                              print(to?.ride?.driverId
                                                  .toString());
                                              return Stack(
                                                children: [
                                                  FlutterMap(
                                                    mapController:
                                                        mapController,
                                                    options: MapOptions(
                                                      center:
                                                          to.currentLocation,
                                                      zoom: 17.0,
                                                    ),
                                                    layers: [
                                                      TileLayerOptions(
                                                        errorImage: AssetImage(
                                                            AllImages.adddp),
                                                        errorTileCallback:
                                                            (tile, d) {
                                                          print("from error tile call back 230 trip start " +
                                                              tile.toString() +
                                                              " " +
                                                              d.toString());
                                                        },
                                                        urlTemplate: Urls
                                                            .mapBoxThirPartyUrl,
                                                        additionalOptions: {
                                                          'accessToken':
                                                              ProjectKeys
                                                                  .mapBoxKey,
                                                          "id":
                                                              "mapbox.mapbox-streets-v8",
                                                        },
                                                      ),
                                                      PolylineLayerOptions(
                                                        polylines:
                                                            to?.routeDetail
                                                                        ?.code ==
                                                                    'Ok'
                                                                ? [
                                                                    Polyline(
                                                                      points: [
                                                                        ...to.mapMatchingModel?.matchings?.first?.geometry?.coordinates ??
                                                                            []
                                                                      ],
                                                                      strokeWidth:
                                                                          5,
                                                                      color: AppThemes
                                                                          .lightpauaBackGroundColor,
                                                                    )
                                                                  ]
                                                                : [],
                                                        polylineCulling: true,
                                                      ),
                                                      MarkerLayerOptions(
                                                        markers: to.ride == null
                                                            ? []
                                                            : [
                                                                if (snapshot
                                                                        ?.data
                                                                        ?.snapshot
                                                                        ?.value !=
                                                                    null)
                                                                  // my driver location ( car )
                                                                  Marker(
                                                                    width: 30.0,
                                                                    height:
                                                                        30.0,
                                                                    point:
                                                                        LatLng(
                                                                      snapshot?.data?.snapshot?.value !=
                                                                              null
                                                                          ? snapshot
                                                                              ?.data
                                                                              ?.snapshot
                                                                              ?.value['lat']
                                                                          : 0.0,
                                                                      snapshot?.data?.snapshot?.value !=
                                                                              null
                                                                          ? snapshot
                                                                              ?.data
                                                                              ?.snapshot
                                                                              ?.value['lng']
                                                                          : 0.0,
                                                                    ),
                                                                    builder: (ctx) =>
                                                                        Transform
                                                                            .rotate(
                                                                      angle: vm.radians(
                                                                          (snapshot?.data?.snapshot?.value != null ? snapshot?.data?.snapshot?.value['bearing'] ?? 0.0 : 0.0) + 0.0 ??
                                                                              0.0),
                                                                      child: Image.asset(
                                                                          AllImages
                                                                              .newCar,
                                                                          width:
                                                                              40,
                                                                          height:
                                                                              40),
                                                                    ),
                                                                  ),
                                                                // my current location pin (in black)
                                                                // Marker(
                                                                //     width: 20.0,
                                                                //     height:
                                                                //         20.0,
                                                                //     point: to
                                                                //         .currentLocation,
                                                                //     builder: (ctx) =>
                                                                //         Image.asset(
                                                                //             AllImages.user)),
                                                                // starting location pin ( pink )
                                                                Marker(
                                                                  width: 50.0,
                                                                  height: 50.0,
                                                                  point: LatLng(
                                                                      double.parse(to
                                                                          .ride
                                                                          .pickuplat),
                                                                      double.parse(to
                                                                          .ride
                                                                          .pickuplong)),
                                                                  builder: (ctx) =>
                                                                      Image.asset(
                                                                          AllImages
                                                                              .pin),
                                                                ),
                                                                Marker(
                                                                  width: 50.0,
                                                                  height: 50.0,
                                                                  point: LatLng(
                                                                    double.parse(to
                                                                        .ride
                                                                        .droplat),
                                                                    double.parse(to
                                                                        .ride
                                                                        .droplong),
                                                                  ),
                                                                  builder: (ctx) =>
                                                                      Image.asset(
                                                                          AllImages
                                                                              .pinGreen),
                                                                )
                                                              ],
                                                      ),
                                                    ],
                                                  ),
                                                  Align(
                                                    alignment:
                                                        Alignment.bottomRight,
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .end,
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      children: [
                                                        GestureDetector(
                                                          onTap: shareImage,
                                                          child: Container(
                                                            padding:
                                                                EdgeInsets.all(
                                                                    10),
                                                            margin:
                                                                EdgeInsets.only(
                                                                    right: 10,
                                                                    bottom: 0),
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          50),
                                                              color:
                                                                  Colors.white,
                                                            ),
                                                            child: Icon(
                                                              Icons.share,
                                                              size: 25,
                                                            ),
                                                          ),
                                                        ),
                                                        TripDetail(
                                                          destination: to
                                                              .ride.dropaddress,
                                                          distance: (double.parse(to
                                                                          .ride
                                                                          .distance)
                                                                      .toPrecision(
                                                                          2))
                                                                  .toString() +
                                                              " kms".tr,
                                                          time: (double.parse(to
                                                                          .ride
                                                                          .duration)
                                                                      .toPrecision(
                                                                          2))
                                                                  .toString() +
                                                              " mins".tr,
                                                        )
                                                      ],
                                                    ),
                                                  )
                                                ],
                                              );
                                            })
                                        : Container(),
                                  );
                                },
                              ),
                              to.mapMatchingModel != null && to.ride != null
                                  ? Align(
                                      alignment: Alignment.bottomRight,
                                      child: TripDetail(
                                        destination: to.ride.dropaddress,
                                        distance:
                                            (double.parse(to.ride.distance)
                                                        .toPrecision(2))
                                                    .toString() +
                                                " kms".tr,
                                        time: (double.parse(to.ride.duration)
                                                    .toPrecision(2))
                                                .toString() +
                                            " mins".tr,
                                      ),
                                    )
                                  : Container()
                            ],
                          ),
                        ),
                        isTripEnd ? Container() : DriverDetail(),
                        CureentTripPickUpDrop(),
                      ],
                    ),
                    CustomDrawer(
                      updateMenuPosition: () => setState(() {
                        isMenuShow = false;
                      }),
                      isMenuShow: isMenuShow,
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
