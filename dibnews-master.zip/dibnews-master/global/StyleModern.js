import {sizes, colors} from "./GlobalStyle";
import {Dimensions, StyleSheet} from "react-native";
const win = Dimensions.get('screen');
const ofHeight = (p)=> p * win.height / 100;
const ofWidth = (p)=> p * win.width / 100;


const modern = StyleSheet.create({
    circles_header: {

    },
    circles_scroll: {},
    circles: {
        flexDirection:'row',
        marginVertical: 8,
        padding: 12,
    },
    circle: {
        height: 80,
        width: 80,
        overflow:'hidden',
        borderRadius: 40,
        marginHorizontal: 12,
        borderWidth: 4,
        borderColor:'#fc403b',
        position:'relative',
    },
    circle_inside: {},
    circle_outer: {
        position:'relative',
    },
    circle_icon: {
        height: 32,
        width: 32,
        color:'#fc403b',
        backgroundColor:'#fc403b',
        position : 'absolute',
        left: -8,
        top: -8,
        borderRadius: 12,
        borderBottomRightRadius: 0,
    },

    circle_text: {
        color:'#404040',
        textAlign: 'center',
        marginVertical: 8,
    },

    headline : {
        padding: 12,
        borderBottomWidth: 1,
        borderBottomColor: '#f0f0f0',
        marginBottom: 18,
    },
    headline_title : {
        marginBottom: 12,
        fontSize: sizes.md,
        fontWeight: 'bold',
    },
    headline_image : {
        width: '100%',
        height: ofWidth(100) / 1.61803398875,
        borderRadius: 12,
        overflow: 'hidden',
        elevation: 12,
        marginBottom: 8,
    },
    headline_date: {
        color: '#696969',
        fontSize: sizes.sm,
        paddingBottom: 16,
    },
    headline_exerpt: {
        color: '#222222',
        fontSize: sizes.nr,
        paddingVertical: 4,
    },
    sep_title: {
        color: '#a8a8a8',
        fontSize: 16,
        paddingVertical: 4,
    },
});


export default modern;
