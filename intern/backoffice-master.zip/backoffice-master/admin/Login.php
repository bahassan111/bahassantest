<?php

class Login{

    public $db;
    public $lang;
    public function __construct()
    {
        $this->db = new Database(config()->db_host, config()->db_user, config()->db_password, config()->db_name, config()->port);
        $this->lang = currentLanguage();
    }


    public function login(){

        if(__($_POST)->email) return $this->enter();

        $data = [
            'title' => 'Log in'
        ];

        load_view('login', $data, false);
    }

    public function enter(){
        $rep = (object)['status' => 'NO', 'message' => 'Please provide a valid email address and password'];

        $email = __($_POST)->email;
        $password = __($_POST)->password;

        if($email && $password){

            $data = $this->db->query("SELECT * FROM admin WHERE email = '$email' AND password = '$password'");

            if(count($data) > 0){
                $user = $data[0];
                $s = new Session();
                $s->set('user_id', $user->id);
                $s->set('user', $user);

                $rep->status = 'OK';
                $rep->user = $user->fullname;
            }else{
                $rep->message = 'The Password/Email you have entred is wrong.';
            }

        }


        responseJSON($rep);
    }

    public function logout(){
        $s = new Session();
        $s->delete('user_id');
        header('Location: '. site_url('admin/?c=login&page=login'));
    }




}