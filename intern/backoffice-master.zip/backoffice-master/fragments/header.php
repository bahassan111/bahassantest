<?php
defined('BASE') OR die('Direct access is not allowed');
$clang = currentLanguage()?: 'french';
$lang_text = languageFullName($clang);
?>
<!doctype html>
<html class="no-js" lang="">

<head>
    <meta charset="utf-8">
    <title><?= $title; ?></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?= site_url('images/logo_sm.png'); ?>">

    <!--<link rel="manifest" href="site.webmanifest">-->

    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700&display=swap" rel="stylesheet">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= site_url('assets/css/normalize.css'); ?>">
    <link rel="stylesheet" href="<?= site_url('assets/css/standard.css'); ?>">
    <link rel="stylesheet" href="<?= site_url('assets/css/default.css'); ?>">
    <link rel="stylesheet" href="<?= site_url('assets/css/default2.css'); ?>">
    <link rel="stylesheet" href="<?= site_url('assets/css/mobile.css'); ?>">

    <?php if(current_language()->rtl){?>
        <link href="https://fonts.googleapis.com/css?family=Almarai:300,400,700,800&display=swap&subset=arabic" rel="stylesheet">
        <link rel="stylesheet" href="<?= site_url('assets/css/rtl.css'); ?>">
    <?php } ?>

    <meta name="theme-color" content="#fafafa">

    <script>
        var ifes = {
            url : '<?= site_url() ?>',
            language : {
                loading : '<?= lang('loading') ?>',
            },
        };

    </script>
</head>
<body <?= currentLanguage() === 'arabic' ? 'dir="ltr"' : ''; ?>>

<div class="loading"><div class="loader"><span><i></i></span> <b><?= lang('loading') ?> ..</b></div></div>
<header>
    <div class="fheader">
        <div class="logo">
            <a href="<?= site_url(); ?>">
                <img src="<?= site_url('images/logo_sm.png'); ?>" alt="logo">
            </a>
        </div>

        <div class="nav">
            <ul>
                <li><a href="<?= site_url(); ?>"><?= lang('home'); ?></a></li>
                <li><a href="<?= site_url('?page=chapitres'); ?>"><?= lang('chapters'); ?></a></li>
                <li><a href="<?= site_url('?page=about'); ?>"><?= lang('about'); ?></a></li>
                <li>
                    <a href="#"><?= lang('mobile_app'); ?></a>
                    <ul>
                        <li><a target="_blank" href="<?= config()->lien_playstore; ?>"><?= lang('android'); ?></a></li>
                        <li><a target="_blank" href="<?= config()->lien_appstore; ?>"><?= lang('iphone'); ?></a></li>
                    </ul>
                </li>

                <li>
                    <a target="_blank" href="<?= site_url('uploads/إشارتي صوتي.pdf') ?>" download class="upload_document"><?= lang('telecharger_doc'); ?></a>
                </li>




            </ul>
        </div>

        <div class="lng_switch">
            <?php
            foreach ($country_languages as $key=>$country_language){
                if($country_language->id == current_language()->id){?>
                    <span class="slng a"><img src="<?= site_url('images/flags/'.$country_language->iso.'.png'); ?>" alt="<?= $country_language->name; ?>"> <b><?= $country_language->native; ?></b></span>
            <?php }}?>
            <div class="l">
                <?php foreach ($country_languages as $key=>$country_language){  ?>
                <a href="javascript:void(0)"  class="change_language slng <?= $country_language->id == current_language()->id ? 'selected' : '' ?>" data-lang="<?= $country_language->id ?>" data-index="<?= $key+1 ?>"><img src="<?= site_url('images/flags/'.$country_language->iso.'.png'); ?>" alt="<?= $country_language->name ?>"> <b><?= $country_language->native ?></b></a>
                <?php } ?>
            </div>
        </div>

        <div class="mobile_sandw">
            <div class="msand_btn">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </div>


</header>
<div class="content">
