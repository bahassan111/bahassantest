<?php

addCSS([
    'assets/plugins/bootstrap/css/bootstrap.min.css',
    'assets/plugins/fontawesome/css/all.css',
    'assets/plugins/bootstrap-select/css/bootstrap-select.css',
    'assets/plugins/datatables/datatables.css',
    'assets/style/default/fonts.css',
    'assets/style/default/external.css',
]);

addJS([
    'assets/plugins/jquery-3.4.1.min.js',
    'assets/plugins/moment-with-locales.js',
    'assets/plugins/bootstrap/js/bootstrap.bundle.min.js',
    'assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js',
    'assets/plugins/datatables/datatables.min.js',
    'assets/plugins/bootstrap-select/js/bootstrap-select.min.js',
    'assets/plugins/jquery.validate/jquery.validate.min.js',
    'assets/plugins/jquery.validate/additional-methods.min.js',
    'assets/plugins/tw_datatables/tw.datatable.js',
    'assets/plugins/jscolor.js',
    'assets/js/external.js',
]);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" type="text/css" href="../../../assets/style/default/external.css"/>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Login</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <?php

    echo getCSS();

    ?>


    <script>
        var site_url = '<?= site_url();?>',
            site_title = '<?= get_instance()->config->item('site_title') ?>';
    </script>
</head>

<body id="login_body">

<div class="login_holder entring">
    <div class="login_bg"></div>
    <div class="login_screen">
        <div class="screen_back">
            <div class="scrren_btext">
                <h3>Welcome Back!</h3>
                <p>Please sign in using your professional e-mail or your username.</p>
            </div>
        </div>
        <div class="screen_body">
            <form method="post" enctype="multipart/form-data">
                <div class="lgf">
                    <label for="identity">Username / Email</label>
                    <input name="identity" id="identity" type="text">
                </div>
                <div class="lgf">
                    <label for="password">Password</label>
                    <input name="password" id="password" type="password">
                </div>
                <div class="lgf">
                    <input type="checkbox" name="remeber" id="remember">
                    <label for="remember">Keep me in</label>
                </div>
                <div class="lgf fbtn">
                    <button type="submit">Connect</button>
                </div>
            </form>
        </div>

    </div>

</div>



<?php echo getJS(); ?>
</body>
</html>