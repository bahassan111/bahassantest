class LanguageModel {
  final String name;
  final String language;
  final String country;
  final String lname;
  LanguageModel({this.country, this.language, this.name, this.lname});
}
