<?php
$total = 0;
foreach ($stats as $stat) $total += $stat->total;
?>

<div class="autorun_overview">
    <div class="autr_right">
        <div class="autr_stats">
            <div class="total">
                <b><?= $total; ?></b>
                <span>Test Cases</span>
            </div>
            <?php foreach($stats as $stat){ ?>
                <div style="color:<?= $stat->color ?>;border-color:<?= $stat->color ?>;" class="s<?= strtolower($stat->name); ?>">
                    <b><?= $stat->total ?: 0; ?></b>
                    <span><?= $stat->name; ?></span>
                </div>
            <?php } ?>
        </div>
        <div class="autr_actions">
            <p><?= $message ?: ''; ?></p>
            <?= $button ?: ''; ?>
        </div>
    </div>
</div>
