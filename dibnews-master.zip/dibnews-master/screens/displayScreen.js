import React, { Component, useState, useEffect, useRef  } from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    ImageBackground,
    ActivityIndicator,
    Button, Dimensions,
    TouchableOpacity,
    Animated, AppState, SafeAreaView, ScrollView,
    BackHandler, Alert, Platform
} from "react-native";

import HTMLView from 'react-native-htmlview';
import YoutubePlayer from "react-native-youtube-iframe";
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {updateData} from "../redux/actions/dataAction";
import TopHeader from "../componants/TopHeader";
import css, {colors, sizes} from "../global/GlobalStyle";
import Carousel from 'react-native-snap-carousel';
import GestureRecognizer from 'react-native-swipe-gestures';
import Loader from "./_loader";
import {AntDesign, FontAwesome5, FontAwesome, MaterialIcons} from '@expo/vector-icons';
import news from "../data/newsDemo";


const win = Dimensions.get('screen');
const ofHeight = (p)=> p * win.height / 100;
const ofWidth = (p)=> p * win.width / 100;



class displayScreen extends Component {

    state = {
       item : null,
    };


    componentDidMount() {

        let params = this.props.route.params;
        this.setState({item : params.item});

    }

    logoPressed = ()=>{

    };

    menuPressed = ()=>{
        const {navigation} = this.props;

        navigation.toggleDrawer();
    };


    render() {

        return (

            <View style={[css.background, {height:'100%', position:'relative', backgroundColor: '#f0f0f0'}]}>
                <TopHeader transparent={false} semi_transparent={false} floatable={false} title={this.state.item_title} onMenu={this.menuPressed} onUser={this.logoPressed}/>

                <SafeAreaView style={[styles.scrollholder]}>
                    <ScrollView style={[styles.sections]}>

                        <SafeAreaView>


                            {(()=>{
                                let params = this.props.route.params;
                                let item = params.item;
                                if(!item) return (<Loader/>);

                                return (
                                    <View>
                                        <View style={[styles.np_body]}>

                                            <View style={[styles.npb_head]}>
                                                <Text style={[styles.npb_title]}>{item.title}</Text>
                                            </View>

                                            <View style={[styles.npb_sub]}>
                                                <Text style={[styles.npb_subtitle]}>{item.date}</Text>
                                            </View>

                                            <View style={[styles.npb_body]}>

                                                {(()=>{


                                                    if(item.video){

                                                        switch (item.video.source) {
                                                            case "youtube":
                                                                return (
                                                                    <YoutubePlayer
                                                                        height={300}
                                                                        play={true}
                                                                        videoId={item.video.id}
                                                                    />
                                                                );
                                                            default:
                                                                return (
                                                                    <HTMLView
                                                                        value={item.video.id}
                                                                        stylesheet={StyleSheet.create({

                                                                        })}
                                                                        onLinkPress={(url) => console.log('clicked link: ', url)}
                                                                    />
                                                                );
                                                        }

                                                    }else{

                                                        return (<Image style={{height : 300}} source={{uri : item.image}}/>)

                                                    }



                                                })()}

                                                <View style={[styles.npb_content_holder]}>
                                                    <HTMLView
                                                        value={item.content}
                                                        onLinkPress={(url) => console.log('clicked link: ', url)}
                                                    />
                                                </View>

                                            </View>


                                            <View>
                                                <View style={[styles.np_footer]}>
                                                    <Text style={[styles.np_footer_txt]}>Partager</Text>
                                                    <TouchableOpacity style={[styles.npf_btn]}>
                                                        <AntDesign  name="facebook-square" size={32} color="#2553D8" />
                                                    </TouchableOpacity>
                                                    <TouchableOpacity style={[styles.npf_btn]}>
                                                        <AntDesign name="twitter" size={32} color="#00D4FF" />
                                                    </TouchableOpacity>
                                                    <TouchableOpacity style={[styles.npf_btn]}>
                                                        <FontAwesome5 name="whatsapp-square" size={32} color="#00E979" />
                                                    </TouchableOpacity>

                                                    <TouchableOpacity style={[styles.npf_btn]}>
                                                        <AntDesign name="sharealt" size={32} color="black" />
                                                    </TouchableOpacity>


                                                </View>
                                                <View style={[styles.np_ac]}>
                                                    <TouchableOpacity onPress={()=>{
                                                        this.props.navigation.goBack();
                                                    }} style={[styles.np_ac_btn]}>
                                                        <Text style={[styles.np_ac_txt]}>Retour</Text>
                                                        <AntDesign style={[styles.np_ac_icon]} name="closecircle" size={42} color="white" />
                                                    </TouchableOpacity>
                                                </View>
                                            </View>

                                        </View>

                                    </View>
                                )
                            })()}


                        </SafeAreaView>

                    </ScrollView>
                </SafeAreaView>






            </View>

        );
    }

}

const styles = StyleSheet.create({
    np_body : {
        minHeight: 900,
        marginBottom: 120,

    },
    scrollholder: {
        paddingTop: 32,
    },

    npb_head : {
        paddingHorizontal: 12,
        paddingVertical: 12,
    },
    npb_title : {
        fontSize : sizes.lg,
        fontWeight: 'bold',
    },
    npb_sub : {
        paddingHorizontal:12,
        paddingBottom:18,
    },
    npb_subtitle : {
        color:'#686868',
    },
    npb_body : {
        marginBottom: 32,
    },
    WebViewContainer: {

        marginTop: (Platform.OS === 'android') ? 20 : 0,

        height:300,
        width:'100%',
        backgroundColor:'red',
    },
    vframe : {
        height: 400,
        width: 500,
        backgroundColor : 'red',
    },

    npb_content_holder: {
        paddingHorizontal: 18,
        marginTop: 42,
    },

    np_footer: {
        flexDirection : 'row',
        backgroundColor : '#fff',
        marginBottom : 18,
        borderRadius: ofWidth(4),
        padding : 18,
        paddingVertical: 6,
        alignItems : 'center',
        justifyContent : 'center',
        flexWrap : 'wrap',
        //elevation: 0,
    },
    npf_btn: {
        margin : 10,
        color : '#ccc',
    },
    np_footer_txt: {
        width : '100%',
        padding : 6,
        textAlign: 'center',
        marginBottom : 12,
    },


    np_ac : {
        padding : 22,
        paddingHorizontal : 8,
    },
    np_ac_btn : {
        alignItems : 'center',
        justifyContent : 'center',
        color : '#ccc',
    },

    np_ac_txt : {
        textAlign: 'center',
        fontWeight : 'bold',
        fontSize : sizes.lg,
        color : '#292929',
        marginBottom: 8,
    },
    np_ac_icon : {
        color: '#3e3e3e'
    },


});

const mapDispatchToProps = dispatch => (
    bindActionCreators({
        updateData: updateData,
    }, dispatch)
);

const mapStateToProps = (state) => {
    const { data } = state;
    return { data }
};

export default connect(mapStateToProps, mapDispatchToProps)(displayScreen);
