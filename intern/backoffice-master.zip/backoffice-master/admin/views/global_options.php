<div id="global_options_view">
    <div class="dt_section">
        <div class="dt_head">
            <div class="t">
                <h3>Global options</h3>
            </div>
        </div>
        <div class="dt_inner">
            <div class="row">

                <div class="col-lg-4 col-xs-12 text-center">
                    <div class="box">
                        <a href="<?= '?page=languages_front' ?>">
                            <i class="fa fa-language fa-3x" aria-hidden="true"></i>
                            <div class="box-title">
                                <h3>Config Language front</h3>
                            </div>
                        </a>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>