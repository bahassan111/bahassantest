package ma.rak.ovr.bodyResponse;

import com.google.gson.annotations.SerializedName;

import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;
import ma.rak.ovr.models.Agent;
public class AgentsResponse extends RealmObject {

    @PrimaryKey
    @SerializedName("id")
    private int id;

    @SerializedName("status")
    private String status;

    @SerializedName("last_date")
    private String lastDate;

    @SerializedName("data")
    private RealmList<Agent> agents;

    public AgentsResponse() {
    }

    public AgentsResponse(int id, String status, String lastDate, RealmList<Agent> agents) {
        this.id = id;
        this.status = status;
        this.lastDate = lastDate;
        this.agents = agents;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLastDate() {
        return lastDate;
    }

    public void setLastDate(String lastDate) {
        this.lastDate = lastDate;
    }

    public RealmList<Agent> getAgents() {
        return agents;
    }

    public void setAgents(RealmList<Agent> agents) {
        this.agents = agents;
    }

    @Override
    public String toString() {
        return "AgentsResponse{" +
                "id=" + id +
                ", status='" + status + '\'' +
                ", lastDate='" + lastDate + '\'' +
                ", agents=" + agents +
                '}';
    }
}
