import {StyleSheet, Dimensions, Platform} from "react-native";

const win = Dimensions.get('screen');
const ofHeight = (p)=> p * win.height / 100;
const ofWidth = (p)=> p * win.width / 100;

export const colors = {
    back : '#343434',
    front : '#fff',
    primary1 : '#ee312e',
    primary2 : '#63bc46',
    primary3 : '#00a6e5',
};

export const sizes = {
    xl : 30,
    lg : 25,
    md : 18,
    nr : 14,
    sm : 12,
    xs : 10,
};

const css = StyleSheet.create({

    background : {
        backgroundColor: colors.back,
        minHeight: ofHeight(100),
        //width: ofWidth(100),
    },
    background_fordark : {
        backgroundColor: "#e2e2e2",
        minHeight: ofHeight(100),
        //width: ofWidth(100),
    },

    with_floating_header: {
        paddingTop: 84,
    },

    news_holder: {
        position: 'relative',
        /*height: ofHeight(100),
        width: ofWidth(100),*/
        //flexDirection: 'row',
    },
    news_item: {

        height: ofHeight(100),
        width: ofWidth(100),

    },
    ni_bg: {
        backgroundColor: colors.back,

        width : '100%',
        height : '100%',
        resizeMode: 'center',
        flexDirection: 'column',
        alignItems: 'flex-end',
        justifyContent: 'flex-end',
    },

    ni_tags: {
        padding: 12,
        flexDirection: 'row',
        alignItems: 'flex-end',
        justifyContent: 'flex-end',

    },
    ni_tag: {
        backgroundColor: colors.primary3,
        fontSize: sizes.sm,
        color: colors.front,
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 4,
        elevation: 12,
        writingDirection: 'rtl',
    },
    ni_inner: {
        //paddingTop: ofHeight(60),
        minHeight: ofHeight(100),
        width: '100%',
        //backgroundColor: '#ccc',
        writingDirection: 'rtl',
    },
    ni_inner_tc: {
        paddingTop: ofHeight(60),

        width: '100%',
        writingDirection: 'rtl',

    },
    ni_title_holder: {
        padding: 12,
        writingDirection: 'rtl',
    },
    ni_title: {
        fontSize: sizes.lg,
        fontWeight: 'bold',
        color: colors.front,
        textShadowColor : colors.back,
        textShadowOffset : {width : 0, height:0},
        textShadowRadius : 12,
        writingDirection: 'rtl',
        textAlign:'right',
    },
    ni_foot: {
        padding: 12,
    },
    ni_foot_txt: {
        fontSize: sizes.xs,
        color: colors.front,
        textShadowColor : colors.back,
        textShadowOffset : {width : 4, height:4},
        textShadowRadius : 9,
        writingDirection: 'rtl',
        textAlign:'right',
    },


    modal: {
        position: 'absolute',
        zIndex: 99,
        left: 0,
        top: 0,
        right: 0,
        bottom: 0,
        alignItems: 'center',
        justifyContent: 'flex-end',
        height : ofHeight(100),
        /*borderTopLeftRadius: ofWidth(4),
        borderTopRightRadius: ofWidth(4),*/
        overflow: 'hidden',
    },

    modal_inside: {
        width: '100%',
        height: '100%',
        alignItems: 'center',
        justifyContent:'flex-end',
        maxHeight: '100%',
        //marginBottom: 22,
        /*borderTopLeftRadius: ofWidth(4),
        borderTopRightRadius: ofWidth(4),*/
        overflow:'hidden',
    },

    modal_shadow: {
        width: '100%',
        height: '100%',
        alignItems: 'center',
        justifyContent:'flex-end',
        position: 'absolute',
        backgroundColor: 'rgba(0,0,0,0.77)',
    },

    news_popup: {
        width: ofWidth(100),
        //backgroundColor: 'rgba(0,0,0,0.64)',
        zIndex: 9,
        height: ofHeight(100),
    },
    np_sc:{
        backgroundColor: colors.front,
        borderTopLeftRadius: ofWidth(4),
        borderTopRightRadius: ofWidth(4),
        borderBottomLeftRadius: ofWidth(4),
        borderBottomRightRadius: ofWidth(4),
        marginBottom: 0,
        //paddingBottom: 22,
    },
    np_sc_l:{
        borderBottomLeftRadius: ofWidth(4),
        borderBottomRightRadius: ofWidth(4),
    },
    np_inner: {
        zIndex: 100,
        position:'relative',
        width: '96%',
        //backgroundColor: colors.front,
        height: '97%',
        maxHeight: '97%',
        overflow: 'hidden',
        elevation: 22,
        paddingBottom: 32,
        borderBottomLeftRadius: ofWidth(4),
        borderBottomRightRadius: ofWidth(4),

    },
    np_body : {
        //minHeight: 900,
        //marginBottom: 30,

    },

    npb_head : {
        paddingHorizontal: 12,
        paddingVertical: 12,
    },
    npb_title : {
        fontSize : sizes.md,
        fontWeight: 'bold',
        paddingRight: 100,
        textAlign: 'right',
        writingDirection: 'rtl'

    },
    npb_sub : {
       paddingHorizontal:12,
        paddingBottom:18,
    },
    npb_subtitle : {
        color:'#686868',
        fontSize:sizes.sm,
    },
    npb_body : {
        paddingBottom: 6,
    },
    WebViewContainer: {

        marginTop: (Platform.OS === 'android') ? 20 : 0,

        minHeight:300,
        width:'100%',
        backgroundColor:'red',
    },
    vframe : {
        height: 400,
        width: 500,
        backgroundColor : 'red',
    },

    npb_content_holder: {
        paddingHorizontal: 18,
       // backgroundColor:'#cc1e60',
        marginTop: 20,
    },

    np_footer: {
        flexDirection : 'row',
        backgroundColor : '#fff',
        marginBottom : 18,
        borderRadius: ofWidth(4),
        padding : 18,
        paddingVertical: 6,
        alignItems : 'center',
        justifyContent : 'center',
        flexWrap : 'wrap',
        marginTop: -32,
        elevation: 32,
    },
    npf_btn: {
        margin : 10,
        color : '#ccc',
        flexDirection: 'row',
        alignItems: 'center',
    },
    np_footer_txt: {
        width : '100%',
        padding : 6,
        textAlign: 'center',
        marginBottom : 12,
    },


    np_ac : {
        padding : 22,
        paddingHorizontal : 8,
        marginBottom: 32,
    },
    np_ac_btn : {
        alignItems : 'center',
        justifyContent : 'center',
    },

    np_ac_txt : {
        textAlign: 'center',
        fontWeight : 'bold',
        fontSize : sizes.lg,
        color : '#fff',
        marginBottom: 8,
    },
    np_ac_icon : {},

    // Drawer CSS
    dr_whole: {
        flexDirection: 'column',
        backgroundColor: colors.back,
        minHeight: ofHeight(100),
    },
    dr_scroll: {
        height: ofHeight(100),
        backgroundColor: '#273272',
    },
    dr_logo : {
        backgroundColor: '#000',
        paddingTop: 44,
        paddingLeft: 12,
        paddingBottom: 12,
    },
    dr_logo_top : {
        flexDirection: 'row',
        alignItems:'center',
        justifyContent:'center',
    },
    dr_l_dib : {
        color: colors.front,
        fontSize: 40,
        fontWeight: 'bold',
        paddingRight: 8,
    },
    dr_l_news : {
        flexDirection : 'row',
        alignItems : 'center',
    },
    dr_ln_text : {
        color: colors.front,
        fontSize: 40,
        fontWeight: 'bold',
    },
    dr_l_tags : {
        marginLeft: 4,


    },
    dr_l_tag : {
        width: 8,
        height: 8,
        margin: 2,
    },
    dr_ln_sub : {
        color: colors.front,
        textAlign: 'center',
        fontSize: 11.5,
        fontWeight: 'bold',
        paddingBottom: 8,
    },

    dr_menu : {
        marginVertical: 22,
        flex: 1,
    },
    dr_menu_item : {
        flexDirection:'row',
        marginBottom: 8,
        alignItems: 'center',

    },
    dr_menu_ind : {
        height: 18,
        width: 8,
        //borderRadius : 4,
        marginLeft: -4,
    },
    dr_menu_ind_c : {
        height: 18,
        width: 4,
        //borderRadius : 4,
        marginLeft: -4,
    },
    dr_mi_ic : {

        minHeight: 42,
        width:50,
        alignItems: 'flex-end',
        padding: 12,
        paddingHorizontal: 8,
    },
    dr_f_ic : {

        minHeight: 42,
        width:50,
        alignItems: 'flex-end',
        padding: 12,
        paddingHorizontal: 8,
    },
    dr_mi_icon : {
        color: '#c0c0c0',
        fontSize: sizes.lg,
    },
    dr_fi_icon : {
        color: '#c0c0c0',
        fontSize: sizes.lg,
    },
    dr_menu_child : {
        paddingLeft : 14,
        borderLeftWidth: 4,
        marginTop: -8,
        paddingTop: 8,
    },
    dr_mi_txt : {
        padding: 8,
        paddingLeft: 16,
        flex:1,
    },
    dr_mi_text : {
        color:colors.front,
        fontSize:sizes.nr,
        fontWeight: '400',
        //textTransform: 'uppercase',
    },

    dr_foot: {
        padding: 12,
    },
    dr_foot_text: {
        fontSize:sizes.sm,
        color: colors.front,
        opacity:0.4,
        textAlign: 'center',
    },

    dr_foot_soc: {
        marginVertical: 22,
    },
    dr_soc_text: {
        color:colors.front,
        textAlign:'center',
    },
    dr_soc_items: {
        flexDirection:'row',
        alignItems:'center',
        justifyContent:'center',
    },
    dr_soc_item: {
        padding:12,
    },
});


export default css;
