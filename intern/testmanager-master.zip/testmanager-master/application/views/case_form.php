<?php
addJS([
    'assets/js/views/case.js',
]);
?>

<div data-label="Create new Test Case" class="df-example demo-forms case_frm" id="case_form_view">
    <form>
        <?php if($edit){?>
            <input type="hidden" name="id" value="<?= $case->id; ?>">
        <?php } ?>
        <div class="row row-sm">
            <div class="col-sm-12">
                <div class="form-group">
                    <label for="title">Title</label>
                    <input value="<?= $edit ? $case->title : ''; ?>" id="title" name="title" type="text" class="form-control form-control-sm" placeholder="">
                </div>
            </div>
            <div class="col-sm-12">
                <div class="form-group">
                    <label for="desc">Note</label>
                    <textarea style="height: 60px;" id="desc" name="desc" class="form-control form-control-sm" placeholder=""><?= $edit ? $case->desc : ''; ?></textarea>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="type">Type</label>
                    <select class="form-control form-control-sm" name="type" id="type">
                        <option value="">(No type)</option>
                        <?php foreach($types as $i => $type){ ?>
                            <option <?= ($edit && $type->id === $case->type) ? 'selected' : (!$edit && $type->id === '1' ? 'selected' : ''); ?> value="<?= $type->id; ?>"><?= $type->name; ?></option>
                        <?php } ?>
                    </select>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="priority">Priority</label>
                    <select class="form-control form-control-sm" name="priority" id="priority">
                        <?php foreach($priorities as $i => $priority){ ?>
                            <option <?= ($edit && $priority->id === $case->priority) ? 'selected' : (!$edit && $priority->id === '1' ? 'selected' : ''); ?> value="<?= $priority->id; ?>"><?= $priority->name; ?></option>
                        <?php } ?>
                    </select>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="time_estimate">Estimated Time (in minutes)</label>
                    <input id="time_estimate" name="time_estimate" type="number" class="form-control form-control-sm" value="<?= $edit ? $case->time_estimate : '10'; ?>">
                </div>
            </div>

            <?php if($plan->type !== 'auto'){?>

                <div class="col-sm-12">
                    <div class="form-group">
                        <label for="desc">Steps</label>


                        <div class="case_steps_holder">
                            <div class="case_steps">
                                <?php if($edit && count($case->steps) > 0){?>
                                    <?php foreach($case->steps as $step){ ?>
                                        <div class="case_step">
                                            <span data-number="<?= $step->order; ?>"><?= $step->order; ?></span>
                                            <div class="cstep_actions">
                                                <a href="javascript:void(0);" class="r"><i class="fas fa-times"></i></a>
                                                <a href="javascript:void(0);" class="u"><i class="fas fa-angle-up"></i></a>
                                                <a href="javascript:void(0);" class="d"><i class="fas fa-angle-down"></i></a>
                                            </div>
                                            <div class="cstep_todo">
                                                <label>Todo :</label>
                                                <textarea><?= $step->todo; ?></textarea>
                                            </div>
                                            <div class="cstep_assert">
                                                <label>Expected Result :</label>
                                                <textarea><?= $step->expect; ?></textarea>
                                            </div>
                                        </div>
                                    <?php } ?>
                                <?php }else{?>
                                    <div class="case_step">
                                        <span data-number="1">1</span>
                                        <div class="cstep_actions">
                                            <a href="javascript:void(0);" class="r"><i class="fas fa-times"></i></a>
                                            <a href="javascript:void(0);" class="u"><i class="fas fa-angle-up"></i></a>
                                            <a href="javascript:void(0);" class="d"><i class="fas fa-angle-down"></i></a>
                                        </div>
                                        <div class="cstep_todo">
                                            <label>Todo :</label>
                                            <textarea></textarea>
                                        </div>
                                        <div class="cstep_assert">
                                            <label>Expected Result :</label>
                                            <textarea></textarea>
                                        </div>
                                    </div>
                                <?php } ?>


                            </div>
                            <div class="cases_actions">
                                <button type="button" class="btnx btn btn-sm btn-outline-primary add_casestep">Add step<i class="fas fa-plus"></i></button>
                            </div>
                        </div>


                    </div>
                </div>

            <?php } ?>

            <?php if($plan->type === 'auto'){?>
                <div class="col-sm-12">
                    <div data-label="Auto Test config" class="df-example demo-forms mt-4 plan_auto_config">
                        <div class="row row-sm">
                            <div class="col-sm-3">
                                <div class="form-group">
                                    <label for="method">Method</label>
                                    <select style="width: 100%" class="form-control-sm" name="method" id="method">
                                        <option <?= $edit && $case->method == 'GET' ? 'selected' : ''; ?> value="GET">GET</option>
                                        <option <?= $edit && $case->method == 'POST' ? 'selected' : ''; ?> value="POST">POST</option>
                                        <option <?= $edit && $case->method == 'PUT' ? 'selected' : ''; ?> value="PUT">PUT</option>
                                        <option <?= $edit && $case->method == 'DELETE' ? 'selected' : ''; ?> value="DELETE">DELETE</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-9">
                                <div class="form-group">
                                    <label for="url">URL</label>
                                    <input value="<?= $edit ? $case->url : ($plan->url ?: ''); ?>" id="url" name="url" type="text" class="form-control form-control-sm" placeholder="">
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="cookies">Cookies</label>
                                    <select class="selectpicker" name="cookies" id="cookies">
                                        <option <?= $edit && $case->use_cookies === '0' ? 'selected' : ''; ?> value="no">No cookies</option>
                                        <option <?= $edit && $case->use_cookies === '1' && $case->clear_cookies === '0' ? 'selected' : (!$edit ? 'selected' : ''); ?> value="yes">Use cookies</option>
                                        <option <?= $edit && $case->use_cookies === '1' && $case->clear_cookies === '1' ? 'selected' : ''; ?> value="clear">Use new session cookies</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="">Header</label>
                                    <div class="case_params h">
                                        <div class="h">
                                            <span>Key</span>
                                            <span>Value</span>
                                        </div>
                                        <div class="t">
                                            <a class="a" href="javascript:void(0);"><i class="fas fa-plus"></i></a>
                                            <a class="r" href="javascript:void(0);"><i class="fas fa-minus"></i></a>
                                        </div>
                                        <div class="l">
                                            <?php if(!$edit){?>
                                                <div>
                                                    <span contenteditable="true">User-Agent</span>
                                                    <span contenteditable="true">twTester Agent</span>
                                                </div>
                                            <?php } ?>
                                            <?php
                                            $headers = $edit ? json_decode($case->headers) : [];
                                            foreach($headers as $key => $val){ ?>
                                                <div>
                                                    <span contenteditable="true"><?= $key; ?></span>
                                                    <span contenteditable="true"><?= $val; ?></span>
                                                </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="">Params</label>
                                    <div class="case_params p">
                                        <div class="h">
                                            <span>Key</span>
                                            <span>Value</span>
                                        </div>
                                        <div class="t">
                                            <a class="a" href="javascript:void(0);"><i class="fas fa-plus"></i></a>
                                            <a class="r" href="javascript:void(0);"><i class="fas fa-minus"></i></a>
                                        </div>
                                        <div class="l">
                                            <?php
                                            $params = $edit ? (json_decode($case->params) ?: []) : [];
                                            foreach($params as $key => $val){ ?>
                                                <div>
                                                    <span contenteditable="true"><?= $key; ?></span>
                                                    <span contenteditable="true"><?= $val; ?></span>
                                                </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-12 expect_results_holder">
                                <div class="form-group">
                                    <label>Expected result</label>
                                    <div class="case_expect_list">
                                        <?php if($edit){?>
                                            <?php foreach($case->asserts as $i => $assert){ ?>
                                                <div id="tobea<?= $i; ?>" class="case_expect_item">
                                                    <span><?= asserts($assert->id_assert)->title ?></span>
                                                    <a href="javascript:void(0);" class="e"><i class="fas fa-pencil-alt"></i></a>
                                                    <a href="javascript:void(0);" class="r"><i class="fas fa-times"></i></a>
                                                </div>
                                            <?php } ?>
                                        <?php } ?>
                                    </div>
                                    <div class="case_add_expect">
                                        <button type="button" class="btnx btn btn-sm btn-outline-primary add_case_expect">Add Expected result <i class="fas fa-plus"></i></button>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-12 case_assert">
                                <div class="form-group">
                                    <label for="assert">Assert</label>
                                    <select style="width: 100%" class="form-control-sm" name="assert" id="assert">
                                        <option value="" selected disabled>Select an assert</option>
                                        <?php foreach(asserts() as $index => $item){ ?>
                                            <option <?= $edit && $index == $case->assert ? 'selected' : ''; ?> value="<?= $index; ?>"><?= $item->title; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>

                                <div class="asserts_values">
                                    <?php foreach(asserts() as $index => $item){ ?>
                                        <div class="fg_<?= $index ?> <?= $edit && $case->assert == $index ? 'v' : ''; ?>" <?= $edit && $case->assert == $index ? 'style="display:block;"' : ''; ?>>
                                            <?php foreach($item->values as $i => $value){
                                                $sel = $edit && $case->assert == $index && isset($case->assert_values->{'inpv_'.$i}) ? $case->assert_values->{'inpv_'.$i} : '';
                                                ?>
                                                <div class="form-group">
                                                    <label for="inpv_<?= $i ?>"><?= $value->title; ?></label>

                                                    <?php if($value->type != 'list'){?>
                                                        <input value="<?= $sel; ?>" class="form-control form-control-sm" type="<?= $value->type; ?>" id="inpv_<?= $i ?>">
                                                    <?php }else{?>
                                                        <select class="form-control form-control-sm" id="inpv_<?= $i ?>">
                                                            <?php foreach($value->values as $item){ ?>
                                                                <option <?= $sel == $item ? 'selected' : ''; ?> value="<?= $item; ?>"><?= $item; ?></option>
                                                            <?php } ?>
                                                        </select>
                                                    <?php } ?>
                                                </div>

                                            <?php } ?>
                                        </div>
                                    <?php } ?>
                                </div>

                                <div class="asserts_action">
                                    <button type="button" class="btnx btn btn-sm btn-outline-dark cancelassert">Cancel <i class="fas fa-save"></i></button>
                                    <button type="button" class="btn btn-sm btn-outline-primary saveassert">Save <i class="fas fa-save"></i></button>
                                </div>
                            </div>






                        </div>
                    </div>
                </div>
            <?php } ?>


        </div>
    </form>


</div>

<script id="toberemoved">
    $(document).ready(function () {
        <?php if(isset($case->asserts)){foreach($case->asserts as $i => $assert){ ?>
        $('#tobea' + <?= $i ?>).data('data', {
            assert : <?= $assert->id_assert ?>,
            value : [
                {id : 'inpv_0', val : '<?= $assert->value1 ?: '' ?>'},
                {id : 'inpv_1', val : '<?= $assert->value2 ?: '' ?>'},
                {id : 'inpv_3', val : '<?= $assert->value3 ?: '' ?>'},
                {id : 'inpv_4', val : '<?= $assert->value4 ?: '' ?>'},
            ]
        });
        <?php }} ?>


        $('#toberemoved').remove();
    });
</script>
