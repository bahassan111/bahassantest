import React, { Component } from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    ImageBackground,
    ActivityIndicator,
    Button,
    TouchableOpacity
} from "react-native";

import { connect } from 'react-redux';
import i18n from 'i18n-js';
import {AntDesign, Entypo, FontAwesome5, Ionicons} from "@expo/vector-icons";
import { StatusBar } from 'expo-status-bar';


class TopHeader extends Component {

    state = {

    };

    render() {

        i18n.locale = this.props.language;
        let onMenu = ('onMenu' in this.props) ? this.props.onMenu : ()=>{};
        let onUser = ('onUser' in this.props) ? this.props.onUser : ()=>{};
        let title = ('title' in this.props) ? this.props.title : '';
        let floatable = ('floatable' in this.props) ? this.props.floatable : false;
        let transparent = ('transparent' in this.props) ? this.props.transparent : false;
        let semi_transparent = ('semi_transparent' in this.props) ? this.props.semi_transparent : false;
        let menu_color = ('menuColor' in this.props) ? this.props.menuColor : 'white';
        let hide_logo = ('hideLogo' in this.props) ? this.props.hideLogo : false;


        return (

            <View style={[styles.header, floatable ? styles.floatable : {}, transparent ? styles.transparent : {}, semi_transparent ? styles.semi_transparent : {}]}>
                <TouchableOpacity style={styles.menu_btn} onPress={('onMenu' in this.props) ? this.props.onMenu : ()=>{}}>
                    <Ionicons name="menu-sharp" size={40} color={menu_color} />
                </TouchableOpacity>
                <Text style={styles.title}>{title}</Text>

                {(hide_logo) ? (null) : (<TouchableOpacity style={styles.user_btn} onPress={onUser}>
                    <Image style={styles.logo} source={require('../assets/logo.png')}/>
                </TouchableOpacity>)}

                <StatusBar style="light" />
            </View>

        );
    }

}

const styles = StyleSheet.create({
    logo : {
        height: 64,
        width: 64,
        marginRight: 22,
        marginTop: 22,
    },
    header: {
        //height: '10%',
        paddingTop: '8%',
        backgroundColor: 'rgb(0,0,0)',
        flexDirection: 'row',
        alignItems: 'center',
        position:'relative',
        zIndex: 99
    },
    transparent:{
        backgroundColor: 'rgba(39,50,114,0)',
    },
    semi_transparent:{
        backgroundColor: 'rgba(0,0,0,0.49)',
    },
    floatable:{
        position:'absolute',
        left:0,
        top:0,
        width: '100%',
        zIndex: 99,
    },
    bg: {
        height:"100%",
        backgroundColor: '#fff',
    },
    title : {
        flex: 1,
        padding: 12,
        paddingTop: 6,
        paddingBottom: 6,
        fontSize: 14,
        color: '#fff',
    },
    menu_btn : {
        padding: 6,
    },
    user_btn : {
        marginRight: 12,
        marginLeft: 12,
        height: 32,
        width: 32,
        borderRadius: 16,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
    },
    rtl_flex: {
        flexDirection: 'row-reverse',
    }
});


const mapStateToProps = (state) => {
    const { data } = state;
    return { data }
};

export default connect(mapStateToProps)(TopHeader);
