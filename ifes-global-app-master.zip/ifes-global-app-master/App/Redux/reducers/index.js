import { combineReducers } from "redux";
import chapitres from "./chapitres";
import countries from "./countries";
import sousChapitre from "./sousChapitre";
import searchAll from "./searchAll";
import banners from "./banners";
import galleries from "./galleries";
import fontSize from "./fontSize";
import saveInfoFb from "./saveInfoFb";
import saveComments from "./saveComment";
import fetchComments from "./fetchComments";
import getComments from "./getComments";
import postFiles from "./postFile";

export default combineReducers({
  fontSize,
  chapitres,
  countries,
  searchAll,
  saveInfoFb,
  saveComments,
  fetchComments,
  getComments,
  postFiles,
  sousChapitre,
  banners,
  galleries,
});
