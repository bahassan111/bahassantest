package ma.rak.ovr.ui.main;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import ma.rak.ovr.R;
import ma.rak.ovr.api.RetrofitClient;
import ma.rak.ovr.bodyResponse.HistoriqueConsoResponse;
import ma.rak.ovr.storage.SharedPrefManager;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HistoriqueConsom extends AppCompatActivity {

    EditText search;
    Button btn;
    Button extiBtn;
    ListView list;
    TextView label;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_histoconsom);

        extiBtn = findViewById(R.id.exitbtn);
        list = findViewById(R.id.list);
        label = findViewById(R.id.label);

        extiBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });




        Bundle b = getIntent().getExtras();
        String address = b != null ? b.getString("address") : "";


        if(address != null && !address.equals("")){
            rechercher(address);
        }

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rechercher(address);
            }
        });
    }


    public void rechercher(String search){

        if(search.trim().equals("")){
            label.setText("Veuillez spécifier une adresse!");
            return;
        }

        boolean isDossier = false;

        String[] parts = search.split("/");

        if(parts.length == 2){

            try{
                int year = Integer.parseInt(parts[0]);
                int doss = Integer.parseInt(parts[1]);
                Calendar cal = (new GregorianCalendar());
                cal.setTime(new Date());
                int cyear = cal.get(Calendar.YEAR);
                if(year < 1900 || year > cyear){
                    label.setText("Si vous recherchez par numéro de dossier et année, veuillez taper l'année en premier / le numéro de dossier");
                    return;
                }

                isDossier = true;

            }catch (Exception e){

            }

        }


        label.setText("Recherche en cours ..");

        list.setAdapter(null);

        Call<HistoriqueConsoResponse> call = RetrofitClient.getApi(SharedPrefManager.getInstance(this).getToken()).historiqueConso("XDEBUG_SESSION=XDEBUG_ECLIPSE", search);


        call.enqueue(new Callback<HistoriqueConsoResponse>() {
            @Override
            public void onResponse(Call<HistoriqueConsoResponse> call, Response<HistoriqueConsoResponse> response) {



                if(response.code() != 200){
                    //(Toast.makeText(getApplicationContext(),"Error while running this request!")).show();
                    label.setText("Erreur lors de l'exécution de la requête, réessayez plus tard !");
                    return;
                }



                if(response.body().getResults().size() == 0){
                    label.setText("Aucun devis trouvé pour le dossier sélectionnée, essayez avec une autre adresse !");
                }else{
                    label.setText(response.body().getResults().size() +" resultat trouvés pour le dossier sélectionnée");
                }

                //DevisListAdapter adapter=new DevisListAdapter(DevisActivity.this, response.body().getDevis());
                //list.setAdapter(adapter);



            }

            @Override
            public void onFailure(Call<HistoriqueConsoResponse> call, Throwable t) {


                label.setText("Erreur lors de l'exécution de la requête, assurez-vous que vous êtes connecté à Internet");
            }
        });

    }
}