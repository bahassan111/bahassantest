<?php

use League\OAuth2\Client\Provider\Exception\IdentityProviderException;
use League\OAuth2\Client\Provider\GenericProvider;

defined('BASEPATH') OR exit('No direct script access allowed');

class Messenger extends TwController
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        responseJSON(['OK']);
    }

    public function enter($login_key = null){

        //if(!$login_key) return;

        $provider = new GenericProvider([
            'clientId'                => '6d8743715014a2a81b9388d2e461c5fe410e2de7959bfc69c8a694016a1b6f36',    // The client ID assigned to you by the provider
            'clientSecret'            => 'a42564419f825b376af44a3811a207068e0f8e4287c032ac9e9f1d30855f51ae',    // The client password assigned to you by the provider
            'redirectUri'             => site_url('Messenger/enter'),
            'urlAuthorize'            => 'http://git.twinsgroupe.com:81/oauth/authorize',
            'urlAccessToken'          => 'http://git.twinsgroupe.com:81/oauth/token',
            'urlResourceOwnerDetails' => 'https://service.example.com/resource'
        ]);

        // If we don't have an authorization code then get one
        if (!($this->input->get('code')) && $login_key) {

            // Fetch the authorization URL from the provider; this returns the
            // urlAuthorize option and generates and applies any necessary parameters
            // (e.g. state).
            $authorizationUrl = $provider->getAuthorizationUrl();

            // Get the state generated for you and store it to the session.
            $_SESSION['oauth2state'] = $provider->getState();
            $this->session->set_userdata('login_key', $login_key);

            // Redirect the user to the authorization URL.
            redirect($authorizationUrl);
            return;

        } elseif (empty($_GET['state']) || (isset($_SESSION['oauth2state']) && $_GET['state'] !== $_SESSION['oauth2state'])) {

            if (isset($_SESSION['oauth2state'])) {
                unset($_SESSION['oauth2state']);
            }

            exit('Invalid state');

        } else {

            try {

                // Try to get an access token using the authorization code grant.
                $accessToken = $provider->getAccessToken('authorization_code', [
                    'code' => $_GET['code']
                ]);

                // We have an access token, which we may use in authenticated
                // requests against the service provider's API.
                $key = $this->session->userdata('login_key');
                $user =  $this->getUser($accessToken->getToken(), $key, TRUE);

                echo "<h1>You're now connected!</h1>";
                echo "<h5>Please close this page and return to the messenger</h5>";
                echo "<script>setTimeout(()=>{window.close();}, 1000)</script>";
                die;

                echo 'Access Token: ' . $accessToken->getToken() . "<br>";
                echo 'Refresh Token: ' . $accessToken->getRefreshToken() . "<br>";
                echo 'Expired in: ' . $accessToken->getExpires() . "<br>";
                echo 'Already expired? ' . ($accessToken->hasExpired() ? 'expired' : 'not expired') . "<br>";

                // Using the access token, we may look up details about the
                // resource owner.
                $resourceOwner = $provider->getResourceOwner($accessToken);

                var_export($resourceOwner->toArray());

                // The provider provides a way to get an authenticated API request for
                // the service, using the access token; it returns an object conforming
                // to Psr\Http\Message\RequestInterface.
                $request = $provider->getAuthenticatedRequest(
                    'GET',
                    'https://service.example.com/resource',
                    $accessToken
                );

            } catch (IdentityProviderException $e) {

                // Failed to get the access token or user details.
                exit($e->getMessage());

            }

        }
    }

    public function getUser($token, $key, $return_it = FALSE){

        if(!$key) return;

        $result = $this->getEmptyResponse();
        $client = new Gitlab\Client();
        $client->setUrl("http://git.twinsgroupe.com:81/");
        $client->authenticate($token, Gitlab\Client::AUTH_OAUTH_TOKEN);

        $user = $client->users()->user();

        if($user){
            $user = (object)$user;

            $user_data = [
                'source' => 'gitlab',
                'source_id' => $user->id,
                'email' => $user->email,
                'username' => $user->username,
                'password' => null,
                'fullname' => $user->name,
                'image' => $user->avatar_url,
                'date_created' => (new DateTime($user->created_at))->format('Y-m-d H:i:s'),
                'date_updated' => (new DateTime($user->confirmed_at))->format('Y-m-d H:i:s'),
                'last_login' => (new DateTime($user->last_sign_in_at))->format('Y-m-d H:i:s'),
                'enabled' => 1,
                'deleted' => 0,
            ];

            $q = $this->db->get_where('users', ['source' => 'gitlab', 'source_id' => $user->id]);
            $exists = $q && $q->num_rows() > 0 ? $q->row()->id : null;


            if($exists){
                $q = $this->db->update('users', $user_data, ['source' => 'gitlab', 'source_id' => $user->id]);
            }else{
                $q = $this->db->insert('users', $user_data);
            }




            if($q){



                $id = $exists ?: $this->db->insert_id();

                $q = $this->db->update('_pending_login', ['user_id' => $id], ['key' => $key]);

                $result->status = 'OK';
                $result->data = $user_data;
                $result->method = $exists ? 'updated' : 'created';
                $result->id = $id;

            }else{
                $result->status = 'ERROR';
                $result->message = "Unknown error!";
            }

        }

        if($return_it) return $return_it;
        responseJSON($result);

    }
}
