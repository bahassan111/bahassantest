


<div class="">
    <form id="form_save_file" enctype="multipart/form-data" method="post" class="container-fluid">
        <div class="row">

            <div class="col-sm-6">
                <div class="form-group">
                    <label for="lang" style="display: block;">Langue</label>
                    <select id="lang" name="lang" class="selectpicker_">
                        <option <?= $one && $one->lang === 'ar' ? 'selected' : ($one ? '' : 'selected') ?> value="ar">Arabe</option>
                        <option <?= $one && $one->lang === 'ar' ? 'selected' : ''; ?> value="fr">Français</option>
                    </select>
                </div>
            </div>

            <div class="col-sm-6">
                <div class="form-group">
                    <label for="name">Titre</label>
                    <input type="text" name="title" id="title" class="form-control" value="<?= $one ?  $one->title : '' ?>">
                </div>
            </div>

            <div class="col-sm-6 catfr" style="display: none;">
                <div class="form-group">
                    <label for="director" style="display: block;">Categorie</label>
                    <select class="selectpicker_ cat_selector">
                        <option value="new">Nouvelle Catégorie</option>
                        <?php foreach($cats_fr as $cat){ ?>
                            <option value="<?= $cat->name; ?>"><?= $cat->name; ?></option>
                        <?php } ?>
                    </select>
                </div>
            </div>
            <div class="col-sm-6 catar">
                <div class="form-group">
                    <label for="director" style="display: block;">Categorie</label>
                    <select class="selectpicker_ cat_selector">
                        <option value="new">Nouvelle Catégorie</option>
                        <?php foreach($cats_ar as $cat){ ?>
                            <option value="<?= $cat->name; ?>"><?= $cat->name; ?></option>
                        <?php } ?>
                    </select>
                </div>
            </div>

            <div class="col-sm-6">
                <div class="form-group">
                    <label for="director">Nouveau nom de catégorie</label>
                    <input type="text" name="cat" id="cat" class="form-control" value="<?= $one ?  $one->cat : '' ?>">
                </div>
            </div>

            <div class="col-sm-12">
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea type="text" name="description" id="description" class="form-control"><?= $one ?  $one->description : '' ?></textarea>
                </div>
            </div>


            <?php if($one){?>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="name">Fichier</label>
                        <a target="_blank" href="<?= site_url('uploads/'.$one->file) ?>"><?= basename($one->file); ?></a>
                    </div>
                </div>
            <?php }else{?>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="name">Fichier</label>
                        <input type="file" id="file" name="file" class="form-control" value="">
                    </div>
                </div>
            <?php } ?>



        </div>

    </form>

</div>
