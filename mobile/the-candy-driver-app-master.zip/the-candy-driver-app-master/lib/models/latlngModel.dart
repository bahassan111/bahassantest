class LatlngModel {
  String id;
  String zoneId;
  String latlngData;
  String compareLatLngData;
  LatlngModel({this.id, this.zoneId, this.latlngData});

  LatlngModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    zoneId = json['zone_id'];
    latlngData = json['latlng_data'];
    compareLatLngData = json['latlng_data']
        .split(',')
        .map((e) => (double.tryParse(e)).toStringAsFixed(2))
        .toList()
        .join(',');
  }
}
