import React from "react";
import {
  ScrollView,
  StyleSheet,
  Image,
  ImageBackground,
  TouchableOpacity,
  AsyncStorage,
} from "react-native";
import { View, Text } from "react-native-ui-lib";
import { connect } from "react-redux";

import * as Facebook from "expo-facebook";

import Icon from "../constants/Icons";
import Colors from "../constants/Colors";

import {
  fetchFontSize,
  increaseFontSize,
  decreaseFontSize,
  changeFont,
} from "../Redux/actions/FontSizeActions";

const styles = StyleSheet.create({
  menu_home: {
    marginBottom: 10,
    paddingTop: 10,
    backgroundColor: "#4f5151a8",
  },
  menu_settings: {
    paddingBottom: 10,
    paddingTop: 10,
    backgroundColor: "#31897e",
  },
  menu_logout: {
    paddingBottom: 10,
    paddingTop: 10,
    backgroundColor: Colors.orange,
  },
  menu_countries: {
    paddingBottom: 10,
    paddingTop: 10,
    backgroundColor: "#5da4d2cf",
  },
  view_menu: {
    color: "#FAFAFA",
  },
  icon_menu: {
    marginRight: 10,
    marginLeft: 0,
    width: 30,
  },
  menu_border: {
    borderRightWidth: 1,
    borderRightColor: "#FAFAFA",
    marginRight: 10,
  },
  text_menu: {
    fontWeight: "400",
  },
  footer_menu: {
    position: "absolute",
    bottom: 10,
    justifyContent: "center",
    alignItems: "center",
    height: "5%",
  },
  title_menu: {
    fontWeight: "600",
    color: "#fff",
    position: "absolute",
    bottom: 15,
    left: "35%",
    justifyContent: "center",
    alignItems: "center",
  },
  content_menu: {
    flex: 1,
    height: "70%",
    marginTop: "3%",
  },
  logo: {
    width: 140,
    height: 140,
    marginTop: 80,
    marginBottom: 40,
    flex: 1,
  },
  content_logo: {
    height: "20%",
  },
});

class DrawerScreen extends React.Component {
  state = {
    homeScreen: "Home",
    settingScreen: "Settings",
    logout: "Logout",
    countries: "Countries",
    iso_country: "",
  };
  // async componentDidMount() {
  //   let homeScreen = await AsyncStorage.getItem("homeScreen");
  //   let settingScreen = await AsyncStorage.getItem("settingScreen");
  //   let countries = await AsyncStorage.getItem("countries");
  //   let iso_country = await AsyncStorage.getItem("iso_country");
  //   this.setState({
  //     homeScreen: homeScreen,
  //     settingScreen: settingScreen,
  //     countries: countries,
  //     iso_country: iso_country,
  //   });
  // }

  async componentDidUpdate(prevProps, prevState) {
    let homeScreen = await AsyncStorage.getItem("homeScreen");
    let settingScreen = await AsyncStorage.getItem("settingScreen");
    let countries = await AsyncStorage.getItem("countries");
    this.setState({
      homeScreen: homeScreen,
      settingScreen: settingScreen,
      countries: countries,
    });
  }

  logoutFacebook() {
    Facebook.logOutAsync();
    AsyncStorage.setItem("id", "").then(() => {
      this.props.navigation.navigate("Intro");
    });
  }

  render() {
    return (
      <ImageBackground
        source={require("../assets/images/bgMenu.png")}
        style={{ flex: 1, height: "100%" }}
        imageStyle={{ borderTopRightRadius: 120 }}
      >
        <ScrollView
          ref={(ref) => {
            this.scrollview_ref = ref;
          }}
        >
          <View flex column centerH style={styles.content_logo}>
            <Image
              source={require("../assets/images/menuLogo.png")}
              style={styles.logo}
            />
          </View>
          <View style={styles.content_menu}>
            <TouchableOpacity
              onPress={() =>
                this.props.navigation.navigate({
                  routeName: "Home",
                })
              }
            >
              <View
                row
                left
                marginV-5
                paddingL-15
                paddingV-7
                centerV
                style={styles.menu_home}
              >
                <Icon
                  name="home"
                  iconSize={30}
                  color={Colors.white}
                  style={styles.icon_menu}
                />
                <Text style={styles.menu_border}></Text>
                <Text style={styles.text_menu} color="#FAFAFA">
                  {this.state.homeScreen}
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => this.props.navigation.navigate("ChangeCountries")}
            >
              <View
                row
                left
                paddingL-15
                paddingV-7
                marginV-5
                centerV
                style={styles.menu_countries}
              >
                <Icon
                  name="ion-flag"
                  iconSize={30}
                  color={Colors.white}
                  style={styles.icon_menu}
                />
                <Text style={styles.menu_border}></Text>
                <Text style={styles.text_menu} color="#FAFAFA">
                  {this.state.countries}
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => this.props.navigation.navigate("Settings")}
            >
              <View
                row
                left
                paddingL-15
                paddingV-7
                marginV-5
                centerV
                style={styles.menu_settings}
              >
                <Icon
                  name="parameters"
                  iconSize={30}
                  color={Colors.white}
                  style={styles.icon_menu}
                />
                <Text style={styles.menu_border}></Text>
                <Text style={styles.text_menu} color="#FAFAFA">
                  {this.state.settingScreen}
                </Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => this.logoutFacebook()}>
              <View
                row
                left
                paddingL-15
                paddingV-7
                marginV-5
                centerV
                style={styles.menu_logout}
              >
                <Icon
                  name="ion-power"
                  iconSize={30}
                  color={Colors.red}
                  style={styles.icon_menu}
                />
                <Text style={styles.menu_border}></Text>
                <Text style={styles.text_menu} color="#FAFAFA">
                  {this.state.logout}
                </Text>
              </View>
            </TouchableOpacity>

            <View
              row
              style={{
                justifyContent: "space-between",
              }}
              padding-40
              centerV
            >
              <TouchableOpacity
                onPress={() =>
                  this.props.changeFont(this.props.fontSizeValue - 1)
                }
              >
                <Image
                  source={require("../assets/images/minus.png")}
                  style={{ width: 60, height: 44 }}
                />
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() =>
                  this.props.changeFont(this.props.fontSizeValue + 1)
                }
              >
                <Image
                  source={require("../assets/images/plus.png")}
                  style={{ width: 60, height: 44 }}
                />
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </ImageBackground>
    );
  }
}

const mapStateToProps = (state) => {
  const fontSizeValue = state.fontSize.fontSize;
  const lang = state.fontSize.lang;
  return {
    fontSizeValue,
    lang,
  };
};

export default connect(mapStateToProps, {
  fetchFontSize,
  increaseFontSize,
  decreaseFontSize,
  changeFont,
})(DrawerScreen);
