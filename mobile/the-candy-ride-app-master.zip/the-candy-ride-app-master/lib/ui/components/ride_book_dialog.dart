import 'dart:async';
import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:rider_app/constants/app_themes.dart';
import 'package:get/get.dart';
import 'package:rider_app/constants/urls.dart';
import 'package:rider_app/controllers/controllers.dart';
import 'components.dart';

class RideBookSuccessDialog extends StatefulWidget {
  final int rideId;
  RideBookSuccessDialog({this.rideId});
  @override
  _RideBookSuccessDialogState createState() => _RideBookSuccessDialogState();
}

class _RideBookSuccessDialogState extends State<RideBookSuccessDialog> {
  static HomeController to = Get.find();
  static TripAcceptController tripTo = Get.find();

  int rideId;
  Timer _timer;
  Timer _riderDetailTimer;
  int _start = 30;
  bool isDriverFound = false;
  @override
  void initState() {
    tripTo.ride = null;
    tripTo.driverImage = null;
    tripTo.driverRating = null;

    print("widget.rideId ${widget.rideId}");
    tripTo.tripId = widget.rideId;
    rideId = widget.rideId;

    _riderDetailTimer = Timer.periodic(Duration(seconds: 5), (Timer timer) {
      tripTo
          .getRideDetail(isShowLoadingIndicator: false, shoDialog: false)
          .then((value) {
        if (tripTo?.ride != null) {
          _riderDetailTimer.cancel();
          setState(() {
            BotToast.cleanAll();
            Get.toNamed('/TripAceeptUI', parameters: {
              "vehicleModel": tripTo?.ride?.vehicleModel,
              "vehicleColor": tripTo?.ride?.vehicleColor,
            });
            isDriverFound = true;
          });
          print("${tripTo.ride.fname} + " " + ${tripTo.ride.lname}");
        }
      }).catchError((err) {
        print("error from ride book dialog " + err.toString());
      });
    });
    startTimer();
    super.initState();
  }

  startTimer() {
    const oneSec = const Duration(seconds: 1);
    _start = 30;
    _timer = Timer.periodic(
      oneSec,
      (Timer timer) {
        if (mounted) {
          if (_start == 0) {
            setState(() {
              timer.cancel();
            });
          } else {
            setState(() {
              _start--;
            });
          }
        }
      },
    );
  }

  @override
  void dispose() {
    _timer.cancel();
    _riderDetailTimer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // return isDriverFound
    //     ? Container(
    //         color: Colors.black87,
    //         child: Center(
    //           child: GestureDetector(
    //             onTap: () {
    //               _riderDetailTimer.cancel();
    //               _timer.cancel();

    //               Get.offAllNamed('/TripAceeptUI');
    //               BotToast.cleanAll();
    //             },
    //             child: Container(
    //               height: 215,
    //               decoration: BoxDecoration(
    //                 color: Colors.white,
    //                 borderRadius: BorderRadius.circular(10),
    //                 border: Border.all(color: Colors.black),
    //               ),
    //               margin: EdgeInsets.symmetric(horizontal: 30),
    //               padding: EdgeInsets.symmetric(horizontal: 20),
    //               child: Center(
    //                 child: Column(
    //                   mainAxisSize: MainAxisSize.min,
    //                   children: [
    //                     Row(
    //                       mainAxisSize: MainAxisSize.min,
    //                       crossAxisAlignment: CrossAxisAlignment.center,
    //                       children: [
    //                         // ProfilePicture(
    //                         //   size: 50,
    //                         //   image: tripTo.driverImage != Urls.baseDriverUrl
    //                         //       ? tripTo.driverImage
    //                         //       : null,
    //                         // ),
    //                         SizedBox(
    //                           width: 20,
    //                         ),
    //                         Expanded(
    //                           child: Column(
    //                             crossAxisAlignment: CrossAxisAlignment.start,
    //                             mainAxisSize: MainAxisSize.min,
    //                             mainAxisAlignment: MainAxisAlignment.center,
    //                             children: [
    //                               Text(
    //                                 "driverFound".tr,
    //                                 style: AppThemes
    //                                     .lightTheme.textTheme.subtitle1
    //                                     .copyWith(
    //                                   fontWeight: FontWeight.bold,
    //                                   color: Colors.black,
    //                                   fontSize: 16,
    //                                 ),
    //                               ),

    //                               /* Text(
    //                                 tripTo.ride.fname + " " + tripTo.ride.lname,
    //                                 style: AppThemes.lightTheme.textTheme.subtitle1
    //                                     .copyWith(
    //                                         fontWeight: FontWeight.normal,
    //                                         fontSize: 14,
    //                                         color: Colors.black),
    //                               ),
    //                               Text(
    //                                 tripTo.ride.categoryName,
    //                                 style: AppThemes.lightTheme.textTheme.subtitle1
    //                                     .copyWith(
    //                                         fontWeight: FontWeight.normal,
    //                                         fontSize: 14,
    //                                         color: Colors.black),
    //                               ),*/
    //                             ],
    //                           ),
    //                         )
    //                       ],
    //                     ),
    //                     SizedBox(
    //                       height: 10,
    //                     ),
    //                     rideFareDetail(
    //                       context,
    //                       "driver_name".tr,
    //                       tripTo?.ride?.fname ??
    //                           "" + " " + tripTo?.ride?.lname ??
    //                           "",
    //                     ),
    //                     rideFareDetail(
    //                       context,
    //                       "mobileNo".tr,
    //                       tripTo.ride.driverMobile,
    //                     ),
    //                     rideFareDetail(
    //                       context,
    //                       "vehicle_make".tr,
    //                       tripTo.ride.categoryName ?? "NA",
    //                     ),
    //                     rideFareDetail(
    //                       context,
    //                       "model".tr,
    //                       tripTo.ride.vehicleModel ?? "NA",
    //                     ),
    //                     rideFareDetail(
    //                       context,
    //                       "color".tr,
    //                       tripTo.ride.vehicleColor ?? "NA",
    //                     ),
    //                     rideFareDetail(
    //                       context,
    //                       "registration_no".tr,
    //                       tripTo.ride.plateNo,
    //                     ),
    //                     /* rideFareDetail(
    //                                 context,
    //                                 "ratings".tr,
    //                                 tripTo.driverRating,
    //                               ),*/
    //                     Row(
    //                       children: [
    //                         Text(
    //                           "ratings".tr + ": ",
    //                           style: Theme.of(context)
    //                               .textTheme
    //                               .headline4
    //                               .copyWith(
    //                                 fontSize: 14,
    //                                 fontFamily: 'NunitoSans',
    //                                 fontWeight: FontWeight.bold,
    //                               ),
    //                         ),
    //                         RatingBar(
    //                           initialRating: double.parse(tripTo.driverRating),
    //                           direction: Axis.horizontal,
    //                           allowHalfRating: true,
    //                           ignoreGestures: true,
    //                           itemCount: 5,
    //                           itemSize: 13,
    //                           ratingWidget: RatingWidget(
    //                             full: Icon(
    //                               Icons.star,
    //                               color: AppThemes.lightPinkBackGroundColor,
    //                             ),
    //                             half: Icon(
    //                               Icons.star_half,
    //                               color: AppThemes.lightPinkBackGroundColor,
    //                             ),
    //                             empty: Icon(
    //                               Icons.star_border,
    //                               color: AppThemes.lightStarColor,
    //                             ),
    //                           ),
    //                           glow: false,
    //                           itemPadding:
    //                               EdgeInsets.symmetric(horizontal: 0.0),
    //                           onRatingUpdate: (rating) {},
    //                         ),
    //                       ],
    //                     )
    //                   ],
    //                 ),
    //               ),
    //             ),
    //           ),
    //         ),
    //       )
    return Container(
      color: Colors.black12.withOpacity(0.5),
      child: Center(
        child: Container(
          height: 190,
          //color: Colors.red,
          margin: EdgeInsets.symmetric(horizontal: 20),
          child: Material(
            color: Colors.transparent,
            child: Stack(
              children: [
                Container(
                  height: 140,
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.black, width: 4),
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.white,
                  ),
                  child: Container(
                    margin: EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.black, width: 1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Expanded(
                                child: Text(
                                  _start != 0
                                      ? "rideBookSuccessFully".tr
                                      : "driverNotFoundText".tr,
                                  style: AppThemes
                                      .lightTheme.textTheme.subtitle1
                                      .copyWith(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 17,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Opacity(
                        opacity: _start == 0 ? 1 : 0,
                        child: GestureDetector(
                          onTap: _start == 0
                              ? () async {
                                  print(
                                      "cancel ride id $rideId ${widget.rideId}");
                                  //  await to.cancelTrip(rideId,
                                  //    isCleardata: false, isLoader: true);

                                  await to.rideReBook(tripTo.tripId);
                                  startTimer();
                                }
                              : () {},
                          child: Chip(
                            padding: EdgeInsets.all(10),
                            backgroundColor: AppThemes.lightPinkBackGroundColor,
                            label: Text(
                              "rebook".tr,
                              style: AppThemes.lightTheme.textTheme.subtitle1
                                  .copyWith(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16),
                            ),
                          ),
                        ),
                      ),
                      CircleAvatar(
                        backgroundColor: AppThemes.lightpauaBackGroundColor,
                        maxRadius: 50,
                        child: Text(
                          "$_start Sec",
                          style: AppThemes.lightTheme.textTheme.subtitle1
                              .copyWith(
                                  fontWeight: FontWeight.bold, fontSize: 22),
                        ),
                      ),
                      GestureDetector(
                        onTap: () async {
                          _riderDetailTimer.cancel();
                          print("cancel ride id $rideId ${widget.rideId}");
                          await to.cancelTrip(rideId,
                              isCleardata: true, isLoader: true);
                          BotToast.cleanAll();
                        },
                        child: Chip(
                          padding: EdgeInsets.all(10),
                          backgroundColor: AppThemes.lightPinkBackGroundColor,
                          label: Text("cancel".tr,
                              style: AppThemes.lightTheme.textTheme.subtitle1
                                  .copyWith(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16)),
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  rideFareDetail(context, String title, String data) => Row(
        children: [
          Text(
            title + ": ",
            style: Theme.of(context).textTheme.headline4.copyWith(
                  fontSize: 14,
                  fontFamily: 'NunitoSans',
                  fontWeight: FontWeight.bold,
                ),
          ),
          Text(
            data,
            style: Theme.of(context)
                .textTheme
                .headline4
                .copyWith(fontSize: 14, fontFamily: 'NunitoSans'),
          ),
          SizedBox(width: 10),
        ],
      );
}
