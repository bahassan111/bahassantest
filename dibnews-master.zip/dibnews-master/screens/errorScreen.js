import React, { Component, useState, useEffect, useRef  } from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    ImageBackground,
    ActivityIndicator,
    Button, Dimensions,
    TouchableOpacity,
    Animated, AppState, SafeAreaView,ScrollView,
    BackHandler,Alert
} from "react-native";

import HTMLView from 'react-native-htmlview';
import YoutubePlayer from "react-native-youtube-iframe";
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {updateData} from "../redux/actions/dataAction";
import TopHeader from "../componants/TopHeader";
import css, {colors as Colors} from "../global/GlobalStyle";
import Carousel from 'react-native-snap-carousel';
import GestureRecognizer from 'react-native-swipe-gestures';
import Loader from "./_loader";
import { AntDesign, FontAwesome5 } from '@expo/vector-icons';
import news from "../data/newsDemo";
import storage from "../storage/TwStorage";
import {fetchNewsData} from "../data/NewsData";
import NewsObject from "../data/NewsObject";
import SliderIndicator from "../componants/SliderIndicator";
import modernHome from "../componants/views/modernHome"
import NewsSlider from "../componants/NewsSlider";
import i18n from 'i18n-js';
import TwButton from "../componants/TwButton";
import { CommonActions } from '@react-navigation/native';

const win = Dimensions.get('window');
const ofHeight = (p)=> p * win.height / 100;
const ofWidth = (p)=> p * win.width / 100;




class errorScreen extends Component {


    state = {

    };





    componentDidUpdate(nextProps, nextState, nextContext) {

    }

    componentDidMount() {



    }





    render() {


        return (

            <View style={[css.background]}>

                <ScrollView style={{backgroundColor: '#dedede', maxHeight: ofHeight(100), paddingTop: ofHeight(6), paddingBottom: ofHeight(16)}}>

                    <SafeAreaView>
                        <View style={[styles.about_header]}>

                            <View style={[styles.about_header_logo]}>

                                <Image style={[styles.logo]} source={require('../assets/full_logo.jpg')}/>
                                <View style={[styles.flogo]}>
                                    <Image style={[styles.flogo_img]} source={require('../assets/no_ner.png')}/>
                                </View>


                            </View>

                        </View>

                        <View style={[styles.about_body, {marginBottom: 50}]}>

                            <Text style={[styles.about_title, {color:'rgba(48,48,48,0.81)'}]}>Hors connexion</Text>

                            {/*<View style={[styles.about_shape]}>
                                <View style={{backgroundColor: 'transparent',   height: 4, flex:3}}/>
                                <View style={{backgroundColor: Colors.primary1, height: 4, flex:1}}/>
                                <View style={{backgroundColor: Colors.primary2, height: 4, flex:1}}/>
                                <View style={{backgroundColor: Colors.primary3, height: 4, flex:1}}/>
                            </View>
*/}
                            <Text style={[styles.about_text, {color:'rgba(67,67,67,0.81)'}]}>
                                Impossible de se connecter à internet, veuillez vérifier que votre connexion Internet fonctionne, et réessayer
                            </Text>

                            <TwButton onPress={()=>{

                                const { navigation } = this.props;
                                navigation.dispatch(
                                    CommonActions.reset({
                                        index: 1,
                                        routes: [
                                            { name: 'splash' },
                                        ],
                                    })
                                );

                            }} full={false} small style={{minWidth: 200}} title={"Reésseyer"} icon={'sync'} />
                        </View>
                    </SafeAreaView>




                </ScrollView>


            </View>

        );
    }

}

const styles = StyleSheet.create({

    about_body : {
        alignItems: 'center',
    },
    about_text : {
        fontSize: 12,
        padding: 22,
        textAlign: 'center',
    },
    about_url : {
        fontSize: 14,
        padding: 22,
        textAlign: 'center',
        color: '#000',
    },
    about_shape : {
        height:30,
        width: 160,
        flexDirection: 'row',
    },
    about_title : {
        textAlign: 'center',
        fontWeight: 'bold',
        fontSize: 18,
    },
    about_subtitle : {
        textAlign: 'center',
        fontSize: 16,
    },
    about_header : {

        alignItems: 'center',
        justifyContent: 'center',

    },
    about_header_logo : {
        width: 300,
        height: 300,
        maxWidth: ofWidth(25),
        maxHeight: ofWidth(25),
        position: 'relative',
    },
    logo : {
        width: "100%",
        height: "100%",
        borderRadius: 8,
    },
    flogo_img : {
        width: '100%',
        height: '100%',
    },
    flogo : {
        width: 60,
        height: 60,
        padding: 10,
        position: 'absolute',
        right : -20,
        bottom : -20,
        backgroundColor: '#454545',
        borderRadius: 30,
        //borderWidth: 8,
        borderColor: '#454545'
        //resizeMode: 'contain',

    },
    logo_sh : {
        width: "120%",
        height: "120%",
        position: 'absolute',
        left : '-10%',
        top : '-10%',
        backgroundColor: 'rgba(0,0,0,0.59)',
        borderRadius: 8,
    },

    set_row: {
        paddingHorizontal: 8,
        paddingVertical: 12,
        margin: 12,
        marginBottom: 18,
        alignItems: 'center',
        borderWidth: 1,
        borderColor: '#ccc',

    },
    set_row_q: {
        paddingHorizontal: 8,
        paddingVertical: 12,
        margin: 12,
        marginBottom: 18,
        alignItems: 'center',

    },
    set_title: {
        color : '#000',
        padding: 8,
        textAlign: 'center',
        marginBottom: 18,
    },

    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    box: {
        backgroundColor: '#61dafb',
        width: 80,
        height: 80,
        borderRadius: 4,
    },

    lsels : {
        flexDirection: 'row',
        //flex: 2,
        //backgroundColor: 'rgba(3,178,255,0.25)',
    },
    lsel : {
        paddingHorizontal: 12,
        paddingVertical: 4,
        margin: 8,
        alignItems: 'center',
        borderRadius: 8,
        flex: 1,
        maxWidth: 280,

    },
    lsel_a : {
        backgroundColor: 'rgba(3,178,255,0.25)',
    },
    lsel_ai : {
        opacity: 1,
        color: '#03b2ff',
    },
    lsel_icon : {
        opacity: .2,
        marginBottom: 12,
    },
    lsel_image : {
        width: 60,
        height: 100,
        resizeMode: 'contain',
    },
    lsel_text : {
        paddingTop: 6,
        color : '#343434'
        //backgroundColor: '#ccc',
    },
    lsel_details : {
        //flexDirection: 'row',
        alignItems: 'center',
        padding: 8,
        marginVertical: 12,
    },
    row_sel: {
        flexDirection: 'row',
        borderColor : '#4b4b4b',
        borderWidth: 2,
        borderRadius : 8,
        height: 42,
        width: 320,
        marginVertical: 12,
    },
    row_sel_a: {
        borderColor: '#03b2ff',
        backgroundColor: "rgba(3,178,255,0.09)",
        //color : "#fff",
    },
    row_sel_icon: {
        height: 40,
        width: 64,
        alignItems: 'center',
        justifyContent: 'center',
    },
    row_sel_detail: {
        //height : 46,
        flex: 1,
        height: "100%",
        justifyContent : 'center',
        alignItems : 'center',
        //backgroundColor: '#ccc',
    },
    row_sel_text: {
        width: "100%",
        paddingHorizontal: 12,
    },
});

const mapDispatchToProps = dispatch => (
    bindActionCreators({
        updateData: updateData,
    }, dispatch)
);

const mapStateToProps = (state) => {
    const { data } = state;
    return { data }
};

export default connect(mapStateToProps, mapDispatchToProps)(errorScreen);
