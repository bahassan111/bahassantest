import 'dart:async';
import 'dart:convert';

import 'package:bot_toast/bot_toast.dart';
import 'package:driver/constants/constants.dart';
import 'package:driver/constants/helpers/helpers.dart';
import 'package:driver/models/models.dart';
import 'package:driver/ui/components/components.dart';
import 'package:driver/ui/home_ui/payment_mode.dart';
import 'package:driver/ui/home_ui/toll_tax.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import "package:latlong/latlong.dart";
import 'package:dio/dio.dart' as dio;
import 'package:logger/logger.dart';

import 'controllers.dart';

class HomeController extends GetxController {
  static HomeController to = Get.find();
  static AuthController authTo = Get.find();
  static PreBookingController preTo = Get.find();
  static MyMapController mapTo = Get.find();
  String selectedJobType = "";

  NetWorkCall netWorkCall = NetWorkCall();
  final databaseRef =
      FirebaseDatabase.instance.reference(); //database reference object
  ValueNotifier<HomeScreenStatus> homeScreenStatus =
      ValueNotifier(HomeScreenStatus.None);
  String _testTime;
  int charterTimeToShow = 0;
  bool canFinishTrip = false;
  StreamSubscription<int> tickerSubscription;
  Stream<int> tick(
    int ticks,
  ) {
    return Stream.periodic(Duration(seconds: 1), (x) => ticks - x - 1)
        .take(ticks);
  }

  @override
  onClose() {
    tickerSubscription?.cancel();
  }
   
   
  final store = GetStorage();

  int leftChartertimeInSeconds;
  //  driver statistics
  DriverStatistics driverStatistics;
  // is driver online
  bool isDriverOnline = false;
  // current driver location
  LatLng currentLocation;
  double bearing;
  // instance booking ride
  RideDetailModel rideDetail;

  @override
  void onReady() {
    
    super.onReady();
  }

  getTrip() async {
    if (authTo.userModel == null) {
      return;
    }
    final result = await netWorkCall.postRequestWithResponse(
      url: Urls.getTrip,
      json: {
        Params.driverId: int.tryParse(authTo.userModel.id),
        Params.fleetId: int.tryParse(authTo.userModel.fleetid)
      },
    );
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return;
    }, (response) async {
      print("notification get ride response $response");
      if (response?.statusCode == 200) {
        // for instant booking
        if (response.data['instantautobook'].length > 0) {
         
            to.rideDetail =
                RideDetailModel.fromJson(response.data['instantautobook'][0]);
            // show dialog
            var prebook = await  preTo.getUpbookings() ;
            if(prebook.length > 0 && prebook[0] is RideDetailModel) {
            if ((strinToDateTime((prebook[0] as RideDetailModel).bookDate)).difference(DateTime.now()).inMinutes >=40  )
            BotToast.showWidget(
              toastBuilder: (ctx) {
                return BookingNotification();
              },
            ); }
            else {BotToast.showWidget(
              toastBuilder: (ctx) {
                return BookingNotification();
              },
            ) ;}
            Future.delayed(const Duration(seconds: 9), () {
              BotToast.cleanAll();
            });
          
        }
      }
      return false;
    });
  }

  Future driverRideDetail({int time}) async {
    BotToast.showLoading();
    if (authTo.userModel == null) {
      return;
    }

    final result = await netWorkCall.postRequestWithResponse(
      url: Urls.driverRideDetail,
      json: {
        Params.rideId: int.tryParse(rideDetail.id),
        Params.driverId: int.tryParse(authTo.userModel.id)
      },
    );
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return;
    }, (response) {
      print("driverRideDetail $response");
      if (response?.statusCode == 200 && response.data['response'] != 'Fail') {
        to.rideDetail = RideDetailModel.fromJson(response.data['myridedetail']);
      }
      BotToast.cleanAll();
      return false;
    });
  }

  Future driverAlreadyassignRide() async {
    if (authTo.userModel == null) {
      return;
    }
    print("rideDetail.id ${rideDetail.id}");
    final result = await netWorkCall.postRequestWithResponse(
      url: Urls.driverAlreadyassignRide,
      json: {
        Params.rideId: int.tryParse(rideDetail.id),
      },
    );
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return;
    }, (response) {
      print("driverAlreadyassignRide ${response.data.runtimeType}");
      if (response?.statusCode == 200 && response.data.runtimeType != String) {
        return response.data['ride_status'];
      }
      return 0;
    });
  }

  updateCharterTime() {
    leftChartertimeInSeconds = getTimeDifferenceInSeconds(
        to?.rideDetail?.startTime, to?.rideDetail?.waitingTime);
    update();
  }


  startCountingCharterTime() async {
    tickerSubscription?.cancel();
    canFinishTrip = false;

    update();
    await driverRideDetail(time: 111);
    if (to.rideDetail.waitingTime == '0') {
      print("FAWZIYA BOZITIF BARA RAWAH ");
      canFinishTrip = true;
      charterTimeToShow = 0;
      update();
      return;
    }
    if (kDebugMode) print('start time herer ' + to?.rideDetail?.startTime);
    updateCharterTime();
    print("left charter time in hours" + leftChartertimeInSeconds.toString());
    if (leftChartertimeInSeconds <= 0) {
      canFinishTrip = true;
      charterTimeToShow = 0;
      update();
      return;
    }

    tickerSubscription = tick(leftChartertimeInSeconds).listen((duration) {
      print("tick");
      charterTimeToShow = duration;
      update();
    })
      ..onDone(() {
        canFinishTrip = true;

        tickerSubscription?.cancel();
        update();
      });
  }

  changeRideStatus(
      {@required int rideId,
      @required int statusType,
      @required int bookType,
      @required int driverId,
      @required DateTime startTime,
      @required DateTime driverArrivaltime,
      @required int countryId,
      @required HomeScreenStatus navigateTo}) async {
    try {
      print("waiting time +++ " + rideDetail.waitingTime);

      print("driverId $driverId");
      if (kDebugMode) {
        Logger().wtf(startTime.toString());
      }

      BotToast.showLoading();
      final result = await netWorkCall.postRequest(
        url: Urls.rideStatus,
        json: {
          Params.rideId: rideId,
          Params.statusType: statusType,
          Params.bookType: bookType,
          //(hh:mm:ss)
          Params.driverId: driverId,
          Params.startTime: startTime.toString(),
          Params.driverArrivaltime: formatehhmmss(driverArrivaltime),
          Params.countryId: countryId,
          // below is static
          Params.autoBooking: 1,
          Params.latitude: currentLocation.latitude,
          Params.longitude: currentLocation.longitude,
        },
      );
      return result.fold((l) {
        BotToast.showWidget(
            toastBuilder: (_) => ErrorDialog(
                  title: "Error".tr,
                  message: l ?? "unexcpected error occured",
                ));
        BotToast.closeAllLoading();
        return;
      }, (response) {
        print("status" +
            statusType.toString() +
            "change responce ${response.response}");
        if (response.responsecode == 1) {
          // show trip detail
          homeScreenStatus.value = navigateTo;
          if (statusType == 3) {
            startCountingCharterTime();
          }
        }

        BotToast.cleanAll();
      });
    } catch (e) {
      Logger().e(e);
      BotToast.cleanAll();
    }
  }

  iHaveArrived({
    @required int rideId,
    @required int statusType,
    @required int bookType,
    @required int driverId,
    @required DateTime startTime,
    @required DateTime driverArrivaltime,
    @required HomeScreenStatus navigateTo,
  }) async {
    print("ride id $rideId driver id $driverId");
    BotToast.showLoading();
    final result = await netWorkCall.postRequest(
      url: Urls.rideStatusArrived,
      json: {
        Params.rideId: rideId,
        Params.statusType: statusType,
        Params.bookType: bookType,
        //(hh:mm:ss)
        Params.driverId: driverId,
        Params.startTime: startTime.toString(),
        Params.driverArrivaltime: formatehhmmss(driverArrivaltime),
        // below is static
        Params.autoBooking: 1,
        Params.latitude: currentLocation?.latitude,
        Params.longitude: currentLocation?.longitude,
      },
    );
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return;
    }, (response) {
      print("iHaveArrived status ${response.response}");
      if (response.responsecode == 1) {
        // show trip detail
        homeScreenStatus.value = navigateTo;
      }
      BotToast.cleanAll();
    });
  }

  completeRide({
    @required int rideId,
    @required int statusType,
    @required int bookType,
    @required DateTime endTime,
    @required HomeScreenStatus navigateTo,
  }) async {
    BotToast.showLoading();
    final result = await netWorkCall.postRequest(
      url: Urls.completedRide,
      json: {
        Params.rideId: rideId,
        Params.statusType: statusType,
        Params.bookType: bookType,
        Params.endTime: ddmmyyhhmmss(endTime),
        // below is static
        Params.latitude: currentLocation.latitude,
        Params.longitude: currentLocation.longitude,
      },
    );
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
    }, (response) {
      print(
          "completeRide status ${response.response} ${response.responsecode}");
      if (response.responsecode == 1) {
        homeScreenStatus.value = HomeScreenStatus.None;
        BotToast.cleanAll();
        BotToast.showWidget(
          toastBuilder: (ctx) {
            return TollTax();
          },
        );
      }
    });
  }

  addTollTax({
    @required int rideId,
    @required int amount,
  }) async {
    BotToast.showLoading();
    final result = await netWorkCall.postRequest(
      url: Urls.driverTolltax,
      json: {
        Params.rideId: rideId,
        Params.amount: amount,
        Params.driverPaymentMode: 1,
      },
    );
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return;
    }, (response) {
      print("addTollTax  ${response.response} ${response.responsecode}");
      if (response.responsecode == 1) {
        homeScreenStatus.value = HomeScreenStatus.None;
        BotToast.cleanAll();
        BotToast.showWidget(
          toastBuilder: (ctx) {
            return PaymentMode();
          },
        );
      }
    });
  }

  driverNoShow({
    @required int rideId,
    @required int countryId,
  }) async {
    BotToast.showLoading();
    final result = await netWorkCall.postRequest(
      url: Urls.driverNoshowride,
      json: {
        Params.rideId: rideId,
        Params.reason: "No show",
        // 5 because its no show
        Params.statusType: 5,
        Params.countryId: countryId,
        Params.cancelDateTime: datedayddMMMyyyyhhMMss(DateTime.now()),
      },
    );
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return;
    }, (response) {
      print("driverNoShow  ${response.response} ${response.responsecode}");
      if (response.responsecode == 1) {
        homeScreenStatus.value = HomeScreenStatus.None;
        mapTo.routeDetail.value = null;
        mapTo.mapMatchingModel = null;
      }
      BotToast.cleanAll();
    });
  }

  cancelRide({
    @required int rideId,
    @required int countryId,
  }) async {
    BotToast.showLoading();
    final result = await netWorkCall.postRequest(
      url: Urls.driverCancelRide,
      json: {
        Params.rideId: rideId,
        Params.reason: "",
        // 2 because its cancel
        Params.statusType: 2,
        Params.countryId: countryId,
        Params.cancelDateTime: datedayddMMMyyyyhhMMss(DateTime.now()),
      },
    );
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return;
    }, (response) {
      print("cancel ride ${response.response}");
      if (response.responsecode == 1) {
        // for instant booking
      }
      BotToast.cleanAll();
    });
  }

  // get driver rating cancel accept
  // https://dms.thecandytech.com/api/driverapi/driver_rating
  Future getDriverStatistics() async {
    final result = await netWorkCall.postRequestWithResponse(
      url: Urls.driverRating,
      json: {
        Params.driverId: int.tryParse(authTo.userModel.id),
      },
    );
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return;
    }, (response) {
      if (response?.statusCode == 200) {
        driverStatistics = DriverStatistics(
          myRating: response.data['myrating'],
          myacceptance: response.data['myacceptance'],
          mycancellation: response.data['mycancellation'],
        );
      }
    });
  }

  Future getDriverIsOnlineOrNot() async {
    DataSnapshot dataSnapshot =
        await databaseRef.child(authTo.userModel.id).once();
    if (dataSnapshot.value != null) {
      isDriverOnline = true;
    }
  }

  changeDriverOnlineStatus({@required bool status}) async {
    BotToast.showLoading();
    print(authTo.userModel.vehicletype);
    print(authTo.userModel.carcategory);
    if (status) {
      await databaseRef.child(authTo.userModel.id).update(
        {
          //todo update actual angle if get somehow
          Params.angle: 90,
          Params.countryId: authTo.userModel.country,
          Params.fleetId: authTo.userModel.fleetid,
          Params.id: authTo.userModel.id,
          Params.lat: currentLocation?.latitude ?? null,
          Params.lng: currentLocation?.longitude ?? null,
          Params.name: authTo.userModel.firstname,
          Params.onlineStatus: "1",
        },
      );
    } else {
      try {
        await databaseRef.child(authTo.userModel.id).remove();
      } catch (e) {
        print("firebase error $e");
      }
    }
    await netWorkCall.postRequest(
      url: Urls.changeStatus,
      json: {
        Params.driverId: int.tryParse(authTo.userModel.id),
        Params.newStatus: status ? '1' : '0'
      },
    );
    BotToast.closeAllLoading();
  }

  updateDriverLocation() async {
    if (currentLocation == null) {
      return;
    }

    DataSnapshot dataSnapshot =
        await databaseRef.child(authTo.userModel.id).once();

    // if driver is online
    if (dataSnapshot.value != null) {
      // update in firebase
      print(currentLocation);
      databaseRef.child(authTo.userModel.id).update({
        Params.lat: currentLocation.latitude,
        Params.lng: currentLocation.longitude,
        Params.bearing: bearing,
        // Params.bearing: currentLocation.bearing,
      });
      // update in server
      final result = await netWorkCall.postRequest(
        url: Urls.driverLatlong,
        json: {
          Params.driverId: int.tryParse(authTo.userModel.id),
          Params.latitude: currentLocation.latitude,
          Params.longitude: currentLocation.longitude
        },
      );
      result.fold((l) {
        BotToast.showWidget(
            toastBuilder: (_) => ErrorDialog(
                  title: "Error".tr,
                  message: l ?? "unexcpected error occured",
                ));
        BotToast.closeAllLoading();
        return false;
      }, (r) {
        return true;
      });
    }
  }
}
