package ma.rak.ov.bodyResponse;

import com.google.gson.annotations.SerializedName;

import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;
import ma.rak.ov.models.Categorie;
import ma.rak.ov.models.Emplacement;
import ma.rak.ov.models.Motif;
import ma.rak.ov.models.Nature;

public class SettingsResponse extends RealmObject {

    @SerializedName("id")
    private int id;

    @PrimaryKey
    @SerializedName("type")
    private String type;

    @SerializedName("status")
    private String status;

    @SerializedName("last_date")
    private String lastDate;

    @SerializedName("nature")
    private RealmList<Nature> nature;

    @SerializedName("categorie")
    private RealmList<Categorie> categorie;

    @SerializedName("emplacement")
    private RealmList<Emplacement> emplacement;

    @SerializedName("motif")
    private RealmList<Motif> motif;

    @SerializedName("branchement")
    private SettingsResponseBr branchement;

    public SettingsResponse() {
    }

    public SettingsResponse(int id, String type, String status, String lastDate, RealmList<Nature> nature, RealmList<Categorie> categorie, RealmList<Motif> motif, RealmList<Emplacement> emplacement, SettingsResponseBr branchement) {
        this.id = id;
        this.type = type;
        this.status = status;
        this.lastDate = lastDate;
        this.nature = nature;
        this.categorie = categorie;
        this.motif = motif;
        this.emplacement = emplacement;
        this.branchement = branchement;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLastDate() {
        return lastDate;
    }

    public void setLastDate(String lastDate) {
        this.lastDate = lastDate;
    }

    public RealmList<Nature> getNature() {
        return nature;
    }

    public void setNature(RealmList<Nature> nature) {
        this.nature = nature;
    }

    public RealmList<Categorie> getCategorie() {
        return categorie;
    }

    public void setCategorie(RealmList<Categorie> categorie) {
        this.categorie = categorie;
    }

    public RealmList<Motif> getMotif() {
        return motif;
    }

    public void setMotif(RealmList<Motif> motif) {
        this.motif = motif;
    }

    @Override
    public String toString() {
        return "SettingsResponse{" +
                "id=" + id +
                ", type='" + type + '\'' +
                ", status='" + status + '\'' +
                ", lastDate='" + lastDate + '\'' +
                ", nature=" + nature +
                ", categorie=" + categorie +
                ", emplacement=" + emplacement +
                ", motif=" + motif +
                ", branchement=" + branchement +
                '}';
    }

    public RealmList<Emplacement> getEmplacement() {
        return emplacement;
    }

    public void setEmplacement(RealmList<Emplacement> emplacement) {
        this.emplacement = emplacement;
    }

    public SettingsResponseBr getBranchement() {
        return branchement;
    }

    public void setBranchement(SettingsResponseBr branchement) {
        this.branchement = branchement;
    }
}
