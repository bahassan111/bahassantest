import React, { PureComponent } from "react";
import Carousel, {
  Pagination,
  getInputRangeFromIndexes
} from "react-native-snap-carousel";
import { Constants, Colors, View } from "react-native-ui-lib";
import { Image } from "react-native";
const SLIDER_1_FIRST_ITEM = 0;
export default class MyCustomCarousel extends PureComponent {
  state = {
    slider1ActiveSlide: SLIDER_1_FIRST_ITEM
  };
  render() {
    _scrollInterpolator = (index, carouselProps) => {
      const range = [3, 2, 1, 0, -1];
      const inputRange = getInputRangeFromIndexes(range, index, carouselProps);
      const outputRange = range;

      return { inputRange, outputRange };
    };

    _animatedStyles = (index, animatedValue, carouselProps) => {
      const sizeRef = carouselProps.vertical
        ? carouselProps.itemHeight
        : carouselProps.itemWidth;
      const translateProp = carouselProps.vertical
        ? "translateY"
        : "translateX";

      return {
        zIndex: carouselProps.data.length - index,
        opacity: animatedValue.interpolate({
          inputRange: [2, 3],
          outputRange: [1, 0]
        }),
        transform: [
          {
            rotate: animatedValue.interpolate({
              inputRange: [-1, 0, 1, 2, 3],
              outputRange: ["-25deg", "0deg", "-3deg", "1.8deg", "0deg"],
              extrapolate: "clamp"
            })
          },
          {
            [translateProp]: animatedValue.interpolate({
              inputRange: [-1, 0, 1, 2, 3],
              outputRange: [
                -sizeRef * 0.5,
                0,
                -sizeRef, // centered
                -sizeRef * 2, // centered
                -sizeRef * 3 // centered
              ],
              extrapolate: "clamp"
            })
          }
        ]
      };
    };
    return (
      <View Column paddingL-0>
        <Carousel
          ref={c => (this._slider1Ref = c)}
          scrollInterpolator={this._scrollInterpolator}
          slideInterpolatedStyle={this._animatedStyles}
          sliderWidth={Constants.screenWidth}
          itemWidth={(Constants.screenWidth / 4) * 3.3}
          hasParallaxImages={true}
          useScrollView={true}
          inactiveSlideScale={0.94}
          inactiveSlideOpacity={0.7}
          inactiveDotColor={Colors.primary}
          onSnapToItem={index => this.setState({ slider1ActiveSlide: index })}
          {...this.props}
        />

        <Pagination
          containerStyle={{
            position: "absolute",
            bottom: 0,
            top: 100,
            left: 0,
            right: 0
          }}
          dotsLength={this.props.data.length}
          activeDotIndex={this.state.slider1ActiveSlide}
          dotColor={Colors.white}
          inactiveDotColor={Colors.white}
          inactiveDotOpacity={0.4}
          inactiveDotScale={0.6}
          carouselRef={this._slider1Ref}
          tappableDots={!!this._slider1Ref}
        />

        <Image
          source={require("../assets/images/banners.png")}
          style={{
            height: 50,
            width: Constants.screenWidth
          }}
          resizeMode="cover"
        />
      </View>
    );
  }
}
