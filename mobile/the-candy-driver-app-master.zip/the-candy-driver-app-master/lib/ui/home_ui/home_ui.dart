import 'package:driver/constants/constants.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:driver/ui/components/components.dart';
import 'package:driver/ui/home_ui/statistics.dart';
import 'package:driver/ui/home_ui/trip_detail.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'finish_trip.dart';
import 'map.dart';
import 'menubar.dart';
import 'proceed.dart';
import 'start_trip.dart';

class HomeUI extends StatefulWidget {
  @override
  _HomeUIState createState() => _HomeUIState();
}

class _HomeUIState extends State<HomeUI> with WidgetsBindingObserver {
  bool isMenuShow = false;
  static HomeController to = Get.find();
  static PreBookingController preTo = Get.find();

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    var data = Get.arguments;
    if (data != null) {
      print("data $data");
      if (data['route'] != null) {
        Future.delayed(Duration(seconds: 5));
        to.homeScreenStatus.value = HomeScreenStatus.TripDetail;
      }
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      print('AppLifecycleState state: Paused audio playback');
    }
    if (state == AppLifecycleState.resumed) {
      
      preTo.showNotif();

      print('AppLifecycleState state: resumed audio playback');
    }
    print('AppLifecycleState state:  $state');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      /*floatingActionButton: FloatingActionButton(
        onPressed: () {
          
        },
      ),*/
      body: Container(
        child: Stack(
          children: [
            Column(
              children: [
                Expanded(
                  child: Stack(
                    children: [
                      ShowMap(),
                      MenuBar(
                        updateMenuPosition: () => setState(() {
                          isMenuShow = !isMenuShow;
                        }),
                        isMenuShow: isMenuShow,
                      ),
                    ],
                  ),
                ),
                ValueListenableBuilder(
                    valueListenable: to.homeScreenStatus,
                    builder: (context, value, child) {
                      return getBottomWidget(value);
                    }),
              ],
            ),
            CustomDrawer(
              updateMenuPosition: () => setState(() {
                isMenuShow = false;
              }),
              isMenuShow: isMenuShow,
            )
          ],
        ),
      ),
    );
  }

  getBottomWidget(HomeScreenStatus value) {
    switch (value) {
      case HomeScreenStatus.None:
        return Statistics();
      case HomeScreenStatus.TripDetail:
        return TripDetail();
      case HomeScreenStatus.Procced:
        return Proceed();
      case HomeScreenStatus.IhaveArrived:
        return StartTrip();
      case HomeScreenStatus.StartTrip:
        return FinishTrip();
      case HomeScreenStatus.FinishTrip:
        return Container();
    }
  }
}
