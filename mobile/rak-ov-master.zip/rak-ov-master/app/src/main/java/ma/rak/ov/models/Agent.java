package ma.rak.ov.models;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class Agent extends RealmObject {
    @PrimaryKey
    private String CODEUTIL;
    private String NOM_UTIL;
    private String CODE_TSP;
    private String IMEI;
    private String CODEPROF;

    public Agent() {
    }

    @Override
    public String toString() {
        return "Agent{" +
                "CODEUTIL='" + CODEUTIL + '\'' +
                ", NOM_UTIL='" + NOM_UTIL + '\'' +
                ", CODE_TSP='" + CODE_TSP + '\'' +
                ", IMEI='" + IMEI + '\'' +
                ", CODEPROF='" + CODEPROF + '\'' +
                '}';
    }

    public Agent(String CODEUTIL, String NOM_UTIL, String CODE_TSP, String IMEI, String CODEPROF) {
        this.CODEUTIL = CODEUTIL;
        this.NOM_UTIL = NOM_UTIL;
    }

    public String getCODEUTIL() {
        return CODEUTIL;
    }

    public void setCODEUTIL(String CODEUTIL) {
        this.CODEUTIL = CODEUTIL;
    }

    public String getNOM_UTIL() {
        return NOM_UTIL;
    }

    public void setNOM_UTIL(String NOM_UTIL) {
        this.NOM_UTIL = NOM_UTIL;
    }

    public String getCODE_TSP() {
        return CODE_TSP;
    }

    public void setCODE_TSP(String CODE_TSP) {
        this.CODE_TSP = CODE_TSP;
    }

    public String getCODEPROF() {
        return CODEPROF;
    }

    public void setCODEPROF(String CODEPROF) {
        this.CODEPROF = CODEPROF;
    }

    public String getIMEI() {
        return IMEI;
    }

    public void setIMEI(String IMEI) {
        this.IMEI = IMEI;
    }
}
