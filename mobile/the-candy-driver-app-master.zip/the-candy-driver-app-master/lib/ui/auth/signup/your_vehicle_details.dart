import 'package:driver/constants/constants.dart';
import 'package:driver/constants/helpers/helpers.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:driver/models/models.dart';
import 'package:driver/ui/components/components.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

class YourVehicleDetails extends StatefulWidget {
  @override
  _YourVehicleDetailsState createState() => _YourVehicleDetailsState();
}

class _YourVehicleDetailsState extends State<YourVehicleDetails> {
  final AuthController authController = AuthController.to;

  @override
  void initState() {
    super.initState();
    if (authController.userModel != null) {
      authController.plateNumberController.text =
          authController.userModel.plateNo;

      authController.vehiclecategories.forEach((element) {
        if (element.name == authController.userModel.carcategory) {
          authController.selectedVehicleCategorytype = element;
          authController.getVehicleType(int.tryParse(element.id)).then((value) {
            setState(() {
              authController.vehicleType.forEach((vehicle) {
                if (vehicle.categoryName ==
                    authController.userModel.vehicletype) {
                  authController.selectedVehicleType = vehicle;
                }
              });
            });
          });
        }
      });
      authController.yearOfReg =
          stringToDateOnlyYear(authController.userModel.yearofreg);
      authController.insuranceExp =
          stringToDate(authController.userModel.vinsuranceexpiry);
      authController.permitExp =
          stringToDate(authController.userModel.vehiclepermitexpiry);
      if (authController.userModel.vehiclemodel != "") {
        authController.vehicleModelController.text =
            authController.userModel.vehiclemodel;
      }
      if (authController.userModel.vehiclecolor != "") {
        authController.selectedColor = authController.userModel.vehiclecolor;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 15),
      child: Column(
        children: [
          SizedBox(
            height: 30,
          ),
          Text(
            "your_vehicle_details".tr,
            style: Theme.of(context).textTheme.headline2.copyWith(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Expanded(
                child: FormInputField(
                  labelText: "plate_number".tr,
                  controller: authController.plateNumberController,
                ),
              ),
              SizedBox(
                width: 20,
              ),
              Expanded(
                child: CustomPicker(
                  isClickAble: authController.userModel == null,
                  label: "yeat_of_registration".tr + " *",
                  intialDate: DateTime.now().subtract(Duration(days: 999999)),
                  endDate: DateTime.now(),
                  onDateSelect: (DateTime selectedDate) {
                    authController.yearOfReg = selectedDate;
                  },
                  selectedDate: authController.yearOfReg,
                ),
              ),
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Expanded(
                child: selectVehicleColor(),
              ),
              SizedBox(
                width: 20,
              ),
              Expanded(
                child: FormInputField(
                  labelText: "vehicle_model".tr,
                  controller: authController.vehicleModelController,
                ),
              ),
            ],
          ),
          SizedBox(
            height: 10,
          ),
          vehicleCategoryType(),
          SizedBox(
            height: 10,
          ),
          vehicleType(),
          /*  SizedBox(
            height: 10,
          ),
         Row(
            children: [
              Expanded(child: vehicleType()),
              SizedBox(
                width: 20,
              ),
              Expanded(
                child: CustomPicker(
                  isClickAble: authController.userModel == null,
                  label: "yeat_of_registration".tr + " *",
                  intialDate: DateTime.now().subtract(Duration(days: 999999)),
                  endDate: DateTime.now(),
                  onDateSelect: (DateTime selectedDate) {
                    authController.yearOfReg = selectedDate;
                  },
                  selectedDate: authController.yearOfReg,
                ),
              ),
            ],
          ),*/
          SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Expanded(
                child: CustomImageSelector(
                  label: "vehicle_insurance".tr + " *",
                  onImageSelect: (PickedFile image) {
                    authController.vehicleInsuranceImg = image;
                  },
                  image: authController.userModel?.insurancephoto,
                ),
              ),
              SizedBox(
                width: 20,
              ),
              Expanded(
                child: CustomPicker(
                  isClickAble: authController.userModel == null,
                  label: "insurance_expiry_date".tr + " *",
                  onDateSelect: (DateTime selectedDate) {
                    authController.insuranceExp = selectedDate;
                  },
                  selectedDate: authController.permitExp,
                ),
              )
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Expanded(
                  child: CustomImageSelector(
                label: "vehicle_permit".tr + " *",
                onImageSelect: (PickedFile image) {
                  authController.vehiclePermitImg = image;
                },
                image: authController.userModel?.vehiclepermit,
              )),
              SizedBox(
                width: 20,
              ),
              Expanded(
                child: CustomPicker(
                  isClickAble: authController.userModel == null,
                  label: "permit_expiry_date".tr + " *",
                  onDateSelect: (DateTime selectedDate) {
                    authController.permitExp = selectedDate;
                  },
                  selectedDate: authController.permitExp,
                ),
              )
            ],
          ),
        ],
      ),
    );
  }

  selectVehicleColor() {
    return Container(
      height: 40.0,
      padding: EdgeInsets.symmetric(horizontal: 15),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(40),
        border: Border.all(
          color: AppThemes.lightInputBorderColor,
        ),
      ),
      child: DropdownButton<String>(
        value: authController.selectedColor,
        hint: Text(
          "vehicle_color".tr,
          style: Theme.of(context).textTheme.headline2.copyWith(
                fontSize: 15,
              ),
        ),
        icon: Icon(
          Icons.keyboard_arrow_down,
          color: AppThemes.lightdeepPinkDropDownIconColor,
          size: 30,
        ),
        iconSize: 24,
        elevation: 16,
        style: Theme.of(context).textTheme.headline2.copyWith(
              fontSize: 15,
            ),
        isExpanded: true,
        underline: SizedBox.shrink(),
        onChanged: (newValue) {
          setState(() {
            print("newValue $newValue}");
            authController.selectedColor = newValue;
          });
        },
        items: authController.colors.map<DropdownMenuItem<String>>((color) {
          return DropdownMenuItem(
            value: color,
            child: Text(
              color,
              overflow: TextOverflow.ellipsis,
            ),
          );
        }).toList(),
      ),
    );
  }

  vehicleType() {
    return Container(
      height: 40.0,
      padding: EdgeInsets.symmetric(horizontal: 15),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(40),
        border: Border.all(
          color: AppThemes.lightInputBorderColor,
        ),
      ),
      child: DropdownButton<VehicleType>(
        value: authController.selectedVehicleType,
        hint: Text("vehicle_type".tr + "*"),
        icon: Icon(
          Icons.keyboard_arrow_down,
          color: AppThemes.lightdeepPinkDropDownIconColor,
          size: 30,
        ),
        iconSize: 24,
        elevation: 16,
        style: Theme.of(context).textTheme.headline2.copyWith(
              fontSize: 13,
            ),
        isExpanded: true,
        underline: SizedBox.shrink(),
        onChanged: (newValue) async {
          setState(() {
            authController.selectedVehicleType = newValue;
            print(
                "authController.selectedVehicleType ${authController.selectedVehicleType.id}");
          });
          setState(() {});
        },
        items: authController.vehicleType
            .map<DropdownMenuItem<VehicleType>>((type) {
          return DropdownMenuItem(
            value: type,
            child: Text(type.categoryName, overflow: TextOverflow.ellipsis),
          );
        }).toList(),
      ),
    );
  }

  vehicleCategoryType() {
    return Container(
      height: 40.0,
      padding: EdgeInsets.symmetric(horizontal: 15),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(40),
        border: Border.all(
          color: AppThemes.lightInputBorderColor,
        ),
      ),
      child: DropdownButton<VehicleCategorytype>(
        value: authController.selectedVehicleCategorytype,
        hint: Text("vehicle_category".tr + "*"),
        icon: Icon(
          Icons.keyboard_arrow_down,
          color: AppThemes.lightdeepPinkDropDownIconColor,
          size: 30,
        ),
        iconSize: 24,
        elevation: 16,
        style: Theme.of(context).textTheme.headline2.copyWith(
              fontSize: 13,
            ),
        isExpanded: true,
        underline: SizedBox.shrink(),
        onChanged: (newValue) async {
          setState(() {
            authController.selectedVehicleCategorytype = newValue;
            authController.selectedVehicleType = null;
            authController.vehicleType.clear();
          });
          await authController.getVehicleType(int.tryParse(newValue.id));
          setState(() {});
        },
        items: authController.vehiclecategories
            .map<DropdownMenuItem<VehicleCategorytype>>((category) {
          return DropdownMenuItem(
            value: category,
            child: Text(
              category.name,
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
            ),
          );
        }).toList(),
      ),
    );
  }
}
