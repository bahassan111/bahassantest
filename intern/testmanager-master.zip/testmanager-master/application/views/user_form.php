<?php



?>

<div class="" id="user_form">


    <form>
        <div class="form-group">
            <label for="username" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Username</label>
            <input required value="<?= $edit ? $user->username : ''; ?>" name="username" id="username" type="text" class="form-control form-control-sm" placeholder="">
        </div>

        <div class="form-group">
            <label for="email" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">E-Mail</label>
            <input required value="<?= $edit ? $user->email : ''; ?>" name="email" id="email" type="email" class="form-control form-control-sm" placeholder="">
        </div>

        <div class="form-group">
            <label for="group" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Group</label>
            <select required title="Select a group" name="group" id="group" class="selectpicker">
                <?php foreach($groups as $g){ ?>
                    <option <?= $edit && $user->group === $g->id ? 'selected' : '' ?> value="<?= $g->id; ?>"><?= $g->name; ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="form-group">
            <label for="active" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Account Status</label>
            <select required name="active" id="active" class="selectpicker">
                <option <?= $edit && $user->active === '0' ? 'selected' : '' ?> value="0">Inactive</option>
                <option <?= $edit ? ($user->active ? 'selected' : '') : 'selected' ?> value="1">Active</option>
            </select>
        </div>

        <div class="form-group">
            <label for="first_name" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">First name</label>
            <input required value="<?= $edit ? $user->first_name : ''; ?>" name="first_name" id="first_name" type="text" class="form-control form-control-sm" placeholder="">
        </div>

        <div class="form-group">
            <label for="last_name" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Last name</label>
            <input value="<?= $edit ? $user->last_name : ''; ?>" name="last_name" id="last_name" type="text" class="form-control form-control-sm" placeholder="">
        </div>

        <div class="form-group">
            <label for="phone" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Phone Number</label>
            <input value="<?= $edit ? $user->phone : ''; ?>" name="phone" id="phone" type="text" class="form-control form-control-sm" placeholder="">
        </div>

        <div class="form-group">
            <label for="company" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Team</label>
            <input value="<?= $edit ? $user->company : ''; ?>" name="company" id="company" type="text" class="form-control form-control-sm" placeholder="">
        </div>

        <hr>

        <div class="group">
            <?php if($edit){?><label>Change Password</label><?php } ?>
            <div class="form-group">
                <label for="password" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Password</label>
                <input <?= $edit ? '' : 'required' ?> value="" name="password" id="password" type="password" class="form-control form-control-sm" placeholder="">
            </div>

            <div class="form-group">
                <label for="password" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Confirm Password</label>
                <input <?= $edit ? '' : 'required' ?> value="" name="password2" id="password2" type="password" class="form-control form-control-sm" placeholder="">
            </div>
        </div>
    </form>




</div>
