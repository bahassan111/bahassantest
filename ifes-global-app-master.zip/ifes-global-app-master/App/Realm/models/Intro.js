import Model from '../model'
export default class Intro extends Model {
  static schema = {
    name: 'Intro',
    primaryKey: 'id',
    properties: {
      id : {type: 'int'},
      firstTime : {type: 'bool', default: true},
    }
  }
}