import 'package:driver/models/models.dart';

class Features {
  String id;
  String type;
  List<String> placeType;
  String text;
  String placeName;
  List<double> center;
  List<Context> context;

  Features(
      {this.id,
      this.type,
      this.placeType,
      this.text,
      this.placeName,
      this.center,
      this.context});

  Features.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    type = json['type'];
    placeType = json['place_type'].cast<String>();

    text = json['text'];
    placeName = json['place_name'];
    center = json['center'].cast<double>();
    if (json['context'] != null) {
      context = [];
      json['context'].forEach((v) {
        context.add(new Context.fromJson(v));
      });
    }
  }
}
