package ma.rak.ov.ui.main;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import ma.rak.ov.R;
import ma.rak.ov.api.TwSyncher;

public class SyncUI extends AppCompatActivity {

    public int index = 0;
    TextView info;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_syncui);

        info = findViewById(R.id.synctxt);


        TwSyncher.init(this, new Runnable() {
            @Override
            public void run() {
                //Step

                switch (index) {
                    case 0:
                        info.setText("Démarrage de synchronisation ..");
                        break;
                    case 1:
                        info.setText("Synchronisation des paramètres..");
                        break;
                    case 2:
                        info.setText("Synchronisation des demandes..");
                        break;
                    case 3:
                        info.setText("Synchronisation d'historiques..");
                        break;
                    case 4:
                        info.setText("Finalisation ..");
                        break;
                    case 5:
                        info.setText("Démarrage ..");
                        break;
                }


                index++;
            }
        }, new Runnable() {
            @Override
            public void run() {

                //OnSuccess
                Intent intent = new Intent(SyncUI.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            }
        }, new Runnable() {
            @Override
            public void run() {

                //OnError
                Intent intent = new Intent(SyncUI.this, Error.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(SyncUI.this).toBundle());
                }
            }
        }, 0);

    }
}