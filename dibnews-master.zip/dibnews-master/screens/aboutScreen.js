import React, { Component, useState, useEffect, useRef  } from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    ImageBackground,
    ActivityIndicator,
    Button, Dimensions,
    TouchableOpacity,
    Animated, AppState, SafeAreaView,ScrollView,
    BackHandler,Alert
} from "react-native";

import HTMLView from 'react-native-htmlview';
import YoutubePlayer from "react-native-youtube-iframe";
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {updateData} from "../redux/actions/dataAction";
import TopHeader from "../componants/TopHeader";
import css, {colors as Colors} from "../global/GlobalStyle";
import Carousel from 'react-native-snap-carousel';
import GestureRecognizer from 'react-native-swipe-gestures';
import Loader from "./_loader";
import { AntDesign, FontAwesome5 } from '@expo/vector-icons';
import news from "../data/newsDemo";
import storage from "../storage/TwStorage";
import {fetchNewsData} from "../data/NewsData";
import NewsObject from "../data/NewsObject";
import SliderIndicator from "../componants/SliderIndicator";
import modernHome from "../componants/views/modernHome"
import NewsSlider from "../componants/NewsSlider";
import i18n from 'i18n-js';
import TwButton from "../componants/TwButton";
import { CommonActions } from '@react-navigation/native';

const win = Dimensions.get('window');
const ofHeight = (p)=> p * win.height / 100;
const ofWidth = (p)=> p * win.width / 100;


class aboutScreen extends Component {


    state = {
        fade : new Animated.Value(0),
        fade2 : new Animated.Value(0),
    };





    componentDidUpdate(nextProps, nextState, nextContext) {

    }

    componentDidMount() {

        let data = this.props.data;

        this.animate();

    }

    animate = ()=>{

        Animated.parallel([
            Animated.timing(this.state.fade, {
                toValue: 1,
                duration: 1000,
                useNativeDriver : true,
            }),
            Animated.timing(this.state.fade2, {
                toValue: 1,
                duration: 1300,
                useNativeDriver : true,
            })
        ]).start(() => {
            this.Deanimate();
        });

    };

    Deanimate = ()=>{

        Animated.parallel([
            Animated.timing(this.state.fade, {
                toValue: 0,
                duration: 1200,
                useNativeDriver : true,
            }),
            Animated.timing(this.state.fade2, {
                toValue: 0,
                duration: 1000,
                useNativeDriver : true,
            })
        ]).start(() => {
            this.animate();
        });

    };

    logoPressed = ()=>{
        const {navigation} = this.props;
        navigation.navigate('news');
    };
    menuPressed = ()=>{
        const {navigation} = this.props;

        navigation.toggleDrawer();
    };



    render() {

        const scaleX = this.state.fade.interpolate({
            inputRange: [0, 1],
            outputRange: [0.96, 1]
        });

        const scaleY = this.state.fade.interpolate({
            inputRange: [0, 1],
            outputRange: [0.96, 1]
        });

        return (

            <View style={[this.props.data.theme === 'dark' ? css.background : css.background_fordark]}>
                <TopHeader menuColor={this.props.data.theme === 'dark' ? 'white' : '#444444'} hideLogo={true} transparent={true} floatable={true} title="" onMenu={this.menuPressed} onUser={this.logoPressed}/>

                <ScrollView style={{backgroundColor: this.props.data.theme === 'dark' ? '#454545' : '#fff', maxHeight: ofHeight(100), paddingTop: ofHeight(6), paddingBottom: ofHeight(16)}}>

                    <SafeAreaView>
                        <View style={[styles.about_header]}>


                            <Animated.View style={[styles.about_header_logo, {scaleX}, {scaleY}]}>

                                <Animated.View style={[styles.logo_sh, {opacity: this.state.fade, height: '108%',width: '106%', top:'-4%', left:'-4%'}]}/>
                                <Animated.View style={[styles.logo_sh, {opacity: this.state.fade2, height: '112%',width: '112%', top:'-6%', left:'-6%'}]}/>

                                <TouchableOpacity onPress={()=>{
                                    const {navigation} = this.props;
                                    navigation.goBack();
                                }}>
                                    <Image style={[styles.logo]} source={require('../assets/full_logo.jpg')}/>
                                </TouchableOpacity>


                            </Animated.View>

                        </View>

                        <View style={[styles.about_body, {marginBottom: 50}]}>

                            <Text style={[styles.about_title, (this.props.data.theme === 'dark' ? {color:'rgba(255,255,255,0.81)'} : {})]}>DIB NEWS</Text>
                            {/*<Text style={[styles.about_subtitle]}>Digital Information Broadcast</Text>*/}
                            <View style={[styles.about_shape]}>
                                <View style={{backgroundColor: 'transparent',   height: 4, flex:3}}/>
                                <View style={{backgroundColor: Colors.primary1, height: 4, flex:1}}/>
                                <View style={{backgroundColor: Colors.primary2, height: 4, flex:1}}/>
                                <View style={{backgroundColor: Colors.primary3, height: 4, flex:1}}/>
                            </View>

                            <Text style={[styles.about_text, (this.props.data.theme === 'dark' ? {color:'rgba(255,255,255,0.81)'} : {})]}>
                                DIB News (Digital information broadcast) est un nouveau produit informatif ayant pour ambition de devenir un média de référence pour les jeunes âgés entre 15 et 35 ans.
                            </Text>
                            <Text style={[styles.about_text, (this.props.data.theme === 'dark' ? {color:'rgba(255,255,255,0.81)'} : {})]}>
                                DIB News est destiné principalement à une population urbaine qui cherche des plateformes pour révéler sa créativité et son talent.
                            </Text>
                            <Text style={[styles.about_text, (this.props.data.theme === 'dark' ? {color:'rgba(255,255,255,0.81)'} : {})]}>
                                Partant du constat que les médias sont peu inclusifs en matière de jeunesse, “DIB News” cherche alors à remédier à cela en offrant un produit médiatique qui privilégie la créativité et l’expression, en abordant des sujets et des thématiques relatifs aux attentes des jeunes, avec un langage simple et accessible et un ton amical.
                            </Text>
                            <Text style={[styles.about_text, (this.props.data.theme === 'dark' ? {color:'rgba(255,255,255,0.81)'} : {})]}>
                                Aussi, DIB News a pour but de mettre en avant les expériences sociales et humaines abouties, encourager les créateurs de contenu et accompagner des mouvements d’idées, des courants modernes tout en priorisant l’art contemporain, à savoir les arts plastiques, la musique, la littérature, la photographie, le théâtre, le cinéma…
                            </Text>
                            <Text style={[styles.about_text, (this.props.data.theme === 'dark' ? {color:'rgba(255,255,255,0.81)'} : {})]}>
                                Pour mener à bien sa mission, le site informatif DIB News reposera sur des vidéos, conformes aux normes professionnelles, qui ne dépasseront pas les trois minutes. Il s’agira alors d’interviews, documentaires, tutoriels… qui seront diffusés sur l’ensemble des réseaux sociaux (Facebook, Instagram, TikTok, Youtube…).
                            </Text>
                            <Text style={[styles.about_text, (this.props.data.theme === 'dark' ? {color:'rgba(255,255,255,0.81)'} : {})]}>
                                L’ensemble du contenu de DIB News sera conçu par un groupe de jeunes journalistes et techniciens de la nouvelle génération qui tiendront à enrichir l’ensemble des plateformes de ce média informatif par des programmes relatifs aux problèmes, ambitions et aspirations de la jeunesse marocaine.
                            </Text>
                            <Text style={[styles.about_text, (this.props.data.theme === 'dark' ? {color:'rgba(255,255,255,0.81)'} : {})]}>
                                Le lancement du nouveau produit DIB News consacre l’orientation de la MAP en matière de multimédia, faisant d’elle un acteur incontournable dans le paysage médiatique national et ce grâce aux efforts entrepris durant ces dernières années dans le cadre d’une vision stratégique claire et précise pour en faire de la MAP une agence du 21è siècle.
                            </Text>


                            <Text style={[styles.about_url, (this.props.data.theme === 'dark' ? {color:'rgba(255,255,255,0.81)'} : {})]}>www.dibnews.ma</Text>

                            {/*<View style={{marginVertical: 22, marginBottom: 40}}>
                                <TwButton onPress={()=>{
                                    const {navigation} = this.props;
                                    navigation.goBack();
                                }} small={true} white={false} title={"Retour"} icon="leftcircleo" style={{minWidth:200}} flip={true}/>
                            </View>*/}
                        </View>
                    </SafeAreaView>




                </ScrollView>


            </View>

        );
    }

}

const styles = StyleSheet.create({

    about_body : {
        alignItems: 'center',
    },
    about_text : {
        fontSize: 17,
        padding: 22,
        paddingBottom: 10,
        paddingTop: 10,
    },
    about_url : {
        fontSize: 14,
        padding: 22,
        textAlign: 'center',
        color: '#000',
    },
    about_shape : {
        height:30,
        width: 160,
        flexDirection: 'row',
    },
    about_title : {
        textAlign: 'center',
        fontWeight: 'bold',
        fontSize: 30,
    },
    about_subtitle : {
        textAlign: 'center',
        fontSize: 16,
    },
    about_header : {

        alignItems: 'center',
        justifyContent: 'center',

    },
    about_header_logo : {
        width: 300,
        height: 300,
        maxWidth: ofWidth(25),
        maxHeight: ofWidth(25),
        position: 'relative',
    },
    logo : {
        width: "100%",
        height: "100%",
        borderRadius: 8,
    },
    logo_sh : {
        width: "120%",
        height: "120%",
        position: 'absolute',
        left : '-10%',
        top : '-10%',
        backgroundColor: 'rgba(0,0,0,0.59)',
        borderRadius: 8,
    },

    set_row: {
        paddingHorizontal: 8,
        paddingVertical: 12,
        margin: 12,
        marginBottom: 18,
        alignItems: 'center',
        borderWidth: 1,
        borderColor: '#ccc',

    },
    set_row_q: {
        paddingHorizontal: 8,
        paddingVertical: 12,
        margin: 12,
        marginBottom: 18,
        alignItems: 'center',

    },
    set_title: {
        color : '#000',
        padding: 8,
        textAlign: 'center',
        marginBottom: 18,
    },

    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    box: {
        backgroundColor: '#61dafb',
        width: 80,
        height: 80,
        borderRadius: 4,
    },

    lsels : {
        flexDirection: 'row',
        //flex: 2,
        //backgroundColor: 'rgba(3,178,255,0.25)',
    },
    lsel : {
        paddingHorizontal: 12,
        paddingVertical: 4,
        margin: 8,
        alignItems: 'center',
        borderRadius: 8,
        flex: 1,
        maxWidth: 280,

    },
    lsel_a : {
        backgroundColor: 'rgba(3,178,255,0.25)',
    },
    lsel_ai : {
        opacity: 1,
        color: '#03b2ff',
    },
    lsel_icon : {
        opacity: .2,
        marginBottom: 12,
    },
    lsel_image : {
        width: 60,
        height: 100,
        resizeMode: 'contain',
    },
    lsel_text : {
        paddingTop: 6,
        color : '#343434'
        //backgroundColor: '#ccc',
    },
    lsel_details : {
        //flexDirection: 'row',
        alignItems: 'center',
        padding: 8,
        marginVertical: 12,
    },
    row_sel: {
        flexDirection: 'row',
        borderColor : '#4b4b4b',
        borderWidth: 2,
        borderRadius : 8,
        height: 42,
        width: 320,
        marginVertical: 12,
    },
    row_sel_a: {
        borderColor: '#03b2ff',
        backgroundColor: "rgba(3,178,255,0.09)",
        //color : "#fff",
    },
    row_sel_icon: {
        height: 40,
        width: 64,
        alignItems: 'center',
        justifyContent: 'center',
    },
    row_sel_detail: {
        //height : 46,
        flex: 1,
        height: "100%",
        justifyContent : 'center',
        alignItems : 'center',
        //backgroundColor: '#ccc',
    },
    row_sel_text: {
        width: "100%",
        paddingHorizontal: 12,
    },
});

const mapDispatchToProps = dispatch => (
    bindActionCreators({
        updateData: updateData,
    }, dispatch)
);

const mapStateToProps = (state) => {
    const { data } = state;
    return { data }
};

export default connect(mapStateToProps, mapDispatchToProps)(aboutScreen);
