import AsyncStorage from '@react-native-async-storage/async-storage';

function setStorage(key, value){
    return new Promise(((resolve, reject) => {
        try {

            if(typeof value === 'object'){
                value = JSON.stringify(value);
            }

            AsyncStorage.setItem(key, value);
            resolve(true);
        } catch(e) {
            reject(false);
        }

    }));
}

function getStorage(key, def){
    return new Promise(((resolve, reject) => {
        try {
            AsyncStorage.getItem(key).then((value)=>{
                try {
                    let value = JSON.parse(value);
                }catch(e){

                }

                resolve(value === null ? def : value);

            });


        } catch(e) {
            resolve(def);
        }

    }));
}

function getStorages(keys){

    return new Promise(((resolve, reject) => {
        try {
            let list = [];
            keys.map((key)=>{
                list.push(AsyncStorage.getItem(key))
            });

            let values = [];
            Promise.all(list)
                .then(vals => {


                    vals.map((val, i)=>{

                        try {
                            values.push(JSON.parse(val));
                        }catch(e){
                            values.push(val);
                        }
                    });

                    resolve(values);

                });



        } catch(e) {
            resolve(null);
        }

    }));
}


const storage = {setStorage, getStorage, getStorages};


export default storage;
