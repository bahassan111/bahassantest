import I18n from "ex-react-native-i18n";
import fr from "./locales/fr.json";
import ar from "./locales/ar.json";

I18n.locale = "fr";
I18n.fallbacks = true;
I18n.translations = { fr, ar };
export default I18n;
