class DriverEwalletModel {
  String rideid;
  String booktype;
  String carcategory;
  double driverfees;
  String fullname;
  String bookType;
  String categoryCode;
  double adminfees;
  double tolltaxamount;
  DriverEwalletModel(
      {this.rideid,
      this.booktype,
      this.carcategory,
      this.bookType,
      this.driverfees,
      this.categoryCode,
      this.adminfees,
      this.tolltaxamount,
      this.fullname});

  DriverEwalletModel.fromJson(Map<String, dynamic> json) {
    rideid = json['rideid'];
    booktype = json['booktype'];
    carcategory = json['carcategory'];
    driverfees = double.tryParse(json['driverfees'].toString());
    fullname = json['fullname'];
    bookType = json['booktype'];
    categoryCode = json['category_code'];
    adminfees = double.tryParse(json['adminfees'].toString());
    tolltaxamount = double.tryParse(json['tolltaxamount'].toString());
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['rideid'] = this.rideid;
    data['booktype'] = this.booktype;
    data['carcategory'] = this.carcategory;
    data['driverfees'] = this.driverfees;
    data['fullname'] = this.fullname;
    data['booktype'] = this.bookType;
    data['category_code'] = this.categoryCode;
    return data;
  }
}
