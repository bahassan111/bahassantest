import React, { Component } from "react";
import { StyleSheet, TouchableOpacity, Image, Text } from "react-native";
import Config from "../constants/Config";

const styles = StyleSheet.create({
  image_countries: {
    width: 20,
    height: 20,
    borderRadius: 20,
  },
  Card_Container: {
    backgroundColor: "#fff",
    padding: 15,
    margin: 1.4,
    borderRadius: 4,
    width: 110,
    height: 110,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 15,
    marginRight: 2,
    elevation: 4,
  },
});
class CountryItem extends Component {
  render() {
    const { onPress, borderColor, borderWidth, data } = this.props;
    return (
      <TouchableOpacity
        style={[
          styles.Card_Container,
          {
            borderColor: borderColor,
            borderWidth: borderWidth,
          },
        ]}
        onPress={onPress}
        key={data.id}
      >
        <Image
          style={styles.image_countries}
          source={{
            uri: Config.IMAGE + "images/flags/" + data.iso + ".png",
          }}
        />

        <Text style={styles.title}> {data.name}</Text>
      </TouchableOpacity>
    );
  }
}

export default CountryItem;
