import 'package:flutter/material.dart';
import 'package:flutter_dash/flutter_dash.dart';
import 'package:rider_app/constants/app_themes.dart';
import 'package:get/get.dart';
import 'package:rider_app/constants/utils.dart';
import 'package:rider_app/controllers/controllers.dart';

class CureentTripPickUpDrop extends StatelessWidget {
  static TripAcceptController to = Get.find();

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(
              child: Text(
                "tripFare".tr +
                    ": ${to?.ride?.currency} ${numberFormating.format(double.parse(to?.ride?.totalfare ?? "0.0"))}",
                style: Theme.of(context).textTheme.headline2.copyWith(
                    fontSize: 20, fontWeight: FontWeight.w700, height: 1.2),
              ),
            ),
          ),
          Divider(
            thickness: 0,
            height: 2,
            color: AppThemes.lightpauaBackGroundColor,
          ),
          Container(
            padding: EdgeInsets.only(left: 20, top: 5, right: 20),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    SizedBox(height: 8),
                    Container(
                      height: 10,
                      width: 10,
                      decoration: BoxDecoration(
                        color: AppThemes.lightPinkBackGroundColor,
                        shape: BoxShape.circle,
                      ),
                    ),
                    SizedBox(height: 8),
                    Dash(
                      direction: Axis.vertical,
                      length: 30,
                      dashLength: 5,
                      dashGap: 6,
                      dashColor: AppThemes.lightCircularDividerColor,
                      dashBorderRadius: 4,
                      dashThickness: 5,
                    ),
                    SizedBox(height: 8),
                    Container(
                      height: 10,
                      width: 10,
                      decoration: BoxDecoration(
                        color: AppThemes.lightGreenbackGroundColor,
                        shape: BoxShape.circle,
                      ),
                    )
                  ],
                ),
                SizedBox(
                  width: 20,
                ),
                Expanded(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "pickupFrom".tr,
                        style: Theme.of(context).textTheme.subtitle2.copyWith(
                            fontSize: 13, fontWeight: FontWeight.w500),
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              to?.ride?.pickupaddress ?? "",
                              style: Theme.of(context)
                                  .textTheme
                                  .headline2
                                  .copyWith(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w700,
                                    height: 1.2,
                                  ),
                              maxLines: 1,
                              overflow: TextOverflow.clip,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: Divider(
                              thickness: 2,
                              height: 2,
                              color: AppThemes.lightpauaBackGroundColor,
                            ),
                          ),
                        ],
                      ),
                      IntrinsicHeight(
                        child: Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  SizedBox(height: 10),
                                  Text(
                                    "dropAt".tr,
                                    style: Theme.of(context)
                                        .textTheme
                                        .subtitle2
                                        .copyWith(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w500),
                                  ),
                                  Text(
                                    to?.ride?.dropaddress ?? "",
                                    style: Theme.of(context)
                                        .textTheme
                                        .headline2
                                        .copyWith(
                                          fontSize: 18,
                                          fontWeight: FontWeight.w700,
                                          height: 1.2,
                                        ),
                                    overflow: TextOverflow.clip,
                                    maxLines: 1,
                                    softWrap: true,
                                  ),
                                  SizedBox(height: 15),
                                ],
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
