import React, { Component } from "react";
import {
  FlatList,
  ScrollView,
  ActivityIndicator,
  RefreshControl, AsyncStorage
} from "react-native";
import { AnimatableManager, View, Button } from "react-native-ui-lib"; //eslint-disable-line
import Banners from "../components/Banners";
import Items from "./Items";

import I18n from "../commons/i18n";
import _ from "lodash";

import Text from "../components/CustomText";
import {
  fetchFontSize,
  changeLanguage
} from "../Redux/actions/FontSizeActions";

import { fetchArticleDetails } from "../Redux/actions/ChapitresActions";
import { fetchBanners } from "../Redux/actions/BannersActions";

import { connect } from "react-redux";
import Icon from "../constants/Icons";
import Colors from "../constants/Colors";
import Config from "../constants/Config";

class HomeScreen extends Component {



  static navigationOptions = ({ navigation }) => ({


    headerRight: (
      <Button
        size="small"
        label={navigation.getParam("lang")}
        avoidMinWidth
        avoidInnerPadding
        bg-green20
        marginH-10
        style={{
          paddingHorizontal: 5,
          fontSize: 10,
          fontFamily: "ge-thameen-book"
        }}
        onPress={navigation.getParam("changeLanguage")}
      />
    ),
  });

  state = {
    loading: false,
    data: [],
    page: 1,
    seed: 1,
    error: null,
    refreshing: false,
    see_more:'',
    rtl:"0",

  };
  arrayholder = [];

  async componentDidMount() {

    let id_country= await AsyncStorage.getItem('id_country');
    let lang=await AsyncStorage.getItem('lang');
    let see_more=await AsyncStorage.getItem('see_more');
    let rtl=await AsyncStorage.getItem('rtl');
    let count_languages=await AsyncStorage.getItem('count_languages');
    await  this.setState({see_more:see_more,rtl:rtl});

    this.props.fetchFontSize();
    this.props.fetchBanners(id_country);
    this.props.navigation.setParams({
          changeLanguage: this._changeLanguage,
          lang: count_languages > 1 ? lang : ''
      });
  }

  async componentDidUpdate(prevProps, prevState) {

    if (prevProps.lang !== this.props.lang) {
      this.fetchData();
      this.props.navigation.setParams({
        changeLanguage: this._changeLanguage,
        lang: I18n.t("Commons.lang", { locale: this.props.lang })
      });
    }
    if (prevProps.keyword !== this.props.keyword) {
      this.getData();
    }
    if (prevProps.data !== this.props.data) {
      this.getData();
    }
  }

 async fetchData() {
      let id_country=await AsyncStorage.getItem('id_country');
      let lang_index=await AsyncStorage.getItem('lang_index');
      this.props.fetchArticleDetails(id_country,lang_index);
  }

  _changeLanguage = async () => {




    let id_country=await AsyncStorage.getItem('id_country');
    let lang_index=await AsyncStorage.getItem('lang_index');
    let rtl=await AsyncStorage.getItem('rtl');
    let lang=await AsyncStorage.getItem('lang');
    let lang_index2=await AsyncStorage.getItem('lang_index2');
    let rtl2=await AsyncStorage.getItem('rtl2');
    let lang2=await AsyncStorage.getItem('lang2');
    let lang_header='';
    this.props.changeLanguage();
    this.setState({ data: null });

      this.changeFields(id_country,lang_index2);

      await AsyncStorage.setItem("lang_index", lang_index2);
      await AsyncStorage.setItem("rtl", rtl2);
      await AsyncStorage.setItem("lang", lang2);
      await AsyncStorage.setItem("lang_index2", lang_index);
      await AsyncStorage.setItem("rtl2", rtl);
      await AsyncStorage.setItem("lang2", lang);
      lang_header=lang2;

    this.props.navigation.setParams({
      changeLanguage: this._changeLanguage,
      lang: lang_header
    });
      await this.setState({rtl:rtl2});

      this.props.fetchArticleDetails(id_country,lang_index2);

  };



     changeFields(id_country,lang_index){

        fetch(
            "http://ifes-esll.com/new/api/includes/encode/index.php",{
                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    post: 'change_lang',
                    id_country: id_country,
                    lang_index: lang_index,
                }),
            }
        )
            .then(res => res.json())
            .then(responseJson => {

                console.log('data fields');
                console.log(responseJson);
                AsyncStorage.setItem("fields", JSON.stringify(responseJson.fields));
                AsyncStorage.setItem("see_more", responseJson.see_more);
                AsyncStorage.setItem("search", responseJson.search);
                AsyncStorage.setItem("see_less", responseJson.see_less);
                AsyncStorage.setItem("homeScreen", responseJson.homeScreen);
                AsyncStorage.setItem("settingScreen", responseJson.settingScreen);
                AsyncStorage.setItem("countries", responseJson.countries);
                AsyncStorage.setItem("change_country", responseJson.change_country);

                this.setState({see_more:responseJson.see_more});
                this.props.navigation.state.params.refresh();
            })
            .catch(error => {
                console.log("error", error);
            });
    }


    _onRefresh = () => {
    this.props.fetchArticleDetails(this.props.lang);
  };

  keyExtractor = item => item.titre;

  renderRow(row, id,see_more,rtl) {

    const animationProps = AnimatableManager.presets.fadeInRight;
    const imageAnimationProps = AnimatableManager.getRandomDelay();
    const imageChapitre = Config.CHAPITRE_IMAGE + row.image;

    return (
      <Items
        row={row}
        key={id}
        animationProps={animationProps}
        imageAnimationProps={imageAnimationProps}
        imageChapitre={imageChapitre}
        lang={this.props.lang}
        see_more={see_more}
        rtl={rtl}
        onPress={() =>
          this.props.navigation.navigate("SousChapitre", {
            row: row
          })
        }
      />
    );
  }

  renderFooter = () => {
    if (this.props.isLoadingData == false && !this.state.data) {
      return (
        <View flex center>
          <ActivityIndicator
            animating={this.props.isLoadingData}
            size={"large"}
          />
        </View>
      );
    } else {
      return null;
    }
  };
  navigationScreen(chapitre) {
    this.props.navigation.navigate("TestScreen", { chapitre });
  }

  getData() {
    const { keyword, data } = this.props;
    var dataSearch = [];
    var filter = null;
    if (keyword.length > 0) {
      filter = _.find(data, function(o) {
        var test = o.titre.toLowerCase().includes(keyword);
        return test;
      });
    }

    if (filter != undefined) {
      dataSearch.push(filter);
      this.setState({
        data: dataSearch
      });
    } else {
      if (keyword.length > 0) {
        this.setState({
          data: []
        });
      } else {
        this.setState({
          data: data
        });
      }
    }
  }

    render() {

        let see_more=this.state.see_more;
        let rtl=this.state.rtl;

        return (
            <View>
                <ScrollView
                    refreshControl={
                        <RefreshControl
                            refreshing={this.props.isLoadingData}
                            onRefresh={this._onRefresh}
                        />
                    }
                >
                    <Banners banners={this.props.banners} />
                    <FlatList
                        ref={flatlist => {
                            this.flatlist = flatlist;
                        }}
                        data={this.state.data}
                        renderItem={({ item, index }) => this.renderRow(item, index,see_more,rtl)}
                        keyExtractor={this.keyExtractor}
                        ListFooterComponent={this.renderFooter}
                    />
                    {this.props.isLoadingData == false &&
                    this.props.keyword != "" &&
                    this.state.data.length == 0 && (
                        <View flex column center padding-20>
                            <Icon name="ion-alert" iconSize={40} color={Colors.tabBar} />
                            <Text text60>
                                {I18n.t("Commons.empty_search", { locale: this.props.lang })} {this.props.key}
                            </Text>

                        </View>
                    )}
                </ScrollView>
            </View>
        );
    }
}



const mapStateToProps = state => {
  const fontSizeValue = state.fontSize.fontSize;
  const lang = state.fontSize.lang;
  const data = state.chapitres.data;
  const keyword = state.chapitres.keyword || "";
  const isLoadingData = state.chapitres.isLoadingData;

  const banners = state.banners;

  return {
    fontSizeValue,
    lang,
    isLoadingData,
    data,
    banners,
    keyword
  };
};

export default connect(
  mapStateToProps,
  {
    fetchFontSize,
    changeLanguage,
    fetchBanners,
    fetchArticleDetails
  }
)(HomeScreen);
