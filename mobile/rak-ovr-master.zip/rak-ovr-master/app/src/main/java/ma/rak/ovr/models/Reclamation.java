package ma.rak.ovr.models;

import io.realm.RealmList;
import io.realm.RealmObject;

public class Reclamation extends RealmObject {

    private String CATEGORIE;
    private String CODEGERA;
    private String LIBEGERA;
    private String CODEAGEN;
    private String CODELOCA;
    private String CODESECT;
    private String LIBEAGEN;
    private String DESNATRE;
    private String CODNATRE;
    private String PRIODOSS;
    private String NUMDOSRE;
    private String DESCRECL;
    private String DATCREDO;
    private String NOMPRECL;
    private String TELERECL;
    private String CIN_CLIE;
    private String ADRECLIE;
    private String ADRERECL;
    private String USERSAIS;
    private String NUMEDOSS;
    private String ANNEDOSS;
    private String NUMOPRAB;
    private String REFECOMP;
    private String CODSTRDE;
    private String CODEMERE;
    private String LIBEEMET;
    private String CODCATRE;
    private String CODENTTR;
    private String USERAFF;
    private String LONGITUDE;
    private String LATITUDE;
    private String DATE_OPERATION;
    private String OBJECT_VERIF;
    private String STATUS;

    public Reclamation() {
    }

    public Reclamation(String CATEGORIE, String CODEGERA, String LIBEGERA, String CODEAGEN, String CODELOCA, String CODESECT, String LIBEAGEN, String DESNATRE, String CODNATRE, String PRIODOSS, String NUMDOSRE, String DESCRECL, String DATCREDO, String NOMPRECL, String TELERECL, String CIN_CLIE, String ADRECLIE, String ADRERECL, String USERSAIS, String NUMEDOSS, String ANNEDOSS, String NUMOPRAB, String REFECOMP, String CODSTRDE, String CODEMERE, String LIBEEMET, String CODCATRE, String CODENTTR, String USERAFF, String LONGITUDE, String LATITUDE, String DATE_OPERATION, String OBJECT_VERIF, String STATUS) {
        this.CATEGORIE = CATEGORIE;
        this.CODEGERA = CODEGERA;
        this.LIBEGERA = LIBEGERA;
        this.CODEAGEN = CODEAGEN;
        this.CODELOCA = CODELOCA;
        this.CODESECT = CODESECT;
        this.LIBEAGEN = LIBEAGEN;
        this.DESNATRE = DESNATRE;
        this.CODNATRE = CODNATRE;
        this.PRIODOSS = PRIODOSS;
        this.NUMDOSRE = NUMDOSRE;
        this.DESCRECL = DESCRECL;
        this.DATCREDO = DATCREDO;
        this.NOMPRECL = NOMPRECL;
        this.TELERECL = TELERECL;
        this.CIN_CLIE = CIN_CLIE;
        this.ADRECLIE = ADRECLIE;
        this.ADRERECL = ADRERECL;
        this.USERSAIS = USERSAIS;
        this.NUMEDOSS = NUMEDOSS;
        this.ANNEDOSS = ANNEDOSS;
        this.NUMOPRAB = NUMOPRAB;
        this.REFECOMP = REFECOMP;
        this.CODSTRDE = CODSTRDE;
        this.CODEMERE = CODEMERE;
        this.LIBEEMET = LIBEEMET;
        this.CODCATRE = CODCATRE;
        this.CODENTTR = CODENTTR;
        this.USERAFF = USERAFF;
        this.LONGITUDE = LONGITUDE;
        this.LATITUDE = LATITUDE;
        this.DATE_OPERATION = DATE_OPERATION;
        this.OBJECT_VERIF = OBJECT_VERIF;
        this.STATUS = STATUS;
    }

    public String getCATEGORIE() {
        return CATEGORIE;
    }

    public void setCATEGORIE(String CATEGORIE) {
        this.CATEGORIE = CATEGORIE;
    }

    public String getCODEGERA() {
        return CODEGERA;
    }

    public void setCODEGERA(String CODEGERA) {
        this.CODEGERA = CODEGERA;
    }

    public String getLIBEGERA() {
        return LIBEGERA;
    }

    public void setLIBEGERA(String LIBEGERA) {
        this.LIBEGERA = LIBEGERA;
    }

    public String getCODEAGEN() {
        return CODEAGEN;
    }

    public void setCODEAGEN(String CODEAGEN) {
        this.CODEAGEN = CODEAGEN;
    }

    public String getCODELOCA() {
        return CODELOCA;
    }

    public void setCODELOCA(String CODELOCA) {
        this.CODELOCA = CODELOCA;
    }

    public String getCODESECT() {
        return CODESECT;
    }

    public void setCODESECT(String CODESECT) {
        this.CODESECT = CODESECT;
    }

    public String getLIBEAGEN() {
        return LIBEAGEN;
    }

    public void setLIBEAGEN(String LIBEAGEN) {
        this.LIBEAGEN = LIBEAGEN;
    }

    public String getDESNATRE() {
        return DESNATRE;
    }

    public void setDESNATRE(String DESNATRE) {
        this.DESNATRE = DESNATRE;
    }

    public String getCODNATRE() {
        return CODNATRE;
    }

    public void setCODNATRE(String CODNATRE) {
        this.CODNATRE = CODNATRE;
    }

    public String getPRIODOSS() {
        return PRIODOSS;
    }

    public void setPRIODOSS(String PRIODOSS) {
        this.PRIODOSS = PRIODOSS;
    }

    public String getNUMDOSRE() {
        return NUMDOSRE;
    }

    public void setNUMDOSRE(String NUMDOSRE) {
        this.NUMDOSRE = NUMDOSRE;
    }

    public String getDESCRECL() {
        return DESCRECL;
    }

    public void setDESCRECL(String DESCRECL) {
        this.DESCRECL = DESCRECL;
    }

    public String getDATCREDO() {
        return DATCREDO;
    }

    public void setDATCREDO(String DATCREDO) {
        this.DATCREDO = DATCREDO;
    }

    public String getNOMPRECL() {
        return NOMPRECL;
    }

    public void setNOMPRECL(String NOMPRECL) {
        this.NOMPRECL = NOMPRECL;
    }

    public String getTELERECL() {
        return TELERECL;
    }

    public void setTELERECL(String TELERECL) {
        this.TELERECL = TELERECL;
    }

    public String getCIN_CLIE() {
        return CIN_CLIE;
    }

    public void setCIN_CLIE(String CIN_CLIE) {
        this.CIN_CLIE = CIN_CLIE;
    }

    public String getADRECLIE() {
        return ADRECLIE;
    }

    public void setADRECLIE(String ADRECLIE) {
        this.ADRECLIE = ADRECLIE;
    }

    public String getADRERECL() {
        return ADRERECL;
    }

    public void setADRERECL(String ADRERECL) {
        this.ADRERECL = ADRERECL;
    }

    public String getUSERSAIS() {
        return USERSAIS;
    }

    public void setUSERSAIS(String USERSAIS) {
        this.USERSAIS = USERSAIS;
    }

    public String getNUMEDOSS() {
        return NUMEDOSS;
    }

    public void setNUMEDOSS(String NUMEDOSS) {
        this.NUMEDOSS = NUMEDOSS;
    }

    public String getANNEDOSS() {
        return ANNEDOSS;
    }

    public void setANNEDOSS(String ANNEDOSS) {
        this.ANNEDOSS = ANNEDOSS;
    }

    public String getNUMOPRAB() {
        return NUMOPRAB;
    }

    public void setNUMOPRAB(String NUMOPRAB) {
        this.NUMOPRAB = NUMOPRAB;
    }

    public String getREFECOMP() {
        return REFECOMP;
    }

    public void setREFECOMP(String REFECOMP) {
        this.REFECOMP = REFECOMP;
    }

    public String getCODSTRDE() {
        return CODSTRDE;
    }

    public void setCODSTRDE(String CODSTRDE) {
        this.CODSTRDE = CODSTRDE;
    }

    public String getCODEMERE() {
        return CODEMERE;
    }

    public void setCODEMERE(String CODEMERE) {
        this.CODEMERE = CODEMERE;
    }

    public String getLIBEEMET() {
        return LIBEEMET;
    }

    public void setLIBEEMET(String LIBEEMET) {
        this.LIBEEMET = LIBEEMET;
    }

    public String getCODCATRE() {
        return CODCATRE;
    }

    public void setCODCATRE(String CODCATRE) {
        this.CODCATRE = CODCATRE;
    }

    public String getCODENTTR() {
        return CODENTTR;
    }

    public void setCODENTTR(String CODENTTR) {
        this.CODENTTR = CODENTTR;
    }

    public String getUSERAFF() {
        return USERAFF;
    }

    public void setUSERAFF(String USERAFF) {
        this.USERAFF = USERAFF;
    }

    public String getDATE_OPERATION() {
        return DATE_OPERATION;
    }

    public void setDATE_OPERATION(String DATE_OPERATION) {
        this.DATE_OPERATION = DATE_OPERATION;
    }

    public String getOBJECT_VERIF() {
        return OBJECT_VERIF;
    }

    public void setOBJECT_VERIF(String OBJECT_VERIF) {
        this.OBJECT_VERIF = OBJECT_VERIF;
    }

    public String getSTATUS() {
        return STATUS;
    }

    public void setSTATUS(String STATUS) {
        this.STATUS = STATUS;
    }

    public String getLONGITUDE() {
        return LONGITUDE;
    }

    public void setLONGITUDE(String LONGITUDE) {
        this.LONGITUDE = LONGITUDE;
    }

    public String getLATITUDE() {
        return LATITUDE;
    }

    public void setLATITUDE(String LATITUDE) {
        this.LATITUDE = LATITUDE;
    }

    @Override
    public String toString() {
        return "Reclamation{" +
                "CATEGORIE='" + CATEGORIE + '\'' +
                ", CODEGERA='" + CODEGERA + '\'' +
                ", LIBEGERA='" + LIBEGERA + '\'' +
                ", CODEAGEN='" + CODEAGEN + '\'' +
                ", CODELOCA='" + CODELOCA + '\'' +
                ", CODESECT='" + CODESECT + '\'' +
                ", LIBEAGEN='" + LIBEAGEN + '\'' +
                ", DESNATRE='" + DESNATRE + '\'' +
                ", CODNATRE='" + CODNATRE + '\'' +
                ", PRIODOSS='" + PRIODOSS + '\'' +
                ", NUMDOSRE='" + NUMDOSRE + '\'' +
                ", DESCRECL='" + DESCRECL + '\'' +
                ", DATCREDO='" + DATCREDO + '\'' +
                ", NOMPRECL='" + NOMPRECL + '\'' +
                ", TELERECL='" + TELERECL + '\'' +
                ", CIN_CLIE='" + CIN_CLIE + '\'' +
                ", ADRECLIE='" + ADRECLIE + '\'' +
                ", ADRERECL='" + ADRERECL + '\'' +
                ", USERSAIS='" + USERSAIS + '\'' +
                ", NUMEDOSS='" + NUMEDOSS + '\'' +
                ", ANNEDOSS='" + ANNEDOSS + '\'' +
                ", NUMOPRAB='" + NUMOPRAB + '\'' +
                ", REFECOMP='" + REFECOMP + '\'' +
                ", CODSTRDE='" + CODSTRDE + '\'' +
                ", CODEMERE='" + CODEMERE + '\'' +
                ", LIBEEMET='" + LIBEEMET + '\'' +
                ", CODCATRE='" + CODCATRE + '\'' +
                ", CODENTTR='" + CODENTTR + '\'' +
                ", USERAFF='" + USERAFF + '\'' +
                ", LONGITUDE='" + LONGITUDE + '\'' +
                ", LATITUDE='" + LATITUDE + '\'' +
                ", DATE_OPERATION='" + DATE_OPERATION + '\'' +
                ", OBJECT_VERIF='" + OBJECT_VERIF + '\'' +
                ", STATUS='" + STATUS + '\'' +
                '}';
    }
}
