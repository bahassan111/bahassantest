import {
  PENDING_FETCH_GALLERIES,
  SET_ARTICLE_GALLERIES,
  SUCCESS_FETCH_GALLERIES,
} from "../actions/types";

export default function (
  state = { isLoadingData: false, isDoSearch: false, data: [], keyword: null },
  action
) {
  switch (action.type) {
    case PENDING_FETCH_GALLERIES:
      return {
        ...state,
        isLoadingData: true,
      };
    case SET_ARTICLE_GALLERIES:
      return { ...state, data: action.payload };

    case SUCCESS_FETCH_GALLERIES:
      return {
        ...state,
        isLoadingData: false,
      };
    default:
      return state;
  }
}
