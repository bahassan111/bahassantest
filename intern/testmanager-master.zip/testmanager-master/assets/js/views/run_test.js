(function () {
    var view = $('#run_test_view');
    if (!view.length) return;

    var keepRuning = false;

    $(view)
        .on('click', '[data-statid]', function () {
            var on = $(this).hasClass('selected');

            var that = $(this),
                id_status = that.data('statid'),
                id_runcase = that.closest('[data-runcaseid]').data('runcaseid'),
                id_step    = that.closest('[data-stepid]').data('stepid');

            if(id_status && id_runcase && id_step){

                setLoading(true, 'Saving ..');

                post('project/update_run_step', {
                    id_step : id_step,
                    id_runcase : id_runcase,
                    id_status : on ? id_status : 4,
                }, function (rep) {

                    if(rep.status === 'OK'){

                        updateStepWStatus(`[data-stepid="${id_step}"]`);
                        updateCaseStatus(`[data-runcaseid="${id_runcase}"]`);


                    }else{
                        toastr_('Unable to update the selected step', 'error', 'danger', 9000);
                    }


                }, function () {
                    setLoading(false);
                }, function () {
                    toastr_('Unable to update the selected step', 'error', 'danger', 9000);
                })
            }
        })
        .on('click', '.rtest_case > .h .r', function () {
            var rcase = $(this).closest('.rtest_case');
            var open = rcase.toggleClass('open').hasClass('open');

            if(open){
                rcase.find('> .b').hide().slideDown(200);
            }else{
                rcase.find('> .b').show().slideUp(200);
            }

        })
        .on('click', '[data-autocase]', function () {
            runAutoTest(this.dataset.autocase);
        })
        .on('click', '[data-rautocase]', function () {
            var rcase = $(this).closest('[data-runcaseid]');

            keepRuning = true;
            runAll(rcase.data('runcaseid'));

        })


        .ready(function () {
            getStats();
        })
    ;

    function updateStepWStatus(step) {
        step = $(step);

        step.removeClass('step_wstatus_1 step_wstatus_2 step_wstatus_3 step_wstatus_4');

        step.addClass('step_wstatus_' + step.find('[data-statid].selected').data('statid'))
    }

    function updateCaseStatus(runcase) {
        runcase = $(runcase);
        var id = runcase.data('runcaseid');

        if(id){
            post('project/get_runcase_status/' + id, {}, function (rep) {
                if(rep.data){

                    runcase.find('> .h .s').last().html(`<span style="color: ${rep.data.color2}; background-color: ${rep.data.color}" class="run_status"><i class="${rep.data.icon}"></i> ${rep.data.name}</span>`);

                }
            })
        }
    }

    function runAutoTest(id_rc, then) {
        var tcase = $(`[data-runcaseid="${id_rc}"]`),
            holder = tcase.find('.rtestr_inner').last().find('.rtestr_inner_list'),
            notif = tcase.find('.rlast_run')
            ;

        then = then || function(){};


        notif.html('Running ..').tooltip('dispose');

        holder.html('Running ..');

        tcase.find('[data-autocase]').prop('disabled', true);

        setLoading(true, "Running Test Case ..");

        post('project/run_testcase/', {id : id_rc}, function (rep) {



            holder.html('');
            $.each(rep.asserts || [], function (i, assert) {

                holder.append(`
                
                <div><small>Condition ${i+1}</small></div>
                <div><span>Result</span><b>${assert.result}</b></div>
                
                `);


            });

            holder.append(`
                
                <div><small>Overview</small></div>
                <div><span>Runtime</span><b>${rep.runtime}</b></div>
                <div><span>Result ALL</span><b>${rep.result}</b></div>
                
                `);

            if(keepRuning) return;
            if(rep.result.toUpperCase() === 'PASSED'){
                toastr_('Test Case PASSED!', 'success', 'success');
            }else if(rep.result.toUpperCase() === 'FAILED'){
                toastr_('Test Case FAILED!', 'error', 'danger');
            }else{
                toastr_('Test Case Was Not Applicable!', 'error', 'danger');
            }

        }, function () {
            setLoading(false);
            notif.html('Just now!');
            tcase.find('[data-autocase]').prop('disabled', false);
            updateCaseStatus(tcase);
            getStats();
            then();
        }, function () {

            holder.html('');
            toastr_('Failed to run the Test case', 'error', 'danger');

        })
    }

    function getStats(first) {
        var holder = $('#autotrun_stats');

        post('project/get_run_stats/' + run_id, {}, function (rep) {
            holder.html(rep);
        }, function () {
            holder.removeClass('loading');
        })
    }

    function runAll(startFrom) {
        if(!keepRuning) return;
        startFrom = startFrom || $('[data-runcaseid]').first().data('runcaseid');

        var rcase = $(`[data-runcaseid="${startFrom}"]`);
        var rnext = rcase.next();

        if(rcase.length){
            runAutoTest(rcase.data('runcaseid'), function () {

                if(rnext.length){
                    runAll(rnext.data('runcaseid'));
                }else{
                    keepRuning = false;
                    toastr_('The Test Run execution was finished successfully', 'success', 'success', 90000);
                }


            });
        }


    }


})();