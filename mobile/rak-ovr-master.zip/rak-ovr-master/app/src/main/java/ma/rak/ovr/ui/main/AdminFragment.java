package ma.rak.ovr.ui.main;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.util.ArrayList;

import ma.rak.ovr.LoginActivity;
import ma.rak.ovr.R;
import ma.rak.ovr.api.RetrofitClient;
import ma.rak.ovr.api.TwDatabase;
import ma.rak.ovr.bodyResponse.RootResponse;
import ma.rak.ovr.storage.RealmBackupRestore;
import ma.rak.ovr.storage.SharedPrefManager;
import ma.rak.ovr.utils.NetworkUtility;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdminFragment extends AppCompatActivity {

    private Button export, sync, delete, saveButton, cancelButton;
    private EditText endpoint;
    private TextView last_sync, non_sync, db_size, db_count, devid;
    ArrayList<File> databases_files;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_admin);

        RealmBackupRestore realmBackupRestore = new RealmBackupRestore(this);


        devid = findViewById(R.id.devid);
        export = findViewById(R.id.export);
        delete = findViewById(R.id.delete);
        endpoint = findViewById(R.id.endpoint);
        saveButton = findViewById(R.id.save_button);
        cancelButton = findViewById(R.id.cancel_button);

        endpoint.setText(RetrofitClient.getBaseUrl());

        last_sync = findViewById(R.id.last_sync);
        non_sync = findViewById(R.id.non_sync);
        db_size = findViewById(R.id.db_size);
        db_count = findViewById(R.id.db_count);


        init();

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminFragment.this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

                startActivity(intent);
            }
        });

        //endpoint.setText(SharedPrefManager.getInstance(this).getBaseUrl());

        export.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                try {

                    String dstPath = Environment.getExternalStorageDirectory() + File.separator + "OV_BACKUPS" + File.separator;
                    File dst = new File(dstPath);

                    File res = null;

                    for(File db:databases_files){
                        res = res!=null? res: exportFile(db, dst);
                    }


                   if(res != null){
                       try {
                           Uri selectedUri = Uri.parse(res.getParent());
                           Intent intent = new Intent(Intent.ACTION_VIEW);
                           intent.setDataAndType(selectedUri, "resource/folder");
                           startActivity(intent);
                       }catch(Exception e){
                           Toast.makeText(getApplicationContext(), "Dossier : " + res.getParent(), Toast.LENGTH_LONG);
                       }
                   }

                    Toast.makeText(getApplicationContext(), "Export terminé!", Toast.LENGTH_LONG);


                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), e.getMessage().toString(), Toast.LENGTH_LONG).show();
                }
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String msg = realmBackupRestore.deleteAll();

                MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(AdminFragment.this)
                        .setTitle(getResources().getString(R.string.title))
                        .setNegativeButton(getResources().getString(R.string.cancel), (dialog, which) -> {

                        })
                        .setPositiveButton(getResources().getString(R.string.delete), (dialog, which) -> {

                            delete.setVisibility(View.INVISIBLE);
                            for(File db:databases_files){

                                try {
                                    db.delete();
                                }catch (Exception e){
                                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                                }

                            }

                            Toast.makeText(getApplicationContext(),"Toutes les bases de données ont été supprimées!", Toast.LENGTH_LONG).show();
                            delete.setVisibility(View.VISIBLE);

                        })
                        .setMessage(msg);

                builder.show();
            }
        });


        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String endpointValue = endpoint.getText().toString().trim();
                Log.e("##############", endpoint.getText().toString());
                Log.e("{{{{{{{{{{{{{{{{{{", endpointValue);
                if (endpointValue.isEmpty()) {
                    endpoint.setError("Base url required");
                    endpoint.requestFocus();
                    return;
                }


                MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(AdminFragment.this)
                        .setTitle(getResources().getString(R.string.title))
                        .setNegativeButton(getResources().getString(R.string.cancel), (dialog, which) -> {

                        })
                        .setPositiveButton(getResources().getString(R.string.ok), (dialog, which) -> {

                            try {
                                boolean status = RetrofitClient.testApi(SharedPrefManager.getInstance(AdminFragment.this).getToken(), endpointValue);

                                if (status == true) {
                                    Call<RootResponse> call = RetrofitClient.getApiBaseUrl(SharedPrefManager.getInstance(AdminFragment.this).getToken(), endpointValue).root();

                                    call.enqueue(new Callback<RootResponse>() {
                                        @Override
                                        public void onResponse(Call<RootResponse> call, Response<RootResponse> response) {
                                            if (response.body() != null) {
                                                SharedPrefManager.getInstance(AdminFragment.this).saveBaseUrl(endpoint.getText().toString());
                                                Toast.makeText(AdminFragment.this, "L'URL de base a été mise à jour avec succès \r\r Database connection time: " + response.body().getData().get("db_time"), Toast.LENGTH_LONG).show();

                                                Intent intent = new Intent(AdminFragment.this, LoginActivity.class);
                                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

                                                startActivity(intent);

                                            } else {
                                                Toast.makeText(AdminFragment.this, "URL non valide fournie, aucune réponse valide de l'hôte", Toast.LENGTH_LONG).show();

                                            }

                                        }

                                        @Override
                                        public void onFailure(Call<RootResponse> call, Throwable t) {
                                            Toast.makeText(AdminFragment.this, "URL non valide fournie, aucune réponse valide de l'hôte", Toast.LENGTH_LONG).show();
                                            RetrofitClient.setBaseUrl("");
                                        }
                                    });

                                } else {
                                    Toast.makeText(AdminFragment.this, "URL non valide fournie, aucune réponse valide de l'hôte", Toast.LENGTH_LONG).show();
                                    RetrofitClient.setBaseUrl("");
                                }


                            } catch (IllegalArgumentException e) {
                                RetrofitClient.setBaseUrl("");
                                Toast.makeText(AdminFragment.this, "Veuillez inserer un lien valide", Toast.LENGTH_LONG).show();
                            }


                        })
                        .setMessage("L'URL de base a été modifiée, vous devez se déconnecter ?");
                builder.show();


            }
        });
    }

    private File exportFile(File src, File dst) throws IOException {

        //if folder does not exist
        if (!dst.exists()) {
            if (!dst.mkdir()) {

                String dstPath = getExternalFilesDir(null) + File.separator + "BACKUPS" + File.separator;
                File dd = new File(dstPath);

                if(dd.getPath().equals(dst.getPath())){
                    throw new IOException("Can't creat export folder?");
                }

                return exportFile(src, dd);

            }
        }


        File expFile = new File(dst + File.separator + src.getName());
        FileChannel inChannel = null;
        FileChannel outChannel = null;

        try {
            inChannel = new FileInputStream(src).getChannel();
            outChannel = new FileOutputStream(expFile).getChannel();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        try {
            inChannel.transferTo(0, inChannel.size(), outChannel);
        } finally {
            if (inChannel != null)
                inChannel.close();
            if (outChannel != null)
                outChannel.close();
        }

        return expFile;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 4 && resultCode == Activity.RESULT_OK) {
            Uri uri = data.getData();

            try {
                for(File db: databases_files){
                    OutputStream output = getContentResolver().openOutputStream(uri);


                    byte[] bytes = new byte[(int) db.length()];

                    FileInputStream fis = null;
                    fis = new FileInputStream(db);

                    output.write(fis.read(bytes));
                    output.flush();
                    output.close();
                }
            } catch (IOException e) {
                Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void init(){

        devid.setText(NetworkUtility.getIMEI(this));

        databases_files = new ArrayList<File>();

        TwDatabase.TwDatabaseHelper master_dbh = new TwDatabase.TwDatabaseHelper(this, "admin.db");

        String path = this.getDatabasePath(master_dbh.getDatabaseName()).getParent();

        File fpath = new File(path);

        File[] dbs = fpath.listFiles(new FilenameFilter() {
            @Override
            public boolean accept(File file, String s) {
                return s.endsWith(".db") && (!s.endsWith("_.db"));

            }
        });

        db_count.setText(String.valueOf(dbs.length));

        long sizes = 0;
        int pendings = 0;

        for(File db: dbs){
            databases_files.add(db);
            sizes += db.length();
            TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(this, db.getName());
            pendings += dbh.query(TwDatabase.Pending.TABLE_NAME, null, null, null).size();
        }

        db_size.setText(printableFileSize(sizes));
        non_sync.setText(String.valueOf(pendings) + " Operations");
        last_sync.setText(SharedPrefManager.getInstance(this).getSyncTime());


        if(dbs.length == 0){
            export.setEnabled(false);
            delete.setEnabled(false);
        }

    }


    public String printableFileSize(long sizes) {


        long bytes = sizes;

        long kilobytes = (bytes / 1024);
        long megabytes = (kilobytes / 1024);

        if(megabytes > 0) return String.valueOf(megabytes) + " Mb";
        if(kilobytes > 0) return String.valueOf(kilobytes) + " Kb";

        return String.valueOf(bytes) + " Bytes";

    }
}