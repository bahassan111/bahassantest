import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rider_app/constants/app_themes.dart';
import 'package:rider_app/constants/images.dart';
import 'package:rider_app/controllers/controllers.dart';
import 'package:rider_app/helpers/helpers.dart';
import 'package:rider_app/ui/components/components.dart';

class SetPickUpWindow extends StatefulWidget {
  const SetPickUpWindow({this.setPickUpWindow});
  final Function setPickUpWindow;

  @override
  _SetPickUpWindowState createState() => _SetPickUpWindowState();
}

class _SetPickUpWindowState extends State<SetPickUpWindow> {
  DateTime selectedDate;
  TimeOfDay selectedTime;
  static HomeController to = Get.find();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: AppThemes.lightWhitebackGroundColor,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(10),
            topRight: Radius.circular(10),
          )),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(height: 10),
          Text(
            "scheduleAPre-Booking".tr,
            style: Theme.of(context)
                .textTheme
                .headline2
                .copyWith(fontSize: 16, fontWeight: FontWeight.w700),
          ),
          Divider(
            color: AppThemes.lightpauaBackGroundColor,
            thickness: 1,
          ),
          GestureDetector(
            onTap: () async {
              final date = await selectDate(context);
              if (date != null) {
                setState(() {
                  selectedDate = date;
                });
              }
            },
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Image.asset(
                  AllImages.calender,
                  height: 25,
                ),
                SizedBox(width: 5),
                Text(
                  selectedDate == null
                      ? "selectADate".tr
                      : formateDateToDDMMYYYY(selectedDate),
                  style: Theme.of(context)
                      .textTheme
                      .headline2
                      .copyWith(fontSize: 15, fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ),
          Divider(
            color: AppThemes.lightpauaBackGroundColor,
            thickness: 1,
          ),
          GestureDetector(
            onTap: () async {
              if (selectedDate == null) {
                BotToast.showWidget(
                    toastBuilder: (_) => ErrorDialog(
                          message: "Please select date first",
                          title: "",
                        ));
                return;
              }
              final time =
                  await selectTime(context, selectedDate: selectedDate);
              if (time != null)
                setState(() {
                  selectedTime = time;
                });
            },
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Image.asset(
                  AllImages.clock,
                  height: 25,
                ),
                SizedBox(width: 5),
                Text(
                  selectedTime != null
                      ? timeFormate(selectedTime)
                      : "selectTime".tr,
                  style: Theme.of(context)
                      .textTheme
                      .headline2
                      .copyWith(fontSize: 15, fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ),
          Divider(
            color: AppThemes.lightpauaBackGroundColor,
            thickness: 1,
          ),
          SizedBox(height: 10),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: SquareButton(
              text: "setPickUpWindow".tr.toUpperCase(),
              onTap: selectedDate == null || selectedTime == null
                  ? null
                  : () {
                      if (selectedDate == null) {
                        BotToast.showWidget(
                          toastBuilder: (_) => ErrorDialog(
                            title: "error".tr,
                            message: "errorSelectDate".tr,
                          ),
                        );
                      } else if (selectedTime == null) {
                        BotToast.showWidget(
                          toastBuilder: (_) => ErrorDialog(
                            title: "error".tr,
                            message: "errorSelectTime".tr,
                          ),
                        );
                      } else {
                        to.preBookingDate = selectedDate;
                        to.prebookingTime = selectedTime;
                        widget.setPickUpWindow();
                      }
                    },
            ),
          ),
          SizedBox(height: 15),
        ],
      ),
    );
  }
}
