<?php
defined('BASE') OR die('Direct access is not allowed');

function config(){
    require "config.php";
    return __($config);
}

function site_url($path = ""){
    return config()->site_url . "/" . $path;
}

function get_page_data($page){
    $menu = config()->admin_menu;
    $p = __($menu)->get($page);

    if($p) return __($p);

    foreach ($menu as $item){
        $p = __($item['items'])->get($page);

        if($p) return (object) __($p);
    }

    return null;


}

function current_admin(){
    $s = new Session();
    $id = $s->get('user_id');
    $r = [];

    if($id){
        $db = new Database(config()->db_host, config()->db_user, config()->db_password, config()->db_name, config()->port);
        $q = $db->query("SELECT * FROM admin WHERE id = '$id'");
        if(count($q)) return $q[0];
    }

    return __($r);

}

function load_view($view, $data = [], $full = TRUE){
    $view_path = BASE."/views/$view.php";
    if(!isset($data['page'])) $data['page'] = 'dashboard';

    $id_user=current_admin()->id;

    $sections_actifs = sections_byuser($id_user);

    $data['sections_actifs']=$sections_actifs;


    if(file_exists($view_path)) {

        if(!__($data)->title) $data['title'] = '';

        $data['title'] .= ' - ' .config()->default_title;

        foreach ($data as $var => $val) $$var = $val;

        if($full) include BASE."fragments/header.php";
        include $view_path;
        if($full) include BASE."fragments/footer.php";


    }else{
        include "404.html";
    }


}

function render_view($path)
{
    ob_start();
    include $path;
    $var=ob_get_contents();
    ob_end_clean();
    return $var;
}

function notFound(){
    Header('Location: ?404');
    exit(0);
}

function responseJSON($data){
    header('Content-type:application/json');
    echo json_encode($data);
    exit(0);
}

class arrayHelper{
    protected $array;
    protected $object;

    public $length;

    public function __construct(&$array)
    {
        $this->array = (array) $array;
    }

    public function __get($name)
    {
        switch ($name){
            case 'length' : return count($this->array);

            default :
                if(property_exists($this, $name)) return $this->{$name};
                elseif ($this->has($name)) return $this->get($name);
                else return null;
        }
    }

    public function has($prop){
        return isset($this->array[$prop]);
    }
    public function keys(){
        return array_keys($this->array);
    }
    public function values(){
        return array_values($this->array);
    }
    public function each($func){
        foreach ($this->array as $key => $value){
            $func($key, $value);
        }
        return $this;
    }
    public function set($key, $value){
        $this->array[$key] = $value;
        return $this;
    }
    public function get($key){
        return $this->has($key) ? $this->array[$key] : null;
    }
    public function first(){
        return count($this->array) > 0 ? $this->get(0) : null;
    }

}

function currentLanguage(){
    $s = new Session();

    return $s->get('language') ?: 'french';
}

function abbrLng($lang = FALSE){
    $lang = $lang ?: currentLanguage();

    switch ($lang){
        case 'french': return 'fr';
        case 'arabic': return 'ar';
        case 'english': return 'en';
    }
}

function languageFullName($lang){
    switch ($lang){
        case 'arabic': return 'العربية';
        case 'french': return 'Français';
        case 'english': return 'English';
    }

    return $lang;
}

function changeLanguage($to){
    if(!$to) return false;
    $s = new Session();
    $s->set('language', $to);
    return TRUE;
}

function __(&$array){
    return new arrayHelper($array);
}

function lang($word){
    $f = BASE . "languages/". currentLanguage() . ".php";
    if(!file_exists($f)) return $word;

    include $f;
    $s=new Session();
    $languages_front=$s->get('languages_front');
    return __($languages_front)->{$word} ?: $word;
}

function lngSuffix($add = '', $chapter = FALSE){

    switch (currentLanguage()){
        case 'arabic' : return $add.'_ar';
        case 'french' : return $chapter ? $add : $add.'_fr';
        case 'english': return $add.'_en';
    }

    return '';

}

function lngSuffix2($add = '', $chapter = FALSE){
    switch (current_indexLang()){
        case '1' : return $add.'_lang1';
        case '2' : return $add.'_lang2';
    }

    return '';
}

function isConnected(){
    $s = new Session();
    return !!$s->get('user_id');
}
function datatable($id, $cols){
    $ths = "";
    for($i = 1; $i <= $cols; $i++) $ths .= "<th></th>";

    return "<table id='$id' class='dt_tbl'><thead>$ths</thead><tbody></tbody></table>";
}
function rand_number() {
    return 'c' . str_pad(dechex(mt_rand(0, 0xFFFFFF)), 6, '0', STR_PAD_LEFT);
}
function check_extensionFile($type=null,$file=null){
    $extension_img  =  array('png','jpeg','gif','jpg','PNG','JPEG','GIF','JPG');
    $extension_video  =  array('mp4','3gp','MP4','3GP');
    $get_extension = pathinfo($file, PATHINFO_EXTENSION);
    $extension=false;
    if($type=='image')
        $extension=in_array($get_extension,$extension_img);
    if($type=='video')
        $extension=in_array($get_extension,$extension_video);
    return $extension;
}
function current_country(){
    $s = new Session();
    $id_country = $s->get('id_country');
    return $id_country;
}
 function countries_byuser($id_user=null){
     $db = new Database(config()->db_host, config()->db_user, config()->db_password, config()->db_name, config()->port);
    $query="SELECT  c.*,a.iso FROM admin_country d join countries c on c.id=d.id_country and c.deleted=0 "
        ."join all_countries a on a.id=c.id_country and a.deleted=0 where d.id_user=$id_user and d.deleted=0";
    $countries=$db->query($query);
    return $countries;
}
 function in_countries($id_user=null){
     $countries=countries_byuser($id_user);
     $in="";
     foreach ($countries as $country)
         $in.="$country->id,";
     $in=substr($in, 0, -1);

     return $in;
}
function sections_byuser($id_user=null){
    $db = new Database(config()->db_host, config()->db_user, config()->db_password, config()->db_name, config()->port);
    $sections=(object)$db->get("admin_sections",array('id_user'=>$id_user,'deleted'=>0));
    $st=array();
    foreach ($sections as $section)
    $st[]=$section->name;
    return $st;
}
function languages_bycountry($id_country=null){
    $db = new Database(config()->db_host, config()->db_user, config()->db_password, config()->db_name, config()->port);
    $query=" select a.*, lower(alc.iso) iso from country_languages c join all_languages a on c.id_lang=a.id and a.deleted=0 JOIN countries cc ON cc.id = c.id_country JOIN all_countries alc ON alc.id = cc.id_country where c.id_country=$id_country ";
    $languages=$db->query($query);
    return $languages;
}
function current_language(){
    $s = new Session();
    $id_lang = $s->get('id_lang');
    $lang_index = $s->get('lang_index');
    $rtl = check_rtl();
    return (object) array(
        'id'=>$id_lang,
        'index'=>$lang_index,
        'rtl'=>$rtl,
    );
}
function current_indexLang(){
    $s = new Session();
    $lang_index = $s->get('lang_index');
    return $lang_index;
}
function language_index(){
    $s = new Session();
    $lang_index = $s->get('lang_index');
    return $lang_index;
}
function changeCountry($to){
    if(!$to) return false;
    $s = new Session();
    $s->set('id_country', $to);
    return TRUE;
}
function change_language($to){
    if(!$to) return false;
    $s = new Session();
    $s->set('id_lang', $to);
    return TRUE;
}
function change_languageIndex($to){
    if(!$to) return false;
    $s = new Session();
    $s->set('lang_index', $to);
    return TRUE;
}
function check_rtl(){
    $s = new Session();
    $id_lang=$s->get('id_lang');
    $db = new Database(config()->db_host, config()->db_user, config()->db_password, config()->db_name, config()->port);
    $lang=$db->query("select * from all_languages where id=$id_lang");
    return count($lang) > 0 ? $lang[0]->rtl : null;
}
function all_countries(){
    $db = new Database(config()->db_host, config()->db_user, config()->db_password, config()->db_name, config()->port);
    $query="SELECT  c.*,a.iso FROM  countries c  "
        ."join all_countries a on a.id=c.id_country and a.deleted=0 where  c.deleted=0";
    $countries=$db->query($query);
    return $countries;
}
function information_country(){
    $db = new Database(config()->db_host, config()->db_user, config()->db_password, config()->db_name, config()->port);
    $id_country=current_country();
    $query="SELECT  c.*,a.iso FROM  countries c  "
        ."join all_countries a on a.id=c.id_country and a.deleted=0 where c.id=$id_country";
    $countries=$db->query($query);
    return count($countries) > 0 ? $countries[0] : null;
}
function languages_front(){
    $db = new Database(config()->db_host, config()->db_user, config()->db_password, config()->db_name, config()->port);
    $id_lang=current_language()->id;
    $languages=$db->get('languages_front',array('id_lang'=>$id_lang,'deleted'=>0));
    return count($languages) > 0 ?  json_decode($languages[0]->fields) : [];
}


