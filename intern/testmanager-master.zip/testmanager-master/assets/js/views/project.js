//project
(function () {
    var view = $('#project_view');
    if(!view.length) return;

    var table = $('.project_members');
    view
        .on('click', '[data-pedit]', function () {
            var id = this.dataset.pedit;
            ajaxModal('projects/create', 'Edit Project', 'Please provide all the required informations', 'fa fa-globe', {
                close_text : 'Cancel',
                confirm_text : 'Update',
                whenLoaded : function(modal, data){

                },
                whenConfirm : function(modal, data){
                    modal.find('input, textarea, button').prop('disabled', true);

                    $.post(site_url + 'projects/save/' + id, {
                        name : modal.find('#name').val(),
                        url : modal.find('#url').val(),
                        desc : modal.find('#desc').val(),
                        tags : modal.find('#tags').val(),
                    }, function (rep) {

                        if(rep.status === 'OK'){
                            toastr_('Project added successfully', 'success', 'success');
                            $('[data-lprojects].active').trigger('click');

                            modal.modal('hide');
                        }else{
                            toastr_('Error', 'error', 'danger', 9000);
                        }

                    })
                        .always(function () {
                            modal.find('input, textarea, button').prop('disabled', false);
                        })
                        .fail(function () {
                            toastr_('Error', 'error', 'danger', 9000);
                        })
                },
                whenError : function(modal, error){},
                whenClosed : function(modal){},

            });
        })


        .ready(function () {

            table.twTable({

                url     : site_url + 'project/get_members/' + project_id,
                key     : 'id',

                dblclick : function(id, tr){
                    log(id);
                },

                columns : [
                    {name : 'username', data : 'username', title : 'Member', orderable : true, searchable : true},
                    {name : 'type', data : 'type', title : 'Type', orderable : true, searchable : true},
                ],

                buttons : [
                    {
                        text : 'Add',
                        icon : 'fas fa-plus',
                        color : 'primary',
                        global : true,
                        remote : 'manage_members',
                        action : function(){
                            addMember();
                        },
                    },
                    {
                        separator : true,
                    },



                    {
                        icon : 'fas fa-times',
                        remote : 'manage_members',
                        global : false,
                        action : function(id){
                            deleteMember(id);
                        },
                    },

                ],

            });

        })
    ;





    function addMember() {

        ajaxSideModal('project/add_member/' + project_id ,'Add a member to the Project', 'far fa-paper-plane', {
            close_text : 'Cancel',
            confirm_text : 'Save',
            size: '',
            whenLoaded : function(modal, data){

                modal.find('form')
                    .validate();
                modal
                    .on('submit', 'form', function (e) {
                        e.preventDefault();
                        var btn = modal.find('.confirm').prop('disabled', true);

                        var form = $(this);

                        if(form.valid()){
                            post('project/save_member/', form.serialize(), function (rep) {
                                if(rep.status === 'OK'){
                                    toastr_('The member was successfully added', 'success', 'success', 6000);
                                    modal.sideModal('hide');
                                    table.twTable('refresh');
                                }else{
                                    toastr_(rep.message || 'Error while saving the data', 'error', 'danger', 9000);
                                }
                            })
                        }



                    })
            },
            whenConfirm : function(modal, data){
                modal.find('form').submit();
            },
            whenError : function(modal, error){},
            whenClosed : function(modal){},

        });
    }
    function deleteMember(id) {
        ask('Are you sure?', 'Do you really want to delete this member from the team?, this action will clear all the reports.', function (yes) {

            if(yes){

                post('project/delete_member/' + id, {}, function (rep) {
                    if(rep.status === 'OK'){
                        toastr_('The Member was successfully deleted from this team!', 'success', 'success');
                        table.twTable('refresh');
                    }else{
                        toastr_("We couldn't remove the selected Member", 'error', 'danger');
                    }
                })

            }else{

            }

        }, 'Yes', 'Cancel', true);
    }
    function getActivity() {


    }


})();