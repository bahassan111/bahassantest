class RiderVehicleSubTypeModel {
  String id;
  String categoryName;
  String typeId;

  RiderVehicleSubTypeModel({this.id, this.categoryName, this.typeId});

  RiderVehicleSubTypeModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    categoryName = json['category_name'];
    typeId = json['type_id'];
  }
}
