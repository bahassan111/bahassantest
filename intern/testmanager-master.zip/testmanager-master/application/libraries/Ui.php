<?php
class Ui{

    public $run_status;
    protected $ci;

    public function __construct()
    {
        $this->ci =& get_instance();
        $this->run_status = $this->ci->db->get_where('_status', ['deleted' => 0])->result();
    }

    protected function get_status($id){
        foreach ($this->run_status as $status) if($status->id == $id) return $status;
        return null;
    }

    public function status_badge($status_id){

        $status = $this->get_status($status_id);

        if($status){
            return "<span class='run_status' style='color:{$status->color2}; background-color: {$status->color};'>{$status->name}</span>";
        }


        return $status_id;


    }


}