// GLOBAL
var log = console.log || function(){};

$.fn.sideModal = function (op) {
    if(op === 'show'){
       this.addClass('open');
       this.trigger('shown');
    }else if(op === 'hide'){
        this.removeClass('open');
        this.trigger('hidden');
    }


    return this;
};



(function () {

    $(document)

        .on('click', '[data-showcase]', function () {
            showCase(this.dataset.showcase);
        })

        .on('click', '[href="#"]', function (e) {
            e.preventDefault();
        })
        .on('blur', '.main_nav .nav_inner > div', function () {
            setTimeout(function () {
                $('.main_nav .nav_inner > div').removeClass('open');
            }, 100);
        })
        .on('click', '.main_nav .nav_inner > div', function () {
            if($(this).find('ul').length){
                $(this).addClass('open');
            }
        })
        .on('blur', '.un_notif a', function () {
            var that = $(this).parent();
            setTimeout(function () {
                that.removeClass('open');
            }, 100);
        })
        .on('click', '.un_notif a', function () {
            $(this).parent().addClass('open');
        })
        .on('blur', '.un_user > a', function () {
            var that = $(this).parent();
            setTimeout(function () {
                that.removeClass('open');
            }, 100);
        })
        .on('click', '.un_user > a', function () {
            $(this).parent().addClass('open');
        })
        .on('click', '.search_list', function () {
            var card = $(this).closest('.card');
            var list = card.find('ul');
            
            var search = $('<div class="card_search"><a href="javascript:void(0);"><i class="fas fa-times"></i></a><input type="text" id="lst_search" class="form-control form-control-sm" placeholder=""aria-describedby="button-addon1"></div>');

            card.append(search);

            search
                .on('change keyup', 'input', function () {
                    var srch = $(this).val().toLowerCase().trim();
                    list.find('li').show();

                    if(!srch) return;

                    list.find('li').each(function () {
                        if(!$(this).text().toLowerCase().trim().includes(srch)){
                            $(this).css('display', 'none');
                        }
                    })
                })
                .on('click', 'a', function () {
                    search.find('input').val('').trigger('change');
                    search.slideUp(removeMe);
                })
        })
        .on('click', 'a[href^="http"]', function (e) {
            var url = this.href,
                isInternal = url.indexOf(site_url) >= 0;


            if(isInternal && $(this).attr('data-own') === undefined){
                e.preventDefault();

                loadView(url, this);

            }



        })
        .on('click', '.nav-item > a', function () {

            $(this).addClass('active').closest('.nav').find('.active').not(this).removeClass('active');
        })

        .on('click', '.run_stat_list > li', function () {
            $(this).toggleClass('selected').parent().find('.selected').not(this).removeClass('selected');
        })

        .on('click', '.sml_search > div > a.f', function () {
            $(this).parent().find('input').val('').trigger('change');
        })
        .on('change keyup', '.sml_search > div > input', function () {
            log(moment().format('x'));
            var div = $(this).closest('.smart_list'),
                a = div.find('.sml_search > div > a'),
                list = div.find('.sml_list'),
                search = ($(this).val() || '').toLowerCase(),
                search_in = $(this).data('search') || '> div'
            ;

            if(search){
                a.addClass('f').html('<i class="fas fa-times"></i>');
            }else{
                a.removeClass('f').html('<i class="fas fa-search"></i>');
            }



            list.find(search_in).hide().each(function (i, item) {
                if($(item).text().trim().toLowerCase().indexOf(search) >= 0) $(item).show();
            });
            log(moment().format('x'));


        })

        .on('click', '[data-tmm]', function () {
            var val = this.dataset.tmm;
            var input = $(this).closest('.form-group').find('input');

            input.val(val).trigger('change');
        })
        .ready(function () {
            handleInits();
        })
    ;


    $(window)
        .on('popstate', function (e) {
            if(e.originalEvent.state && e.originalEvent.state.url){
                loadView(e.originalEvent.state.url, null);
            }else{
                loadView(window.location.href, null);
            }
        });

})();









function loadView(fullURL, element) {
    var url = fullURL.replace(site_url, ''),
        holder = $('#the_holder'), oldURL = document.location.href, oldTitle = document.title,
        addHistory = element !== null,
        body = $('body'),
        loads = body.data('loads') || 0;


    body.addClass('loading');
    $('.tooltip').remove();

    if(loads > 10){
        return document.location.href = fullURL;
    }else{
        body.data('loads', ++loads);
    }



    post(url, {_ajax : true}, function (rep) {

        holder.html(rep);

        setTimeout(handleInits, 200);



    }, function () {

        if(addHistory) history.pushState({url : fullURL}, oldTitle, fullURL);

        $('html, body').animate({scrollTop:0});

        body.removeClass('loading');

        setTimeout(function () {

            var title = $('[data-xtitle]').data('xtitle') || '';
            document.title = title + ' | ' + site_title;

        }, 200);

    }, function (err) {
        holder.html('<div class="nodata">Can\'t load the requested page :(</div>');
    })




}
function initDatatable(table, cols, config, whenDraw , btns){
    cols = cols || [];
    config = config || {};
    whenDraw = whenDraw || function(){};
    table = $(table);

    var datatable_settings = {
        processing      : true,
        serverSide      : true,
        columns         : cols,
        order           : [[0, 'desc']],
        responsive      : true,
        scrollX         : false,
        columnDefs      : [],
        bLengthChange   : false,
        language        : {
            searchPlaceholder: 'Search...',
            sSearch: '',
            lengthMenu: '_MENU_ items/page',
        },
    };

    $.each(cols, function(i, col){
        if('orderable' in col && !col.orderable){
            datatable_settings.columnDefs.push({targets:i, orderable:false});
        }
        if('searchable' in col && !col.searchable){
            datatable_settings.columnDefs.push({targets:i, searchable:false});
        }
    });

    $.each(config, function(i, e){
        datatable_settings[i] = e;
    });

    datatable_settings.preDrawCallback = function(){
        (function(table, dt){


        })(table, datatable);
    };
    datatable_settings.drawCallback = function(){
        whenDraw(table, datatable);
        (function(table, dt){

        })(table, datatable);
    };
    datatable_settings.initComplete = function(set){


        (function(table, dt){



        })(table, datatable);
    };

    var datatable = table.DataTable(datatable_settings);

    return datatable;

}
function ajaxModal(url, title, subtitle, icon, options){
    icon = icon || 'fa fa-globe';
    subtitle = subtitle || '';

    url = site_url + url;
    options = $.extend({}, {
        show_close_button : true,
        show_confirm_button : true,
        close_from_header : true,
        always_close : false,

        hide_header : false,
        hide_footer : false,

        close_text : 'CLOSE',
        confirm_text : 'OK',
        preload_toastr : true,
        preload_text : 'Loading data ..',
        preload_icon : 'loading',

        id : randomID('lcmodal_', '', 6),
        fixed : false,
        size : 'md',

        whenLoaded : function(modal, data){},
        whenConfirm : function(modal, data){},
        whenError : function(modal, error){},
        whenClosed : function(modal){},

        more_buttons : [

        ],
        post_data : {}
    }, options || {});

    var modal = $(`<div class="modal fade" id="modalBillingInfo" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered wd-sm-650" role="document">
        <div class="modal-content">
          <div class="modal-header pd-y-20 pd-x-20 pd-sm-x-30">
            
            <div class="media align-items-center">
              <span class="tx-color-03 d-none d-sm-block micon"><i class="fa fa-globe"></i></span>
              <div class="media-body mg-sm-l-20">
                <h4 class="tx-18 tx-sm-20 mg-b-2 mtitle"></h4>
                <p class="tx-13 tx-color-03 mg-b-0 msubtitle"></p>
              </div>
            </div><!-- media -->
          </div><!-- modal-header -->
          <div class="modal-body pd-sm-t-30 pd-sm-b-40 pd-sm-x-30"></div>
          <div class="modal-footer pd-x-20 pd-y-15">
            
            
          </div>
        </div><!-- modal-content -->
      </div><!-- modal-dialog -->
    </div>`),

        ok = $('<button type="button" class="btn btn-primary confirm">Save Info</button>'),
        close = $('<button type="button" class="btn btn-white cancel" data-dismiss="modal">Cancel</button>'),
        header_close = $(`<a href="" role="button" class="close pos-absolute t-15 r-15" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </a>`),
        button = $('<button type="button" class="btn btn-primary">Save Info</button>'),
        toast = null
    ;

    if(options.preload_toastr){
        toast = toastr_(options.preload_text, options.preload_icon, undefined, 900000000);

    }

    if(options.show_close_button)
        modal.find('.modal-footer').append(close.html(options.close_text));
    if(options.show_confirm_button)
        modal.find('.modal-footer').append(ok.html(options.confirm_text));
    if(options.close_from_header)
        modal.find('h4').before(header_close);
    if(options.hide_footer) modal.find('.modal-footer').hide();
    if(options.hide_header) modal.find('.modal-header').hide();

    $.each(options.more_buttons, function(i, e){
        var btn = button
            .clone()
            .addClass(this.class)
            .html(this.text)
            .on('click', function(){
                e.onClick(modal);
            });
        $.each(e.attrs, function(a, p){
            btn.attr(a, p);
        });
        modal.find('.modal-footer').append(btn);
    });

    log(modal.find('.mtitle'));
    modal
        .attr('id', options.id)
        .find('.mtitle').html(title).end()
        .find('.msubtitle').html(subtitle).end()
        .find('.micon').html(`<i class="${icon}"></i>`).end()
        .find('.modal-dialog').addClass('modal-' + options.size);

    ok.on('click', function(){

        options.whenConfirm(modal);
        if(options.always_close) modal.modal('hide');
    });



    $
        .post(url, $.extend({}, options.post_data, {ajax : true}), function(response){

            modal.find('.modal-body').css('height', 'unset').html(response);

            if(options.preload_toastr){
                toast.trigger('click');
                modal.modal('show');
            }

            setTimeout(function () {
                options.whenLoaded(modal, response);
            }, 200);


        })
        .fail(function(error){
            options.whenError(modal, error);
            toastr_('There was an error during the process', 'error', 'danger');
            modal.modal('hide');
            if(toast) toast.trigger('click');
        });




    if(!options.preload_toastr){
        modal.modal('show');
    }




    return modal
        .on('hidden.bs.modal', function(){
            $(this).remove();
        })
        .find('.modal-body').css('height', 300).end();

}
function randomID(prefix, suffix, length){
    prefix = prefix || '';
    suffix = suffix || '';
    length = length || 20;

    var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijqlmnopkrstuvwyxz1234567890_-';
    var ret = '';
    while(ret.length < length) ret += chars.charAt(rnd(0, chars.length -1));
    return prefix + ret + suffix;

}
function removeMe(){
    return $(this).remove();
}
function pad(n, width, z) {
    z = z || '0';
    n = n + '';
    return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n;
}
function rnd(min, max){
    return min + Math.floor(Math.random() * ((max - min) + 1));
}
function toastr_(text, icon, color, timeout, holder) {
    if(icon === 'loading') icon = 'fa-spin fas fa-circle-notch';
    if(icon === 'success') icon = 'fas fa-check';
    if(icon === 'error') icon = 'fas fa-times';
    if(icon === 'info') icon = 'fas fa-info';

    var toast = $(`<div class="toastr ${color || ''}">
        <div class="icon"><i class="${icon || 'fas fa-info'}"></i></div>
        <div class="t"><p>${text}</p></div>
    </div>`);

    function closeMe(){
        toast.fadeOut(200, ()=>{toast.remove();})
    }


    var height = 0;

    if($('.toastr').length > 0) height = $(window).height() - $('.toastr').last().position().top - 62;

    toast
        .appendTo(holder || 'body')
        .css({opacity : 0, right : 0, bottom : 64 + height})
        .on('click', closeMe)
        .animate({
            right : 64,
            opacity : 1
        })
    ;



    setTimeout(closeMe, timeout || 6000);



    return toast;
}
function post(path, params, then, always, error) {

    params = params || {};
    then = then || function(){};
    always = always || function(){};
    error = error || function(){};

    if(path.indexOf('http') < 0) path = site_url + path;

    log(path);

    return $
        .post(path, params, function (rep) {
            then(rep);
        })
        .always(function () {
            always();
        })
        .fail(function () {
            error();
        })
}
function ask(title, question, then, confirmText, cancelText) {
    confirmText = confirmText || 'Yes';
    cancelText = cancelText || 'No';
    then = then || function(){};

    var modal = $(`<div class="modal fade" id="modal5" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel5" aria-hidden="true">
                      <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
                        <div class="modal-content tx-14">
                          <div class="modal-header">
                            <h6 class="modal-title" id="exampleModalLabel5">${title}</h6>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                            <p class="mg-b-0">${question}</p>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary tx-13 cancel" data-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary tx-13 confirm">Yes</button>
                          </div>
                        </div>
                      </div>
                    </div>`);

    modal
        .appendTo('body')
        .on('bs.hide', function () {
            if(!modal.data('answred')){
                then(false);
            }

            modal.remove();

        })
        .on('click', '.confirm', function () {
            modal.data('answred', true);
            modal.modal('hide');
            then(true);
        })
        .on('click', '.cancel', function () {
            modal.data('answred', true);
            then(false);
        })
        .modal('show');


}
function ask2(title, question, then, confirmText, cancelText, loading) {
    confirmText = confirmText || 'Yes';
    cancelText = cancelText || 'No';
    then = then || function(){};


    var modal = $(`<div class="ask_user">
        <div class="h">
            <span class="icon"><i class="fas fa-question"></i></span>
            <span class="title">${title}</span>
        </div>
        <div class="b">
            <p>${question}</p>
        </div>
        <div class="f">
            <button class="btn btn-xs pd-x-15 btn-outline-dark btn-uppercase no"><i class="fas fa-times"></i> ${cancelText}</button>
            <button class="btn btn-xs pd-x-15 btn-primary btn-uppercase yes"><i class="fas fa-check"></i> ${confirmText}</button>
        </div>
    </div>`);

    var handle = {
        close : function () {
            modal.animate({bottom : -60, opacity : 0}, 200, removeMe);
            $('body').removeClass('hasdialog');
            return this;
        },
        await : function () {
            modal.find('.yes').html('Working ..').prop('disabled', true);
            return this;
        },
        show : function(){
            $('body').addClass('hasdialog');
            modal.css({bottom: -60, opacity : 0}).animate({bottom : 0, opacity : 1}, 300);
            return this;
        },
        obj : modal,

    };

    modal
        .appendTo('body')
        .on('click', '.yes', function () {
            if(!loading){
                handle.close();
            }else {
                handle.await();
            }

            then(true);
        })
        .on('click', '.no', function () {
            handle.close();
            then(false);
        })
    ;

    return handle.show();


}
function shadeColor(color, percent) {

    var R = parseInt(color.substring(1,3),16);
    var G = parseInt(color.substring(3,5),16);
    var B = parseInt(color.substring(5,7),16);

    R = parseInt(R * (100 + percent) / 100);
    G = parseInt(G * (100 + percent) / 100);
    B = parseInt(B * (100 + percent) / 100);

    R = (R<255)?R:255;
    G = (G<255)?G:255;
    B = (B<255)?B:255;

    var RR = ((R.toString(16).length==1)?"0"+R.toString(16):R.toString(16));
    var GG = ((G.toString(16).length==1)?"0"+G.toString(16):G.toString(16));
    var BB = ((B.toString(16).length==1)?"0"+B.toString(16):B.toString(16));

    return "#"+RR+GG+BB;
}
function ajaxSideModal(url, title, icon, options){
    icon = icon || 'fas fa-globe';

    url = site_url + url;
    options = $.extend({}, {
        show_close_button : true,
        show_confirm_button : true,
        close_from_header : true,
        always_close : false,

        hide_header : false,
        hide_footer : false,

        close_text : 'CLOSE',
        confirm_text : 'OK',
        preload_toastr : true,
        preload_text : 'Loading data ..',
        preload_icon : 'loading',

        id : randomID('lcmodal_', '', 6),
        fixed : true,
        size : 'sm',

        whenLoaded : function(modal, data){},
        whenConfirm : function(modal, data){},
        whenError : function(modal, error){},
        whenClosed : function(modal){},

        more_buttons : [

        ],
        post_data : {}
    }, options || {});

    var modal = $(`<div class="side_modal">
    <div class="side_modal_inner">
        <div class="smodal_head">
            <span class="i"><i class="${icon || ''}"></i></span>
            <span class="t">${title || ''}</span>
            
        </div>
        <div class="smodal_body">
            
        </div>
        <div class="smodal_footer">
           
        </div>
    </div>
</div>`),

        ok = $('<button type="button" class="btn btn-primary confirm">Ok</button>'),
        close = $('<button type="button" class="btn btn-white cancel">Cancel</button>'),
        header_close = $(`<span class="a"><a href="javascript:void(0);"><i class="fas fa-times"></i></a></span>`),
        button = $('<button type="button" class="btn btn-primary">Save Info</button>'),
        toast = null
    ;

    if(options.preload_toastr){
        toast = setLoading(true, options.preload_text);

    }

    if(options.show_close_button)
        modal.find('.smodal_footer').append(close.html(options.close_text));
    if(options.show_confirm_button)
        modal.find('.smodal_footer').append(ok.html(options.confirm_text));
    if(options.close_from_header)
        modal.find('.smodal_head').append(header_close);
    if(options.hide_footer) modal.find('.smodal_footer').hide();
    if(options.hide_header) modal.find('.smodal_head').hide();

    $.each(options.more_buttons, function(i, e){
        var btn = button
            .clone()
            .addClass(this.class)
            .html(this.text)
            .on('click', function(){
                e.onClick(modal);
            });
        $.each(e.attrs, function(a, p){
            btn.attr(a, p);
        });
        modal.find('.smodal_footer').append(btn);
    });

    modal
        .attr('id', options.id)
        .addClass(options.size);

    ok.on('click', function(){

        options.whenConfirm(modal);
        if(options.always_close) modal.sideModal('hide');
    });

    close.on('click', function () {
        modal.sideModal('hide');
    });



    $
        .post(url, $.extend({'_ajax': true}, options.post_data, {ajax : true}), function(response){

            modal.find('.smodal_body').html(response);

            if(options.preload_toastr){
                setLoading(false);
                modal.sideModal('show');
            }

            setTimeout(function () {
                handleInits(modal);
                options.whenLoaded(modal, response);
            }, 200);


        })
        .fail(function(error){
            options.whenError(modal, error);
            toastr_('There was an error during the process', 'error', 'danger');
            modal.sideModal('hide');
            if(toast) setLoading(false)
        });




    if(!options.preload_toastr){
        modal.sideModal('show');
    }




    return modal
        .on('click', function (e) {
            if(options.fixed) return;
            if($(e.originalEvent.target).hasClass('side_modal')) {
                modal.sideModal('hide');
            }
        })
        .on('click', '.smodal_head > .a a', function () {
            modal.sideModal('hide');
        })
        .on('shown', function () {
            $('body').addClass('modal-open');
        })
        .on('hidden', function(){
            $('body').removeClass('modal-open');
            setTimeout(function () {
                modal.remove();

            }, 600);
        })
        .appendTo('body');

}
function setLoading(visible, text) {
    visible = typeof visible == "undefined" ? true : visible;
    text = text || 'Loading ..';
    var tmpl = $(`<div class="float_waiting"><span><i></i><i></i><i></i></span><b>${text}</b></div>`),
        holder = $('body'),
        inHolder = holder.find('.float_waiting');

    if(visible){
        if(inHolder.length){
            inHolder.show();
        }else{
            holder.append(tmpl);
        }
    }else{
        inHolder.fadeOut(removeMe);
    }

    return holder.find('.float_waiting');

}
function handleInits(view) {
    view = $(view || 'body');


    view.find('[data-title]').not('.dne').tooltip();

    view.find('.selectpicker').not('.dne').each(function(){
        var that = $(this).addClass('dne');

        log(that);
        that.selectpicker({
            liveSearch: that.find('option').length > 8,
            size : 8,
        });
    });


    view.find('.datepicker').not('.dne').addClass('dne').datepicker({
        autoclose : true,
        format : 'yyyy-mm-dd',
        todayBtn : true,
        todayHighlight : true,
        zIndexOffset : 10000,
    });

    view.find('[data-shownby]').each(function () {
       var query = this.dataset.shownby || '';
       var items = query.split('|');
       var that = $(this);

       $.each(items, function (i, item) {
           var q = item.split(':');
           if(q.length === 2){
               view.on('change keyup', q[0], function () {
                   if($(this).val() === q[1]) that.show(); else that.hide();
               })
           }
       })

    });

}
function testAcase(id, then) {
    ajaxSideModal('project/test_a_case/' + id, 'Test a Test Case', '', {
        size : 'md',
        show_close_button : false,
        confirm_text : 'Return',
        always_close : true,
        ok : false,
        whenClosed : function () {
            (then || function(){})();
        }
    });
}
function viewTask(id, then) {
    ajaxSideModal('tasks/show/' + id, 'View TASK', '', {
        size : 'lg',
        show_close_button : false,
        confirm_text : 'Return',
        always_close : true,
        ok : false,
        whenClosed : function () {
            (then || function(){})();
        }
    });
}




function showCase(id, then) {
    ajaxSideModal('project/show_case/' + id, 'Preview Case', '', {
        size : 'lg',
        show_close_button : false,
        confirm_text : 'Return',
        always_close : true,
        whenClosed : function () {
            (then || function(){})();
        }
    });
}