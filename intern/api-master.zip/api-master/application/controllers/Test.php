<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends CI_Controller{

    public function index(){

        $token = $this->input->get('token');
        $uid = $this->input->get('uid');


        if($token && $uid){

            $data = [
                'token' => $token,
                'uid' => $uid,
                'date' => date('Y-m-d H:i:s'),
                'ip' => $_SERVER['REMOTE_ADDR'],
            ];

            if($this->userExists($uid)){
                $query = $this->db->update('_push_tokens', $data, ['uid' => $uid]);
            }else{
                $query = $this->db->insert('_push_tokens', $data);
            }


            responseJSON([
                'status' => $query,
            ]);




        }else{

            responseJSON([
                'status' => 'EMPTY!',
            ]);

        }

    }


    protected function userExists($uid){
        return $this->db->get_where('_push_tokens', ['uid' => $uid])->num_rows() > 0;
    }


    public function update_notif(){

        $uid = $this->input->get('uid');
        $enable = $this->input->get('enabled') === '1';

        if($uid){
            $this->db->update('_push_tokens', ['enabled' => $enable], ['uid' => $uid]);
        }


        responseJSON(['status' => 'OK']);

    }

    public function update_cat_notif(){

        $uid = $this->input->get('uid');
        $enable = $this->input->get('enabled') === '1';
        $cat_id = $this->input->get('cat');

        if($cat_id && $uid){
            if($enable){
                $this->db->query("DELETE FROM _push_tokens_cat WHERE uid = ? AND cat = ?", [$uid, $cat_id]);
            }else{
                $this->db->insert('_push_tokens_cat', ['cat' => $cat_id, 'uid' => $uid]);
            }
        }


        responseJSON(['status' => 'OK']);

    }

}