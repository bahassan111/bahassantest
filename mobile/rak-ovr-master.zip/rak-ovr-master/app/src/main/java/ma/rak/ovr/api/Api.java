package ma.rak.ovr.api;

import ma.rak.ovr.bodyResponse.AbonnementResponse;
import ma.rak.ovr.bodyResponse.AgentsResponse;
import ma.rak.ovr.bodyResponse.BranchementResponse;
import ma.rak.ovr.bodyResponse.HistoriqueAbonnementResponse;
import ma.rak.ovr.bodyResponse.HistoriqueBranchementResponse;
import ma.rak.ovr.bodyResponse.HistoriqueConsoResponse;
import ma.rak.ovr.bodyResponse.LoginResponse;
import ma.rak.ovr.bodyResponse.OperationResponse;
import ma.rak.ovr.bodyResponse.ReclamationResponse;
import ma.rak.ovr.bodyResponse.RootResponse;
import ma.rak.ovr.bodyResponse.SettingsResponse;
import ma.rak.ovr.bodyResponse.StatistiqueResponse;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Query;

public interface Api {
    @FormUrlEncoded
    @POST("auth/refresh_token")
    Call<LoginResponse> auth(@Header("Authorization") String basicAuth,
                             @Field("grant_type") String grants,
                             @Field("imei") String imei
    );

    @FormUrlEncoded
    @PUT("auth/change_password")
    Call<LoginResponse> change_password(
            @Field("Username") String Username,
            @Field("old_pass") String old_pass,
            @Field("new_pass") String new_pass
    );

    // TODO: 12/18/20 body or data of statistiques
    @GET("statstiques/1")
    Call<StatistiqueResponse> statstiques();

    @GET("info")
    Call<RootResponse> root();

    // TODO: 12/18/20 body or data of settings
    @GET("settings/abonnement")
    Call<SettingsResponse> settingsAb();

    @GET("reclamation/meta/")
    Call<SettingsResponse> settingsReclamation();

    @GET("reclamation/historique_consomation/")
    Call<HistoriqueConsoResponse> historiqueConso(@Header("Cookie") String debugCookie,@Query("page") String search);

    @GET("settings/branchement")
    Call<SettingsResponse> settingsBr();

    @GET("agents/")
    Call<AgentsResponse> agents();


    @GET("demandes/abonnement/")
    Call<AbonnementResponse> abonnemnts(@Query("page") int page);

    @GET("reclamation/operations/")
    Call<ReclamationResponse> reclamations(@Query("page") int page);
    @GET("reclamation/operations/new")
    Call<ReclamationResponse> new_reclamations(@Query("fdate") String filter_date);

    @FormUrlEncoded
    @POST("reclamation/executer")
    Call<OperationResponse> executerReclamation(
            @Header("Cookie") String debugCookie,
            @Field("STATOPER") String STATOPER,
            @Field("DATTRAOP") String DATTRAOP,
            @Field("LONGITUDE") String LONGITUDE,
            @Field("LATITUDE") String LATITUDE,
            @Field("NUMDOSRE") String NUMDOSRE,
            @Field("REPECLIE") String REPECLIE,
            @Field("RESU_FIN") String RESU_FIN,
            @Field("base64Image") String base64Image,
            @Field("observation") String observation
    );


}
