import 'package:get/get.dart';
import 'package:rider_app/ui/ui.dart';

class AppRoutes {
  AppRoutes._();
  static final routes = [
    GetPage(name: '/', page: () => SplashUI()),
    GetPage(name: '/HomeUI', page: () => HomeUI()),
    GetPage(name: '/LanguageUI', page: () => LanguageUI()),
    GetPage(name: '/SignUpUI', page: () => SignUpUI()),
    GetPage(name: '/SignInUI', page: () => SignInUI()),
    GetPage(name: '/IntroUI', page: () => IntroUI()),
    GetPage(name: '/ForgotPasswordUI', page: () => ForgotPasswordUI()),
    GetPage(name: '/ProfileUI', page: () => ProfileUI()),
    GetPage(name: '/RatingUI', page: () => RatingUI()),
    GetPage(name: '/TripHistoryUI', page: () => TripHistoryUI()),
    GetPage(name: '/TripAceeptUI', page: () => TripAceeptUI()),
    GetPage(name: '/TripStart', page: () => TripStart()),
    GetPage(name: '/PreBookingUI', page: () => PreBookingUI()),
  ];
}
