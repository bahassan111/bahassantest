import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:rider_app/controllers/language_controller.dart';
import 'constants/constants.dart';
import 'controllers/controllers.dart';
import 'package:device_preview/device_preview.dart';
import 'package:location_permissions/location_permissions.dart';
import 'dart:ui';

import 'home.dart';

@override
void initState() {}
void main() async {
  await GetStorage.init();

  Get.put<AuthController>(AuthController());
  Get.put<ProfileController>(ProfileController());
  Get.put<HomeController>(HomeController());
  Get.put<LanguageController>(LanguageController());
  Get.put<TripHistoryController>(TripHistoryController());
  Get.put<TripAcceptController>(TripAcceptController());
  Get.put<RatingController>(RatingController());

  runApp(
    MyApp(), // Wrap your app
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      // locale: DevicePreview.locale(context), // Add the locale here
      // builder: DevicePreview.appBuilder,
      //home: Home(),
      translations: Messages(),
      locale: Locale('en', 'US'),
      fallbackLocale: Locale('en', 'US'),
      title: 'Candy Rider App',
      navigatorObservers: [BotToastNavigatorObserver()],
      builder: BotToastInit(),
      debugShowCheckedModeBanner: false,
      theme: AppThemes.lightTheme,
      initialRoute: "/",
      getPages: AppRoutes.routes,
    );
  }

  void showLocationAllowPopup() {
    Image.asset('assets/images/whiteBck.png');
  }

  Future<void> askForPermissionNow() async {
    PermissionStatus permission =
        await LocationPermissions().requestPermissions();
  }
}
