export default {
	appname : 'DIB NEWS',
	loading_news : "جاري تحميل آخر الأخبار..",
	checking_updates : "البحث عن تحديثات ..",


	start_btn : 'تخصيص',
	welcome_title : 'مرحبــا',
	welcome_text : 'إبدا الآن بتخصيص طريقة عرض الأخبار و الألوان و لغتكم المفظلة',
	select_your_language : 'إختر لغتك المفظلة',
	select_layout : 'طريقة العرض',
	layouts_description : 'تخصيص طريقة عرض الأخبار',
	themes_description : 'تخصيص الألوان',
	modern_mode : 'طريقة حديثة',
	stack_mode : 'طريقة تقليدية',
	select_theme : 'أختر اللالوان المناسبة',
	theme_light : "الوصع النهاري",
	theme_dark : "الوضع الليلي",
	setup_final_message : "شكراً",
	go_back : "عودة",
	save_language : "حفظ اللغة",
	save_layout : "حفظ التخصيص",
	finish_btn : "إنتهاء",

	save : 'حفظ',
	settings : 'إعدادات',
	home : 'الرئيسية',
	reset : 'حذف الإعدادات',
}
