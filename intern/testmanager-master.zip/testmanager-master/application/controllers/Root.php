<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Root extends CI_Controller {

    public function __construct()
    {
        parent::__construct();

        if(!isLoggedIn()){
            callback_whenNotLoggedIn();
        }
    }


    public function index()
	{

		redirect('projects');
	}
    public function no_permission()
	{
	    echo "No Permissions";
	}
}
