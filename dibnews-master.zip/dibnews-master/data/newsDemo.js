const news = {

    sport : [
        {
            title: "Cristiano Ronaldo positif au Covid-19",
            content: "L’attaquant vedette de la sélection portugaise, Cristiano Ronaldo, a été testé positif au Covid-19 et sera forfait contre la Suède mercredi soir à Lisbonne en Ligue des Nations, a annoncé mardi la Fédération portugaise de football (FPF).",
            image: "https://api.time.com/wp-content/uploads/2017/06/170629_cristiano-ronaldo.jpg",
            video: {
                "source": "youtube",
                "id": "-hvEZzXXPqg"
            },
            date : '12 décembre 2020'
        },
        {
            title: "Football/Liverpool: Le défenseur Virgil van Dijk devra être opéré du genou",
            content: "Le défenseur néerlandais de Liverpool, Virgil van Dijk, blessé à un ligament du genou lors de la rencontre samedi contre Everton (2-2), va devoir être opéré, ont fait savoir les Reds dimanche.",
            image: "https://cdn.mos.cms.futurecdn.net/GqMHs5SY4Z9H4b2jNxLkyR.jpg",
            video: null,
            date : '12 décembre 2020'
        },
        {
            title: "Demo Sport 1 (Youtube)",
            content: '<div id="article-body" class="text-copy bodyCopy auto">\n' +
                '<p>Liverpool defender Virgil Van Dijk admits he has to stay focused on the job he has to do despite opposition teams seemingly now targeting his centre-back partner as a weak spot.</p><div id="ad-unit-1" class="ad-unit"></div><p>Bournemouth’s Callum Wilson attached himself to the Dutchman’s fellow central defender Joe Gomez and his physicality helped give them the lead at Anfield before the Reds fought back to win 2-1 for a league record 22nd consecutive home top-flight victory.</p><aside class="hawk-placeholder" data-render-type="fte" data-skip="dealsy" data-widget-type="seasonal" data-widget-id="3236749782359935500" data-result="missing"></aside><p>It was a tactic Watford employed with Troy Deeney in their surprise 3-0 victory a week ago which ended the Premier League leaders’ unbeaten run.</p><p>However, manager Jurgen Klopp attributed that to their failure to deal with ‘second balls’ which is why Van Dijk accepts he cannot go looking to help out his fellow defender.</p><p>“Obviously, teams have been looking at us and trying to find difficulties for us,” said Van Dijk. “I think first and foremost, if the ball goes to them (his defensive partner), they challenge.</p><div id="ad-unit-2" class="ad-unit"></div><p>“Whether you win it or lose it ,the most important thing is the second ball.</p><p>“When the goalkeeper has the ball, they tried to get into a position to challenge with Philip Billing and they tried to get Callum Wilson with Joe in the middle.</p><div class="twitter-tweet twitter-tweet-rendered" style="display: flex; max-width: 550px; width: 100%; margin-top: 10px; margin-bottom: 10px;"><iframe id="twitter-widget-0" scrolling="no" frameborder="0" allowtransparency="true" allowfullscreen="true" class="" style="position: static; visibility: visible; width: 550px; height: 496px; display: block; flex-grow: 1;" title="Twitter Tweet" src="https://platform.twitter.com/embed/index.html?creatorScreenName=FourFourTwo&amp;dnt=false&amp;embedId=twitter-widget-0&amp;frame=false&amp;hideCard=false&amp;hideThread=false&amp;id=1236375503117967360&amp;lang=en&amp;origin=https%3A%2F%2Fwww.fourfourtwo.com%2Fus%2Fnews%2Fvirgil-van-dijk-stays-focused-opposition-teams-target-his-centre-back-partner&amp;siteScreenName=FourFourTwo&amp;theme=light&amp;widgetsVersion=ed20a2b%3A1601588405575&amp;width=550px" __idm_frm__="689" data-tweet-id="1236375503117967360"></iframe></div><p class="mid__article"></p><p>“It is something teams will try to be clever with but the most important thing is the second ball because you cannot score from that.</p><p>“I have to be in the right position when Joe is challenging for that and the midfielders are the same.”</p><p>Three more wins will be enough for Liverpool to lift their first title in 30 years – less if Manchester City drop points in either of their two matches in hand.</p><p>After three defeats in four matches in all competitions, it was imperative the Reds returned to winning ways ahead of Wednesday’s vital Champions League last-16 second-leg tie against Atletico Madrid when Klopp’s side must overturn a 1-0 deficit.</p><div class="instagram-embed"><iframe class="instagram-media" id="instagram-embed-0" src="https://www.instagram.com/p/https:/embed/captioned/?cr=1&amp;v=6&amp;wp=600&amp;rd=https%3A%2F%2Fwww.fourfourtwo.com&amp;rp=%2Fus%2Fnews%2Fvirgil-van-dijk-stays-focused-opposition-teams-target-his-centre-back-partner#%7B%22ci%22%3A0%2C%22os%22%3A5469.379999907687%7D" allowtransparency="true" allowfullscreen="true" frameborder="0" height="0" data-instgrm-payload-id="instagram-media-payload-0" scrolling="no" style="width: calc(100% - 2px); background-color: white; border-radius: 3px; border: 1px solid rgb(219, 219, 219); box-shadow: none; display: block; margin: 0px; min-width: 326px; padding: 0px; position: absolute;"></iframe><blockquote class=" instagram-media-registered" data-instgrm-captioned="" data-instgrm-version="6" style="width:99.375%; width:-webkit-calc(100% - 2px); width:calc(100% - 2px);" id="instagram-media-payload-0"><p><a href="https://www.instagram.com/p/https://www.instagram.com/p/B9eNUhilJQV/?utm_source=ig_embed&amp;utm_campaign=loading/" target="_blank" data-component-tracked="1" class="hawk-link-parsed"></a></p><p>A photo posted by on </p></blockquote></div><p>The show of character they displayed in recovering from Wilson’s early goal – after his apparent push on Gomez had been deemed not to be a foul by referee Paul Tierney – was therefore significant.</p><p>Mohamed Salah’s 80th goal in his 100th Premier League appearance made him the first Liverpool player since Michael Owen in 2002-03 to score 20-plus goals in three-successive seasons, while also taking him past Luis Suarez as the club’s leading overseas Premier League scorer.</p><p>Sadio Mane’s coolly-taken effort eight minutes later turned around the game before half-time.</p><div class="instagram-embed"><iframe class="instagram-media" id="instagram-embed-1" src="https://www.instagram.com/p/https:/embed/captioned/?cr=1&amp;v=6&amp;wp=600&amp;rd=https%3A%2F%2Fwww.fourfourtwo.com&amp;rp=%2Fus%2Fnews%2Fvirgil-van-dijk-stays-focused-opposition-teams-target-his-centre-back-partner#%7B%22ci%22%3A1%2C%22os%22%3A5474.784999853%7D" allowtransparency="true" allowfullscreen="true" frameborder="0" height="0" data-instgrm-payload-id="instagram-media-payload-1" scrolling="no" style="width: calc(100% - 2px); background-color: white; border-radius: 3px; border: 1px solid rgb(219, 219, 219); box-shadow: none; display: block; margin: 0px; min-width: 326px; padding: 0px; position: absolute;"></iframe><blockquote class=" instagram-media-registered" data-instgrm-captioned="" data-instgrm-version="6" style="width:99.375%; width:-webkit-calc(100% - 2px); width:calc(100% - 2px);" id="instagram-media-payload-1"><p><a href="https://www.instagram.com/p/https://www.instagram.com/p/B9eFDo8loNp/?utm_source=ig_embed&amp;utm_campaign=loading/" target="_blank" data-component-tracked="1" class="hawk-link-parsed"></a></p><p>A photo posted by on </p></blockquote></div><p>Under-pressure Bournemouth boss Eddie Howe is trying to remain confident despite just three victories in 18 league matches leaving them mired in relegation trouble.</p><p>“The last six games we have been a lot better, back to creating goals, looking a lot better. But ultimately, at this stage of the season with games running out it is about points and I would take points over performances,” he said.</p><p>“You saw a team that was very motivated and hungry to do well, with quality as well.</p><p>“We have to take that confidence and use it.”</p>\n' +
                '<div class="onesignal-customlink-container" data-cl-initialized="true"><p class="onesignal-customlink-explanation onesignal-reset state-unsubscribed large">Get updates from all sorts of things that matter to you</p><button class="onesignal-customlink-subscribe onesignal-reset state-unsubscribed button large" data-cl-state="false" data-cl-optedout="false" data-cl-initialized="true" style="background-color: rgb(174, 16, 6); color: rgb(255, 255, 255);">Subscribe to push notifications</button></div>\n' +
                '</div>',
            image: "https://icdn.football-espana.net/wp-content/uploads/2020/11/merlin_153612873_5bb119b9-8972-4087-b4fd-371cab8c5ba2-superJumbo.jpg",
            video: {
                source : 'youtube',
                id : 'v3dclL2grbs'
            },
            date : '12 décembre 2020'
        },
        {
            title: "Demo Sport 2",
            content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis a tristique felis, quis ornare odio. Praesent tempus massa ut aliquet vulputate. Nunc et ipsum posuere, ultricies sem sed, aliquet neque. Sed a gravida neque, ac fermentum diam. Cras sagittis libero non elit volutpat facilisis. Integer a nisl quis nunc imperdiet sodales. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; In accumsan euismod sem, sit amet condimentum neque tincidunt non. Nunc egestas sit amet quam nec scelerisque. Curabitur sed interdum libero. Cras iaculis sed ante sagittis gravida. Nam maximus eleifend porttitor. Quisque facilisis quam non elit sollicitudin facilisis. Nam maximus elit sed molestie lacinia.\n' +
                '\n' +
                'Nulla fringilla sed felis eget semper. Fusce ut velit ornare, ullamcorper magna ac, tincidunt nulla. Duis vehicula lorem vel justo finibus aliquet. Proin venenatis, elit eu hendrerit malesuada, augue augue molestie sapien, quis feugiat ipsum nisl laoreet felis. Curabitur vulputate ut lectus eget bibendum. Nullam accumsan sit amet dui nec tempor. Phasellus quis orci facilisis, interdum magna vel, fringilla tortor. Donec vehicula hendrerit lacus nec lacinia. Donec rutrum, orci dapibus luctus tristique, ante augue pellentesque nulla, id ornare lectus ex id urna. Aliquam sapien ex, tincidunt sit amet vehicula vel, fermentum sit amet nisi. Vivamus nec sem diam. Donec blandit elit lorem, eget commodo nunc ultrices vel.\n' +
                '\n' +
                'Morbi sollicitudin, velit nec accumsan convallis, diam risus imperdiet ligula, a dapibus nibh nisl a quam. Pellentesque dui nulla, pulvinar vitae imperdiet nec, consectetur eget odio. Ut ac bibendum mauris. In nec lacus ac massa venenatis congue eu a neque. Integer ac fringilla libero. Nulla facilisi. Maecenas efficitur mollis tempor.\n' +
                '\n' +
                'Phasellus bibendum euismod urna elementum maximus. Aenean non neque purus. Pellentesque placerat commodo sapien, eu auctor sapien laoreet ut. Etiam tellus odio, scelerisque ac felis a, finibus blandit dui. Praesent semper, quam in placerat semper, ex elit commodo erat, sit amet aliquet risus erat in velit. Quisque non nibh libero. Quisque bibendum ex ut lobortis venenatis. Proin viverra velit at purus fermentum, a scelerisque lacus pellentesque. Maecenas sapien elit, pharetra egestas lectus eu, varius rhoncus massa. Praesent et turpis vitae arcu dictum suscipit. In eu leo et elit sagittis porta sit amet non nisl. Mauris quis luctus diam. Integer semper ultricies eros, a imperdiet massa mollis et.\n' +
                '\n' +
                'Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed rutrum ornare lorem non consectetur. Quisque egestas odio id eros tincidunt luctus. Proin sit amet sapien sed urna interdum dictum maximus vel nunc. Aliquam arcu velit, pellentesque quis eleifend nec, ornare vitae nulla. Donec non commodo ligula. Cras sit amet mi feugiat sapien tincidunt bibendum ut tristique eros. Interdum et malesuada fames ac ante ipsum primis in faucibus.',
            image: "https://images.theconversation.com/files/202542/original/file-20180119-80200-1lvcufx.jpg?ixlib=rb-1.1.0&q=45&auto=format&w=1200&h=1200.0&fit=crop",
            video: null,
            date : '12 décembre 2020'
        },
        {
            title: "Demo Sport 3",
            content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis a tristique felis, quis ornare odio. Praesent tempus massa ut aliquet vulputate. Nunc et ipsum posuere, ultricies sem sed, aliquet neque. Sed a gravida neque, ac fermentum diam. Cras sagittis libero non elit volutpat facilisis. Integer a nisl quis nunc imperdiet sodales. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; In accumsan euismod sem, sit amet condimentum neque tincidunt non. Nunc egestas sit amet quam nec scelerisque. Curabitur sed interdum libero. Cras iaculis sed ante sagittis gravida. Nam maximus eleifend porttitor. Quisque facilisis quam non elit sollicitudin facilisis. Nam maximus elit sed molestie lacinia.\n' +
                '\n' +
                'Nulla fringilla sed felis eget semper. Fusce ut velit ornare, ullamcorper magna ac, tincidunt nulla. Duis vehicula lorem vel justo finibus aliquet. Proin venenatis, elit eu hendrerit malesuada, augue augue molestie sapien, quis feugiat ipsum nisl laoreet felis. Curabitur vulputate ut lectus eget bibendum. Nullam accumsan sit amet dui nec tempor. Phasellus quis orci facilisis, interdum magna vel, fringilla tortor. Donec vehicula hendrerit lacus nec lacinia. Donec rutrum, orci dapibus luctus tristique, ante augue pellentesque nulla, id ornare lectus ex id urna. Aliquam sapien ex, tincidunt sit amet vehicula vel, fermentum sit amet nisi. Vivamus nec sem diam. Donec blandit elit lorem, eget commodo nunc ultrices vel.\n' +
                '\n' +
                'Morbi sollicitudin, velit nec accumsan convallis, diam risus imperdiet ligula, a dapibus nibh nisl a quam. Pellentesque dui nulla, pulvinar vitae imperdiet nec, consectetur eget odio. Ut ac bibendum mauris. In nec lacus ac massa venenatis congue eu a neque. Integer ac fringilla libero. Nulla facilisi. Maecenas efficitur mollis tempor.\n' +
                '\n' +
                'Phasellus bibendum euismod urna elementum maximus. Aenean non neque purus. Pellentesque placerat commodo sapien, eu auctor sapien laoreet ut. Etiam tellus odio, scelerisque ac felis a, finibus blandit dui. Praesent semper, quam in placerat semper, ex elit commodo erat, sit amet aliquet risus erat in velit. Quisque non nibh libero. Quisque bibendum ex ut lobortis venenatis. Proin viverra velit at purus fermentum, a scelerisque lacus pellentesque. Maecenas sapien elit, pharetra egestas lectus eu, varius rhoncus massa. Praesent et turpis vitae arcu dictum suscipit. In eu leo et elit sagittis porta sit amet non nisl. Mauris quis luctus diam. Integer semper ultricies eros, a imperdiet massa mollis et.\n' +
                '\n' +
                'Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed rutrum ornare lorem non consectetur. Quisque egestas odio id eros tincidunt luctus. Proin sit amet sapien sed urna interdum dictum maximus vel nunc. Aliquam arcu velit, pellentesque quis eleifend nec, ornare vitae nulla. Donec non commodo ligula. Cras sit amet mi feugiat sapien tincidunt bibendum ut tristique eros. Interdum et malesuada fames ac ante ipsum primis in faucibus.',
            image: "https://images.theconversation.com/files/202542/original/file-20180119-80200-1lvcufx.jpg?ixlib=rb-1.1.0&q=45&auto=format&w=1200&h=1200.0&fit=crop",
            video: null,
            date : '12 décembre 2020'
        },
        {
            title: "Demo Sport 4 (image)",
            content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis a tristique felis, quis ornare odio. Praesent tempus massa ut aliquet vulputate. Nunc et ipsum posuere, ultricies sem sed, aliquet neque. Sed a gravida neque, ac fermentum diam. Cras sagittis libero non elit volutpat facilisis. Integer a nisl quis nunc imperdiet sodales. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; In accumsan euismod sem, sit amet condimentum neque tincidunt non. Nunc egestas sit amet quam nec scelerisque. Curabitur sed interdum libero. Cras iaculis sed ante sagittis gravida. Nam maximus eleifend porttitor. Quisque facilisis quam non elit sollicitudin facilisis. Nam maximus elit sed molestie lacinia.\n' +
                '\n' +
                'Nulla fringilla sed felis eget semper. Fusce ut velit ornare, ullamcorper magna ac, tincidunt nulla. Duis vehicula lorem vel justo finibus aliquet. Proin venenatis, elit eu hendrerit malesuada, augue augue molestie sapien, quis feugiat ipsum nisl laoreet felis. Curabitur vulputate ut lectus eget bibendum. Nullam accumsan sit amet dui nec tempor. Phasellus quis orci facilisis, interdum magna vel, fringilla tortor. Donec vehicula hendrerit lacus nec lacinia. Donec rutrum, orci dapibus luctus tristique, ante augue pellentesque nulla, id ornare lectus ex id urna. Aliquam sapien ex, tincidunt sit amet vehicula vel, fermentum sit amet nisi. Vivamus nec sem diam. Donec blandit elit lorem, eget commodo nunc ultrices vel.\n' +
                '\n' +
                'Morbi sollicitudin, velit nec accumsan convallis, diam risus imperdiet ligula, a dapibus nibh nisl a quam. Pellentesque dui nulla, pulvinar vitae imperdiet nec, consectetur eget odio. Ut ac bibendum mauris. In nec lacus ac massa venenatis congue eu a neque. Integer ac fringilla libero. Nulla facilisi. Maecenas efficitur mollis tempor.\n' +
                '\n' +
                'Phasellus bibendum euismod urna elementum maximus. Aenean non neque purus. Pellentesque placerat commodo sapien, eu auctor sapien laoreet ut. Etiam tellus odio, scelerisque ac felis a, finibus blandit dui. Praesent semper, quam in placerat semper, ex elit commodo erat, sit amet aliquet risus erat in velit. Quisque non nibh libero. Quisque bibendum ex ut lobortis venenatis. Proin viverra velit at purus fermentum, a scelerisque lacus pellentesque. Maecenas sapien elit, pharetra egestas lectus eu, varius rhoncus massa. Praesent et turpis vitae arcu dictum suscipit. In eu leo et elit sagittis porta sit amet non nisl. Mauris quis luctus diam. Integer semper ultricies eros, a imperdiet massa mollis et.\n' +
                '\n' +
                'Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed rutrum ornare lorem non consectetur. Quisque egestas odio id eros tincidunt luctus. Proin sit amet sapien sed urna interdum dictum maximus vel nunc. Aliquam arcu velit, pellentesque quis eleifend nec, ornare vitae nulla. Donec non commodo ligula. Cras sit amet mi feugiat sapien tincidunt bibendum ut tristique eros. Interdum et malesuada fames ac ante ipsum primis in faucibus.',
            image: "https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/20200407144605-2-2-1586272081.jpg",
            video: null,
            date : '12 décembre 2020'
        },
        {
            title: "Demo Sport 5",
            content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis a tristique felis, quis ornare odio. Praesent tempus massa ut aliquet vulputate. Nunc et ipsum posuere, ultricies sem sed, aliquet neque. Sed a gravida neque, ac fermentum diam. Cras sagittis libero non elit volutpat facilisis. Integer a nisl quis nunc imperdiet sodales. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; In accumsan euismod sem, sit amet condimentum neque tincidunt non. Nunc egestas sit amet quam nec scelerisque. Curabitur sed interdum libero. Cras iaculis sed ante sagittis gravida. Nam maximus eleifend porttitor. Quisque facilisis quam non elit sollicitudin facilisis. Nam maximus elit sed molestie lacinia.\n' +
                '\n' +
                'Nulla fringilla sed felis eget semper. Fusce ut velit ornare, ullamcorper magna ac, tincidunt nulla. Duis vehicula lorem vel justo finibus aliquet. Proin venenatis, elit eu hendrerit malesuada, augue augue molestie sapien, quis feugiat ipsum nisl laoreet felis. Curabitur vulputate ut lectus eget bibendum. Nullam accumsan sit amet dui nec tempor. Phasellus quis orci facilisis, interdum magna vel, fringilla tortor. Donec vehicula hendrerit lacus nec lacinia. Donec rutrum, orci dapibus luctus tristique, ante augue pellentesque nulla, id ornare lectus ex id urna. Aliquam sapien ex, tincidunt sit amet vehicula vel, fermentum sit amet nisi. Vivamus nec sem diam. Donec blandit elit lorem, eget commodo nunc ultrices vel.\n' +
                '\n' +
                'Morbi sollicitudin, velit nec accumsan convallis, diam risus imperdiet ligula, a dapibus nibh nisl a quam. Pellentesque dui nulla, pulvinar vitae imperdiet nec, consectetur eget odio. Ut ac bibendum mauris. In nec lacus ac massa venenatis congue eu a neque. Integer ac fringilla libero. Nulla facilisi. Maecenas efficitur mollis tempor.\n' +
                '\n' +
                'Phasellus bibendum euismod urna elementum maximus. Aenean non neque purus. Pellentesque placerat commodo sapien, eu auctor sapien laoreet ut. Etiam tellus odio, scelerisque ac felis a, finibus blandit dui. Praesent semper, quam in placerat semper, ex elit commodo erat, sit amet aliquet risus erat in velit. Quisque non nibh libero. Quisque bibendum ex ut lobortis venenatis. Proin viverra velit at purus fermentum, a scelerisque lacus pellentesque. Maecenas sapien elit, pharetra egestas lectus eu, varius rhoncus massa. Praesent et turpis vitae arcu dictum suscipit. In eu leo et elit sagittis porta sit amet non nisl. Mauris quis luctus diam. Integer semper ultricies eros, a imperdiet massa mollis et.\n' +
                '\n' +
                'Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed rutrum ornare lorem non consectetur. Quisque egestas odio id eros tincidunt luctus. Proin sit amet sapien sed urna interdum dictum maximus vel nunc. Aliquam arcu velit, pellentesque quis eleifend nec, ornare vitae nulla. Donec non commodo ligula. Cras sit amet mi feugiat sapien tincidunt bibendum ut tristique eros. Interdum et malesuada fames ac ante ipsum primis in faucibus.',
            image: "https://i.guim.co.uk/img/media/2d5590652f33929b1bd00c0edfd0674f35137b77/0_202_3892_2336/master/3892.jpg?width=1200&quality=85&auto=format&fit=max&s=3230b38aa20b8dc3f4956a90c812177f",
            video: null,
            date : '12 décembre 2020'
        },
        {
            title: "Demo Sport 6",
            content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis a tristique felis, quis ornare odio. Praesent tempus massa ut aliquet vulputate. Nunc et ipsum posuere, ultricies sem sed, aliquet neque. Sed a gravida neque, ac fermentum diam. Cras sagittis libero non elit volutpat facilisis. Integer a nisl quis nunc imperdiet sodales. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; In accumsan euismod sem, sit amet condimentum neque tincidunt non. Nunc egestas sit amet quam nec scelerisque. Curabitur sed interdum libero. Cras iaculis sed ante sagittis gravida. Nam maximus eleifend porttitor. Quisque facilisis quam non elit sollicitudin facilisis. Nam maximus elit sed molestie lacinia.\n' +
                '\n' +
                'Nulla fringilla sed felis eget semper. Fusce ut velit ornare, ullamcorper magna ac, tincidunt nulla. Duis vehicula lorem vel justo finibus aliquet. Proin venenatis, elit eu hendrerit malesuada, augue augue molestie sapien, quis feugiat ipsum nisl laoreet felis. Curabitur vulputate ut lectus eget bibendum. Nullam accumsan sit amet dui nec tempor. Phasellus quis orci facilisis, interdum magna vel, fringilla tortor. Donec vehicula hendrerit lacus nec lacinia. Donec rutrum, orci dapibus luctus tristique, ante augue pellentesque nulla, id ornare lectus ex id urna. Aliquam sapien ex, tincidunt sit amet vehicula vel, fermentum sit amet nisi. Vivamus nec sem diam. Donec blandit elit lorem, eget commodo nunc ultrices vel.\n' +
                '\n' +
                'Morbi sollicitudin, velit nec accumsan convallis, diam risus imperdiet ligula, a dapibus nibh nisl a quam. Pellentesque dui nulla, pulvinar vitae imperdiet nec, consectetur eget odio. Ut ac bibendum mauris. In nec lacus ac massa venenatis congue eu a neque. Integer ac fringilla libero. Nulla facilisi. Maecenas efficitur mollis tempor.\n' +
                '\n' +
                'Phasellus bibendum euismod urna elementum maximus. Aenean non neque purus. Pellentesque placerat commodo sapien, eu auctor sapien laoreet ut. Etiam tellus odio, scelerisque ac felis a, finibus blandit dui. Praesent semper, quam in placerat semper, ex elit commodo erat, sit amet aliquet risus erat in velit. Quisque non nibh libero. Quisque bibendum ex ut lobortis venenatis. Proin viverra velit at purus fermentum, a scelerisque lacus pellentesque. Maecenas sapien elit, pharetra egestas lectus eu, varius rhoncus massa. Praesent et turpis vitae arcu dictum suscipit. In eu leo et elit sagittis porta sit amet non nisl. Mauris quis luctus diam. Integer semper ultricies eros, a imperdiet massa mollis et.\n' +
                '\n' +
                'Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed rutrum ornare lorem non consectetur. Quisque egestas odio id eros tincidunt luctus. Proin sit amet sapien sed urna interdum dictum maximus vel nunc. Aliquam arcu velit, pellentesque quis eleifend nec, ornare vitae nulla. Donec non commodo ligula. Cras sit amet mi feugiat sapien tincidunt bibendum ut tristique eros. Interdum et malesuada fames ac ante ipsum primis in faucibus.',
            image: "https://cdn.vox-cdn.com/thumbor/_YnNALdcK9wB7saMR1Sk0Q1eZZU=/0x0:4411x2941/1200x800/filters:focal(1854x1119:2558x1823)/cdn.vox-cdn.com/uploads/chorus_image/image/66088233/1149689772.jpg.0.jpg",
            video: null,
            date : '12 décembre 2020'
        },
    ],
    buzz : [
        {
            title: "Chutes de neige et averses orageuses localement fortes du mercredi au jeudi dans plusieurs provinces (Bulletin spécial)",
            content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis a tristique felis, quis ornare odio. Praesent tempus massa ut aliquet vulputate. Nunc et ipsum posuere, ultricies sem sed, aliquet neque. Sed a gravida neque, ac fermentum diam. Cras sagittis libero non elit volutpat facilisis. Integer a nisl quis nunc imperdiet sodales. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; In accumsan euismod sem, sit amet condimentum neque tincidunt non. Nunc egestas sit amet quam nec scelerisque. Curabitur sed interdum libero. Cras iaculis sed ante sagittis gravida. Nam maximus eleifend porttitor. Quisque facilisis quam non elit sollicitudin facilisis. Nam maximus elit sed molestie lacinia.\n' +
                '\n' +
                'Nulla fringilla sed felis eget semper. Fusce ut velit ornare, ullamcorper magna ac, tincidunt nulla. Duis vehicula lorem vel justo finibus aliquet. Proin venenatis, elit eu hendrerit malesuada, augue augue molestie sapien, quis feugiat ipsum nisl laoreet felis. Curabitur vulputate ut lectus eget bibendum. Nullam accumsan sit amet dui nec tempor. Phasellus quis orci facilisis, interdum magna vel, fringilla tortor. Donec vehicula hendrerit lacus nec lacinia. Donec rutrum, orci dapibus luctus tristique, ante augue pellentesque nulla, id ornare lectus ex id urna. Aliquam sapien ex, tincidunt sit amet vehicula vel, fermentum sit amet nisi. Vivamus nec sem diam. Donec blandit elit lorem, eget commodo nunc ultrices vel.\n' +
                '\n' +
                'Morbi sollicitudin, velit nec accumsan convallis, diam risus imperdiet ligula, a dapibus nibh nisl a quam. Pellentesque dui nulla, pulvinar vitae imperdiet nec, consectetur eget odio. Ut ac bibendum mauris. In nec lacus ac massa venenatis congue eu a neque. Integer ac fringilla libero. Nulla facilisi. Maecenas efficitur mollis tempor.\n' +
                '\n' +
                'Phasellus bibendum euismod urna elementum maximus. Aenean non neque purus. Pellentesque placerat commodo sapien, eu auctor sapien laoreet ut. Etiam tellus odio, scelerisque ac felis a, finibus blandit dui. Praesent semper, quam in placerat semper, ex elit commodo erat, sit amet aliquet risus erat in velit. Quisque non nibh libero. Quisque bibendum ex ut lobortis venenatis. Proin viverra velit at purus fermentum, a scelerisque lacus pellentesque. Maecenas sapien elit, pharetra egestas lectus eu, varius rhoncus massa. Praesent et turpis vitae arcu dictum suscipit. In eu leo et elit sagittis porta sit amet non nisl. Mauris quis luctus diam. Integer semper ultricies eros, a imperdiet massa mollis et.\n' +
                '\n' +
                'Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed rutrum ornare lorem non consectetur. Quisque egestas odio id eros tincidunt luctus. Proin sit amet sapien sed urna interdum dictum maximus vel nunc. Aliquam arcu velit, pellentesque quis eleifend nec, ornare vitae nulla. Donec non commodo ligula. Cras sit amet mi feugiat sapien tincidunt bibendum ut tristique eros. Interdum et malesuada fames ac ante ipsum primis in faucibus.',
            image: "https://s.france24.com/media/display/d437c532-12a9-11e9-b161-005056bff430/w:1280/p:16x9/1702-othmani-m.webp",
            video: {
                source : 'youtube',
                id : '_1GBE1o7eE4'
            },
            date : '12 décembre 2020'
        },
        {
            title: "Prévisions météorologiques pour la journée du mercredi 16 décembre 2020",
            content: 'Rabat - Voici les prévisions météorologiques pour la journée du mercredi 16 décembre 2020, établies par la Direction générale de la météorologie:\n' +
                '\n' +
                '- Temps nuageux avec pluies ou averses par endroits et par moments sur les côtes et les plaines atlantique au Nord d\'Essaouira.\n' +
                '\n' +
                '- Temps demeurant passagèrement nuageux le Jeudi avec faibles pluies ou gouttes éparses sur le Nord-Ouest, le Saiss, l’Atlas et l’Oriental.\n' +
                '\n' +
                '- Pluie se généralisera à partir de la soirée sur les plaines au Nord d’Agadir, le Rif, la méditerranée, L’Atlas, le Saiss, l’Oriental et les reste des régions situées à l’ouest de l’Atlas.\n' +
                '\n' +
                '- Temps nuageux la seconde partie de la nuit sur les côtes centre avec faibles pluies éparses entre Agadir et Tarfaya.\n' +
                '\n' +
                '- Chutes de neige sur le Haut et Moyen Atlas.\n' +
                '\n' +
                '- Temps assez froid les nuits et les matinées sur les reliefs et les Hauts plateaux.\n' +
                '\n' +
                '- Rafales de vent parfois assez fortes par endroits sur les cotes Nord.\n' +
                '\n' +
                '- Températures minimales de l’ordre de 00/05°C sur l’Atlas, 05/10°C sur le Rif, l’Oriental, les plateaux des phosphates et d’Oulmès et le Sud-Est et de 11/16°C sur le Nord, le Centre et les provinces Sud.\n' +
                '\n' +
                '- Mer belle à peu agitée sur la mediterranée, peu agitée à agitée sur le Détroit, peu agitée à agitée entre Trafaya et Laayoune et agitée à forte ailleurs.\n' +
                '\n' +
                '- Températures maximales de l’ordre de 11/16°C sur les reliefs, 16/22°C sur le Saiss, l’Oriental, le littoral Méditerranéen, les plateaux des phosphates et d’Oulmès, le Nord, le Centre, le Sud-Est et le Souss et de 22/27°C sur le Sud.\n' +
                '\n' +
                'Mer belle à peu agitée sur la Méditerranée et sur l\'est du Détroit, peu agitée à agitée sur l\'ouest, peu agitée à agitée sur les côtes atlantiques entre Tarfaya et Laâyoune et agitée à forte partout ailleurs.',
            image: "https://www.almanac.com/sites/default/files/image_nodes/rainbow-weather.jpg",
            video: {
                source : 'youtube',
                id : '_1GBE1o7eE4'
            },
            date : '12 décembre 2020'
        },
        {
            title: "Le 1er Joumada I de l’an 1442 de l’Hégire correspondra au mercredi 16 décembre",
            content: 'Rabat - Voici les prévisions météorologiques pour la journée du mercredi 16 décembre 2020, établies par la Direction générale de la météorologie:\n' +
                '\n' +
                '- Temps nuageux avec pluies ou averses par endroits et par moments sur les côtes et les plaines atlantique au Nord d\'Essaouira.\n' +
                '\n' +
                '- Temps demeurant passagèrement nuageux le Jeudi avec faibles pluies ou gouttes éparses sur le Nord-Ouest, le Saiss, l’Atlas et l’Oriental.\n' +
                '\n' +
                '- Pluie se généralisera à partir de la soirée sur les plaines au Nord d’Agadir, le Rif, la méditerranée, L’Atlas, le Saiss, l’Oriental et les reste des régions situées à l’ouest de l’Atlas.\n' +
                '\n' +
                '- Temps nuageux la seconde partie de la nuit sur les côtes centre avec faibles pluies éparses entre Agadir et Tarfaya.\n' +
                '\n' +
                '- Chutes de neige sur le Haut et Moyen Atlas.\n' +
                '\n' +
                '- Temps assez froid les nuits et les matinées sur les reliefs et les Hauts plateaux.\n' +
                '\n' +
                '- Rafales de vent parfois assez fortes par endroits sur les cotes Nord.\n' +
                '\n' +
                '- Températures minimales de l’ordre de 00/05°C sur l’Atlas, 05/10°C sur le Rif, l’Oriental, les plateaux des phosphates et d’Oulmès et le Sud-Est et de 11/16°C sur le Nord, le Centre et les provinces Sud.\n' +
                '\n' +
                '- Mer belle à peu agitée sur la mediterranée, peu agitée à agitée sur le Détroit, peu agitée à agitée entre Trafaya et Laayoune et agitée à forte ailleurs.\n' +
                '\n' +
                '- Températures maximales de l’ordre de 11/16°C sur les reliefs, 16/22°C sur le Saiss, l’Oriental, le littoral Méditerranéen, les plateaux des phosphates et d’Oulmès, le Nord, le Centre, le Sud-Est et le Souss et de 22/27°C sur le Sud.\n' +
                '\n' +
                'Mer belle à peu agitée sur la Méditerranée et sur l\'est du Détroit, peu agitée à agitée sur l\'ouest, peu agitée à agitée sur les côtes atlantiques entre Tarfaya et Laâyoune et agitée à forte partout ailleurs.',
            image: "https://i.pinimg.com/originals/d1/5d/2c/d15d2c17f8ba44f6e66205e6276c8b16.jpg",
            video: {
                source : 'youtube',
                id : '_1GBE1o7eE4'
            },
            date : '12 décembre 2020'
        },
        {
            title: "Demo news 1",
            content: 'Rabat - Voici les prévisions météorologiques pour la journée du mercredi 16 décembre 2020, établies par la Direction générale de la météorologie:\n' +
                '\n' +
                '- Temps nuageux avec pluies ou averses par endroits et par moments sur les côtes et les plaines atlantique au Nord d\'Essaouira.\n' +
                '\n' +
                '- Temps demeurant passagèrement nuageux le Jeudi avec faibles pluies ou gouttes éparses sur le Nord-Ouest, le Saiss, l’Atlas et l’Oriental.\n' +
                '\n' +
                '- Pluie se généralisera à partir de la soirée sur les plaines au Nord d’Agadir, le Rif, la méditerranée, L’Atlas, le Saiss, l’Oriental et les reste des régions situées à l’ouest de l’Atlas.\n' +
                '\n' +
                '- Temps nuageux la seconde partie de la nuit sur les côtes centre avec faibles pluies éparses entre Agadir et Tarfaya.\n' +
                '\n' +
                '- Chutes de neige sur le Haut et Moyen Atlas.\n' +
                '\n' +
                '- Temps assez froid les nuits et les matinées sur les reliefs et les Hauts plateaux.\n' +
                '\n' +
                '- Rafales de vent parfois assez fortes par endroits sur les cotes Nord.\n' +
                '\n' +
                '- Températures minimales de l’ordre de 00/05°C sur l’Atlas, 05/10°C sur le Rif, l’Oriental, les plateaux des phosphates et d’Oulmès et le Sud-Est et de 11/16°C sur le Nord, le Centre et les provinces Sud.\n' +
                '\n' +
                '- Mer belle à peu agitée sur la mediterranée, peu agitée à agitée sur le Détroit, peu agitée à agitée entre Trafaya et Laayoune et agitée à forte ailleurs.\n' +
                '\n' +
                '- Températures maximales de l’ordre de 11/16°C sur les reliefs, 16/22°C sur le Saiss, l’Oriental, le littoral Méditerranéen, les plateaux des phosphates et d’Oulmès, le Nord, le Centre, le Sud-Est et le Souss et de 22/27°C sur le Sud.\n' +
                '\n' +
                'Mer belle à peu agitée sur la Méditerranée et sur l\'est du Détroit, peu agitée à agitée sur l\'ouest, peu agitée à agitée sur les côtes atlantiques entre Tarfaya et Laâyoune et agitée à forte partout ailleurs.',
            image: "https://media.lesechos.com/api/v1/images/view/5e567c12d286c23cea3438f6/1280x720/6590-1479987998-maroc-temoignages.jpg",
            video: null,
            date : '12 décembre 2020'
        },
        {
            title: "Demo news 2",
            content: 'Rabat - Voici les prévisions météorologiques pour la journée du mercredi 16 décembre 2020, établies par la Direction générale de la météorologie:\n' +
                '\n' +
                '- Temps nuageux avec pluies ou averses par endroits et par moments sur les côtes et les plaines atlantique au Nord d\'Essaouira.\n' +
                '\n' +
                '- Temps demeurant passagèrement nuageux le Jeudi avec faibles pluies ou gouttes éparses sur le Nord-Ouest, le Saiss, l’Atlas et l’Oriental.\n' +
                '\n' +
                '- Pluie se généralisera à partir de la soirée sur les plaines au Nord d’Agadir, le Rif, la méditerranée, L’Atlas, le Saiss, l’Oriental et les reste des régions situées à l’ouest de l’Atlas.\n' +
                '\n' +
                '- Temps nuageux la seconde partie de la nuit sur les côtes centre avec faibles pluies éparses entre Agadir et Tarfaya.\n' +
                '\n' +
                '- Chutes de neige sur le Haut et Moyen Atlas.\n' +
                '\n' +
                '- Temps assez froid les nuits et les matinées sur les reliefs et les Hauts plateaux.\n' +
                '\n' +
                '- Rafales de vent parfois assez fortes par endroits sur les cotes Nord.\n' +
                '\n' +
                '- Températures minimales de l’ordre de 00/05°C sur l’Atlas, 05/10°C sur le Rif, l’Oriental, les plateaux des phosphates et d’Oulmès et le Sud-Est et de 11/16°C sur le Nord, le Centre et les provinces Sud.\n' +
                '\n' +
                '- Mer belle à peu agitée sur la mediterranée, peu agitée à agitée sur le Détroit, peu agitée à agitée entre Trafaya et Laayoune et agitée à forte ailleurs.\n' +
                '\n' +
                '- Températures maximales de l’ordre de 11/16°C sur les reliefs, 16/22°C sur le Saiss, l’Oriental, le littoral Méditerranéen, les plateaux des phosphates et d’Oulmès, le Nord, le Centre, le Sud-Est et le Souss et de 22/27°C sur le Sud.\n' +
                '\n' +
                'Mer belle à peu agitée sur la Méditerranée et sur l\'est du Détroit, peu agitée à agitée sur l\'ouest, peu agitée à agitée sur les côtes atlantiques entre Tarfaya et Laâyoune et agitée à forte partout ailleurs.',
            image: "https://www.lajauneetlarouge.com/wp-content/uploads/2014/11/AdobeStock_293248809.jpg",
            video: null,
            date : '12 décembre 2020'
        },
        {
            title: "Demo news 3",
            content: 'Rabat - Voici les prévisions météorologiques pour la journée du mercredi 16 décembre 2020, établies par la Direction générale de la météorologie:\n' +
                '\n' +
                '- Temps nuageux avec pluies ou averses par endroits et par moments sur les côtes et les plaines atlantique au Nord d\'Essaouira.\n' +
                '\n' +
                '- Temps demeurant passagèrement nuageux le Jeudi avec faibles pluies ou gouttes éparses sur le Nord-Ouest, le Saiss, l’Atlas et l’Oriental.\n' +
                '\n' +
                '- Pluie se généralisera à partir de la soirée sur les plaines au Nord d’Agadir, le Rif, la méditerranée, L’Atlas, le Saiss, l’Oriental et les reste des régions situées à l’ouest de l’Atlas.\n' +
                '\n' +
                '- Temps nuageux la seconde partie de la nuit sur les côtes centre avec faibles pluies éparses entre Agadir et Tarfaya.\n' +
                '\n' +
                '- Chutes de neige sur le Haut et Moyen Atlas.\n' +
                '\n' +
                '- Temps assez froid les nuits et les matinées sur les reliefs et les Hauts plateaux.\n' +
                '\n' +
                '- Rafales de vent parfois assez fortes par endroits sur les cotes Nord.\n' +
                '\n' +
                '- Températures minimales de l’ordre de 00/05°C sur l’Atlas, 05/10°C sur le Rif, l’Oriental, les plateaux des phosphates et d’Oulmès et le Sud-Est et de 11/16°C sur le Nord, le Centre et les provinces Sud.\n' +
                '\n' +
                '- Mer belle à peu agitée sur la mediterranée, peu agitée à agitée sur le Détroit, peu agitée à agitée entre Trafaya et Laayoune et agitée à forte ailleurs.\n' +
                '\n' +
                '- Températures maximales de l’ordre de 11/16°C sur les reliefs, 16/22°C sur le Saiss, l’Oriental, le littoral Méditerranéen, les plateaux des phosphates et d’Oulmès, le Nord, le Centre, le Sud-Est et le Souss et de 22/27°C sur le Sud.\n' +
                '\n' +
                'Mer belle à peu agitée sur la Méditerranée et sur l\'est du Détroit, peu agitée à agitée sur l\'ouest, peu agitée à agitée sur les côtes atlantiques entre Tarfaya et Laâyoune et agitée à forte partout ailleurs.',
            image: "https://s.france24.com/media/display/0f730b6c-e34a-11ea-95fa-005056a964fe/w:1280/p:16x9/000_1WN09F.webp",
            video: null,
            date : '12 décembre 2020'
        },
        {
            title: "Demo news 4",
            content: 'Rabat - Voici les prévisions météorologiques pour la journée du mercredi 16 décembre 2020, établies par la Direction générale de la météorologie:\n' +
                '\n' +
                '- Temps nuageux avec pluies ou averses par endroits et par moments sur les côtes et les plaines atlantique au Nord d\'Essaouira.\n' +
                '\n' +
                '- Temps demeurant passagèrement nuageux le Jeudi avec faibles pluies ou gouttes éparses sur le Nord-Ouest, le Saiss, l’Atlas et l’Oriental.\n' +
                '\n' +
                '- Pluie se généralisera à partir de la soirée sur les plaines au Nord d’Agadir, le Rif, la méditerranée, L’Atlas, le Saiss, l’Oriental et les reste des régions situées à l’ouest de l’Atlas.\n' +
                '\n' +
                '- Temps nuageux la seconde partie de la nuit sur les côtes centre avec faibles pluies éparses entre Agadir et Tarfaya.\n' +
                '\n' +
                '- Chutes de neige sur le Haut et Moyen Atlas.\n' +
                '\n' +
                '- Temps assez froid les nuits et les matinées sur les reliefs et les Hauts plateaux.\n' +
                '\n' +
                '- Rafales de vent parfois assez fortes par endroits sur les cotes Nord.\n' +
                '\n' +
                '- Températures minimales de l’ordre de 00/05°C sur l’Atlas, 05/10°C sur le Rif, l’Oriental, les plateaux des phosphates et d’Oulmès et le Sud-Est et de 11/16°C sur le Nord, le Centre et les provinces Sud.\n' +
                '\n' +
                '- Mer belle à peu agitée sur la mediterranée, peu agitée à agitée sur le Détroit, peu agitée à agitée entre Trafaya et Laayoune et agitée à forte ailleurs.\n' +
                '\n' +
                '- Températures maximales de l’ordre de 11/16°C sur les reliefs, 16/22°C sur le Saiss, l’Oriental, le littoral Méditerranéen, les plateaux des phosphates et d’Oulmès, le Nord, le Centre, le Sud-Est et le Souss et de 22/27°C sur le Sud.\n' +
                '\n' +
                'Mer belle à peu agitée sur la Méditerranée et sur l\'est du Détroit, peu agitée à agitée sur l\'ouest, peu agitée à agitée sur les côtes atlantiques entre Tarfaya et Laâyoune et agitée à forte partout ailleurs.',
            image: "https://s.rfi.fr/media/display/ce54cfe4-3858-11eb-a942-005056a964fe/w:1280/p:16x9/maroc-coronavirus-mosquee-volontaires.webp",
            video: null,
            date : '12 décembre 2020'
        },
    ],
    videos : [
        {
            title : 'Quatre questions à Marc Vanheukelen, premier ambassadeur de l\'Union européenne pour le climat',
            content : '',
            image : 'https://img.youtube.com/vi/swqJgr-Qh8k/0.jpg',
            video: {
                source : 'youtube',
                id : 'swqJgr-Qh8k',
            }
        },
        {
            title : 'Mise en relief en Australie du rôle de SM le Roi Mohammed VI dans la promotion d\'un Islam modéré',
            content : '',
            image : 'https://img.youtube.com/vi/JUyAqbBKI8s/0.jpg',
            video: {
                source : 'youtube',
                id : 'JUyAqbBKI8s',
            }
        },
        {
            title : 'La reconnaissance US de la marocanité du Sahara, une "décision historique" qui renforcera la paix dans la région (Ambassadeur)',
            content : '',
            image : 'https://img.youtube.com/vi/eVKMFcMEAPE/0.jpg',
            video: {
                source : 'youtube',
                id : 'eVKMFcMEAPE',
            }
        },
        {
            title : 'Le Maroc participe à la 40è session du Conseil des ministres arabes des affaires sociales',
            content : '',
            image : 'https://img.youtube.com/vi/HzcCmyY2D9o/0.jpg',
            video: {
                source : 'youtube',
                id : 'HzcCmyY2D9o',
            }
        },
        {
            title : 'L\'ambassade de Hongrie organise une exposition photographique à l’USCM afin de promouvoir le Water polo',
            content : '',
            image : 'https://img.youtube.com/vi/3NlP5AQq3V8/0.jpg',
            video: {
                source : 'youtube',
                id : '3NlP5AQq3V8',
            }
        },
        {
            title : 'Taekwondo : l\'équipe nationale en stage de préparation en France jusqu\'au 23 janvier',
            content : '',
            image : 'https://img.youtube.com/vi/gVPjw2UXXCI/0.jpg',
            video: {
                source : 'youtube',
                id : 'gVPjw2UXXCI',
            }
        },
        {
            title : 'Le ministère chargé des MRE veille à assurer la convergence et l\'efficacité dans le traitement des plaintes des MRE',
            content : '',
            image : 'https://img.youtube.com/vi/RmGQLDPGT0E/0.jpg',
            video: {
                source : 'youtube',
                id : 'RmGQLDPGT0E',
            }
        },
        {
            title : 'Campagne de vaccination anti-Covid-19 : Mode opératoire',
            content : '',
            image : 'https://img.youtube.com/vi/EGIa6CwqPUU/0.jpg',
            video: {
                source : 'youtube',
                id : 'EGIa6CwqPUU',
            }
        },
    ],
    sorted : [
        {
            title: "Son Altesse la Princesse Lalla Zineb reçoit le Président du Ministère Public",
            exerpt: "Rabat - Son Altesse la Princesse Lalla Zineb, Présidente de la Ligue Marocaine pour la Protection de l’Enfance (LMPE), a reçu..",
            content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis a tristique felis, quis ornare odio. Praesent tempus massa ut aliquet vulputate. Nunc et ipsum posuere, ultricies sem sed, aliquet neque. Sed a gravida neque, ac fermentum diam. Cras sagittis libero non elit volutpat facilisis. Integer a nisl quis nunc imperdiet sodales. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; In accumsan euismod sem, sit amet condimentum neque tincidunt non. Nunc egestas sit amet quam nec scelerisque. Curabitur sed interdum libero. Cras iaculis sed ante sagittis gravida. Nam maximus eleifend porttitor. Quisque facilisis quam non elit sollicitudin facilisis. Nam maximus elit sed molestie lacinia.\n' +
                '\n' +
                'Nulla fringilla sed felis eget semper. Fusce ut velit ornare, ullamcorper magna ac, tincidunt nulla. Duis vehicula lorem vel justo finibus aliquet. Proin venenatis, elit eu hendrerit malesuada, augue augue molestie sapien, quis feugiat ipsum nisl laoreet felis. Curabitur vulputate ut lectus eget bibendum. Nullam accumsan sit amet dui nec tempor. Phasellus quis orci facilisis, interdum magna vel, fringilla tortor. Donec vehicula hendrerit lacus nec lacinia. Donec rutrum, orci dapibus luctus tristique, ante augue pellentesque nulla, id ornare lectus ex id urna. Aliquam sapien ex, tincidunt sit amet vehicula vel, fermentum sit amet nisi. Vivamus nec sem diam. Donec blandit elit lorem, eget commodo nunc ultrices vel.\n' +
                '\n' +
                'Morbi sollicitudin, velit nec accumsan convallis, diam risus imperdiet ligula, a dapibus nibh nisl a quam. Pellentesque dui nulla, pulvinar vitae imperdiet nec, consectetur eget odio. Ut ac bibendum mauris. In nec lacus ac massa venenatis congue eu a neque. Integer ac fringilla libero. Nulla facilisi. Maecenas efficitur mollis tempor.\n' +
                '\n' +
                'Phasellus bibendum euismod urna elementum maximus. Aenean non neque purus. Pellentesque placerat commodo sapien, eu auctor sapien laoreet ut. Etiam tellus odio, scelerisque ac felis a, finibus blandit dui. Praesent semper, quam in placerat semper, ex elit commodo erat, sit amet aliquet risus erat in velit. Quisque non nibh libero. Quisque bibendum ex ut lobortis venenatis. Proin viverra velit at purus fermentum, a scelerisque lacus pellentesque. Maecenas sapien elit, pharetra egestas lectus eu, varius rhoncus massa. Praesent et turpis vitae arcu dictum suscipit. In eu leo et elit sagittis porta sit amet non nisl. Mauris quis luctus diam. Integer semper ultricies eros, a imperdiet massa mollis et.\n' +
                '\n' +
                'Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed rutrum ornare lorem non consectetur. Quisque egestas odio id eros tincidunt luctus. Proin sit amet sapien sed urna interdum dictum maximus vel nunc. Aliquam arcu velit, pellentesque quis eleifend nec, ornare vitae nulla. Donec non commodo ligula. Cras sit amet mi feugiat sapien tincidunt bibendum ut tristique eros. Interdum et malesuada fames ac ante ipsum primis in faucibus.',
            image: "https://www.oncf.ma/var/oncf/storage/images/www-oncf-ma/actualites/son-altesse-la-princesse-lalla-zineb-preside-la-ceremonie-de-signature-d-une-convention-de-partenariat-entre-l-office-national-des-chemins-de-fer-et-la-ligue-marocaine-pour-la-protection-de-l-enfance/1081113-1-fre-FR/Son-altesse-la-princesse-lalla-zineb-preside-la-ceremonie-de-signature-d-une-convention-de-partenariat-entre-l-office-national-des-chemins-de-fer-e.jpg",
            video: null,
            date : '17 décembre 2020'
        },
        {
            title: "Les Etats-Unis informent le Conseil de sécurité et le SG de l'ONU de leur reconnaissance de la marocanité du Sahara",
            exerpt: "New York - L’ambassadrice, Représentante permanente des Etats-Unis auprès des Nations-Unies, Mme Kelly Craft..",
            content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis a tristique felis, quis ornare odio. Praesent tempus massa ut aliquet vulputate. Nunc et ipsum posuere, ultricies sem sed, aliquet neque. Sed a gravida neque, ac fermentum diam. Cras sagittis libero non elit volutpat facilisis. Integer a nisl quis nunc imperdiet sodales. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; In accumsan euismod sem, sit amet condimentum neque tincidunt non. Nunc egestas sit amet quam nec scelerisque. Curabitur sed interdum libero. Cras iaculis sed ante sagittis gravida. Nam maximus eleifend porttitor. Quisque facilisis quam non elit sollicitudin facilisis. Nam maximus elit sed molestie lacinia.\n' +
                '\n' +
                'Nulla fringilla sed felis eget semper. Fusce ut velit ornare, ullamcorper magna ac, tincidunt nulla. Duis vehicula lorem vel justo finibus aliquet. Proin venenatis, elit eu hendrerit malesuada, augue augue molestie sapien, quis feugiat ipsum nisl laoreet felis. Curabitur vulputate ut lectus eget bibendum. Nullam accumsan sit amet dui nec tempor. Phasellus quis orci facilisis, interdum magna vel, fringilla tortor. Donec vehicula hendrerit lacus nec lacinia. Donec rutrum, orci dapibus luctus tristique, ante augue pellentesque nulla, id ornare lectus ex id urna. Aliquam sapien ex, tincidunt sit amet vehicula vel, fermentum sit amet nisi. Vivamus nec sem diam. Donec blandit elit lorem, eget commodo nunc ultrices vel.\n' +
                '\n' +
                'Morbi sollicitudin, velit nec accumsan convallis, diam risus imperdiet ligula, a dapibus nibh nisl a quam. Pellentesque dui nulla, pulvinar vitae imperdiet nec, consectetur eget odio. Ut ac bibendum mauris. In nec lacus ac massa venenatis congue eu a neque. Integer ac fringilla libero. Nulla facilisi. Maecenas efficitur mollis tempor.\n' +
                '\n' +
                'Phasellus bibendum euismod urna elementum maximus. Aenean non neque purus. Pellentesque placerat commodo sapien, eu auctor sapien laoreet ut. Etiam tellus odio, scelerisque ac felis a, finibus blandit dui. Praesent semper, quam in placerat semper, ex elit commodo erat, sit amet aliquet risus erat in velit. Quisque non nibh libero. Quisque bibendum ex ut lobortis venenatis. Proin viverra velit at purus fermentum, a scelerisque lacus pellentesque. Maecenas sapien elit, pharetra egestas lectus eu, varius rhoncus massa. Praesent et turpis vitae arcu dictum suscipit. In eu leo et elit sagittis porta sit amet non nisl. Mauris quis luctus diam. Integer semper ultricies eros, a imperdiet massa mollis et.\n' +
                '\n' +
                'Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed rutrum ornare lorem non consectetur. Quisque egestas odio id eros tincidunt luctus. Proin sit amet sapien sed urna interdum dictum maximus vel nunc. Aliquam arcu velit, pellentesque quis eleifend nec, ornare vitae nulla. Donec non commodo ligula. Cras sit amet mi feugiat sapien tincidunt bibendum ut tristique eros. Interdum et malesuada fames ac ante ipsum primis in faucibus.',
            image: "https://static.timesofisrael.com/www/uploads/2019/11/830120.jpg",
            video: null,
            date : '17 décembre 2020'
        },
        {
            title: "Covid-19: 3.351 nouveaux cas confirmés et 3.924 guérisons en 24 heures (ministère)",
            exerpt: "Rabat - Un total de 3.351 nouveaux cas d'infection au coronavirus et de 3.924 guérisons..",
            content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis a tristique felis, quis ornare odio. Praesent tempus massa ut aliquet vulputate. Nunc et ipsum posuere, ultricies sem sed, aliquet neque. Sed a gravida neque, ac fermentum diam. Cras sagittis libero non elit volutpat facilisis. Integer a nisl quis nunc imperdiet sodales. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; In accumsan euismod sem, sit amet condimentum neque tincidunt non. Nunc egestas sit amet quam nec scelerisque. Curabitur sed interdum libero. Cras iaculis sed ante sagittis gravida. Nam maximus eleifend porttitor. Quisque facilisis quam non elit sollicitudin facilisis. Nam maximus elit sed molestie lacinia.\n' +
                '\n' +
                'Nulla fringilla sed felis eget semper. Fusce ut velit ornare, ullamcorper magna ac, tincidunt nulla. Duis vehicula lorem vel justo finibus aliquet. Proin venenatis, elit eu hendrerit malesuada, augue augue molestie sapien, quis feugiat ipsum nisl laoreet felis. Curabitur vulputate ut lectus eget bibendum. Nullam accumsan sit amet dui nec tempor. Phasellus quis orci facilisis, interdum magna vel, fringilla tortor. Donec vehicula hendrerit lacus nec lacinia. Donec rutrum, orci dapibus luctus tristique, ante augue pellentesque nulla, id ornare lectus ex id urna. Aliquam sapien ex, tincidunt sit amet vehicula vel, fermentum sit amet nisi. Vivamus nec sem diam. Donec blandit elit lorem, eget commodo nunc ultrices vel.\n' +
                '\n' +
                'Morbi sollicitudin, velit nec accumsan convallis, diam risus imperdiet ligula, a dapibus nibh nisl a quam. Pellentesque dui nulla, pulvinar vitae imperdiet nec, consectetur eget odio. Ut ac bibendum mauris. In nec lacus ac massa venenatis congue eu a neque. Integer ac fringilla libero. Nulla facilisi. Maecenas efficitur mollis tempor.\n' +
                '\n' +
                'Phasellus bibendum euismod urna elementum maximus. Aenean non neque purus. Pellentesque placerat commodo sapien, eu auctor sapien laoreet ut. Etiam tellus odio, scelerisque ac felis a, finibus blandit dui. Praesent semper, quam in placerat semper, ex elit commodo erat, sit amet aliquet risus erat in velit. Quisque non nibh libero. Quisque bibendum ex ut lobortis venenatis. Proin viverra velit at purus fermentum, a scelerisque lacus pellentesque. Maecenas sapien elit, pharetra egestas lectus eu, varius rhoncus massa. Praesent et turpis vitae arcu dictum suscipit. In eu leo et elit sagittis porta sit amet non nisl. Mauris quis luctus diam. Integer semper ultricies eros, a imperdiet massa mollis et.\n' +
                '\n' +
                'Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed rutrum ornare lorem non consectetur. Quisque egestas odio id eros tincidunt luctus. Proin sit amet sapien sed urna interdum dictum maximus vel nunc. Aliquam arcu velit, pellentesque quis eleifend nec, ornare vitae nulla. Donec non commodo ligula. Cras sit amet mi feugiat sapien tincidunt bibendum ut tristique eros. Interdum et malesuada fames ac ante ipsum primis in faucibus.',
            image: "https://feature.undp.org/covid-19-and-the-sdgs/assets/img/UNDP-Bangladesh-2020-COVID19-distribution-3161-optimized.jpg",
            video: null,
            date : '17 décembre 2020'
        },

    ],
    home : [
        {
            title: "Tanger: Un policier use de son arme pour interpeller un multirécidiviste ayant tenté d'agresser des citoyens (DGSN)",
            exerpt: "Rabat - Un fonctionnaire de police exerçant à l'unité mobile de la police de secours relevant de la préfecture de police de Tanger a été contraint de faire usage de son arme de service, jeudi matin, pour interpeller un multirécidiviste",
            content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis a tristique felis, quis ornare odio. Praesent tempus massa ut aliquet vulputate. Nunc et ipsum posuere, ultricies sem sed, aliquet neque. Sed a gravida neque, ac fermentum diam. Cras sagittis libero non elit volutpat facilisis. Integer a nisl quis nunc imperdiet sodales. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; In accumsan euismod sem, sit amet condimentum neque tincidunt non. Nunc egestas sit amet quam nec scelerisque. Curabitur sed interdum libero. Cras iaculis sed ante sagittis gravida. Nam maximus eleifend porttitor. Quisque facilisis quam non elit sollicitudin facilisis. Nam maximus elit sed molestie lacinia.\n' +
                '\n' +
                'Nulla fringilla sed felis eget semper. Fusce ut velit ornare, ullamcorper magna ac, tincidunt nulla. Duis vehicula lorem vel justo finibus aliquet. Proin venenatis, elit eu hendrerit malesuada, augue augue molestie sapien, quis feugiat ipsum nisl laoreet felis. Curabitur vulputate ut lectus eget bibendum. Nullam accumsan sit amet dui nec tempor. Phasellus quis orci facilisis, interdum magna vel, fringilla tortor. Donec vehicula hendrerit lacus nec lacinia. Donec rutrum, orci dapibus luctus tristique, ante augue pellentesque nulla, id ornare lectus ex id urna. Aliquam sapien ex, tincidunt sit amet vehicula vel, fermentum sit amet nisi. Vivamus nec sem diam. Donec blandit elit lorem, eget commodo nunc ultrices vel.\n' +
                '\n' +
                'Morbi sollicitudin, velit nec accumsan convallis, diam risus imperdiet ligula, a dapibus nibh nisl a quam. Pellentesque dui nulla, pulvinar vitae imperdiet nec, consectetur eget odio. Ut ac bibendum mauris. In nec lacus ac massa venenatis congue eu a neque. Integer ac fringilla libero. Nulla facilisi. Maecenas efficitur mollis tempor.\n' +
                '\n' +
                'Phasellus bibendum euismod urna elementum maximus. Aenean non neque purus. Pellentesque placerat commodo sapien, eu auctor sapien laoreet ut. Etiam tellus odio, scelerisque ac felis a, finibus blandit dui. Praesent semper, quam in placerat semper, ex elit commodo erat, sit amet aliquet risus erat in velit. Quisque non nibh libero. Quisque bibendum ex ut lobortis venenatis. Proin viverra velit at purus fermentum, a scelerisque lacus pellentesque. Maecenas sapien elit, pharetra egestas lectus eu, varius rhoncus massa. Praesent et turpis vitae arcu dictum suscipit. In eu leo et elit sagittis porta sit amet non nisl. Mauris quis luctus diam. Integer semper ultricies eros, a imperdiet massa mollis et.\n' +
                '\n' +
                'Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed rutrum ornare lorem non consectetur. Quisque egestas odio id eros tincidunt luctus. Proin sit amet sapien sed urna interdum dictum maximus vel nunc. Aliquam arcu velit, pellentesque quis eleifend nec, ornare vitae nulla. Donec non commodo ligula. Cras sit amet mi feugiat sapien tincidunt bibendum ut tristique eros. Interdum et malesuada fames ac ante ipsum primis in faucibus.',
            image: "https://i.le360.ma/fr/sites/default/files/styles/image_la_une_on_home_page/public/assets/images/2020/08/police-masque.jpg",
            video: {
                source : 'youtube',
                id : 'EGIa6CwqPUU',
            },
            date : '17 décembre 2020',
            cat : 'Général'
        },
        {
            title: "Botola Pro D1 \"Inwi\": victoire à l’extérieur de l’IRT face au FUS (1-0), le Raja vainqueur du MCO (3-0)",
            exerpt: "Rabat - Un fonctionnaire de police exerçant à l'unité mobile de la police de secours relevant de la préfecture de police de Tanger a été contraint de faire usage de son arme de service, jeudi matin, pour interpeller un multirécidiviste",
            content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis a tristique felis, quis ornare odio. Praesent tempus massa ut aliquet vulputate. Nunc et ipsum posuere, ultricies sem sed, aliquet neque. Sed a gravida neque, ac fermentum diam. Cras sagittis libero non elit volutpat facilisis. Integer a nisl quis nunc imperdiet sodales. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; In accumsan euismod sem, sit amet condimentum neque tincidunt non. Nunc egestas sit amet quam nec scelerisque. Curabitur sed interdum libero. Cras iaculis sed ante sagittis gravida. Nam maximus eleifend porttitor. Quisque facilisis quam non elit sollicitudin facilisis. Nam maximus elit sed molestie lacinia.\n' +
                '\n' +
                'Nulla fringilla sed felis eget semper. Fusce ut velit ornare, ullamcorper magna ac, tincidunt nulla. Duis vehicula lorem vel justo finibus aliquet. Proin venenatis, elit eu hendrerit malesuada, augue augue molestie sapien, quis feugiat ipsum nisl laoreet felis. Curabitur vulputate ut lectus eget bibendum. Nullam accumsan sit amet dui nec tempor. Phasellus quis orci facilisis, interdum magna vel, fringilla tortor. Donec vehicula hendrerit lacus nec lacinia. Donec rutrum, orci dapibus luctus tristique, ante augue pellentesque nulla, id ornare lectus ex id urna. Aliquam sapien ex, tincidunt sit amet vehicula vel, fermentum sit amet nisi. Vivamus nec sem diam. Donec blandit elit lorem, eget commodo nunc ultrices vel.\n' +
                '\n' +
                'Morbi sollicitudin, velit nec accumsan convallis, diam risus imperdiet ligula, a dapibus nibh nisl a quam. Pellentesque dui nulla, pulvinar vitae imperdiet nec, consectetur eget odio. Ut ac bibendum mauris. In nec lacus ac massa venenatis congue eu a neque. Integer ac fringilla libero. Nulla facilisi. Maecenas efficitur mollis tempor.\n' +
                '\n' +
                'Phasellus bibendum euismod urna elementum maximus. Aenean non neque purus. Pellentesque placerat commodo sapien, eu auctor sapien laoreet ut. Etiam tellus odio, scelerisque ac felis a, finibus blandit dui. Praesent semper, quam in placerat semper, ex elit commodo erat, sit amet aliquet risus erat in velit. Quisque non nibh libero. Quisque bibendum ex ut lobortis venenatis. Proin viverra velit at purus fermentum, a scelerisque lacus pellentesque. Maecenas sapien elit, pharetra egestas lectus eu, varius rhoncus massa. Praesent et turpis vitae arcu dictum suscipit. In eu leo et elit sagittis porta sit amet non nisl. Mauris quis luctus diam. Integer semper ultricies eros, a imperdiet massa mollis et.\n' +
                '\n' +
                'Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed rutrum ornare lorem non consectetur. Quisque egestas odio id eros tincidunt luctus. Proin sit amet sapien sed urna interdum dictum maximus vel nunc. Aliquam arcu velit, pellentesque quis eleifend nec, ornare vitae nulla. Donec non commodo ligula. Cras sit amet mi feugiat sapien tincidunt bibendum ut tristique eros. Interdum et malesuada fames ac ante ipsum primis in faucibus.',
            image: "https://fr.hespress.com/wp-content/uploads/2020/10/WhatsApp-Image-2020-10-18-at-20.59.16-2.jpeg",
            video: {
                source : 'youtube',
                id : 'EGIa6CwqPUU',
            },
            date : '17 décembre 2020',
            cat : 'Sport',
        },
        {
            title: "Le Brésil sort de la récession, mais la prudence prévaut toujours",
            exerpt: "Rabat - Un fonctionnaire de police exerçant à l'unité mobile de la police de secours relevant de la préfecture de police de Tanger a été contraint de faire usage de son arme de service, jeudi matin, pour interpeller un multirécidiviste",
            content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis a tristique felis, quis ornare odio. Praesent tempus massa ut aliquet vulputate. Nunc et ipsum posuere, ultricies sem sed, aliquet neque. Sed a gravida neque, ac fermentum diam. Cras sagittis libero non elit volutpat facilisis. Integer a nisl quis nunc imperdiet sodales. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; In accumsan euismod sem, sit amet condimentum neque tincidunt non. Nunc egestas sit amet quam nec scelerisque. Curabitur sed interdum libero. Cras iaculis sed ante sagittis gravida. Nam maximus eleifend porttitor. Quisque facilisis quam non elit sollicitudin facilisis. Nam maximus elit sed molestie lacinia.\n' +
                '\n' +
                'Nulla fringilla sed felis eget semper. Fusce ut velit ornare, ullamcorper magna ac, tincidunt nulla. Duis vehicula lorem vel justo finibus aliquet. Proin venenatis, elit eu hendrerit malesuada, augue augue molestie sapien, quis feugiat ipsum nisl laoreet felis. Curabitur vulputate ut lectus eget bibendum. Nullam accumsan sit amet dui nec tempor. Phasellus quis orci facilisis, interdum magna vel, fringilla tortor. Donec vehicula hendrerit lacus nec lacinia. Donec rutrum, orci dapibus luctus tristique, ante augue pellentesque nulla, id ornare lectus ex id urna. Aliquam sapien ex, tincidunt sit amet vehicula vel, fermentum sit amet nisi. Vivamus nec sem diam. Donec blandit elit lorem, eget commodo nunc ultrices vel.\n' +
                '\n' +
                'Morbi sollicitudin, velit nec accumsan convallis, diam risus imperdiet ligula, a dapibus nibh nisl a quam. Pellentesque dui nulla, pulvinar vitae imperdiet nec, consectetur eget odio. Ut ac bibendum mauris. In nec lacus ac massa venenatis congue eu a neque. Integer ac fringilla libero. Nulla facilisi. Maecenas efficitur mollis tempor.\n' +
                '\n' +
                'Phasellus bibendum euismod urna elementum maximus. Aenean non neque purus. Pellentesque placerat commodo sapien, eu auctor sapien laoreet ut. Etiam tellus odio, scelerisque ac felis a, finibus blandit dui. Praesent semper, quam in placerat semper, ex elit commodo erat, sit amet aliquet risus erat in velit. Quisque non nibh libero. Quisque bibendum ex ut lobortis venenatis. Proin viverra velit at purus fermentum, a scelerisque lacus pellentesque. Maecenas sapien elit, pharetra egestas lectus eu, varius rhoncus massa. Praesent et turpis vitae arcu dictum suscipit. In eu leo et elit sagittis porta sit amet non nisl. Mauris quis luctus diam. Integer semper ultricies eros, a imperdiet massa mollis et.\n' +
                '\n' +
                'Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed rutrum ornare lorem non consectetur. Quisque egestas odio id eros tincidunt luctus. Proin sit amet sapien sed urna interdum dictum maximus vel nunc. Aliquam arcu velit, pellentesque quis eleifend nec, ornare vitae nulla. Donec non commodo ligula. Cras sit amet mi feugiat sapien tincidunt bibendum ut tristique eros. Interdum et malesuada fames ac ante ipsum primis in faucibus.',
            image: "https://img2.rtve.es/imagenes/mundo-supera-28-millones-contagios-coronavirus-eeuu-india-brasil-como-principales-focos/1599832663808.jpg",
            video: {
                source : 'youtube',
                id : 'EGIa6CwqPUU',
            },
            date : '17 décembre 2020',
            cat : 'Monde',
        },
        {
            title: "Campagne de vaccination anti-Covid-19 : Mode opératoire",
            exerpt: "Rabat - Un fonctionnaire de police exerçant à l'unité mobile de la police de secours relevant de la préfecture de police de Tanger a été contraint de faire usage de son arme de service, jeudi matin, pour interpeller un multirécidiviste",
            content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis a tristique felis, quis ornare odio. Praesent tempus massa ut aliquet vulputate. Nunc et ipsum posuere, ultricies sem sed, aliquet neque. Sed a gravida neque, ac fermentum diam. Cras sagittis libero non elit volutpat facilisis. Integer a nisl quis nunc imperdiet sodales. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; In accumsan euismod sem, sit amet condimentum neque tincidunt non. Nunc egestas sit amet quam nec scelerisque. Curabitur sed interdum libero. Cras iaculis sed ante sagittis gravida. Nam maximus eleifend porttitor. Quisque facilisis quam non elit sollicitudin facilisis. Nam maximus elit sed molestie lacinia.\n' +
                '\n' +
                'Nulla fringilla sed felis eget semper. Fusce ut velit ornare, ullamcorper magna ac, tincidunt nulla. Duis vehicula lorem vel justo finibus aliquet. Proin venenatis, elit eu hendrerit malesuada, augue augue molestie sapien, quis feugiat ipsum nisl laoreet felis. Curabitur vulputate ut lectus eget bibendum. Nullam accumsan sit amet dui nec tempor. Phasellus quis orci facilisis, interdum magna vel, fringilla tortor. Donec vehicula hendrerit lacus nec lacinia. Donec rutrum, orci dapibus luctus tristique, ante augue pellentesque nulla, id ornare lectus ex id urna. Aliquam sapien ex, tincidunt sit amet vehicula vel, fermentum sit amet nisi. Vivamus nec sem diam. Donec blandit elit lorem, eget commodo nunc ultrices vel.\n' +
                '\n' +
                'Morbi sollicitudin, velit nec accumsan convallis, diam risus imperdiet ligula, a dapibus nibh nisl a quam. Pellentesque dui nulla, pulvinar vitae imperdiet nec, consectetur eget odio. Ut ac bibendum mauris. In nec lacus ac massa venenatis congue eu a neque. Integer ac fringilla libero. Nulla facilisi. Maecenas efficitur mollis tempor.\n' +
                '\n' +
                'Phasellus bibendum euismod urna elementum maximus. Aenean non neque purus. Pellentesque placerat commodo sapien, eu auctor sapien laoreet ut. Etiam tellus odio, scelerisque ac felis a, finibus blandit dui. Praesent semper, quam in placerat semper, ex elit commodo erat, sit amet aliquet risus erat in velit. Quisque non nibh libero. Quisque bibendum ex ut lobortis venenatis. Proin viverra velit at purus fermentum, a scelerisque lacus pellentesque. Maecenas sapien elit, pharetra egestas lectus eu, varius rhoncus massa. Praesent et turpis vitae arcu dictum suscipit. In eu leo et elit sagittis porta sit amet non nisl. Mauris quis luctus diam. Integer semper ultricies eros, a imperdiet massa mollis et.\n' +
                '\n' +
                'Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed rutrum ornare lorem non consectetur. Quisque egestas odio id eros tincidunt luctus. Proin sit amet sapien sed urna interdum dictum maximus vel nunc. Aliquam arcu velit, pellentesque quis eleifend nec, ornare vitae nulla. Donec non commodo ligula. Cras sit amet mi feugiat sapien tincidunt bibendum ut tristique eros. Interdum et malesuada fames ac ante ipsum primis in faucibus.',
            image: "https://www.moroccoworldnews.com/wp-content/uploads/2020/11/Moncef-Slaoui-20-Million-Could-Receive-COVID-19-Vaccine-in-December.jpg",
            video: {
                source : 'youtube',
                id : 'EGIa6CwqPUU',
            },
            date : '17 décembre 2020',
            cat : 'Social',
        },
        {
            title: "Souss-Massa en 2020: une nouvelle dynamique dans la région à la faveur de la visite royale",
            exerpt: "Rabat - Un fonctionnaire de police exerçant à l'unité mobile de la police de secours relevant de la préfecture de police de Tanger a été contraint de faire usage de son arme de service, jeudi matin, pour interpeller un multirécidiviste",
            content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis a tristique felis, quis ornare odio. Praesent tempus massa ut aliquet vulputate. Nunc et ipsum posuere, ultricies sem sed, aliquet neque. Sed a gravida neque, ac fermentum diam. Cras sagittis libero non elit volutpat facilisis. Integer a nisl quis nunc imperdiet sodales. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; In accumsan euismod sem, sit amet condimentum neque tincidunt non. Nunc egestas sit amet quam nec scelerisque. Curabitur sed interdum libero. Cras iaculis sed ante sagittis gravida. Nam maximus eleifend porttitor. Quisque facilisis quam non elit sollicitudin facilisis. Nam maximus elit sed molestie lacinia.\n' +
                '\n' +
                'Nulla fringilla sed felis eget semper. Fusce ut velit ornare, ullamcorper magna ac, tincidunt nulla. Duis vehicula lorem vel justo finibus aliquet. Proin venenatis, elit eu hendrerit malesuada, augue augue molestie sapien, quis feugiat ipsum nisl laoreet felis. Curabitur vulputate ut lectus eget bibendum. Nullam accumsan sit amet dui nec tempor. Phasellus quis orci facilisis, interdum magna vel, fringilla tortor. Donec vehicula hendrerit lacus nec lacinia. Donec rutrum, orci dapibus luctus tristique, ante augue pellentesque nulla, id ornare lectus ex id urna. Aliquam sapien ex, tincidunt sit amet vehicula vel, fermentum sit amet nisi. Vivamus nec sem diam. Donec blandit elit lorem, eget commodo nunc ultrices vel.\n' +
                '\n' +
                'Morbi sollicitudin, velit nec accumsan convallis, diam risus imperdiet ligula, a dapibus nibh nisl a quam. Pellentesque dui nulla, pulvinar vitae imperdiet nec, consectetur eget odio. Ut ac bibendum mauris. In nec lacus ac massa venenatis congue eu a neque. Integer ac fringilla libero. Nulla facilisi. Maecenas efficitur mollis tempor.\n' +
                '\n' +
                'Phasellus bibendum euismod urna elementum maximus. Aenean non neque purus. Pellentesque placerat commodo sapien, eu auctor sapien laoreet ut. Etiam tellus odio, scelerisque ac felis a, finibus blandit dui. Praesent semper, quam in placerat semper, ex elit commodo erat, sit amet aliquet risus erat in velit. Quisque non nibh libero. Quisque bibendum ex ut lobortis venenatis. Proin viverra velit at purus fermentum, a scelerisque lacus pellentesque. Maecenas sapien elit, pharetra egestas lectus eu, varius rhoncus massa. Praesent et turpis vitae arcu dictum suscipit. In eu leo et elit sagittis porta sit amet non nisl. Mauris quis luctus diam. Integer semper ultricies eros, a imperdiet massa mollis et.\n' +
                '\n' +
                'Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed rutrum ornare lorem non consectetur. Quisque egestas odio id eros tincidunt luctus. Proin sit amet sapien sed urna interdum dictum maximus vel nunc. Aliquam arcu velit, pellentesque quis eleifend nec, ornare vitae nulla. Donec non commodo ligula. Cras sit amet mi feugiat sapien tincidunt bibendum ut tristique eros. Interdum et malesuada fames ac ante ipsum primis in faucibus.',
            image: "https://cdn.telquel.ma/content/uploads/2018/08/MOU_6485-e1534801237554.jpg",
            video: {
                source : 'youtube',
                id : 'EGIa6CwqPUU',
            },
            date : '17 décembre 2020',
            cat : 'Régional',
        },
    ]

};

export default news;
