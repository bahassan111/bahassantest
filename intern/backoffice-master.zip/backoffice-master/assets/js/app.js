//global
window.log = console.log || function(){};


(function () {

    var current_scroll = 0,
        scroll_anim = false;


    $(document)
        .on('click', 'a[href="#"]', function (e) {

            e.preventDefault();
            return false;
        })
        .on('click', 'a[href^="http"]', function () {
            if($(this).hasClass('noload')) return;
            if(this.href.indexOf(ifes.url) < 0) return;
            loading(true);
        })
        .on('click', '.upload_document', function (e) {
            setTimeout(function () {
                loading(false);
            },300)
        })
        .on('click', '.hslider_points > a', function (e) {
            e.preventDefault();

            sliderGoto(this.dataset.slide);


            return false;
        })
        .on('swipeleft', '.hslider_inner', function () {
            var slider = $('.home_slider');
            var current = slider.find('[data-slide].active').data('slide') || 0;
            var next = current+1;

            if(slider.find(`[data-slide="${next}"]`).length > 0) sliderGoto(next);
            else sliderGoto(0);
        })
        .on('swiperight', '.hslider_inner', function () {
            var slider = $('.home_slider');
            var current = slider.find('[data-slide].active').data('slide') || 0;
            var next = current-1;

            if(next >= 0) sliderGoto(next);
            else sliderGoto(slider.find('[data-slide]').length - 1);
        })

        .on('click', '.video video, .video .v_status', function () {
            var video = $(this).closest('.video').find('video')[0];

            if(video.paused) video.play(); else video.pause();
        })
        .on('click', '.video .v_volume button', function () {
            var video = $(this).closest('.video').find('video')[0];

            video.muted = !video.muted;

            if(video.muted){
                $(this).html('<i class="fas fa-volume-off"></i>');
            }else{
                $(this).html('<i class="fas fa-volume-up"></i>');
            }
        })
        .on('click', '.v_replay > button', function () {
            var video = $(this).closest('.video').find('video')[0];

            video.play();
            $(this).parent().fadeOut();
        })

        .on('click', '.img_show > div > a', function () {
            $(this).closest('.img_show').fadeOut(function () {
                $(this).remove();
            })
        })

        .on('click','.back_to_top',function () {
            $("html, body").animate({ scrollTop: 0 }, 700);
            scroll_animation()
        })
        .on('click','.back_to_bottom',function () {
            var scrollToElement = $('.scrollTo')[1];
            $("html, body").animate({ scrollTop: $(document).height() }, 700);
        })


        .on('click', 'a.img', function (e) {
            e.preventDefault();



            var parent = $(this).closest('div');

            var div = $('.img_show');

            if(div.length){
                div.find('button').prop('disabled', true);
                div.find('img').css('opacity', 0);

            }else{
                div = $('<div class="img_show"><div>' +
                    '<a href="#"><i class="fas fa-times"></i></a>' +
                    '<img src="" alt=""/>' +
                    '<div class="igs_ctrl">' +
                    '<button disabled type="button" class="p"><i class="fas fa-arrow-left"></i></button>' +
                    '<button disabled type="button" class="n"><i class="fas fa-arrow-right"></i></button>' +
                    '</div></div></div>').appendTo('body');
            }





            var ctrl = div.find('.igs_ctrl');


            var next = parent.next();
            var prev = parent.prev();


            if(next.length){
                ctrl.find('.n').prop('disabled', false).off('click').on('click', function () {
                    next.find('a').trigger('click');
                })
            }
            if(prev.length){
                ctrl.find('.p').prop('disabled', false).off('click').on('click', function () {
                    prev.find('a').trigger('click');
                })
            }


            div.find('img').attr('src', $(this).attr('href'));

            div.add(div.find('img')).animate({opacity : 1});


            return false;
        })

        .on('keydown', '#search', function (e) {
            if(e.keyCode === 13) $('.chsearch button, .dv_chsearch button').trigger('click');
        })
        .on('click', '.chsearch button, .dv_chsearch button', function () {
            window.location.href = ifes.url + '?page=search&query=' + $('#search').val();
        })

        .on('click', '.msand_btn', function () {
            var open = $(this).add('.nav').toggleClass('open').hasClass('open');


        })
        .on('keyup', '#search', function (e) {

        })


        .on('click','.change_language',function () {

            var id_lang=this.dataset.lang,
                index_lang=this.dataset.index;
            $.post(ifes.url+'?page=change_language',{'id_lang':id_lang,'index_lang':index_lang,},function (res) {

                if(res.status==='OK')
                    location.reload();
            })
            
        })

        .on('click','.change_country',function () {
            var id_country=this.dataset.country;
            $.post(ifes.url+'?page=change_country',{'id_country':id_country},function (res) {
                if(res.status==='OK')
                    location.reload();
            })
        })
        .on('click','.dropDown-tltp .label',function () {
         $('.dropDown-tltp .content').css('display','flex');
        })
        .on('focusout','.dropDown-tltp .label',function () {
         // $('.dropDown-tltp .content').css('display','none');
        })

        .ready(function () {
            loading(false);
            if($('.home_slider').length > 0) slideIt();

            initVideos();

        })
    ;

    function sliderGoto(index) {
        var slider = $('.home_slider'),
            inner = slider.find('.hslider_inner')
        ;


        slider
            .find('[data-slide]')
            .removeClass('active')
            .end()
            .find('[data-slide="'+index+'"]')
            .addClass('active');

        inner.css('left', -(index * window.innerWidth));

    }
    function slideIt() {
        var slider = $('.home_slider');
        var current = slider.find('[data-slide].active').data('slide') || 0;
        var next = current+1;

        if(slider.find(`[data-slide="${next}"]`).length > 0) sliderGoto(next);
        else sliderGoto(0);

        setTimeout(slideIt, 8000);
    }
    function scrollHandle(e) {
        if(scroll_anim) return;
        var scroll = $(window).scrollTop(),
            diff = current_scroll - scroll,
            goingDown = diff < 0,
            steps = window.innerHeight,
            scrolls = $('.scrollTo');


        var target = current_scroll + (goingDown ? 1 : -1);
        var too = 0;
        var noNeed = false;

        scrolls.each(function (i, th) {
            var t = $(this).offset().top - 64;

            if(t === scroll) noNeed = true;

            var diff = target - t;

            diff = diff > 0 ? diff : (diff * -1);

            console.log('target', target);
            console.log('diff', diff);

            if ((goingDown && diff < 10)) {
                var next = scrolls.eq(i + 1);

                if (next.length) {
                    too = next.offset().top - 64;
                } else {
                    too = scrolls.eq(i).offset().top - 64;
                }

                return false;
            }

        });


        if(!noNeed){
            scroll_anim = true;
            $('html, body').animate({scrollTop : too}, function () {
                scroll_anim = false;
            });
        }




        current_scroll = too;


    }

})();

//Page Select countries

(function () {

    var container=$('#coutries-wrappers');
    if(container.length===0) return false;


    $(document).ready(function () {


    })
        .on('click','.id_country',function () {
            var id_country=this.dataset.country;
            $.post(ifes.url+'?page=change_country',{'id_country':id_country},function (res) {

                if(res.status==='OK')
                    window.location.href=ifes.url+'?page=home';

            })
        });





})();

//Home
(function () {

    var view= $('.home_slider');
    var timer;
    if(view.length===0) return false;
    $(window)
        .on('resize', function () {
            var s = $('.home_slider').css('opacity', 0);
            loading();
            debounce(function(e){
                window.location.reload();
            })();
        });

    $(document)
        .ready(function () {
            /*scroll_animation();
            scrollFunction_to_top();*/
        })
        .on('click','.all_chapitre',function () {
            window.location.href='?page=chapitres';
        })

    ;
    function debounce(func){

        return function(event){
            if(timer) clearTimeout(timer);
            timer = setTimeout(func,600,event);
        };
    }

})();

function initVideos() {
    $('.video').each(function () {
        var container = $(this);
        var video = container.find('video');
        if(video.length === 0) return true;

        video = video[0];


        var i = setInterval(function() {
            if(video.readyState > 0) {
                var minutes = parseInt(video.duration / 60, 10);
                var seconds = video.duration % 60;

                container.find('.v_time').html(`${minutes.toFixed(0).padStart(2, '0')}:${seconds.toFixed(0).padStart(2, '0')}`);
                setInterval(function () {
                    if(video.paused) return;
                    var d = /*video.duration - */video.currentTime;
                    var minutes = parseInt(d / 60, 10);
                    var seconds = d % 60;

                    container.find('.v_time').html(`${minutes.toFixed(0).padStart(2, '0')}:${seconds.toFixed(0).padStart(2, '0')}`);

                }, 1000);

                video.muted = false;
                video.volume = 0.7;
                clearInterval(i);
            }
        }, 200);

        video.onended = function(){
            container
                .find('.v_replay').fadeIn().end()
                .find('.v_volume, .v_status, .v_time').fadeOut();
        };

        video.oncontextmenu = function(e){
            e.preventDefault();
            return false;
        };

        video.onwaiting = function(){
            container.find('.v_loader').show();
        };

        video.onplaying = function (e) {
            container.find('.v_loader').fadeOut();

            container.find('.v_time, .v_volume').fadeIn().removeClass('h');

            container.find('.v_status')
                .addClass('p')
                .fadeIn()
                .html('<i class="fas fa-pause"></i>');

        };

        video.onpause = function () {
            container.find('.v_status')
                .removeClass('p')
                .html('<i class="fas fa-play"></i>');
            container.find('.v_time, .v_volume').addClass('h');
        }



    })
}

function loading(textOR_boolean, container) {
    var text = typeof text === 'string' && text ? text : ifes.language.loading,
        disable = textOR_boolean === false;

    container = container || 'body';
    container = $(container);

    if(disable){
        container.find('.loading').fadeOut(function () {
            $(this).remove();
        });
        return true;
    }else{

        if(container.find('.loading').length > 0) {
            setTimeout(function () {
                loading(textOR_boolean, container);
            }, 400);
            return;
        }

        var loader = $('<div class="loading"><div class="loading_shadow"></div><div class="loader"><span><i></i></span> <b></b></div></div>');

        loader.find('b').html(text);

        container.append(loader);

    }

    return true;

}

