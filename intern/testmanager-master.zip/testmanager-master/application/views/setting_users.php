<?php
addJS([
    'assets/js/views/settings.js',
]);

viewHeader(
    'Manage users',
    '',
    [
        (object) ['name' => 'Dashboard', 'url' => site_url()],
        (object) ['name' => 'Manage users', 'url' => ''],
    ], true);
settingsMenu('users');
?>



<div class="users_list n_menu">

</div>



