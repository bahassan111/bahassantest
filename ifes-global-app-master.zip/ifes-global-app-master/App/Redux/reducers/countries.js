import {
  PENDING_FETCH_PAYS,
  SET_PAYS_DETAILS,
  SUCCESS_FETCH_PAYS,
  ERROR_FETCH_PAYS,
} from "../actions/types";

export default function (
  state = { isLoadingData: false, isDoSearch: false, data: [], keyword: null },
  action
) {
  console.log("Log_action => ", action.type);

  switch (action.type) {
    case PENDING_FETCH_PAYS:
      return {
        ...state,
        isLoadingData: true,
      };
    case SET_PAYS_DETAILS:
      return { ...state, data: action.payload };

    case SUCCESS_FETCH_PAYS:
      return {
        ...state,
        isLoadingData: false,
      };
    case ERROR_FETCH_PAYS:
      return {
        ...state,
        isLoadingData: false,
      };

    default:
      return state;
  }
}
