import 'package:driver/constants/constants.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:driver/models/models.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'components.dart';

class CustomDrawer extends StatefulWidget {
  final bool isMenuShow;
  final Function updateMenuPosition;
  CustomDrawer({Key key, this.isMenuShow, this.updateMenuPosition})
      : super(key: key);

  @override
  _CustomDrawerState createState() => _CustomDrawerState();
}

class _CustomDrawerState extends State<CustomDrawer> {
  double height, width;
  static AuthController to = Get.find();
  static HomeController homeTo = Get.find();

  List<MenuItemModel> menuItems = [
    MenuItemModel(
      image: AllImages.homeIcon,
      onTap: () => Get.toNamed('/HomeUI'),
      title: "home",
    ),
    MenuItemModel(
        image: AllImages.prebookingIcon,
        onTap: () => Get.toNamed('/PrebookingJobsUI'),
        title: "prebooking_jobs"),
    MenuItemModel(
        image: AllImages.upcomingIcon,
        onTap: () => Get.toNamed('/UpbookingJobsUI'),
        title: "upcoming_jobs"),
    MenuItemModel(
        image: AllImages.tripHistoryIcon,
        onTap: () => Get.toNamed('/TripHistoryUI'),
        title: "trip_history"),
    MenuItemModel(
        image: AllImages.eWwalletIcon,
        onTap: () => Get.toNamed('/MyWallet'),
        title: "e_wallet"),
    // MenuItemModel(
    //     image: AllImages.notificationIcon,
    //     onTap: () => Get.toNamed('/HomeUI'),
    //     title: "notifications"),
    MenuItemModel(
        image: AllImages.logoutIcon,
        onTap: () {
          homeTo.changeDriverOnlineStatus(status: false);
          to.logout();
        },
        title: "logout"),
  ];
  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return AnimatedPositioned(
      duration: Duration(milliseconds: 250),
      left: widget.isMenuShow ? 0 : -width,
      width: width,
      child: SafeArea(
        child: Container(
          child: Row(
            children: [
              Container(
                color: Colors.white,
                height: height,
                width: (3.5 * width / 5),
                child: Column(
                  children: [
                    Container(
                      child: Stack(
                        children: [
                          GestureDetector(
                            onTap: () {
                              Get.toNamed('/SignUpUI');
                            },
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                SizedBox(
                                  height: 40,
                                ),
                                ProfilePicture(
                                  size: 75,
                                  image: to.userModel.profilephoto,
                                  //      image: AllImages.profileIcon,
                                ),
                                SizedBox(height: 10),
                                Text(
                                  to.userModel.firstname,
                                  style: Theme.of(context)
                                      .textTheme
                                      .headline1
                                      .copyWith(
                                          fontSize: 20,
                                          fontWeight: FontWeight.w600),
                                  textAlign: TextAlign.center,
                                ),
                                SizedBox(height: 10),
                              ],
                            ),
                          ),
                          Align(
                            alignment: Alignment.topLeft,
                            child: GestureDetector(
                              onTap: () => widget.updateMenuPosition(),
                              child: Container(
                                padding: EdgeInsets.only(left: 20, top: 20),
                                child: Image.asset(
                                  AllImages.backIcon,
                                  height: 25,
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 40),
                      child: Divider(
                        thickness: 2,
                        height: 2,
                        color: AppThemes.lightDividerColor,
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    ListView.separated(
                      shrinkWrap: true,
                      itemCount: menuItems.length,
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () {
                            menuItems[index].onTap();
                            widget.updateMenuPosition();
                          },
                          child: Container(
                            padding: EdgeInsets.symmetric(
                                vertical: 5, horizontal: 30),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Image.asset(
                                  menuItems[index].image,
                                  height: 30,
                                  width: 30,
                                  fit: BoxFit.cover,
                                ),
                                SizedBox(
                                  width: 10,
                                ),
                                Expanded(
                                  child: Text(
                                    menuItems[index].title.tr,
                                    overflow: TextOverflow.ellipsis,
                                    style: Theme.of(context)
                                        .textTheme
                                        .headline2
                                        .copyWith(
                                          color: AppThemes.pauaBorderColor,
                                          fontSize: 15,
                                          fontWeight: FontWeight.w500,
                                        ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                      separatorBuilder: (context, index) {
                        return Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 30),
                          child: Divider(
                            thickness: 0.5,
                            color: Colors.black,
                          ),
                        );
                      },
                    )
                  ],
                ),
              ),
              GestureDetector(
                onTap: () {
                  widget.updateMenuPosition();
                },
                child: Container(
                  color: Colors.transparent,
                  height: height,
                  width: (1.5 * width / 5),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
