import React, { Component } from "react";
import {AsyncStorage, StyleSheet} from "react-native";
import { View, Button, Text, Stepper } from "react-native-ui-lib";
import {
  fetchFontSize,
  increaseFontSize,
  decreaseFontSize,
  changeFont
} from "../Redux/actions/FontSizeActions";

import TextHelper from "../components/CustomText";
import { connect } from "react-redux";
import I18n from "../commons/i18n";

class SettingsScreen extends Component {
  static navigationOptions = ({ navigation }) => ({
      headerTitle2: (
      <Button
        size="small"
        label={navigation.getParam("lang")}
        avoidMinWidth
        avoidInnerPadding
        bg-green20
        marginH-10
        style={{ paddingHorizontal: 5, fontSize: 10 }}
        onPress={navigation.getParam("changeLanguage")}
      />
    )
  });
  state = {
    itemsCount: this.props.fontSizeValue.fontSize,
    setting:'Setting'
  };
 async componentDidMount() {
    let setting=await AsyncStorage.getItem('settingScreen');
    this.setState({setting:setting});
    this.props.fetchFontSize();
  }

  render() {
    return (
      <View style={styles.container} centerV>
        <View column center>
          <TextHelper text30 padding-40 marginV-50 center>
            {this.state.setting}
          </TextHelper>
          <Stepper
            label={this.state.itemsCount === 12 ? "Unités" : "Unités"}
            min={12}
            max={24}
            onValueChange={count => this.props.changeFont(count)}
            initialValue={this.props.fontSizeValue.fontSize}
          />
        </View>
      </View>
    );
  }
}

const mapStateToProps = state => {
  const fontSizeValue = state.fontSize;
  const lang = state.fontSize.lang;
  return {
    lang,
    fontSizeValue
  };
};

export default connect(
  mapStateToProps,
  { fetchFontSize, increaseFontSize, decreaseFontSize, changeFont }
)(SettingsScreen);

const styles = StyleSheet.create({
  container: {
    flex: 1
    // alignItems: "center",
    // justifyContent: "center"
  }
});
