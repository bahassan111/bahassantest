class MenuItemModel {
  final String title;
  final String image;
  final Function onTap;
  MenuItemModel({this.image, this.onTap, this.title});
}
