import 'dart:convert';

import 'package:bot_toast/bot_toast.dart';
import 'package:driver/constants/constants.dart';
import 'package:driver/constants/helpers/helpers.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:driver/ui/components/components.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:logger/logger.dart';

class StartTrip extends StatefulWidget {
  @override
  _StartTripState createState() => _StartTripState();
}

class _StartTripState extends State<StartTrip> {
  static HomeController to = Get.find();
  static MyMapController mapTo = Get.find();
  static AuthController authTo = Get.find();
  final store = GetStorage();

  bool isNoshowButton = false;
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(minutes: 10), () {
      if (mounted) {
        setState(() {
          isNoshowButton = true;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          SizedBox(
            height: 20,
          ),
          displayDetail(
            title: "booking_date".tr + ": ",
            value: datedayddMMMyyyyhhMMssWithSpace(to.rideDetail.bookDatetime),
          ),

          SizedBox(
            height: 5,
          ),
          displayDetail(
              title: "booking_number".tr + ": ",
              value: getBookType(to.rideDetail.bookType) +
                  to.rideDetail.id +
                  to.rideDetail.categoryCode), //
          SizedBox(
            height: 5,
          ),
          displayDetail(
              title: "drop_off_location".tr + ": ",
              value: to.rideDetail.dropaddress),
          SizedBox(
            height: 15,
          ),
          isNoshowButton
              ? Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: RoundButton(
                    text: "no_show".tr,
                    onTap: () async {
                      // check if it is type 2 booking then compate time and after 10 min only no show can be click
                      if (to.rideDetail.bookType == '2') {
                        print(
                            "pickup time ${to.rideDetail.bookDate ?? "its null"} fsdf  ${to.rideDetail.pickupTime ?? "its null"} ");
                        print(
                            "DateTime.now() ${DateTime.now().difference(historystringToDateTime(to.rideDetail.bookDate)).inMinutes}");
                        if (DateTime.now()
                                .difference(historystringToDateTime(
                                    to.rideDetail.bookDate))
                                .inMinutes <
                            10) {
                          BotToast.showWidget(
                            toastBuilder: (_) => ErrorDialog(
                              title: "alert".tr,
                              message: "no_show_only_click".tr,
                            ),
                          );
                          return;
                        }
                      }
                      await to.driverNoShow(
                        rideId: int.tryParse(to.rideDetail.id),
                        countryId: int.tryParse(to.rideDetail.countryId),
                      );
                      to.rideDetail = null;
                      mapTo.mapMatchingModel = null;
                      mapTo.routeDetail = null;
                      store.remove("current_ride");
                    },
                    textStyle: AppThemes.lightTheme.textTheme.headline1
                        .copyWith(fontSize: 15, fontWeight: FontWeight.w600),
                  ),
                )
              : Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: RoundButton(
                    text: "start_trip".tr,
                    onTap: () async {
                      try {
                        await to.changeRideStatus(
                          rideId: int.tryParse(to.rideDetail.id),
                          statusType: 3,
                          bookType: int.tryParse(to.rideDetail.bookType),
                          driverId: int.tryParse(authTo.userModel.id),
                          startTime: DateTime.now(),
                          driverArrivaltime: null,
                          countryId: int.tryParse(to.rideDetail.countryId),
                          navigateTo: HomeScreenStatus.StartTrip,
                        );
                        to.rideDetail.rideStatus = '3';

                        store.write(
                          "current_ride",
                          json.encode(
                            to.rideDetail.toJson(),
                          ),
                        );
                      } catch (e) {
                        Logger().e(e);
                      } finally {
                        Logger().w("kammal change ride status ");
                      }
                    },
                    textStyle: AppThemes.lightTheme.textTheme.headline1
                        .copyWith(fontSize: 15, fontWeight: FontWeight.w600),
                  ),
                ),
          SizedBox(
            height: 15,
          ),
        ],
      ),
    );
  }

  tripDetail(context, {String name, String number}) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          Image.asset(
            AllImages.passangerIcon,
            height: 50,
            fit: BoxFit.cover,
          ),
          SizedBox(
            width: 10,
          ),
          Text(
            name,
            style:
                AppThemes.lightTheme.textTheme.headline1.copyWith(fontSize: 18),
          ),
          Spacer(),
          Image.asset(AllImages.callIcon),
          SizedBox(
            width: 15,
          ),
          Text(
            number,
            style:
                AppThemes.lightTheme.textTheme.headline5.copyWith(fontSize: 16),
          ),
          SizedBox(
            width: 20,
          ),
        ],
      ),
    );
  }

  displayDetail({String title, String value}) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(fontSize: 14),
              maxLines: 2,
            ),
          ),
        ],
      ),
    );
  }
}
