
function randomID () {
    var S4 = function() {
        return (((1+Math.random())*0x10000)|0).toString(16).substring(1);
    };
    return (S4()+S4()+"-"+S4()+"-"+S4()+"-"+S4()+"-"+S4()+S4()+S4());
};

var modalAjax = function (url, options) {

    var loader='../assets/img/animation_modal.gif';
    var defaults = {
            title: 'Modal',
            header_close: true,
            footer_ok: true,
            footer_cancel: true,
            very_small: false,
            close_outsid: false,
            size_md: false,
            size_lg: false,
            ok: 'OK',
            cancel: 'Fermer',
            error_msg: 'impossible d\'afficher cette page, veuillez réessayer plus tard.',
            sucess_msg: 'Données enregistrées avec succès!',
            always_close: true,
            show_header: true,
            show_footer: true,
            post_data: {},
            onLoad: function (data, modal) {
            },
            onOk: function (modal, loader_, modal_sucess, modal_error) {
            },
            onCancel: function () {
            },
            onClose: function (e) {
            },
        },
        settings = $.extend({}, defaults, options);
        settings.post_data.ajax = 'true';




    var modal = $('<div id="" class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">' +
        '<div class="modal-dialog gl-modal-wc"> <div class="modal-content"> <div class="modal-header">' +
        '<h4 class="modal-title"></h4> </div> <div class="modal-body"></div>' +
        '<div class="modal-footer">' +
        '</div> </div> </div> </div>'),

        header_close = $('<button  type="button" class="close" data-dismiss="modal" aria-hidden="true"><span aria-hidden="true">×</span></button>'),
        footer_ok = $('<button type="button" id="modal_dialog_ok" class="button primary">Ok</button>'),
        footer_cancel = $('<button type="button" id="modal_dialog_cancel" data-dismiss="modal" class="button default">' +
            '<span class="md-click-circle md-click-animate"></span>Cancel</button>'),
        id = randomID(20, 'twins_modal'),
        modal_error = $('<div class="modal_fail"><span class="fa fa-close"></span> <span>' + settings.error_msg + '</span></div>'),
        modal_sucess = $('<div class="modal_sucess"><span class="fa fa-check"></span> <span>' + settings.sucess_msg + '</span></div>'),
        loader_ = $('<div class="modal_loader text-center"><div class="ml-icon loader--style1" title="0">' +
            '<img src="' + loader + '">' +
            '</div>' +
            +'<span>En cours...</span></div>')

    ;


    if (settings.very_small) {
        modal.addClass('bs-modal-sm').find('.modal-dialog').removeClass('gl-modal-wc').addClass('modal-sm');
    }
    if (settings.size_md) {
        modal.addClass('bs-modal-md').find('.modal-dialog').removeClass('gl-modal-wc').addClass('modal-md');
    }
    if (settings.size_lg) {
        modal.addClass('bs-modal-lg').find('.modal-dialog').removeClass('gl-modal-wc').addClass('modal-lg');
    }

    if (settings.always_close)
        footer_ok.attr('data-dismiss', 'modal');
    if (!settings.show_header)
        modal.find('.modal-header').remove();
    if (!settings.show_footer)
        modal.find('.modal-footer').remove();

    if(settings.close_outsid){
        modal.attr('data-keyboard',false);
        modal.attr('data-backdrop','static');
    }


    footer_ok.on('click', function () {
        settings.onOk(modal, loader_, modal_sucess, modal_error)
    });
    footer_cancel.on('click', settings.onCancel);


    $.post(url, settings.post_data, function (data) {
        if (settings.footer_ok) footer_ok.html(settings.ok).appendTo(modal.find('.modal-footer'));
        if (settings.footer_cancel) footer_cancel.html(settings.cancel).appendTo(modal.find('.modal-footer'));
        if (settings.header_close) header_close.appendTo(modal.find('.modal-header'));

        modal.find('.modal-title').html(settings.title);
        modal.find('.modal-body').html(data);
        settings.onLoad(data, modal);


    }).fail(function () {
        modal.find('.modal-body').append(modal_error);
        footer_cancel.html('FERMER').appendTo(modal.find('.modal-footer'));
    });

    $('body').css({
        'height': $(window).height(),
        'overflow': 'hidden !important'
    });
    settings.context = modal;


    $('.page-wrapper').css('filter', 'blur(1px)')
    return modal
        .attr('id', id)
        .appendTo('body')
        .modal('show')
        .on('hidden.bs.modal', function (e) {
            $('.page-wrapper').css('filter', 'unset')
            settings.onClose(e);
            $(this).remove();
            $('body').css({
                'height': 'auto',
                'overflow': ''
            });
        })
        .find('.modal-body')
        .append(loader_)


};


