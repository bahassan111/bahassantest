<?php



?>

<div class="" id="groups_form">


    <form method="post" enctype="multipart/form-data" action="<?= site_url('settings/save_group' . ($edit ? ('/'.$group->id) : '')) ?>">
        <div class="form-group">
            <label for="name" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Username</label>
            <input required value="<?= $edit ? $group->name : ''; ?>" name="name" id="name" type="text" class="form-control form-control-sm" placeholder="">
        </div>

        <div class="form-group">
            <label for="description" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Note</label>
            <textarea name="description" id="description" class="form-control form-control-sm"><?= $edit ? $group->description : ''; ?></textarea>
        </div>


        <div class="form-group">
            <label for="status" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Note</label>
            <select name="status" id="status" class="selectpicker">
                <option <?= $edit && $group->status === '0' ? 'selected' : ''; ?> value="0">Disabled</option>
                <option <?= $edit && $group->status === '1' ? 'selected' : (!$edit ? 'selected':''); ?> value="1">Enabled</option>
            </select>
        </div>

    </form>




</div>
