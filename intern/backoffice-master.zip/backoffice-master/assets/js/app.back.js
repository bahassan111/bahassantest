// GLOBAL
var log = console.log || function(){};
(function () {
    $(document)
        .on('click', '.smenu li', function (e) {
            var submenu = $(this).find('ul');
            var isOpen = $(this).hasClass('open');
            log('aaa');

            if(submenu.length){

                submenu[isOpen ? 'slideUp' : 'slideDown']();
                $(this).toggleClass('open');

            }else{
                e.stopPropagation();
            }


        })
        .on('click', '[href="#"]', function (e) {

        })
        .on('click', '.mtogler', function () {
            $(this).add('.smenu').toggleClass('open');
        })
        .on('click', '.user_menu .usm', function () {
            $(this).add('.usm_dropdown').toggleClass('open');
        })
        .on('click', '.button-group > button', function () {
            $(this).parent().toggleClass('open');
        })

       .on('click', '#reload_table', function () {
            var table=this.dataset.table;
            $('#'+table).DataTable().ajax.reload();
        })

        .on('change','.video_lang',function(){
            var text=this.dataset.text;
            var input = $(this),
                numFiles = input.get(0).files ? input.get(0).files.length : 1,
                label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
            $('#'+text).val(label);
        })
        .on('change','#filter_country',function () {
            var id_country=$(this).val();
            $.post(ifes.url+'/?page=change_country',{'id_country':id_country},function (res) {
                if(res.status==='OK'){
                    toastr.options = {
                        "closeButton": true,
                        "positionClass": "toast-bottom-center",
                        "timeOut": "3000",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                    };
                    toastr.success(res.message, toastr.options);
                    $('#reload_table').trigger('click');
                }
                else
                {
                    toastr.options = {
                        "closeButton": true,
                        "positionClass": "toast-bottom-center",
                        "timeOut": "5000",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                    };
                    toastr.error(res.message, toastr.options);
                }
            });
        })
        .ready(function () {
            endLoader();

            $('.smenu li.active').each((i, item)=>{
                var itm = $(item).parent().parent().trigger('click');
                setTimeout(()=>{

                }, 600);
            })

        })
    ;


})();

// DASHBOARD
(function () {
    var view = $('#dashboard');
    if (!view.length) return;

    $(document)
        .ready(function () {

        })
    ;


})();

// REGIONS
(function () {
    var view = $('#regions_view');
    log(view);
    if(!view.length) return;

    var table;
    var table_ =$('#regions_tbl');
    $(document)
        .ready(function () {

            table = initDatatable('#regions_tbl', [
                    {
                        title : 'Région',
                        name  : 'name',
                        data  : 'name',
                        render: null,
                        orderable : true,
                        searchable : true,
                    },
                    {
                        title : 'Adresse',
                        name  : 'address',
                        data  : 'address',
                        render: null,
                        orderable : true,
                        searchable : true,
                    },
                    {
                        title : 'Resp.',
                        name  : 'director',
                        data  : 'director',
                        render: null,
                        orderable : true,
                        searchable : true,
                    },
                    {
                        title : 'Tél',
                        name  : 'phone',
                        data  : 'phone',
                        render: null,
                        orderable : true,
                        searchable : true,
                    },
                    {
                        title : 'Fax',
                        name  : 'fax',
                        data  : 'fax',
                        render: null,
                        orderable : true,
                        searchable : true,
                    },
                    {
                        title : '',
                        name  : 'action',
                        data  : 'action',
                        render: null,
                        orderable : false,
                        searchable : false,
                    },
                ], {
                    ajax    : ifes.url + '?page=dt_regions',
                }, undefined);
        })
        .on('click','#add_region',function () {
           add_region();
        })
        .on('click','.edit_region',function (res) {
            var id=this.dataset.edit;
            add_region(id);

        })
        .on('click','.delete_region',function () {
            var id=this.dataset.delete;

            swal({
                title: 'Êtes-vous sûr?',
                text: 'Êtes-vous sûr de bien vouloir supprimer cet élément?',
                type: "warning",
                showCancelButton: true,
                cancelButtonText: 'Annuler',
                confirmButtonColor: "#43659c",
                confirmButtonText: 'Ok',
                closeOnConfirm: false,
                html: false
            }, function(willDelete){
                if (willDelete) {
                    setTimeout(function(){
                        $('.sa-confirm-button-container button').prop('disabled', true);

                        $.post(ifes.url+'/?page=delete_region',{'id':id}, function(rep){
                            if(rep.status === "OK"){
                                swal('Données supprimées', rep.message, "success");
                                table_.DataTable().ajax.reload();
                            }
                        });
                    }, 200);


                }
            });
        });



   function add_region (id) {

        var table =$('#regions_tbl').DataTable(),
            map, marker, geocoder;

        id=id ? id : null;

        modalAjax(ifes.url + '?page=add_region&id='+id, {

            title           : 'Ajouter région',
            header_close    : true,
            footer_ok       : true,
            footer_cancel   : true,
            close_outsid    : true,
            very_small      : false,
            size_md         : false,
            size_lg         : true,
            ok              : 'sauvegarder',
            cancel          : 'Annuler',
            error_msg       : 'Error',
            sucess_msg      : 'Données enregistrées avec succès!',
            always_close    : false,
            show_header     : true,
            post_data       : {},
            onLoad          : function(){

                map = new google.maps.Map(document.getElementById("map"), {
                    center: { lat: 33.94971410145149, lng: -6.824294046944314 },
                    zoom: 15,
                });

                geocoder = new google.maps.Geocoder();

                marker = new google.maps.Marker({
                    position: { lat: 33.94971410145149, lng: -6.824294046944314 },
                    map,
                });

                map.addListener("center_changed", (e) => {
                    marker.setPosition(map.getCenter());
                    console.log(map.getCenter().lat(), map.getCenter().lng());
                    $('#lat').val(map.getCenter().lat());
                    $('#lng').val(map.getCenter().lng());
                });

                window.map = map;

                $('#rech').on('change', function () {
                    let m = $('#map').addClass('loading');
                    geocoder.geocode( { 'address': $(this).val()}, function(results, status) {
                        m.removeClass('loading');
                        if (status === 'OK') {
                            map.setCenter(results[0].geometry.location);

                        } else {
                            //alert('Geocode was not successful for the following reason: ' + status);
                        }
                    });
                });

                $("#form_save_region").validate({
                    rules: {
                        nom:  {
                            required:true
                        },
                    },

                    errorElement: 'span',
                    errorClass: 'help-block',
                    errorPlacement: function(error, element) {
                        if (element.parent('.input-group').length) {
                            error.insertAfter(element.parent());
                        } else {
                            error.insertAfter(element);
                        }
                    },
                    highlight: function(element) {
                        $(element).closest('.form-group').addClass('has-error');
                    },
                    unhighlight: function(element) {
                        $(element).closest('.form-group').removeClass('has-error');
                    }

                });
            },
            onOk            : function (modal, loader, sucess, fail){

                var form=$('#form_save_region');
                var formData = new FormData(form[0]);
                if(form.valid()){
                    $.ajax({
                        url: ifes.url+'/?page=save_region',
                        type: 'POST',
                        data: formData,
                        async: true,
                        cache: false,
                        contentType: false,
                        processData: false,
                        success: function (res) {
                            if(res.status==='OK'){
                                toastr.options = {
                                    "closeButton": true,
                                    "positionClass": "toast-bottom-center",
                                    "timeOut": "3000",
                                    "showMethod": "fadeIn",
                                    "hideMethod": "fadeOut"
                                };
                                toastr.success(res.message, toastr.options);
                                table.ajax.reload();
                                $(".modal:visible").modal('toggle');
                            }
                            else
                            {
                                toastr.options = {
                                    "closeButton": true,
                                    "positionClass": "toast-bottom-center",
                                    "timeOut": "5000",
                                    "showMethod": "fadeIn",
                                    "hideMethod": "fadeOut"
                                };
                                toastr.error(res.message, toastr.options);
                            }
                        }
                    });


                }

            },
            onCancel        : function () {},
            onClose         : function () {}
        });

    };
})();


// FILES
(function () {
    var view = $('#files_view');
    log(view);
    if(!view.length) return;

    var table;
    var table_ =$('#files_tbl');
    $(document)
        .ready(function () {

            table = initDatatable('#files_tbl', [
                    {
                        title : 'Titre',
                        name  : 'title',
                        data  : 'title',
                        render: null,
                        orderable : true,
                        searchable : true,
                    },
                    {
                        title : 'Catégorie',
                        name  : 'cat',
                        data  : 'cat',
                        render: null,
                        orderable : true,
                        searchable : true,
                    },
                    {
                        title : 'Ficher',
                        name  : 'file',
                        data  : 'file',
                        render: null,
                        orderable : true,
                        searchable : true,
                    },
                    {
                        title : '',
                        name  : 'action',
                        data  : 'action',
                        render: null,
                        orderable : false,
                        searchable : false,
                    },
                ], {
                    ajax    : ifes.url + '?page=dt_files',
                }, undefined);
        })
        .on('click','#add_file',function () {
           add_file();
        })
        .on('click','.edit_file',function (res) {
            var id=this.dataset.edit;
            add_file(id);

        })
        .on('click','.delete_file',function () {
            var id=this.dataset.delete;

            swal({
                title: 'Êtes-vous sûr?',
                text: 'Êtes-vous sûr de bien vouloir supprimer cet élément?',
                type: "warning",
                showCancelButton: true,
                cancelButtonText: 'Annuler',
                confirmButtonColor: "#43659c",
                confirmButtonText: 'Ok',
                closeOnConfirm: false,
                html: false
            }, function(willDelete){
                if (willDelete) {
                    setTimeout(function(){
                        $('.sa-confirm-button-container button').prop('disabled', true);

                        $.post(ifes.url+'/?page=delete_file',{'id':id}, function(rep){
                            if(rep.status === "OK"){
                                swal('Données supprimées', rep.message, "success");
                                table_.DataTable().ajax.reload();
                            }
                        });
                    }, 200);


                }
            });
        })

        .on('change', '#lang', function () {

            $('#cat').val('').trigger('change');
            if($(this).val() === 'ar'){

                $('.catfr').hide();
                $('.catar').show();

            }else{

                $('.catfr').show();
                $('.catar').hide();

            }

        })
        .on('change', '.cat_selector', function () {

            let cat = $('#cat');

            if($(this).val() === 'new'){
                cat.prop('readonly', false)
                    .val('').trigger('change')
                   ;
            }else{
                cat.prop('readonly', true)
                    .val($(this).val()).trigger('change')
                    ;
            }



        })



    ;



   function add_file (id) {

        var table =$('#files_tbl').DataTable(),
            map, marker, geocoder;

        id=id ? id : null;

        modalAjax(ifes.url + '?page=add_file&id='+id, {

            title           : 'Ajouter fichier',
            header_close    : true,
            footer_ok       : true,
            footer_cancel   : true,
            close_outsid    : true,
            very_small      : false,
            size_md         : false,
            size_lg         : true,
            ok              : 'sauvegarder',
            cancel          : 'Annuler',
            error_msg       : 'Error',
            sucess_msg      : 'Données enregistrées avec succès!',
            always_close    : false,
            show_header     : true,
            post_data       : {},
            onLoad          : function(){


                //$('#cat_selector, #lang').selectpicker();

                $("#form_save_file").validate({
                    rules: {
                        title:  {
                            required:true
                        },
                        cat:  {
                            required:true
                        },
                    },

                    errorElement: 'span',
                    errorClass: 'help-block',
                    errorPlacement: function(error, element) {
                        if (element.parent('.input-group').length) {
                            error.insertAfter(element.parent());
                        } else {
                            error.insertAfter(element);
                        }
                    },
                    highlight: function(element) {
                        $(element).closest('.form-group').addClass('has-error');
                    },
                    unhighlight: function(element) {
                        $(element).closest('.form-group').removeClass('has-error');
                    }

                });

                $('#_file').on('change',async function(){
                    let formData = new FormData();
                    formData.append("file", fileupload.files[0]);
                    await fetch('/upload.php', {
                        method: "POST",
                        body: formData
                    });
                    alert('The file has been uploaded successfully.');
                })
            },
            onOk            : function (modal, loader, sucess, fail){

                var form=$('#form_save_file');
                var formData = new FormData(form[0]);

                if(form.valid()){
                    $.ajax({
                        url: ifes.url+'/?page=save_file',
                        type: 'POST',
                        data: formData,
                        async: true,
                        cache: false,
                        contentType: false,
                        processData: false,
                        success: function (res) {
                            if(res.status==='OK'){
                                toastr.options = {
                                    "closeButton": true,
                                    "positionClass": "toast-bottom-center",
                                    "timeOut": "3000",
                                    "showMethod": "fadeIn",
                                    "hideMethod": "fadeOut"
                                };
                                toastr.success(res.message, toastr.options);
                                table.ajax.reload();
                                $(".modal:visible").modal('toggle');
                            }
                            else
                            {
                                toastr.options = {
                                    "closeButton": true,
                                    "positionClass": "toast-bottom-center",
                                    "timeOut": "5000",
                                    "showMethod": "fadeIn",
                                    "hideMethod": "fadeOut"
                                };
                                toastr.error(res.message, toastr.options);
                            }
                        }
                    });


                }

            },
            onCancel        : function () {},
            onClose         : function () {}
        });

    };
})();


// CHAPTERS
(function () {
    var view = $('#chapters_view');
    log(view);
    if(!view.length) return;

    var table;
    var table_ =$('#chapters_tbl');
    $(document)
        .ready(function () {

            table = initDatatable('#chapters_tbl', [
                    {
                        title : 'Country',
                        name  : 'id_country',
                        data  : 'id_country',
                        render: null,
                        orderable : true,
                        searchable : true,
                    },
                    {
                        title : 'Name',
                        name  : 'titre_lang1',
                        data  : 'titre_lang1',
                        render: null,
                        orderable : true,
                        searchable : true,
                    },
                    {
                        title : 'Description',
                        name  : 'description_lang1',
                        data  : 'description_lang1',
                        render: null,
                        orderable : true,
                        searchable : true,
                    },
                    {
                        title : 'Author',
                        name  : 'fullname',
                        data  : 'fullname',
                        render: null,
                        orderable : true,
                        searchable : true,
                    },
                    {
                        title : 'Last Update',
                        name  : 'last_update',
                        data  : 'last_update',
                        render: null,
                        orderable : true,
                        searchable : true,
                    },
                    {
                        title : '',
                        name  : 'action',
                        data  : 'action',
                        render: null,
                        orderable : false,
                        searchable : false,
                    },
                ], {
                    ajax    : ifes.url + '?page=dt_chapters',
                }, undefined);
        })
        .on('click','#add_region',function () {
           add_region();
        })

        .on('click','.show_chapter',function (res) {
            var chapter_id=this.dataset.show;
            show_chapitre(chapter_id);

        })
        .on('click','.edit_chapter',function (res) {
            $(".modal:visible").modal('toggle');
            var chapter_id=this.dataset.edit;
            add_region(chapter_id);

        })
        .on('click','.delete_chapter',function () {
            $(".modal:visible").modal('toggle');
            var chapter_id=this.dataset.delete;

            swal({
                title: 'Are you sure?',
                text: 'Are you sure you want to Delete this Chapter?',
                type: "warning",
                showCancelButton: true,
                cancelButtonText: 'Cancel',
                confirmButtonColor: "#43659c",
                confirmButtonText: 'Ok',
                closeOnConfirm: false,
                html: false
            }, function(willDelete){
                if (willDelete) {
                    setTimeout(function(){
                        $('.sa-confirm-button-container button').prop('disabled', true);

                        $.get(ifes.url+'/?page=delete_chapter',{'id':chapter_id}, function(rep){
                            if(rep.status === "OK"){
                                swal('Data deleted', rep.message, "success");
                                table_.DataTable().ajax.reload();
                            }
                        });
                    }, 200);


                }
            });
        });


})();

// Countries
(function () {
    var view = $('#countries_view');
    log(view);
    if(!view.length) return;

    var table;

    var table_ =$('#countries_tbl');

    $(document)
        .ready(function () {
            table = initDatatable('#countries_tbl', [
                    {
                        title : '',
                        name  : 'flag',
                        data  : 'flag',
                        render: null,
                        orderable : false,
                        searchable : false,
                    },
                    {
                        title : 'Country',
                        name  : 'name',
                        data  : 'name',
                        render: null,
                        orderable : true,
                        searchable : true,
                    },
                    {
                        title : 'URL',
                        name  : 'url',
                        data  : 'url',
                        render: null,
                        orderable : true,
                        searchable : true,
                    },
                    {
                        title : 'Last Update',
                        name  : 'last_update',
                        data  : 'last_update',
                        render: null,
                        orderable : true,
                        searchable : true,
                    },
                    {
                        title : 'Author',
                        name  : 'fullname',
                        data  : 'fullname',
                        render: null,
                        orderable : true,
                        searchable : true,
                    },
                    {
                        title : '',
                        name  : 'action',
                        data  : 'action',
                        render: null,
                        orderable : false,
                        searchable : false,
                    },
                ], {
                    ajax    : ifes.url + '?page=dt_countries',
                    order           : [[1, 'asc']],
                }, undefined);
        })
        .on('click','#add_country',function () {

            add_country();
        })
        .on('click','.edit_country',function (res) {

            var country_id=this.dataset.edit;

            add_country(country_id);


        })
        .on('click','.delete_country',function (res) {

            var country_id=this.dataset.delete;

            swal({
                title: 'Are you sure?',
                text: 'Are you sure you want to Delete this Country?',
                type: "warning",
                showCancelButton: true,
                cancelButtonText: 'Cancel',
                confirmButtonColor: "#43659c",
                confirmButtonText: 'Ok',
                closeOnConfirm: false,
                html: false
            }, function(willDelete){
                if (willDelete) {
                    setTimeout(function(){
                        $('.sa-confirm-button-container button').prop('disabled', true);

                        $.post(ifes.url+'?page=delete_country&id='+country_id, function(rep){
                            if(rep.status === "OK"){
                                swal('Data deleted', rep.message, "success");
                                table_.DataTable().ajax.reload();
                            }
                        });
                    }, 200);


                }
            });



        })

})();



// SUB-CHAPTERS
(function () {
    var view = $('#sub_chapters_view');
    log(view);
    if(!view.length) return;

    var table;
    var table_ =$('#subchapters_tbl');
    $(document)
        .ready(function () {
            $('#filter_subchapitre').selectpicker();
            table = initDatatable('#subchapters_tbl', [
                {
                    title : 'Country',
                    name  : 'id_country',
                    data  : 'id_country',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Chapter',
                    name  : 'chapter',
                    data  : 'chapter',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Name',
                    name  : 'titre_lang1',
                    data  : 'titre_lang1',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Description',
                    name  : 'description_lang1',
                    data  : 'description_lang1',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Author',
                    name  : 'fullname',
                    data  : 'fullname',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Last Update',
                    name  : 'last_update',
                    data  : 'last_update',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : '',
                    name  : 'action',
                    data  : 'action',
                    render: null,
                    orderable : false,
                    searchable : false,
                },
            ], {
                ajax    : ifes.url + '?page=dt_subchapters',
            }, undefined);
        })
        .on('click','#add_subchapter',function () {
            add_subchapter();
        })

        .on('click','.edit_subchapter',function (res) {
            $(".modal:visible").modal('toggle');
            var subchapter_id=this.dataset.edit;
            add_subchapter(subchapter_id);

        })
        .on('click','.show_subchapter',function () {

            var subchapter_id=this.dataset.show;
            show_subchapter(subchapter_id);
        })
        .on('click','.delete_subchapter',function () {
            $(".modal:visible").modal('toggle');
            var chapter_id=this.dataset.delete;

            swal({
                title: 'Are you sure?',
                text: 'Are you sure you want to Delete this Sub-chapter?',
                type: "warning",
                showCancelButton: true,
                cancelButtonText: 'Cancel',
                confirmButtonColor: "#43659c",
                confirmButtonText: 'Ok',
                closeOnConfirm: false,
                html: false
            }, function(willDelete){
                if (willDelete) {
                    setTimeout(function(){
                        $('.sa-confirm-button-container button').prop('disabled', true);

                        $.get(ifes.url+'/?page=delete_subchapter',{'id':chapter_id}, function(rep){
                            if(rep.status === "OK"){
                                swal('Data deleted', rep.message, "success");
                                table_.DataTable().ajax.reload();
                            }
                        });
                    }, 200);


                }
            });
        })
        .on('change','#filter_subchapitre',function () {
            var id_chapter=$(this).val();
            table_.DataTable()
                .ajax.url(ifes.url + '?page=dt_subchapters&id_chapter='+id_chapter).load();
        })

})();


// Sliders
(function () {
    var view = $('#sliders_view');
    log(view);
    if(!view.length) return;
    var table;
    var table_ =$('#sliders_tbl');

    $(document)
        .ready(function () {

            table = initDatatable('#sliders_tbl', [
                {
                    title : 'Country',
                    name  : 'id_country',
                    data  : 'id_country',
                    render: null,
                    orderable : false,
                    searchable : false,
                },
                {
                    title : 'Image',
                    name  : 'image',
                    data  : 'image',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Last Update',
                    name  : 'last_update',
                    data  : 'last_update',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Author',
                    name  : 'fullname',
                    data  : 'fullname',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : '',
                    name  : 'action',
                    data  : 'action',
                    render: null,
                    orderable : false,
                    searchable : false,
                },
            ], {
                ajax    : ifes.url + '?page=dt_sliders',
                order           : [[1, 'asc']],
            }, undefined);
        })
        .on('click','#add_slider',function () {
            add_slider();
        })
        .on('click','.edit_slider',function (res) {

            var slider_id=this.dataset.edit;
            add_slider(slider_id);
        })
        .on('click','.delete_slider',function (res) {

            var slider_id=this.dataset.delete;

            swal({
                title: 'Are you sure?',
                text: 'Are you sure you want to Delete this Slider?',
                type: "warning",
                showCancelButton: true,
                cancelButtonText: 'Cancel',
                confirmButtonColor: "#43659c",
                confirmButtonText: 'Ok',
                closeOnConfirm: false,
                html: false
            }, function(willDelete){
                if (willDelete) {
                    setTimeout(function(){
                        $('.sa-confirm-button-container button').prop('disabled', true);

                        $.get(ifes.url+'/?page=delete_slider',{'id':slider_id}, function(rep){
                            if(rep.status === "OK"){
                                swal('Data deleted', rep.message, "success");
                                table_.DataTable().ajax.reload();
                            }
                        });
                    }, 200);


                }
            });



        })


})();

// CATEGORY QUIZZ
(function () {
    var view = $('#catgoriesquiz_view');
    log(view);
    if(!view.length) return;

    var table;
    var table_ =$('#catgoriesquiz_tbl');
    $(document)
        .ready(function () {
            table = initDatatable('#catgoriesquiz_tbl', [
                {
                    title : 'Country',
                    name  : 'id_country',
                    data  : 'id_country',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Name',
                    name  : 'titre_lang1',
                    data  : 'titre_lang1',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Description',
                    name  : 'description_lang1',
                    data  : 'description_lang1',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Author',
                    name  : 'fullname',
                    data  : 'fullname',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Last Update',
                    name  : 'last_update',
                    data  : 'last_update',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : '',
                    name  : 'action',
                    data  : 'action',
                    render: null,
                    orderable : false,
                    searchable : false,
                },
            ], {
                ajax    : ifes.url + '?page=dt_categoriequiz',
            }, undefined);
        })
        .on('click','#add_catgoriesquiz',function () {
            add_catgoriesquiz();
        })

        .on('click','.edit_catgoriesquiz',function (res) {
            var catgoriesquiz_id=this.dataset.edit;
            add_catgoriesquiz(catgoriesquiz_id);

        })
        .on('click','.show_level',function (res) {
            var catgoriesquiz_id=this.dataset.show;
            show_level(catgoriesquiz_id);

        })
        .on('click','.delete_catgoriesquiz',function () {
            var category_id=this.dataset.delete;
            swal({
                title: 'Are you sure?',
                text: 'Are you sure you want to Delete this Category?',
                type: "warning",
                showCancelButton: true,
                cancelButtonText: 'Cancel',
                confirmButtonColor: "#43659c",
                confirmButtonText: 'Ok',
                closeOnConfirm: false,
                html: false
            }, function(willDelete){
                if (willDelete) {
                    setTimeout(function(){
                        $('.sa-confirm-button-container button').prop('disabled', true);

                        $.get(ifes.url+'/?page=delete_catgoriesquiz',{'id':category_id}, function(rep){
                            if(rep.status === "OK"){
                                swal('Data deleted', rep.message, "success");
                                table_.DataTable().ajax.reload();
                            }
                        });
                    }, 200);


                }
            });
        })


})();

// QUIZZES
(function () {
    var view = $('#quizzes_view');
    log(view);
    if(!view.length) return;

    var table;
    var table_ =$('#quizzes_tbl');
    $(document)
        .ready(function () {
            table = initDatatable('#quizzes_tbl', [
                {
                    title : 'Country',
                    name  : 'id_country',
                    data  : 'id_country',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Category',
                    name  : 'category',
                    data  : 'category',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Name',
                    name  : 'titre_lang1',
                    data  : 'titre_lang1',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Question',
                    name  : 'question_lang1',
                    data  : 'question_lang1',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Correct',
                    name  : 'repcorrect_lang1',
                    data  : 'repcorrect_lang1',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Author',
                    name  : 'fullname',
                    data  : 'fullname',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Last Update',
                    name  : 'last_update',
                    data  : 'last_update',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : '',
                    name  : 'action',
                    data  : 'action',
                    render: null,
                    orderable : false,
                    searchable : false,
                },
            ], {
                ajax    : ifes.url + '?page=dt_quizzes',
            }, undefined);
        })
        .on('click','#add_quiz',function () {
            add_quiz();
        })

        .on('click','.edit_quiz',function (res) {
            var quiz_id=this.dataset.edit;
            add_quiz(quiz_id);

        })
        .on('click','.delete_quiz',function () {
            var category_id=this.dataset.delete;
            swal({
                title: 'Are you sure?',
                text: 'Are you sure you want to Delete this Quiz?',
                type: "warning",
                showCancelButton: true,
                cancelButtonText: 'Cancel',
                confirmButtonColor: "#43659c",
                confirmButtonText: 'Ok',
                closeOnConfirm: false,
                html: false
            }, function(willDelete){
                if (willDelete) {
                    setTimeout(function(){
                        $('.sa-confirm-button-container button').prop('disabled', true);

                        $.get(ifes.url+'/?page=delete_quiz',{'id':category_id}, function(rep){
                            if(rep.status === "OK"){
                                swal('Data deleted', rep.message, "success");
                                table_.DataTable().ajax.reload();
                            }
                        });
                    }, 200);


                }
            });
        })


})();

// DEAF
(function () {
    var view = $('#deaf_view');
    log(view);
    if(!view.length) return;

    var table;
    var table_ =$('#deaf_tbl');
    $(document)
        .ready(function () {
            table = initDatatable('#deaf_tbl', [
                {
                    title : 'Country',
                    name  : 'id_country',
                    data  : 'id_country',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Episode',
                    name  : 'episode',
                    data  : 'episode',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Name',
                    name  : 'titre',
                    data  : 'titre',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Description',
                    name  : 'description',
                    data  : 'description',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Author',
                    name  : 'fullname',
                    data  : 'fullname',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Last Update',
                    name  : 'last_update',
                    data  : 'last_update',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : '',
                    name  : 'action',
                    data  : 'action',
                    render: null,
                    orderable : false,
                    searchable : false,
                },
            ], {
                ajax    : ifes.url + '?page=dt_deaf',
            }, undefined);
        })
        .on('click','#add_deaf',function () {
            add_deaf();
        })

        .on('click','.edit_deaf',function (res) {
            $(".modal:visible").modal('toggle');
            var deaf_id=this.dataset.edit;
            add_deaf(deaf_id);

        })
        .on('click','.show_deaf',function (res) {
            var deaf_id=this.dataset.show;
            show_deaf(deaf_id);

        })
        .on('click','.delete_deaf',function () {
            $(".modal:visible").modal('toggle');
            var deaf_id=this.dataset.delete;
            swal({
                title: 'Are you sure?',
                text: 'Are you sure you want to Delete this Deaf?',
                type: "warning",
                showCancelButton: true,
                cancelButtonText: 'Cancel',
                confirmButtonColor: "#43659c",
                confirmButtonText: 'Ok',
                closeOnConfirm: false,
                html: false
            }, function(willDelete){
                if (willDelete) {
                    setTimeout(function(){
                        $('.sa-confirm-button-container button').prop('disabled', true);

                        $.get(ifes.url+'/?page=delete_deaf',{'id':deaf_id}, function(rep){
                            if(rep.status === "OK"){
                                swal('Data deleted', rep.message, "success");
                                table_.DataTable().ajax.reload();
                            }
                        });
                    }, 200);


                }
            });
        })


})();

// DEAF
(function () {
    var view = $('#survey_view');
    log(view);
    if(!view.length) return;

    var table;
    var table_ =$('#survey_tbl');
    $(document)
        .ready(function () {
            table = initDatatable('#survey_tbl', [
                {
                    title : 'Country',
                    name  : 'id_country',
                    data  : 'id_country',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Language',
                    name  : 'language',
                    data  : 'language',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Titre',
                    name  : 'titre',
                    data  : 'titre',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Author',
                    name  : 'fullname',
                    data  : 'fullname',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Last Update',
                    name  : 'last_update',
                    data  : 'last_update',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : '',
                    name  : 'action',
                    data  : 'action',
                    render: null,
                    orderable : false,
                    searchable : false,
                },
            ], {
                ajax    : ifes.url + '?page=dt_survey',
            }, undefined);
        })
        .on('click','#add_survey',function () {
            add_survey();
        })

        .on('click','.edit_survey',function (res) {
            var survey_id=this.dataset.edit;
            add_survey(survey_id);

        })
        .on('click','.delete_survey',function () {
            var survey_id=this.dataset.delete;
            swal({
                title: 'Are you sure?',
                text: 'Are you sure you want to Delete this Survey?',
                type: "warning",
                showCancelButton: true,
                cancelButtonText: 'Cancel',
                confirmButtonColor: "#43659c",
                confirmButtonText: 'Ok',
                closeOnConfirm: false,
                html: false
            }, function(willDelete){
                if (willDelete) {
                    setTimeout(function(){
                        $('.sa-confirm-button-container button').prop('disabled', true);

                        $.get(ifes.url+'/?page=delete_survey',{'id':survey_id}, function(rep){
                            if(rep.status === "OK"){
                                swal('Data deleted', rep.message, "success");
                                table_.DataTable().ajax.reload();
                            }
                        });
                    }, 200);


                }
            });
        })


})();

// USERS
(function () {
    var view = $('#users_view');
    log(view);
    if(!view.length) return;

    var table;
    var table_ =$('#users_tbl');
    $(document)
        .ready(function () {

            table = initDatatable('#users_tbl', [
                {
                    title : 'Full name',
                    name  : 'fullname',
                    data  : 'fullname',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Username',
                    name  : 'username',
                    data  : 'username',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Author',
                    name  : 'fullname',
                    data  : 'fullname',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Last Update',
                    name  : 'last_update',
                    data  : 'last_update',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : '',
                    name  : 'action',
                    data  : 'action',
                    render: null,
                    orderable : false,
                    searchable : false,
                },
            ], {
                ajax    : ifes.url + '?page=dt_users',
            }, undefined);
        })
        .on('click','#add_user',function () {
            add_user();
        })

        .on('click','.show_user',function (res) {
            var user_id=this.dataset.show;
            show_user(user_id);

        })
        .on('click','.edit_user',function (res) {
            $(".modal:visible").modal('toggle');
            var user_id=this.dataset.edit;
            add_user(user_id);

        })
        .on('click','.delete_user',function () {
            $(".modal:visible").modal('toggle');
            var user_id=this.dataset.delete;

            swal({
                title: 'Are you sure?',
                text: 'Are you sure you want to Delete this User?',
                type: "warning",
                showCancelButton: true,
                cancelButtonText: 'Cancel',
                confirmButtonColor: "#43659c",
                confirmButtonText: 'Ok',
                closeOnConfirm: false,
                html: false
            }, function(willDelete){
                if (willDelete) {
                    setTimeout(function(){
                        $('.sa-confirm-button-container button').prop('disabled', true);

                        $.get(ifes.url+'/?page=delete_user',{'id':user_id}, function(rep){
                            if(rep.status === "OK"){
                                swal('Data deleted', rep.message, "success");
                                table_.DataTable().ajax.reload();
                            }
                        });
                    }, 200);


                }
            });
        });


})();

// Languages
(function () {
    var view = $('#config_lang_view');
    log(view);
    if(!view.length) return;

    var table;
    var table_ =$('#languages_tbl');
    $(document)
        .ready(function () {

            table = initDatatable('#languages_tbl', [
                {
                    title : 'Name',
                    name  : 'name',
                    data  : 'name',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Author',
                    name  : 'fullname',
                    data  : 'fullname',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : 'Last Update',
                    name  : 'last_update',
                    data  : 'last_update',
                    render: null,
                    orderable : true,
                    searchable : true,
                },
                {
                    title : '',
                    name  : 'action',
                    data  : 'action',
                    render: null,
                    orderable : false,
                    searchable : false,
                },
            ], {
                ajax    : ifes.url + '?page=dt_languages',
            }, undefined);
        });


})();


// Edit Languages
(function () {
    var view = $('#edit_lang_view');
    log(view);
    if(!view.length) return;

    $(document)
        .ready(function () {


        })
        .on('click','#save_language',function (e) {
            e.preventDefault();
           var  form=$('#form_save_fields');
            $.post(ifes.url+'/?page=save_fields',form.serialize(),function (res) {
                if(res.status==='OK'){
                    toastr.options = {
                        "closeButton": true,
                        "positionClass": "toast-bottom-center",
                        "timeOut": "3000",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                    };
                    toastr.success(res.message, toastr.options);
                    table.ajax.reload();
                    $(".modal:visible").modal('toggle');
                }
                else
                {
                    toastr.options = {
                        "closeButton": true,
                        "positionClass": "toast-bottom-center",
                        "timeOut": "5000",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                    };
                    toastr.error(res.message, toastr.options);
                }
            })
        })


})();

function endLoader() {
    $('.loading').fadeOut(function () {
        $(this).remove();
    })
}
function startLoader(txt) {
    txt = txt || 'Loading ..';

    $('body').append(`<div class="loading"><div class="loader"><span><i></i></span> <b>${txt}</b></div></div>`)
}

function initDatatable(table, cols, config, whenDraw , btns){
    table = $(table);
    cols = cols || [];
    config = config || {};
    whenDraw = whenDraw || function(){};

    var datatable_settings = {
        processing      : true,
        serverSide      : true,
        columns         : cols,
        order           : [[0, 'desc']],
        dom             : 'Bfrtip',
        buttonss         : [
            {
                extend: 'copyHtml5',
                exportOptions: {
                    columns: '',
                }
            },
            {
                extend: 'print',
                exportOptions: {
                    columns: '',
                }
            },
            {
                extend: 'excelHtml5',
                exportOptions: {
                    columns: '',
                }
            },
            {
                extend: 'pdfHtml5',
                exportOptions: {
                    columns: '',
                }
            },
            {
                extend: 'csvHtml5',
                exportOptions: {
                    columns: '',
                }
            },
            'colvis'
        ],
        buttons : [],
        columnDefs      : [],
        responsive      : true,
    };

    $.each(cols, function(i, col){
        if('orderable' in col && !col.orderable){
            datatable_settings.columnDefs.push({targets:i, orderable:false});
        }
        if('searchable' in col && !col.searchable){
            datatable_settings.columnDefs.push({targets:i, searchable:false});
        }
    });


    $.each(config, function(i, e){
        datatable_settings[i] = e;
    });

    datatable_settings.preDrawCallback = function(){
        return;
        (function(table, dt){
            var holder = table.closest('.dt_block').find('.admb_footer');
            if(holder.find('.fordatatable_info').length === 0) holder.append('<div><p class="fordatatable_info"></p></div>');
            if(holder.find('.pagination_div').length === 0) holder.append('<div class="pagination_div"></div>');

            holder.find('.fordatatable_info').html('Initializing Data..');
            table.closest('.dt_block').find('.admb_body').addClass('loading');

        })(table, datatable);
    };
    datatable_settings.drawCallback = function(){
        whenDraw(table, datatable);
        return;
        (function(table, dt){

            var holder = table.closest('.dt_block').find('.admb_footer');
            if(holder.find('.fordatatable_info').length === 0) holder.append('<div><p class="fordatatable_info"></p></div>');
            if(holder.find('.pagination_div').length === 0) holder.append('<div class="pagination_div"></div>');

            holder.find('.fordatatable_info').html(
                dt.data().length > 1
                    ? 'Showing ' + dt.data().length + ' from ' + dt.settings()[0].json.recordsTotal + ' records'
                    : (dt.data().length < 1
                    ? 'No records to show'
                    : 'Showing one out of ' + dt.settings()[0].json.recordsTotal + ' records')
            );
            holder.parent().find('.loading').removeClass('loading');

            holder.find('.pagination_div').html(holder.parent().find('.dataTables_paginate ul'));

        })(table, datatable);
    };
    datatable_settings.initComplete = function(set){


        return;
        (function(table, dt){


            var tools_holder = table.closest('.dt_block').find('.admb_head > div'),
                buttons = {
                    btn_search : $('<button type="button" title="Search"><i class="icon-search"></i></button>'),
                    btn_row : $('<button type="button" title="Change the number of rows in page"><i class="icon-list-numbered"></i><b>10</b><ul class="dt_numrows_menu"><li>10</li><li>25</li><li>50</li><li>100</li></ul></button>'),
                    btn_cols : $('<button type="button" title="Show/Hide columns"><i class="icon-eye-blocked"></i></button>'),
                    btn_export : $('<button type="button" title="Export"><i class="icon-download"></i><ul class="dt_export_menu">' +
                        '<li><i class="icon-file-pdf"></i> PDF File</li>' +
                        '<li><i class="icon-file-excel"></i> Excel Sheet</li>' +
                        '<li><i class="icon-file-openoffice"></i> CSV File</li>' +
                        '<li class="separator"></li>' +
                        '<li><i class="fa fa-file-excel-o"></i> <b>Export ALL as Excel File</b></li>' +
                        '</ul></button>'),
                    btn_print : $('<button type="button" title="Print"><i class="icon-printer"></i></button>'),
                    btn_refresh : $('<button type="button" title="Refresh"><i class="icon-loop2"></i></button>'),
                },
                sep = $('<div class="dt_menu_sep"></div>'),
                search = $('<div class="dt_search_holder"><input type="search" title="search" placeholder="Search.."><button type="button"><i class="fa fa-close"></i></button></div>'),
                settings = dt ? dt.settings()[0] : {},
                cols = settings.aoColumns;

            if(!tools_holder.hasClass('initialized')){
                init();
            }

            function init(){
                if(!liracoin.preferences.datatable.scroller){
                    buttons.btn_row.find('b').html((settings._iDisplayLength || 10));
                    buttons.btn_row.on('click', function(){
                        var ul = $(this).find('ul')
                            .find('li')
                            .on('click', function(){
                                settings._iDisplayLength = $(this).html();
                                buttons.btn_row.find('b').html($(this).html());
                                (dt || {draw:function(){}}).draw();

                            })
                            .end();

                        if($(this).toggleClass('opened').hasClass('opened')){
                            ul.show().animate({top : '100%', opacity : 1})
                        }else{
                            ul.animate({top : '100%', opacity : 0}, function(){$(this).hide()})
                        }

                    });
                }else{
                    buttons.btn_row = $('');
                }


                buttons.btn_print.on('click', function(){
                    table.closest('.dataTables_wrapper').find('.buttons-print').trigger('click');
                });

                buttons.btn_refresh.on('click', function(){
                    dt.ajax.reload();
                });

                buttons.btn_export.find('ul li')
                    .on('click', function(){
                        if($(this).find('i').hasClass('icon-file-pdf')){

                            table.closest('.dataTables_wrapper').find('.buttons-pdf').trigger('click');
                        }else if($(this).find('i').hasClass('icon-file-excel')){

                            table.closest('.dataTables_wrapper').find('.buttons-excel').trigger('click');
                        }else if($(this).find('i').hasClass('icon-file-openoffice')){

                            table.closest('.dataTables_wrapper').find('.buttons-csv').trigger('click');
                        }else if($(this).find('i').hasClass('fa-file-excel-o')){
                            export_table(table, settings);
                        }
                    });
                buttons.btn_export.on('click', function(){
                    var ul = $(this).find('ul');

                    if($(this).toggleClass('opened').hasClass('opened')){
                        ul.show().animate({top : '100%', opacity : 1})
                    }else{
                        ul.animate({top : '100%', opacity : 0}, function(){$(this).hide()})
                    }

                });

                var cols_list = $('<ul></ul>');
                $.each(cols, function(){
                    cols_list.append(
                        $('<li data-name="'+ this.name +'">'+ this.title +'</li>')
                            .addClass(this.bVisible ? 'active' : '')
                            .on('click', function(){
                                $(this).toggleClass('active');
                                dt.column(this.dataset.name + ':name')
                                    .visible($(this).hasClass('active'));
                            })
                    ).append($('<div class="list_overalshadow"></div>').on('click', function(){
                        cols_list.animate({top : '150%', opacity : 0}, function(){
                            $(this).hide().parent().removeClass('opened');
                        })
                    }));
                });
                buttons.btn_cols.append(cols_list.addClass('dt_colslist_menu'));
                buttons.btn_cols.on('click', function(){
                    if(!$(this).hasClass('opened')){
                        $(this).addClass('opened');
                        cols_list.show().animate({top : '100%', opacity : 1});
                    }
                });

                $.each(buttons, function(i, b){
                    tools_holder.append(
                        b
                            .on('mouseenter', function(){
                                b.append(
                                    $('<span>'+b.attr('title')+'</span>')
                                        .css({right : '100%', opacity : 0})
                                        .stop().animate({right : '50%', opacity : 1})
                                )
                            })
                            .on('mouseleave', function(){
                                $(this).find('span').stop().animate({right : '100%', opacity : 0}, function(){
                                    $(this).remove();
                                })
                            })
                    );
                });
                buttons.btn_print.after(sep.clone());
                buttons.btn_search.after(sep.clone());

                search.find('button').on('click', function(){
                    search.find('input').val('').trigger('change');
                    search.animate({top: 50, opacity : 0}, function(){
                        $(this).hide();
                        buttons.btn_search.removeClass('opened');

                    });
                }).end().find('input').on('change keyup', function(){
                    table.closest('.dataTables_wrapper').find('input[type="search"]').val(this.value).trigger('keyup');
                });
                buttons.btn_search.append(search).on('click', function(){
                    if($(this).hasClass('opened')) return false;
                    $(this).addClass('opened');
                    search.show()
                        .css({opacity : 0, top : 40})
                        .animate({top: 30, opacity : 1});
                });
                $.each(btns || [],function (i,b) {

                    var revok_access = dt.ajax.json();
                    if(! 'id' in b) b.id = '_';
                    revok_access = 'buttons' in revok_access && b.id in revok_access.buttons && revok_access.buttons[b.id] === false;
                    if(revok_access) return true;

                    var _btn = $('<a href="" class="datatable_link_action" title=""><i class=""></i> <span></span> </a>');
                    _btn
                        .attr('title', b.title)
                        .find('span').html(b.title).end()
                        .find('i'). addClass(b.icon).end()
                        .appendTo(tools_holder);
                    if(typeof b.action === 'string'){
                        _btn.attr('href', b.action);
                    }else{
                        _btn.attr('href', 'javascript:void(0);').on('click', b.action);
                    }
                    //tools_holder.find('button').first().before(_btn);
                });

                tools_holder.addClass('initialized');
                if(liracoin.preferences.datatable.scroller){
                    $('.dataTables_scrollBody').slimScroll(ssc_options);
                }
            }


        })(table, datatable);
    };


    var datatable = table.DataTable(datatable_settings);


    if(('context' in ifes) === false) ifes.context = {};
    if(('datatables' in ifes.context) === false) ifes.context.datatables = [];
    ifes.context.datatables.push(datatable);
    return datatable;
}

var add_country=function (id) {

    var table =$('#countries_tbl').DataTable();
    id=id ? id : null;
    modalAjax(ifes.url + '?page=add_country&id='+id, {

        title           : 'Add country',
        header_close    : true,
        footer_ok       : true,
        footer_cancel   : true,
        close_outsid    : true,
        very_small      : false,
        size_md         : true,
        size_lg         : false,
        ok              : 'Save',
        cancel          : 'Cancel',
        error_msg       : 'Error',
        sucess_msg      : 'Données enregistrées avec succès!',
        always_close    : false,
        show_header     : true,
        post_data       : {},
        onLoad          : function(){

            $(document).on('change','#id_country',function () {
                var name=$(this).find(':selected');
                $('#country_name').val(name.attr('data-cname'));
                $('#name_native').val(name.attr('data-nname'));
            })
                .on('click','.import_from_country',function () {
                    $('#id_lang').val('').selectpicker('refresh');
                  $('#content_countries_import').slideDown();
                  $('#content_lang').slideUp();
                  $(this).text('Select languages').attr('class','content_select_language');
                })
                .on('click','.content_select_language',function () {
                    $('#data_import').val('').selectpicker('refresh');
                  $('#content_lang').slideDown();
                  $('#content_countries_import').slideUp();

                  $(this).text('Import data from other country').attr('class','import_from_country');
                });

            $('#id_country').selectpicker();
            $('#data_import').selectpicker();
            $('#id_lang').selectpicker({
                maxOptions:2
            });
            $("#form_save_country").validate({
                rules: {
                    id_country:  {
                        required:true
                    },
                    name:  {
                        required: true
                    },
                    "id_lang[]":  {
                        required: true
                    },
                    name_native:  {
                        required: true
                    },
                    url:  {
                        required: true
                    }
                },

                errorElement: 'span',
                errorClass: 'help-block',
                errorPlacement: function(error, element) {
                    if (element.parent('.input-group').length) {
                        error.insertAfter(element.parent());
                    } else {
                        error.insertAfter(element);
                    }
                },
                highlight: function(element) {
                    $(element).closest('.form-group').addClass('has-error');
                },
                unhighlight: function(element) {
                    $(element).closest('.form-group').removeClass('has-error');
                }

            });
        },
        onOk            : function (modal, loader, sucess, fail){

            var form=$('#form_save_country');

            if(form.valid()){
                startLoader('Waiting..');
                $.get(ifes.url+'?page=save_country',form.serialize(),function (res) {

                    if(res.status==='OK'){
                        toastr.options = {
                            "closeButton": true,
                            "positionClass": "toast-bottom-center",
                            "timeOut": "3000",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        };
                        toastr.success(res.message, toastr.options);
                        table.ajax.reload();
                        $(".modal:visible").modal('toggle');
                    }
                    else
                    {
                        toastr.options = {
                            "closeButton": true,
                            "positionClass": "toast-bottom-center",
                            "timeOut": "5000",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        };
                        toastr.error(res.message, toastr.options);
                    }

                    endLoader();
                });

            }

        },
        onCancel        : function () {},
        onClose         : function () {}
    });

};


var add_slider=function (id) {

    var table =$('#sliders_tbl').DataTable();
    id=id ? id : null;
    modalAjax(ifes.url + '?page=add_slider&id='+id, {

        title           : 'Add slider',
        header_close    : true,
        footer_ok       : true,
        footer_cancel   : true,
        close_outsid    : true,
        very_small      : false,
        size_md         : true,
        size_lg         : false,
        ok              : 'Save',
        cancel          : 'Cancel',
        error_msg       : 'Error',
        sucess_msg      : 'Données enregistrées avec succès!',
        always_close    : false,
        show_header     : true,
        post_data       : {},
        onLoad          : function(){


            $('#id_country').selectpicker();
            $('#image_slider').dropify({
                messages: {
                    'default': 'Drag and drop a file here or click',
                    'replace': 'Drag and drop or click to replace',
                    'remove':  'Remove',
                    'error':   'Ooops, something wrong happended.'
                }
            });
            $("#form_save_slider").validate({
                rules: {
                    id_country:  {
                        required:true
                    },
                    numero:  {
                        required:true,
                        number:true
                    }
                },

                errorElement: 'span',
                errorClass: 'help-block',
                errorPlacement: function(error, element) {
                    if (element.parent('.input-group').length) {
                        error.insertAfter(element.parent());
                    } else {
                        error.insertAfter(element);
                    }
                },
                highlight: function(element) {
                    $(element).closest('.form-group').addClass('has-error');
                },
                unhighlight: function(element) {
                    $(element).closest('.form-group').removeClass('has-error');
                }

            });
        },
        onOk            : function (modal, loader, sucess, fail){

            var form=$('#form_save_slider');

            var formData = new FormData(form[0]);
            if(form.valid()){
                $.ajax({
                    url: ifes.url+'/?page=save_slider',
                    type: 'POST',
                    data: formData,
                    async: true,
                    cache: false,
                    contentType: false,
                    processData: false,
                    success: function (res) {
                        if(res.status==='OK'){
                            toastr.options = {
                                "closeButton": true,
                                "positionClass": "toast-bottom-center",
                                "timeOut": "3000",
                                "showMethod": "fadeIn",
                                "hideMethod": "fadeOut"
                            };
                            toastr.success(res.message, toastr.options);
                            table.ajax.reload();
                            $(".modal:visible").modal('toggle');
                        }
                        else
                        {
                            toastr.options = {
                                "closeButton": true,
                                "positionClass": "toast-bottom-center",
                                "timeOut": "5000",
                                "showMethod": "fadeIn",
                                "hideMethod": "fadeOut"
                            };
                            toastr.error(res.message, toastr.options);
                        }
                    }
                });


            }
        },
        onCancel        : function () {},
        onClose         : function () {}
    });

};


var show_chapitre=function (id) {

    id=id ? id : null;
    modalAjax(ifes.url + '?page=show_chapter&id='+id, {

        title           : 'Show chapter',
        header_close    : true,
        footer_ok       : false,
        footer_cancel   : true,
        close_outsid    : true,
        very_small      : false,
        size_md         : false,
        size_lg         : true,
        ok              : 'Save',
        cancel          : 'Cancel',
        error_msg       : 'Error',
        sucess_msg      : 'Données enregistrées avec succès!',
        always_close    : false,
        show_header     : true,
        post_data       : {},
        onLoad          : function(){

        },
        onOk            : function (modal, loader, sucess, fail){


        },
        onCancel        : function () {},
        onClose         : function () {}
    });

};




var add_catgoriesquiz=function (id) {

    var table =$('#catgoriesquiz_tbl').DataTable();
    id=id ? id : null;
    modalAjax(ifes.url + '?page=add_categoriequiz&id='+id, {
        title           : 'Add Category',
        header_close    : true,
        footer_ok       : true,
        footer_cancel   : true,
        close_outsid    : true,
        very_small      : false,
        size_md         : false,
        size_lg         : true,
        ok              : 'Save',
        cancel          : 'Cancel',
        error_msg       : 'Error',
        sucess_msg      : 'Données enregistrées avec succès!',
        always_close    : false,
        show_header     : true,
        post_data       : {},
        onLoad          : function(){

            $('#id_country').selectpicker();
            $('#icon_category').dropify({
                messages: {
                    'default': 'Drag and drop a file here or click',
                    'replace': 'Drag and drop or click to replace',
                    'remove':  'Remove',
                    'error':   'Ooops, something wrong happended.'
                }
            });
            $(document).on('change','#id_country',function () {
                var id_country=$(this).val(),
                    content='',
                    content_chapter=$('.content_chapter'),
                    id_edit=$('#id_edit').val();
                $.get(ifes.url+'/?page=category_byCountry',{'id_country':id_country,'id_edit':id_edit},function (data) {
                    var pos_rtl=data.pos_rtl,
                        rtl_1=pos_rtl===0 ? 'text-right' : '',
                        rtl_2=pos_rtl===1 ? 'text-right' : '';
                    $.each(data.langs,function (item,value) {
                        if(data.langs.length===2){
                            if(item===0){
                                content+='<div class="col-sm-6 no_padding_l">'
                                    +'<div class="form-group">'
                                    +'<label for="Name">Titre ('+data.lang1+')</label>'
                                    +'<input type="text" name="titre_lang1" class="form-control '+rtl_1+'" value="'+data.titre_lang1+'">'
                                    +'</div>'
                                    +'</div>'
                                    +'<div class="col-sm-6 no_padding_r">'
                                    +'<div class="form-group">'
                                    +'<label for="Name">Titre ('+data.lang2+')</label>'
                                    +'<input type="text" name="titre_lang2" class="form-control '+rtl_2+'" value="'+data.titre_lang2+'">'
                                    +'</div>'
                                    +'</div>';
                            }
                            if(item===1){
                                content+='<div class="col-sm-6 no_padding_l">'
                                    +'<div class="form-group">'
                                    +'<label for="Name">Description ('+data.lang1+')</label>'
                                    +'<textarea  name="description_lang1"  class="form-control '+rtl_1+'" rows="5">'+data.description_lang1+'</textarea>'
                                    +'</div>'
                                    +'</div>'
                                    +'<div class="col-sm-6 no_padding_r">'
                                    +'<div class="form-group">'
                                    +'<label for="Name">Description ('+data.lang2+')</label>'
                                    +'<textarea  name="description_lang2"  class="form-control '+rtl_2+'" rows="5">'+data.description_lang2+'</textarea>'
                                    +'</div>'
                                    +'</div>';
                            }
                        }
                        else
                        {
                            var is_rtl=this.rtl===1 ? 'text-right' : '';
                            content+='<div class="col-sm-6 no_padding_l">'
                                +'<div class="form-group">'
                                +'<label for="Name">Titre ('+data.lang1+')</label>'
                                +'<input type="text" name="titre_lang1" class="form-control '+is_rtl+'">'
                                +'</div>'
                                +'</div>'
                                +'<div class="col-sm-6 no_padding_l">'
                                +'<div class="form-group">'
                                +'<label for="Name">Description ('+data.lang1+')</label>'
                                +'<textarea  name="description_lang1"  class="form-control '+is_rtl+'" rows="5"></textarea>'
                                +'</div>'
                                +'</div>';
                        }
                    });

                    content_chapter.html(content);
                    content_chapter.slideDown();



                });
            });

            $('#id_country').trigger('change');

            $("#form_save_categoriequiz").validate({
                rules: {
                    id_country:  {
                        required:true
                    },
                    titre_lang1:  {
                        required: true
                    },
                    titre_lang2:  {
                        required: true
                    },
                    numero:  {
                        required: true,
                        number:true
                    },
                    coefficient:  {
                        required: true,
                        number:true
                    }
                },

                errorElement: 'span',
                errorClass: 'help-block',
                errorPlacement: function(error, element) {
                    if (element.parent('.input-group').length) {
                        error.insertAfter(element.parent());
                    } else {
                        error.insertAfter(element);
                    }
                },
                highlight: function(element) {
                    $(element).closest('.form-group').addClass('has-error');
                },
                unhighlight: function(element) {
                    $(element).closest('.form-group').removeClass('has-error');
                }

            });
        },
        onOk            : function (modal, loader, sucess, fail){

            var form=$('#form_save_categoriequiz');
            var formData = new FormData(form[0]);
            if(form.valid()){
                $.ajax({
                    url: ifes.url+'/?page=save_categoriequiz',
                    type: 'POST',
                    data: formData,
                    async: true,
                    cache: false,
                    contentType: false,
                    processData: false,
                    success: function (res) {
                        if(res.status==='OK'){
                            toastr.options = {
                                "closeButton": true,
                                "positionClass": "toast-bottom-center",
                                "timeOut": "3000",
                                "showMethod": "fadeIn",
                                "hideMethod": "fadeOut"
                            };
                            toastr.success(res.message, toastr.options);
                            table.ajax.reload();
                            $(".modal:visible").modal('toggle');
                        }
                        else
                        {
                            toastr.options = {
                                "closeButton": true,
                                "positionClass": "toast-bottom-center",
                                "timeOut": "5000",
                                "showMethod": "fadeIn",
                                "hideMethod": "fadeOut"
                            };
                            toastr.error(res.message, toastr.options);
                        }
                    }
                });


            }

        },
        onCancel        : function () {},
        onClose         : function () {}
    });

};
var show_level=function (id) {

    id=id ? id : null;
    modalAjax(ifes.url + '?page=show_level&id='+id, {

        title           : 'Show level',
        header_close    : true,
        footer_ok       : false,
        footer_cancel   : true,
        close_outsid    : true,
        very_small      : false,
        size_md         : false,
        size_lg         : true,
        ok              : 'Save',
        cancel          : 'Cancel',
        error_msg       : 'Error',
        sucess_msg      : 'Données enregistrées avec succès!',
        always_close    : false,
        show_header     : true,
        post_data       : {},
        onLoad          : function(){

        },
        onOk            : function (modal, loader, sucess, fail){


        },
        onCancel        : function () {},
        onClose         : function () {}
    });

};
var add_subchapter=function (id) {

    var table =$('#subchapters_tbl').DataTable();
    id=id ? id : null;
    modalAjax(ifes.url + '?page=add_subchapter&id='+id, {

        title           : 'Add Sub-chapter',
        header_close    : true,
        footer_ok       : true,
        footer_cancel   : true,
        close_outsid    : true,
        very_small      : false,
        size_md         : false,
        size_lg         : true,
        ok              : 'Save',
        cancel          : 'Cancel',
        error_msg       : 'Error',
        sucess_msg      : 'Données enregistrées avec succès!',
        always_close    : false,
        show_header     : true,
        post_data       : {},
        onLoad          : function(){

            $('#id_chapter').selectpicker();
            $('#galeries').fileinput({
                'theme': 'explorer-fa',
                'uploadUrl': '#',
                'showUpload': false,
                allowedFileExtensions: ["jpg", "png", "gif"],
                overwriteInitial: false,
                initialPreviewAsData: true,
                initialPreview: galeries,
                initialPreviewConfig: init_galeries
            });
            $('#image_subchapter').dropify({
                messages: {
                    'default': 'Drag and drop a file here or click',
                    'replace': 'Drag and drop or click to replace',
                    'remove':  'Remove',
                    'error':   'Ooops, something wrong happended.'
                }
            });
            $(document).on('change','#id_chapter',function () {
                var id_chapter=$(this).val(),
                    content='',
                    content_subchapter=$('.content_subchapter'),
                    id_edit=$('#id_edit').val();
                $.get(ifes.url+'/?page=langs_byChapter',{'id_chapter':id_chapter,'id_edit':id_edit},function (data) {
                    var pos_rtl=data.pos_rtl,
                        rtl_1=pos_rtl===0 ? 'text-right' : '',
                        rtl_2=pos_rtl===1 ? 'text-right' : '';
                    $.each(data.langs,function (item,value) {
                        if(data.langs.length===2){

                            if(item===0){
                                content+='<div class="col-sm-6">'
                                    +'<div class="form-group">'
                                    +'<label for="Name">Titre ('+data.lang1+')</label>'
                                    +'<input type="text" name="titre_lang1" class="form-control '+rtl_1+'" value="'+data.titre_lang1+'">'
                                    +'</div>'
                                    +'</div>'
                                    +'<div class="col-sm-6">'
                                    +'<div class="form-group">'
                                    +'<label for="Name">Titre ('+data.lang2+')</label>'
                                    +'<input type="text" name="titre_lang2" class="form-control '+rtl_2+'" value="'+data.titre_lang2+'">'
                                    +'</div>'
                                    +'</div>'
                                    +'<div class="col-sm-6">'
                                    +'<div class="form-group">'
                                    +'<label for="photo">Video ('+data.lang1+')</label>'
                                    +'<div class="input-group">'
                                    +'<label class="input-group-btn">'
                                    +'<span class="btn btn-primary">'
                                    +'Browse… <input type="file"  name="video_lang1" data-text="text_video1"  class="form-control video_lang"  accept="video/*" style="display: none"/>'
                                    +'</span>'
                                    +'</label>'
                                    +'<input type="text" id="text_video1" class="form-control" readonly=""  value="'+data.video_lang1+'">'
                                    +'</div>'
                                    +'</div>'
                                    +'</div>'
                                    +'<div class="col-sm-6">'
                                    +'<div class="form-group">'
                                    +'<label for="photo">Video ('+data.lang2+')</label>'
                                    +'<div class="input-group">'
                                    +'<label class="input-group-btn">'
                                    +'<span class="btn btn-primary">'
                                    +'Browse… <input type="file"  name="video_lang2" data-text="text_video2"  class="form-control video_lang"  accept="video/*" style="display: none"/>'
                                    +'</span>'
                                    +'</label>'
                                    +'<input type="text" id="text_video2" class="form-control" readonly=""  value="'+data.video_lang2+'">'
                                    +'</div>'
                                    +'</div>'
                                    +'</div>';
                            }
                            if(item===1){
                                content+='<div class="col-sm-6">'
                                    +'<div class="form-group">'
                                    +'<label for="Name">Description ('+data.lang1+')</label>'
                                    +'<textarea  name="description_lang1"  class="form-control '+rtl_1+'" rows="5">'+data.description_lang1+'</textarea>'
                                    +'</div>'
                                    +'</div>'
                                    +'<div class="col-sm-6">'
                                    +'<div class="form-group">'
                                    +'<label for="Name">Description ('+data.lang2+')</label>'
                                    +'<textarea  name="description_lang2"  class="form-control '+rtl_2+'" rows="5">'+data.description_lang2+'</textarea>'
                                    +'</div>'
                                    +'</div>';
                            }
                        }
                        else
                        {
                            var is_rtl=this.rtl===1 ? 'text-right' : '';
                            content+='<div class="col-sm-6 no_padding_l">'
                                +'<div class="form-group">'
                                +'<label for="Name">Titre ('+data.lang1+')</label>'
                                +'<input type="text" name="titre_lang1" class="form-control '+is_rtl+'">'
                                +'</div>'
                                +'</div>'
                                +'<div class="col-sm-6 no_padding_l">'
                                +'<div class="form-group">'
                                +'<label for="Name">Description ('+data.lang1+')</label>'
                                +'<textarea  name="description_lang1"  class="form-control '+is_rtl+'" rows="5"></textarea>'
                                +'</div>'
                                +'</div>';
                        }
                    });

                    content_subchapter.html(content);
                    content_subchapter.slideDown();

                });
            })
                .on('change','.video_lang',function(){
                    var text=this.dataset.text;
                    var input = $(this),
                        numFiles = input.get(0).files ? input.get(0).files.length : 1,
                        label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
                    $('#'+text).val(label);
            });

            $('#id_chapter').trigger('change');

            $("#form_save_subchapter").validate({
                rules: {
                    id_chapter:  {
                        required:true
                    },
                    titre_lang1:  {
                        required: true
                    },
                    titre_lang2:  {
                        required: true
                    },
                    numero:  {
                        required: true,
                        number:true
                    }
                },

                errorElement: 'span',
                errorClass: 'help-block',
                errorPlacement: function(error, element) {
                    if (element.parent('.input-group').length) {
                        error.insertAfter(element.parent());
                    } else {
                        error.insertAfter(element);
                    }
                },
                highlight: function(element) {
                    $(element).closest('.form-group').addClass('has-error');
                },
                unhighlight: function(element) {
                    $(element).closest('.form-group').removeClass('has-error');
                }

            });
        },
        onOk            : function (modal, loader, sucess, fail){

            var form=$('#form_save_subchapter');
            var formData = new FormData(form[0]);
            if(form.valid()){
                $.ajax({
                    url: ifes.url+'/?page=save_subchapter',
                    type: 'POST',
                    data: formData,
                    async: true,
                    cache: false,
                    contentType: false,
                    processData: false,
                    success: function (res) {
                        if(res.status==='OK'){
                            toastr.options = {
                                "closeButton": true,
                                "positionClass": "toast-bottom-center",
                                "timeOut": "3000",
                                "showMethod": "fadeIn",
                                "hideMethod": "fadeOut"
                            };
                            toastr.success(res.message, toastr.options);
                            table.ajax.reload();
                            $(".modal:visible").modal('toggle');
                        }
                        else
                        {
                            toastr.options = {
                                "closeButton": true,
                                "positionClass": "toast-bottom-center",
                                "timeOut": "5000",
                                "showMethod": "fadeIn",
                                "hideMethod": "fadeOut"
                            };
                            toastr.error(res.message, toastr.options);
                        }
                    }
                });


            }

        },
        onCancel        : function () {},
        onClose         : function () {}
    });

};

var show_subchapter=function (id) {

    id=id ? id : null;
    modalAjax(ifes.url + '?page=show_subchapter&id='+id, {

        title           : 'Show Sub-chapter',
        header_close    : true,
        footer_ok       : false,
        footer_cancel   : true,
        close_outsid    : true,
        very_small      : false,
        size_md         : false,
        size_lg         : true,
        ok              : 'Save',
        cancel          : 'Cancel',
        error_msg       : 'Error',
        sucess_msg      : 'Données enregistrées avec succès!',
        always_close    : false,
        show_header     : true,
        post_data       : {},
        onLoad          : function(){

        },
        onOk            : function (modal, loader, sucess, fail){


        },
        onCancel        : function () {},
        onClose         : function () {}
    });

};


var add_quiz=function (id) {

    var table =$('#quizzes_tbl').DataTable();
    id=id ? id : null;
    modalAjax(ifes.url + '?page=add_quiz&id='+id, {

        title           : 'Add Quiz',
        header_close    : true,
        footer_ok       : true,
        footer_cancel   : true,
        close_outsid    : true,
        very_small      : false,
        size_md         : false,
        size_lg         : true,
        ok              : 'Save',
        cancel          : 'Cancel',
        error_msg       : 'Error',
        sucess_msg      : 'Données enregistrées avec succès!',
        always_close    : false,
        show_header     : true,
        post_data       : {},
        onLoad          : function(){

            $('#id_category').selectpicker();
            $(document).on('change','#id_category',function () {
                var id_category=$(this).val(),
                    content='',
                    content_quiz=$('.content_quiz'),
                    id_edit=$('#id_edit').val();
                $.get(ifes.url+'/?page=langs_byCategory',{'id_category':id_category,'id_edit':id_edit},function (data) {
                    var pos_rtl=data.pos_rtl,
                        rtl_1=pos_rtl===0 ? 'text-right' : '',
                        rtl_2=pos_rtl===1 ? 'text-right' : '';
                    $.each(data.langs,function (item,value) {
                        if(data.langs.length===2){

                            if(item===0){
                                content+='<div class="col-sm-6 no_padding_l">'
                                    +'<div class="form-group">'
                                    +'<label for="Titre">Titre ('+data.lang1+')</label>'
                                    +'<input type="text" name="titre_lang1" class="form-control '+rtl_1+'" value="'+data.titre_lang1+'">'
                                    +'</div>'
                                    +'</div>'
                                    +'<div class="col-sm-6 no_padding_r">'
                                    +'<div class="form-group">'
                                    +'<label for="Titre">Titre ('+data.lang2+')</label>'
                                    +'<input type="text" name="titre_lang2" class="form-control '+rtl_2+'" value="'+data.titre_lang2+'">'
                                    +'</div>'
                                    +'</div>'
                                    +'<div class="col-sm-6 no_padding_l">'
                                    +'<div class="form-group">'
                                    +'<label for="Definition">Definition ('+data.lang1+')</label>'
                                    +'<textarea type="text" name="definition_lang1" class="form-control '+rtl_1+'" rows="4">'
                                    +data.definition_lang1
                                    +'</textarea>'
                                    +'</div>'
                                    +'</div>'
                                    +'<div class="col-sm-6 no_padding_r">'
                                    +'<div class="form-group">'
                                    +'<label for="Definition">Definition ('+data.lang2+')</label>'
                                    +'<textarea type="text" name="definition_lang2" class="form-control '+rtl_1+'" rows="4">'
                                    +data.definition_lang2
                                    +'</textarea>'
                                    +'</div>'
                                    +'</div>'
                                    +'<div class="col-sm-6 no_padding_l">'
                                    +'<div class="form-group">'
                                    +'<label for="Question">Question ('+data.lang1+')</label>'
                                    +'<textarea type="text" name="question_lang1" class="form-control '+rtl_1+'" rows="4">'
                                    +data.question_lang1
                                    +'</textarea>'
                                    +'</div>'
                                    +'</div>'
                                    +'<div class="col-sm-6 no_padding_r">'
                                    +'<div class="form-group">'
                                    +'<label for="Question">Question ('+data.lang2+')</label>'
                                    +'<textarea type="text" name="question_lang2" class="form-control '+rtl_1+'" rows="4">'
                                    +data.question_lang2
                                    +'</textarea>'
                                    +'</div>'
                                    +'</div>'
                                    +'<div class="col-sm-6 no_padding_l">'
                                    +'<div class="form-group">'
                                    +'<label for="Response">Response ('+data.lang1+')</label>'
                                    +'<input type="text" name="rep1_lang1" class="form-control '+rtl_1+'" value="'+data.rep1_lang1+'">'
                                    +'</div>'
                                    +'</div>'
                                    +'<div class="col-sm-6 no_padding_r">'
                                    +'<div class="form-group">'
                                    +'<label for="Response">Response ('+data.lang2+')</label>'
                                    +'<input type="text" name="rep1_lang2" class="form-control '+rtl_2+'" value="'+data.rep1_lang2+'">'
                                    +'</div>'
                                    +'</div>'
                                    +'<div class="col-sm-6 no_padding_l">'
                                    +'<div class="form-group">'
                                    +'<label for="Response">Response ('+data.lang1+')</label>'
                                    +'<input type="text" name="rep2_lang1" class="form-control '+rtl_1+'" value="'+data.rep2_lang1+'">'
                                    +'</div>'
                                    +'</div>'
                                    +'<div class="col-sm-6 no_padding_r">'
                                    +'<div class="form-group">'
                                    +'<label for="Response">Response ('+data.lang2+')</label>'
                                    +'<input type="text" name="rep2_lang2" class="form-control '+rtl_2+'" value="'+data.rep2_lang2+'">'
                                    +'</div>'
                                    +'</div>'
                                    +'<div class="col-sm-6 no_padding_l">'
                                    +'<div class="form-group">'
                                    +'<label for="Response">Response ('+data.lang1+')</label>'
                                    +'<input type="text" name="rep3_lang1" class="form-control '+rtl_1+'" value="'+data.rep3_lang1+'">'
                                    +'</div>'
                                    +'</div>'
                                    +'<div class="col-sm-6 no_padding_r">'
                                    +'<div class="form-group">'
                                    +'<label for="Response">Response ('+data.lang2+')</label>'
                                    +'<input type="text" name="rep3_lang2" class="form-control '+rtl_2+'" value="'+data.rep3_lang2+'">'
                                    +'</div>'
                                    +'</div>'
                                    +'<div class="col-sm-6 no_padding_l">'
                                    +'<div class="form-group">'
                                    +'<label for="Response correct">Response correct ('+data.lang1+')</label>'
                                    +'<input type="text" name="repcorrect_lang1" class="form-control '+rtl_1+'" value="'+data.repcorrect_lang1+'">'
                                    +'</div>'
                                    +'</div>'
                                    +'<div class="col-sm-6 no_padding_r">'
                                    +'<div class="form-group">'
                                    +'<label for="Response correct">Response correct ('+data.lang2+')</label>'
                                    +'<input type="text" name="repcorrect_lang2" class="form-control '+rtl_2+'" value="'+data.repcorrect_lang2+'">'
                                    +'</div>'
                                    +'</div>';
                            }
                        }
                        else
                        {
                            var is_rtl=this.rtl===1 ? 'text-right' : '';
                            content+='<div class="col-sm-6 no_padding_l">'
                                +'<div class="form-group">'
                                +'<label for="Titre">Titre ('+data.lang1+')</label>'
                                +'<input type="text" name="titre_lang1" class="form-control '+rtl_1+'" value="'+data.titre_lang1+'">'
                                +'</div>'
                                +'</div>'
                                +'<div class="col-sm-6 no_padding_r">'
                                +'<div class="form-group">'
                                +'<label for="Definition">Definition ('+data.lang1+')</label>'
                                +'<textarea type="text" name="definition_lang1" class="form-control '+rtl_1+'" rows="4">'
                                +data.definition_lang1
                                +'</textarea>'
                                +'</div>'
                                +'</div>'
                                +'<div class="col-sm-6 no_padding_l">'
                                +'<div class="form-group">'
                                +'<label for="Question">Question ('+data.lang1+')</label>'
                                +'<textarea type="text" name="question_lang1" class="form-control '+rtl_1+'" rows="4">'
                                +data.question_lang1
                                +'</textarea>'
                                +'</div>'
                                +'</div>'
                                +'<div class="col-sm-6 no_padding_r">'
                                +'<div class="form-group">'
                                +'<label for="Response">Response ('+data.lang1+')</label>'
                                +'<input type="text" name="rep1_lang1" class="form-control '+rtl_1+'" value="'+data.rep1_lang1+'">'
                                +'</div>'
                                +'</div>'
                                +'<div class="col-sm-6 no_padding_l">'
                                +'<div class="form-group">'
                                +'<label for="Response">Response ('+data.lang1+')</label>'
                                +'<input type="text" name="rep2_lang1" class="form-control '+rtl_1+'" value="'+data.rep2_lang1+'">'
                                +'</div>'
                                +'</div>'
                                +'<div class="col-sm-6 no_padding_r">'
                                +'<div class="form-group">'
                                +'<label for="Response">Response ('+data.lang1+')</label>'
                                +'<input type="text" name="rep3_lang1" class="form-control '+rtl_1+'" value="'+data.rep3_lang1+'">'
                                +'</div>'
                                +'</div>'
                                +'<div class="col-sm-6 no_padding_l">'
                                +'<div class="form-group">'
                                +'<label for="Response correct">Response correct ('+data.lang1+')</label>'
                                +'<input type="text" name="repcorrect_lang1" class="form-control '+rtl_1+'" value="'+data.repcorrect_lang1+'">'
                                +'</div>'
                                +'</div>';
                        }
                    });

                    content_quiz.html(content);
                    content_quiz.slideDown();

                });
            });
            $('#id_category').trigger('change');
            $("#form_save_quiz").validate({
                rules: {
                    id_category:  {
                        required:true
                    },
                    titre_lang1:  {
                        required: true
                    },
                    definition_lang1:  {
                        required: true
                    },
                    definition_lang2:  {
                        required: true
                    },
                    titre_lang2:  {
                        required: true
                    },
                    question_lang1:  {
                        required: true
                    },
                    question_lang2:  {
                        required: true
                    },
                    rep1_lang1:  {
                        required: true
                    },
                    rep1_lang2:  {
                        required: true
                    },
                    rep2_lang1:  {
                        required: true
                    },
                    rep2_lang2:  {
                        required: true
                    },
                    repcorrect_lang1:  {
                        required: true
                    },
                    repcorrect_lang2:  {
                        required: true
                    },
                    numero:  {
                        required: true,
                        number:true
                    },
                    note:  {
                        required: true,
                        number:true
                    }
                },

                errorElement: 'span',
                errorClass: 'help-block',
                errorPlacement: function(error, element) {
                    if (element.parent('.input-group').length) {
                        error.insertAfter(element.parent());
                    } else {
                        error.insertAfter(element);
                    }
                },
                highlight: function(element) {
                    $(element).closest('.form-group').addClass('has-error');
                },
                unhighlight: function(element) {
                    $(element).closest('.form-group').removeClass('has-error');
                }

            });
        },
        onOk            : function (modal, loader, sucess, fail){

            var form=$('#form_save_quiz');
            var formData = new FormData(form[0]);
            if(form.valid()){
                $.ajax({
                    url: ifes.url+'/?page=save_quiz',
                    type: 'POST',
                    data: formData,
                    async: true,
                    cache: false,
                    contentType: false,
                    processData: false,
                    success: function (res) {
                        if(res.status==='OK'){
                            toastr.options = {
                                "closeButton": true,
                                "positionClass": "toast-bottom-center",
                                "timeOut": "3000",
                                "showMethod": "fadeIn",
                                "hideMethod": "fadeOut"
                            };
                            toastr.success(res.message, toastr.options);
                            table.ajax.reload();
                            $(".modal:visible").modal('toggle');
                        }
                        else
                        {
                            toastr.options = {
                                "closeButton": true,
                                "positionClass": "toast-bottom-center",
                                "timeOut": "5000",
                                "showMethod": "fadeIn",
                                "hideMethod": "fadeOut"
                            };
                            toastr.error(res.message, toastr.options);
                        }
                    }
                });


            }

        },
        onCancel        : function () {},
        onClose         : function () {}
    });

};
var add_deaf=function (id) {

    var table =$('#deaf_tbl').DataTable();
    id=id ? id : null;
    modalAjax(ifes.url + '?page=add_deaf&id='+id, {

        title           : 'Add deaf',
        header_close    : true,
        footer_ok       : true,
        footer_cancel   : true,
        close_outsid    : true,
        very_small      : false,
        size_md         : false,
        size_lg         : true,
        ok              : 'Save',
        cancel          : 'Cancel',
        error_msg       : 'Error',
        sucess_msg      : 'Données enregistrées avec succès!',
        always_close    : false,
        show_header     : true,
        post_data       : {},
        onLoad          : function(res,modal){

            var id_edit=$('#id_edit').val();
            $('#id_country').selectpicker();
            setTimeout(function () {
                $('#id_country').trigger('change');
            },'800');
            $('#id_lang').selectpicker();
            $('#image_deaf').dropify({
                messages: {
                    'default': 'Drag and drop a file here or click',
                    'replace': 'Drag and drop or click to replace',
                    'remove':  'Remove',
                    'error':   'Ooops, something wrong happended.'
                }
            });
            $(modal).on('change','#id_country',function () {
                var id_country=$(this).val(),
                    langs_option='',
                    one_deaf=null;

                $.get(ifes.url+'/?page=all_langsbyCountry',{'id_country':id_country,'id_edit':id_edit},function (res) {

                    if(res.one_deaf)
                        one_deaf=res.one_deaf;

                    if(res.langs.length > 0){
                        langs_option='<option selected disabled  value="">Select language</option>';
                        $.each(res.langs,function () {
                            var lang_selected=one_deaf && one_deaf.id_lang===this.id ? 'selected' : '';
                            langs_option+='<option data-rtl="'+this.rtl+'" value="'+this.id+'" '+lang_selected+'>'+this.name+'</option>';
                        });

                        $('#id_lang')
                            .html(langs_option)
                            .attr('disabled',false)
                            .selectpicker('refresh');
                        if(id_edit && id_edit!==''){
                            $('#id_lang').trigger('change');
                        }



                    }

                });
            })
                .on('change','#id_lang',function () {
                    var that=$(this),
                        c_rtl=$('#id_lang').find(':selected').attr('data-rtl');
                    if(that.val() && that.val() !== '' ){
                        if(c_rtl==='1'){
                            $('#titre').attr('dir','rtl');
                            $('#description').attr('dir','rtl');
                            $('#episode').attr('dir','rtl');
                        }
                        else {
                            $('#titre').attr('dir','ltr');
                            $('#description').attr ('dir','ltr');
                            $('#episode').attr ('dir','ltr');
                        }

                        $('#titre').attr('readonly',false);
                        $('#description').attr('readonly',false);
                        $('#episode').attr('readonly',false);
                    }

                });

            if(id_edit && id_edit!==''){
                $('#id_country').trigger('change');
            }




            $("#form_save_deaf").validate({
                rules: {
                    id_country:  {
                        required:true
                    },
                    id_lang:  {
                        required:true
                    },
                    titre:  {
                        required: true
                    },
                    description:  {
                        required: true
                    },
                    episode:  {
                        required: true
                    }
                },

                errorElement: 'span',
                errorClass: 'help-block',
                errorPlacement: function(error, element) {
                    if (element.parent('.input-group').length) {
                        error.insertAfter(element.parent());
                    } else {
                        error.insertAfter(element);
                    }
                },
                highlight: function(element) {
                    $(element).closest('.form-group').addClass('has-error');
                },
                unhighlight: function(element) {
                    $(element).closest('.form-group').removeClass('has-error');
                }

            });
        },
        onOk            : function (modal, loader, sucess, fail){

            var form=$('#form_save_deaf');
            var formData = new FormData(form[0]);
            if(form.valid()){
                $.ajax({
                    url: ifes.url+'/?page=save_deaf',
                    type: 'POST',
                    data: formData,
                    async: true,
                    cache: false,
                    contentType: false,
                    processData: false,
                    success: function (res) {
                        if(res.status==='OK'){
                            toastr.options = {
                                "closeButton": true,
                                "positionClass": "toast-bottom-center",
                                "timeOut": "3000",
                                "showMethod": "fadeIn",
                                "hideMethod": "fadeOut"
                            };
                            toastr.success(res.message, toastr.options);
                            table.ajax.reload();
                            $(".modal:visible").modal('toggle');
                        }
                        else
                        {
                            toastr.options = {
                                "closeButton": true,
                                "positionClass": "toast-bottom-center",
                                "timeOut": "5000",
                                "showMethod": "fadeIn",
                                "hideMethod": "fadeOut"
                            };
                            toastr.error(res.message, toastr.options);
                        }
                    }
                });


            }

        },
        onCancel        : function () {},
        onClose         : function () {}
    });

};
var show_deaf=function (id) {

    id=id ? id : null;
    modalAjax(ifes.url + '?page=show_deaf&id='+id, {

        title           : 'Show deaf',
        header_close    : true,
        footer_ok       : false,
        footer_cancel   : true,
        close_outsid    : false,
        very_small      : false,
        size_md         : false,
        size_lg         : true,
        ok              : 'Save',
        cancel          : 'Cancel',
        error_msg       : 'Error',
        sucess_msg      : 'Données enregistrées avec succès!',
        always_close    : false,
        show_header     : true,
        post_data       : {},
        onLoad          : function(){




        },
        onOk            : function (modal, loader, sucess, fail){


        },
        onCancel        : function () {},
        onClose         : function () {}
    });

};

var add_survey=function (id) {

    var table =$('#survey_tbl').DataTable();
    id=id ? id : null;
    modalAjax(ifes.url + '?page=add_survey&id='+id, {
        title           : 'Add survey',
        header_close    : true,
        footer_ok       : true,
        footer_cancel   : true,
        close_outsid    : true,
        very_small      : false,
        size_md         : false,
        size_lg         : true,
        ok              : 'Save',
        cancel          : 'Cancel',
        error_msg       : 'Error',
        sucess_msg      : 'Données enregistrées avec succès!',
        always_close    : false,
        show_header     : true,
        post_data       : {},
        onLoad          : function(res,modal){
            var id_edit=$('#id_edit').val();
            $('#id_country').selectpicker();
            $('#id_lang').selectpicker();
            setTimeout(function () {
                $('#id_country').trigger('change');
            },'800');
            $(modal).on('change','#id_country',function () {
                var id_country=$(this).val(),
                    langs_option='',
                    one_survey=null;
                $.get(ifes.url+'/?page=survey_langsbyCountry',{'id_country':id_country,'id_edit':id_edit},function (res) {
                    if(res.one_survey)
                        one_survey=res.one_survey;
                    if(res.langs.length > 0){
                        langs_option='<option selected disabled  value="">Select language</option>';
                        $.each(res.langs,function () {
                            var lang_selected=one_survey && one_survey.id_lang===this.id ? 'selected' : '';
                            langs_option+='<option data-rtl="'+this.rtl+'" value="'+this.id+'" '+lang_selected+'>'+this.name+'</option>';
                        });

                        $('#id_lang')
                            .html(langs_option)
                            .attr('disabled',false)
                            .selectpicker('refresh');
                    }

                });
            })
                .on('change','#id_lang',function () {
                    var that=$(this),
                        c_rtl=that.find(':selected').attr('data-rtl');
                    console.log(that.val());
                    if(that.val() !== '' ){
                        if(c_rtl==='1'){
                            $('#titre').attr('dir','rtl');
                            $('#description').attr('dir','rtl');
                        }
                        else {
                            $('#titre').attr('dir','ltr');
                            $('#description').attr ('dir','ltr');
                        }

                        $('#titre').attr('readonly',false);
                        $('#description').attr('readonly',false);
                        $('#type_survey').attr('disabled',false);
                    }
                })
                .on('change','#type_survey',function () {
                    var that=$(this),
                        type=that.val(),
                        content_type='';
                    if(type==2){
                      content_type='<div class="form-group survey_type">'
                                   +'<input type="text" name="responses[]" class="form-control" placeholder="Type text">'
                                   +'<button type="button"  class="button primary add_survey_type"><span class="fa fa-plus"></span></button>'
                                   +'</div>';
                    }
                    $('#survey_type').html(content_type);

                })
                .on('click','.add_survey_type',function () {
                    var that=$(this);
                   var clone_that= that.closest('.survey_type').clone();
                    clone_that.find('.add_survey_type')
                        .removeClass('primary add_survey_type').addClass('danger remove_survey_type').find('.fa-plus')
                        .removeClass('fa fa-plus').addClass('fa fa-trash');
                    clone_that.find('input').val('');
                    clone_that.appendTo("#survey_type");
                })
                .on('click','.remove_survey_type',function () {
                    $(this).closest('.survey_type').remove();
                });
            if(id_edit!==''){
                $('#id_country').trigger('change');
                $('#id_lang').trigger('change');
            }

            $("#form_save_survey").validate({
                rules: {
                    id_country:  {
                        required:true
                    },
                    id_lang:  {
                        required:true
                    },
                    titre:  {
                        required: true
                    }
                },

                errorElement: 'span',
                errorClass: 'help-block',
                errorPlacement: function(error, element) {
                    if (element.parent('.input-group').length) {
                        error.insertAfter(element.parent());
                    } else {
                        error.insertAfter(element);
                    }
                },
                highlight: function(element) {
                    $(element).closest('.form-group').addClass('has-error');
                },
                unhighlight: function(element) {
                    $(element).closest('.form-group').removeClass('has-error');
                }

            });
        },
        onOk            : function (modal, loader, sucess, fail){

            var form=$('#form_save_survey');
            var formData = new FormData(form[0]);
            if(form.valid()){
                $.ajax({
                    url: ifes.url+'/?page=save_survey',
                    type: 'POST',
                    data: formData,
                    async: true,
                    cache: false,
                    contentType: false,
                    processData: false,
                    success: function (res) {
                        if(res.status==='OK'){
                            toastr.options = {
                                "closeButton": true,
                                "positionClass": "toast-bottom-center",
                                "timeOut": "3000",
                                "showMethod": "fadeIn",
                                "hideMethod": "fadeOut"
                            };
                            toastr.success(res.message, toastr.options);
                            table.ajax.reload();
                            $(".modal:visible").modal('toggle');
                        }
                        else
                        {
                            toastr.options = {
                                "closeButton": true,
                                "positionClass": "toast-bottom-center",
                                "timeOut": "5000",
                                "showMethod": "fadeIn",
                                "hideMethod": "fadeOut"
                            };
                            toastr.error(res.message, toastr.options);
                        }
                    }
                });


            }

        },
        onCancel        : function () {

        },
        onClose         : function () {

        }
    });

};

var add_user=function (id) {

    var table =$('#users_tbl').DataTable();
    id=id ? id : null;
    modalAjax(ifes.url + '?page=add_user&id='+id, {

        title           : 'Add user',
        header_close    : true,
        footer_ok       : true,
        footer_cancel   : true,
        close_outsid    : true,
        very_small      : false,
        size_md         : false,
        size_lg         : true,
        ok              : 'Save',
        cancel          : 'Cancel',
        error_msg       : 'Error',
        sucess_msg      : 'Données enregistrées avec succès!',
        always_close    : false,
        show_header     : true,
        post_data       : {},
        onLoad          : function(){

            $('#id_country').selectpicker();
            $('#image_user').dropify({
                messages: {
                    'default': 'Drag and drop a file here or click',
                    'replace': 'Drag and drop or click to replace',
                    'remove':  'Remove',
                    'error':   'Ooops, something wrong happended.'
                }
            });


            $("#form_save_user").validate({
                rules: {
                    "id_country[]":  {
                        required:true
                    },
                    username:  {
                        required: true,
                        remote: {
                            url : ifes.url+"/?page=check_mailUser&id_edit="+$('#id_edit').val(),
                            type : "get"
                        }
                    },
                    fullname:  {
                        required: true
                    },
                    email:  {
                        required: true,
                        email: true,
                        remote: {
                            url : ifes.url+"/?page=check_mailUser&id_edit="+$('#id_edit').val(),
                            type : "get",
                        }
                    },
                    password:  {
                        required: true,
                        minlength : 6
                    },
                    password_confirm: {
                        required: true,
                        minlength: 6,
                        equalTo: "#password"
                    }
                },
                message:{
                    username: {
                        required: "This field is required",
                        remote: "Username already in use. Please use other usename."
                    },
                    email: {
                        required: "This field is required",
                        email: "Invalid Email Address",
                        remote: "Email address already in use. Please use other email."
                    },

                },

                errorElement: 'span',
                errorClass: 'help-block',
                errorPlacement: function(error, element) {
                    if (element.parent('.input-group').length) {
                        error.insertAfter(element.parent());
                    } else {
                        error.insertAfter(element);
                    }
                },
                highlight: function(element) {
                    $(element).closest('.form-group').addClass('has-error');
                },
                unhighlight: function(element) {
                    $(element).closest('.form-group').removeClass('has-error');
                }

            });
        },
        onOk            : function (modal, loader, sucess, fail){

            var form=$('#form_save_user');
            var formData = new FormData(form[0]);
            if(form.valid()){
                $.ajax({
                    url: ifes.url+'/?page=save_user',
                    type: 'POST',
                    data: formData,
                    async: true,
                    cache: false,
                    contentType: false,
                    processData: false,
                    success: function (res) {
                        if(res.status==='OK'){
                            toastr.options = {
                                "closeButton": true,
                                "positionClass": "toast-bottom-center",
                                "timeOut": "3000",
                                "showMethod": "fadeIn",
                                "hideMethod": "fadeOut"
                            };
                            toastr.success(res.message, toastr.options);
                            table.ajax.reload();
                            $(".modal:visible").modal('toggle');
                        }
                        else
                        {
                            toastr.options = {
                                "closeButton": true,
                                "positionClass": "toast-bottom-center",
                                "timeOut": "5000",
                                "showMethod": "fadeIn",
                                "hideMethod": "fadeOut"
                            };
                            toastr.error(res.message, toastr.options);
                        }
                    }
                });


            }

        },
        onCancel        : function () {},
        onClose         : function () {}
    });

};
