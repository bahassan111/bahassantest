import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rider_app/constants/constants.dart';
import 'package:rider_app/controllers/controllers.dart';

class VehicaleDetail extends StatelessWidget {
  static TripAcceptController to = Get.find();
  static AuthController authTo = Get.find();
  final vehicleAdditionalInfo;
  const VehicaleDetail({this.vehicleAdditionalInfo});
  @override
  Widget build(BuildContext context) {
    print(vehicleAdditionalInfo.toString() + " vehicle add info ");
    return Container(
      color: Colors.white,
      width: MediaQuery.of(context).size.width,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 10),
            child: Text(
              "vehiclereRegistrationNo".tr + ": ${to.ride.plateNo}",
              style: Theme.of(context)
                  .textTheme
                  .subtitle2
                  .copyWith(fontSize: 14, fontWeight: FontWeight.w600),
            ),
          ),
          Divider(
            color: AppThemes.lightAthensGrayBorderColor,
            thickness: 2,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 10),
            child: Text(
              "vehicleType".tr + ": ${to.vehicleType}",
              style: Theme.of(context)
                  .textTheme
                  .subtitle2
                  .copyWith(fontSize: 14, fontWeight: FontWeight.w600),
            ),
          ),
          Divider(
            color: AppThemes.lightAthensGrayBorderColor,
            thickness: 2,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 10),
            child: Text(
              "Vehicle model".tr +
                  ": ${to?.ride?.vehicleModel ?? "not mentioned"}  --  " +
                  "Vehicle color : ${to?.ride?.vehicleColor ?? "not mentioned"}",
              style: Theme.of(context)
                  .textTheme
                  .subtitle2
                  .copyWith(fontSize: 14, fontWeight: FontWeight.w600),
            ),
          ),
          Divider(
            color: AppThemes.lightAthensGrayBorderColor,
            thickness: 2,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 10),
            child: Text(
              "tripFare".tr +
                  ": ${authTo.currency} ${double.parse(to.ride.totalfare).toPrecision(2)}",
              style: Theme.of(context)
                  .textTheme
                  .subtitle2
                  .copyWith(fontSize: 14, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }
}
