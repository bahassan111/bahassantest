import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

String formateDateToDDMMYYYY(DateTime dateTime) {
  return DateFormat('dd-MM-yyyy').format(dateTime);
}

String datedayddMMMyyyyhhMMssWithSpace(String date) {
  return DateFormat('dd-MM-yyyy').parse(date).toString().split(' ')[0] +
      "     " +
      DateFormat('dd-MM-yyyy hh:mm:ss')
          .parse(date)
          .toString()
          .split(' ')[1]
          .split('.')[0];
}

String timeFormate(TimeOfDay timeOfDay) {
  if (timeOfDay.hour >= 12) {
    return "${(timeOfDay.hour % 12).toString().padLeft(2, '0')} : ${(timeOfDay.minute).toString().padLeft(2, '0')} PM";
  } else {
    return "${(timeOfDay.hour).toString().padLeft(2, '0')} : ${(timeOfDay.minute).toString().padLeft(2, '0')} AM";
  }
}

String formateTime(TimeOfDay timeOfDay) {
  if (timeOfDay != null) {
    return "${timeOfDay.hour}:${timeOfDay.minute}:00";
  }
}

getddMMyyyyHHMMSS({TimeOfDay timeOfDay, DateTime dateTime}) {
  if (timeOfDay != null && dateTime != null) {
    return formateDateToDDMMYYYY(dateTime) + " " + formateTime(timeOfDay);
  }
  return;
}

getTimeInHHMM(TimeOfDay timeOfDay) {
  if (timeOfDay != null) {
    return "${timeOfDay.hour}:${timeOfDay.minute}";
  }
  return;
}

getTimeInMinutes(TimeOfDay timeOfDay) {
  if (timeOfDay != null) {
    return "${timeOfDay.hour}.${timeOfDay.minute}";
  }
}

getddMMyyyyHHMMSSInDateTime({TimeOfDay timeOfDay, DateTime dateTime}) {
  if (timeOfDay != null && dateTime != null) {
    return DateTime(
      dateTime.year,
      dateTime.month,
      dateTime.day,
      timeOfDay.hour,
      timeOfDay.minute,
      00,
    );
  }
  return;
}

DateTime stringToDateTime(String date) {
  return DateFormat('dd-MM-yyyy hh:mm:ss').parse(date);
}

stringToDateTimeFromDateTime(DateTime date) {
  if (date == null) {
    return;
  }
  return DateFormat('dd-MM-yyyy hh:mm:ss aaa').format(date);
}

String dateddMMMyyyy(DateTime date) {
  return DateFormat('dd MMM yyyy').format(date);
}

String datedayddMMMyyyyhhMMss(DateTime date) {
  return DateFormat('EEEE, dd MMM yyyy').format(date); // hh:mm:ss
}

bool isSameDate(DateTime first, DateTime second) {
  return first.year == second.year &&
      first.month == second.month &&
      first.day == second.day;
}
