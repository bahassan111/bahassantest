import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rider_app/controllers/controllers.dart';
import 'package:rider_app/ui/components/components.dart';

class CustomeAlertDoaligWithTwoOption extends StatelessWidget {
  const CustomeAlertDoaligWithTwoOption(
      {Key key, this.message, this.title, this.email, this.password})
      : super(key: key);
  final String title;
  final String message;
  final String email;
  final String password;
  static AuthController to = Get.find();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(title,
          style: Theme.of(context).textTheme.headline2.copyWith(fontSize: 18)),
      content: Text(message,
          style: Theme.of(context).textTheme.headline2.copyWith(fontSize: 16)),
      actions: [
        Align(
          alignment: Alignment.center,
          child: Container(
            padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
            width: 100,
            child: RoundButton(
              onTap: () async {
                bool isSuccess = await to.logoutFromOtherDevices(
                  email: email.trim(),
                  password: password.trim(),
                );
                if (isSuccess) {
                  await to.signIn(
                    email: email.trim(),
                    password: password.trim(),
                  );
                }
                BotToast.cleanAll();
              },
              text: "ok".tr,
            ),
          ),
        ),
        Align(
          alignment: Alignment.center,
          child: Container(
            padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
            width: 100,
            child: RoundButton(
              onTap: () {
                BotToast.cleanAll();
              },
              text: "cancel".tr,
            ),
          ),
        )
      ],
    );
  }
}
