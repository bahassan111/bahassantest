package ma.rak.ov.api;

import android.app.ActivityOptions;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.provider.BaseColumns;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import ma.rak.ov.LoginActivity;
import ma.rak.ov.R;
import ma.rak.ov.bodyResponse.LoginResponse;
import ma.rak.ov.bodyResponse.OperationResponse;
import ma.rak.ov.bodyResponse.StatistiqueResponse;
import ma.rak.ov.models.Abonnement;
import ma.rak.ov.models.Branchement;
import ma.rak.ov.models.Statistique;
import ma.rak.ov.storage.SharedPrefManager;
import ma.rak.ov.ui.main.Error;
import ma.rak.ov.ui.main.SyncUI;
import ma.rak.ov.utils.NetworkUtility;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public final class TwDatabase {
    // To prevent someone from accidentally instantiating the contract class,
    // make the constructor private.
    private TwDatabase() {}

    public static class MetaTable implements BaseColumns {
        public static final String TABLE_NAME = "meta";
        public static final String COL_KEY = "key";
        public static final String COL_VALUE = "value";
    }


    public static class ALLAgents implements BaseColumns {
        public static final String TABLE_NAME = "all_agents";
        public static final String COL_KEY = "CODEUTIL";
        public static final String COL_LABEL = "NOM_UTIL";
        public static final String COL_TYPE = "CODEPROF";
        public static final String COL_IMEI = "IMEI";
        public static final String CODE_TSP = "CODE_TSP";
    }

    public static class ABNatures implements BaseColumns {
        public static final String TABLE_NAME = "ab_natures";
        public static final String COL_KEY = "key";
        public static final String COL_LABEL = "label";
        public static final String COL_GERANCE = "codegera";
        public static final String CODCATAB = "CODCATAB";
    }
    public static class ABMotifs implements BaseColumns {
        public static final String TABLE_NAME = "ab_motifs";
        public static final String COL_KEY = "key";
        public static final String COL_LABEL = "label";
        public static final String COL_GERANCE = "codegera";
    }
    public static class ABCats implements BaseColumns {
        public static final String TABLE_NAME = "ab_cats";
        public static final String COL_KEY = "key";
        public static final String COL_LABEL = "label";
        public static final String COL_GERANCE = "codegera";
    }
    public static class ABEmplacements implements BaseColumns {
        public static final String TABLE_NAME = "ab_emplacements";
        public static final String COL_KEY = "key";
        public static final String COL_LABEL = "label";
    }
    public static class ABPending implements BaseColumns {
        public static final String TABLE_NAME = "ab_pending";
        public static final String STATOPER = "STATOPER";
        public static final String RESTRAOP = "RESTRAOP";
        public static final String DATTRAOP = "DATTRAOP";
        public static final String DATESAIS = "DATESAIS";
        public static final String CODUTIMA = "CODUTIMA";
        public static final String CODNATIN = "CODNATIN";
        public static final String CODEMPCO = "CODEMPCO";
        public static final String NATU_LOT = "NATU_LOT";
        public static final String CODEETAG = "CODEETAG";
        public static final String NIVEALIM = "NIVEALIM";
        public static final String ANDORESI = "ANDORESI";
        public static final String NUDORESI = "NUDORESI";
        public static final String AVESANDE = "AVESANDE";
        public static final String COMOSTOP = "COMOSTOP";
        public static final String NUMEDOSS = "NUMEDOSS";
        public static final String ANNEDOSS = "ANNEDOSS";
        public static final String NUMOPRAB = "NUMOPRAB";
        public static final String CODEGERA = "CODEGERA";
        public static final String CODCATAB = "CODCATAB";
        public static final String CODUTIEX = "CODUTIEX";
        public static final String REASON = "REASON";
        public static final String LATITUDE = "LATITUDE";
        public static final String LONGITUDE = "LONGITUDE";
        public static final String IMG = "IMG";
        public static final String DISJ = "DISJ";
    }


    public static class ABDemandes implements BaseColumns {
        public static final String TABLE_NAME = "ab_demandes";
        public static final String CODUTIEX = "CODUTIEX";
        public static final String CODNATOP = "CODNATOP";
        public static final String STATOPER = "STATOPER";
        public static final String NOM = "NOM";
        public static final String CIN = "CIN";
        public static final String CODE_CLIENT = "CODE_CLIENT";
        public static final String CODNATCL = "CODNATCL";
        public static final String LIBNATCL = "LIBNATCL";
        public static final String RAISSOCI = "RAISSOCI";
        public static final String ADRECORR = "ADRECORR";
        public static final String NUMEDOSS = "NUMEDOSS";
        public static final String ANNEDOSS = "ANNEDOSS";
        public static final String NUMEPOLI = "NUMEPOLI";
        public static final String TELECLIE = "TELECLIE";
        public static final String NOMPRERE = "NOMPRERE";
        public static final String DATDEMAB = "DATDEMAB";
        public static final String DATCREAB = "DATCREAB";
        public static final String IDENLOCA = "IDENLOCA";
        public static final String LIBEGERA = "LIBEGERA";
        public static final String CODECLAB = "CODECLAB";
        public static final String TYPECLIE = "TYPECLIE";
        public static final String ADRELOCA = "ADRELOCA";
        public static final String CODEAGEN = "CODEAGEN";
        public static final String LIBEAGEN = "LIBEAGEN";
        public static final String CODELOCA = "CODELOCA";
        public static final String LIBELOCA = "LIBELOCA";
        public static final String CODESECT = "CODESECT";
        public static final String CODEGERA = "CODEGERA";
        public static final String CODTAREA = "CODTAREA";
        public static final String CODCATAB = "CODCATAB";
        public static final String CODNATIN = "CODNATIN";
        public static final String NUMOPRAB = "NUMOPRAB";
        public static final String DATESAIS = "DATESAIS";
        public static final String RESTRAOP = "RESTRAOP";
        public static final String DATTRAOP = "DATTRAOP";
        public static final String CODUTIMA = "CODUTIMA";
        public static final String CODEMPCO = "CODEMPCO";
        public static final String NATU_LOT = "NATU_LOT";
        public static final String NIVEALIM = "NIVEALIM";
        public static final String CODEETAG = "CODEETAG";
        public static final String ANDORESI = "ANDORESI";
        public static final String NUDORESI = "NUDORESI";
        public static final String AVESANDE = "AVESANDE";
        public static final String COMOSTOP = "COMOSTOP";
        public static final String NUMETOUR = "NUMETOUR";
        public static final String LONGITUDE = "LONGITUDE";
        public static final String LATITUDE = "LATITUDE";
        public static final String DOSSIERS = "DOSSIERS";
        public static final String IMAGE = "IMAGE";
    }


    public static class BRDemandes implements BaseColumns {
        public static final String TABLE_NAME = "br_demandes";
        public static final String STATOPER = "STATOPER";
        public static final String CODEGERA = "CODEGERA";
        public static final String LIBEGERA = "LIBEGERA";
        public static final String ANNDEMDE = "ANNDEMDE";
        public static final String NUMDEMDE = "NUMDEMDE";
        public static final String CATEDEVI = "CATEDEVI";
        public static final String NOM = "NOM";
        public static final String LIBCATDE = "LIBCATDE";
        public static final String ADRESDEVI = "ADRESDEVI";
        public static final String DATSAIDE = "DATSAIDE";
        public static final String STATDEVI = "STATDEVI";
        public static final String LIBSTADE = "LIBSTADE";
        public static final String CODUTIEX = "CODUTIEX";
        public static final String NOM_UTIL = "NOM_UTIL";
        public static final String OBSEVEDE = "OBSEVEDE";
        public static final String DATTRAOP = "DATTRAOP";
        public static final String DATESAIS = "DATESAIS";
        public static final String CODUTIMA = "CODUTIMA";
        public static final String COMOSTOP = "COMOSTOP";
        public static final String CODNATIN = "CODNATIN";
        public static final String CODCATAB = "CODCATAB";
        public static final String NUMOPEDE = "NUMOPEDE";
        public static final String NUMDEVTA = "NUMDEVTA";
        public static final String LONGITUDE = "LONGITUDE";
        public static final String LATITUDE = "LATITUDE";
        public static final String IMAGE = "IMAGE";
    }





    public static class BRMotifs implements BaseColumns {
        public static final String TABLE_NAME = "br_motifs";
        public static final String COL_KEY = "key";
        public static final String COL_LABEL = "label";
        public static final String COL_GERANCE = "codegera";
        public static final String CODSTAOP = "CODSTAOP";
    }

    public static class BRNatures implements BaseColumns {
        public static final String TABLE_NAME = "br_natures";
        public static final String COL_KEY = "key";
        public static final String COL_LABEL = "label";
        public static final String CODCATAB = "CODCATAB";
        public static final String CODNATIN = "CODNATIN";
        public static final String CALICOMP = "CALICOMP";
        public static final String NOMBFILS = "NOMBFILS";
        public static final String INTENSIT = "INTENSIT";
        public static final String TENSELEC = "TENSELEC";
        public static final String PUISSANC = "PUISSANC";
    }
    public static class BRCats implements BaseColumns {
        public static final String TABLE_NAME = "br_cats";
        public static final String COL_KEY = "key";
        public static final String COL_LABEL = "label";
        public static final String COL_GERANCE = "codegera";
    }

    public static class BRPending implements BaseColumns {
        public static final String TABLE_NAME = "br_pending";
        public static final String STATOPER = "STATOPER";
        public static final String ANNDEMDE = "ANNDEMDE";
        public static final String NUMDEMDE = "NUMDEMDE";
        public static final String NUMOPEDE = "NUMOPEDE";
        public static final String CODEGERA = "CODEGERA";

        public static final String NUMDEVTA = "NUMDEVTA";

        public static final String OBSEVEDE = "OBSEVEDE";
        public static final String DATTRAOP = "DATTRAOP";
        public static final String DATESAIS = "DATESAIS";
        public static final String CODUTIMA = "CODUTIMA";
        public static final String COMOSTOP = "COMOSTOP";

        public static final String CODNATIN = "CODNATIN";
        public static final String CODCATAB = "CODCATAB";

        public static final String REASON = "REASON";
        public static final String LONGITUDE = "LONGITUDE";
        public static final String LATITUDE = "LATITUDE";
        public static final String IMG = "IMG";
    }

    public static class TwDatabaseHelper extends SQLiteOpenHelper {
        public static final int DATABASE_VERSION = 34;
        //public static final String DATABASE_NAME = "RAKOV.db";

        public TwDatabaseHelper(Context context) {
            super(context, "RAKOV_" + SharedPrefManager.getInstance(context).getUserID() + ".db", null, DATABASE_VERSION);
        }

        public TwDatabaseHelper(Context context, String dbname) {
            super(context, dbname, null, DATABASE_VERSION);
        }

        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS " + ALLAgents.TABLE_NAME + ";");
            db.execSQL("DROP TABLE IF EXISTS " + ABNatures.TABLE_NAME + ";");
            db.execSQL("DROP TABLE IF EXISTS " + BRNatures.TABLE_NAME + ";");
            db.execSQL("DROP TABLE IF EXISTS " + ABMotifs.TABLE_NAME + ";");
            db.execSQL("DROP TABLE IF EXISTS " + ABCats.TABLE_NAME + ";");
            db.execSQL("DROP TABLE IF EXISTS " + BRCats.TABLE_NAME + ";");
            db.execSQL("DROP TABLE IF EXISTS " + ABEmplacements.TABLE_NAME + ";");
            db.execSQL("DROP TABLE IF EXISTS " + ABDemandes.TABLE_NAME + ";");
            db.execSQL("DROP TABLE IF EXISTS " + BRDemandes.TABLE_NAME + ";");
            db.execSQL("DROP TABLE IF EXISTS " + MetaTable.TABLE_NAME + ";");
            db.execSQL("DROP TABLE IF EXISTS " + ABPending.TABLE_NAME + ";");
            db.execSQL("DROP TABLE IF EXISTS " + BRPending.TABLE_NAME + ";");
            db.execSQL("DROP TABLE IF EXISTS " + ABMotifs.TABLE_NAME + ";");

            db.execSQL("DROP TABLE IF EXISTS " + BRMotifs.TABLE_NAME + ";");
            onCreate(db);
        }

        public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            onUpgrade(db, oldVersion, newVersion);
        }

        @Override
        public void onCreate(SQLiteDatabase sqLiteDatabase) {

            sqLiteDatabase.execSQL("create table all_agents ( \"_id\" INTEGER PRIMARY KEY, CODEUTIL text, CODE_TSP text, IMEI text, NOM_UTIL text, CODEPROF text );");
            sqLiteDatabase.execSQL("create table ab_natures ( \"_id\" INTEGER PRIMARY KEY, key text, label text, codegera text, CODCATAB text);");
            sqLiteDatabase.execSQL("create table br_natures ( \"_id\" INTEGER PRIMARY KEY, key text, label text, CODCATAB text, CODNATIN text, CALICOMP text, NOMBFILS text, INTENSIT text, TENSELEC text, PUISSANC text);");
            sqLiteDatabase.execSQL("create table ab_motifs ( \"_id\" INTEGER PRIMARY KEY, key text, label text, codegera text);");
            sqLiteDatabase.execSQL("create table br_motifs ( \"_id\" INTEGER PRIMARY KEY, key text, label text, codegera text, CODSTAOP text);");
            sqLiteDatabase.execSQL("create table ab_cats ( \"_id\" INTEGER PRIMARY KEY, key text, label text, codegera text);");
            sqLiteDatabase.execSQL("create table br_cats ( \"_id\" INTEGER PRIMARY KEY, key text, label text, codegera text);");
            sqLiteDatabase.execSQL("create table ab_emplacements ( \"_id\" INTEGER PRIMARY KEY, key text, label text);");
            sqLiteDatabase.execSQL("create table meta ( \"_id\" INTEGER PRIMARY KEY, key text, value text);");
            sqLiteDatabase.execSQL("create table ab_demandes (\"_id\" INTEGER PRIMARY KEY,\n" +
                    "CODUTIEX text,\n" +
                    "CODNATOP text,\n" +
                    "STATOPER text,\n" +
                    "NOM text,\n" +
                    "CIN text,\n" +
                    "CODE_CLIENT text,\n" +
                    "CODNATCL text,\n" +
                    "LIBNATCL text,\n" +
                    "RAISSOCI text,\n" +
                    "ADRECORR text,\n" +
                    "NUMEDOSS text,\n" +
                    "ANNEDOSS text,\n" +
                    "NUMEPOLI text,\n" +
                    "TELECLIE text,\n" +
                    "NOMPRERE text,\n" +
                    "DATDEMAB text,\n" +
                    "DATCREAB text,\n" +
                    "IDENLOCA text,\n" +
                    "LIBEGERA text,\n" +
                    "CODECLAB text,\n" +
                    "TYPECLIE text,\n" +
                    "ADRELOCA text,\n" +
                    "CODEAGEN text,\n" +
                    "LIBEAGEN text,\n" +
                    "CODELOCA text,\n" +
                    "LIBELOCA text,\n" +
                    "CODESECT text,\n" +
                    "CODEGERA text,\n" +
                    "CODTAREA text,\n" +
                    "CODCATAB text,\n" +
                    "CODNATIN text,\n" +
                    "NUMOPRAB text,\n" +
                    "DATESAIS text,\n" +
                    "RESTRAOP text,\n" +
                    "DATTRAOP text,\n" +
                    "CODUTIMA text,\n" +
                    "CODEMPCO text,\n" +
                    "NATU_LOT text,\n" +
                    "NIVEALIM text,\n" +
                    "CODEETAG text,\n" +
                    "ANDORESI text,\n" +
                    "NUDORESI text,\n" +
                    "AVESANDE text,\n" +
                    "COMOSTOP text,\n" +
                    "NUMETOUR text,\n" +
                    "LONGITUDE text,\n" +
                    "LATITUDE text,\n" +
                    "DOSSIERS text,\n" +
                    "IMAGE text\n" +
                    ");");

            sqLiteDatabase.execSQL("create table br_demandes (\"_id\" INTEGER PRIMARY KEY,\n" +
                    "STATOPER TEXT,\n" +
                    "CODEGERA TEXT,\n" +
                    "LIBEGERA TEXT,\n" +
                    "ANNDEMDE TEXT,\n" +
                    "NUMDEMDE TEXT,\n" +
                    "CATEDEVI TEXT,\n" +
                    "NOM TEXT,\n" +
                    "LIBCATDE TEXT,\n" +
                    "ADRESDEVI TEXT,\n" +
                    "DATSAIDE TEXT,\n" +
                    "STATDEVI TEXT,\n" +
                    "LIBSTADE TEXT,\n" +
                    "CODUTIEX TEXT,\n" +
                    "NOM_UTIL TEXT,\n" +
                    "OBSEVEDE TEXT,\n" +
                    "DATTRAOP TEXT,\n" +
                    "DATESAIS TEXT,\n" +
                    "CODUTIMA TEXT,\n" +
                    "COMOSTOP TEXT,\n" +
                    "CODNATIN TEXT,\n" +
                    "CODCATAB TEXT,\n" +
                    "NUMOPEDE TEXT,\n" +
                    "NUMDEVTA TEXT,\n" +
                    "LONGITUDE TEXT,\n"+
                    "LATITUDE TEXT,"+
                    "IMAGE text\n" +
                    ");");

            sqLiteDatabase.execSQL("create table ab_pending (\"_id\" INTEGER PRIMARY KEY,\n" +
                    "STATOPER TEXT,\n" +
                    "RESTRAOP TEXT,\n" +
                    "DATTRAOP TEXT,\n" +
                    "DATESAIS TEXT,\n" +
                    "CODUTIMA TEXT,\n" +
                    "CODNATIN TEXT,\n" +
                    "CODCATAB TEXT,\n" +
                    "CODEGERA TEXT,\n" +
                    "CODEMPCO TEXT,\n" +
                    "NATU_LOT TEXT,\n" +
                    "NIVEALIM TEXT,\n" +
                    "CODEETAG TEXT,\n" +
                    "ANDORESI TEXT,\n" +
                    "NUDORESI TEXT,\n" +
                    "AVESANDE TEXT,\n" +
                    "COMOSTOP TEXT,\n" +
                    "NUMOPRAB TEXT,\n" +
                    "NUMEDOSS TEXT,\n" +
                    "ANNEDOSS TEXT,\n" +
                    "CODUTIEX TEXT,\n" +
                    "REASON TEXT\n," +
                    "LATITUDE TEXT\n," +
                    "LONGITUDE TEXT\n," +
                    "IMG TEXT\n," +
                    "DISJ TEXT\n" +
                    ");");

            sqLiteDatabase.execSQL("create table br_pending (\"_id\" INTEGER PRIMARY KEY,\n" +
                    "STATOPER TEXT,\n" +
                    "ANNDEMDE TEXT,\n" +
                    "NUMDEMDE TEXT,\n" +
                    "NUMOPEDE TEXT,\n" +
                    "CODEGERA TEXT,\n" +
                    "NUMDEVTA TEXT,\n" +
                    "OBSEVEDE TEXT,\n" +
                    "DATTRAOP TEXT,\n" +
                    "DATESAIS TEXT,\n" +
                    "CODUTIMA TEXT,\n" +
                    "COMOSTOP TEXT,\n" +
                    "CODNATIN TEXT,\n" +
                    "CODCATAB TEXT,\n" +
                    "REASON TEXT,\n" +
                    "IMG TEXT\n," +
                    "LATITUDE TEXT,\n" +
                    "LONGITUDE TEXT\n" +
                    ");");



        }





        public long insert(String table, HashMap<String, String> set){

            ContentValues values = new ContentValues();


            for (Map.Entry mapElement : set.entrySet()) {
                values.put(mapElement.getKey().toString(), mapElement.getValue().toString());
            }

            return this.getWritableDatabase().insert(table, null, values);

        }


        public ArrayList query(String table, String Where, String[] params, String order){
            SQLiteDatabase db = this.getReadableDatabase();
            ArrayList<HashMap<String, String>> result = new ArrayList<>();
            Cursor cursor = db.query(table,null, Where, params, null, null, order);
            String[] columnNames = cursor.getColumnNames();
            while(cursor.moveToNext()) {
                HashMap<String, String> row = new HashMap<>();
                for (String col : columnNames) {
                    row.put(col, cursor.getString(cursor.getColumnIndex(col)));
                }
                result.add(row);
            }
            cursor.close();
            return result;
        }


        public StatistiqueResponse getStats(int mode){
            SQLiteDatabase db = this.getReadableDatabase();
            Cursor cursor;
            if(mode == 1){
                cursor = db.query(BRDemandes.TABLE_NAME, new String[]{"STATOPER", "COUNT(STATOPER) total"}, null, null, "STATOPER", null, null);
            }else{
                cursor = db.query(ABDemandes.TABLE_NAME, new String[]{"STATOPER", "COUNT(STATOPER) total"}, null, null, "STATOPER", null, null);
            }


            StatistiqueResponse result = new StatistiqueResponse();
            int total = 0;

            result.setRejetees("0");
            result.setTotal("0");
            result.setExecutees("0");
            result.setEn_cours("0");
            while(cursor.moveToNext()) {
                String st = cursor.getString(0);
                String vl = cursor.getString(1);
                vl = vl == null || vl.equals("") ? "0" : vl;

                total += Integer.valueOf(vl);

                if(mode == 1){
                    if(st.equals("1")){
                        result.setEn_cours(vl);
                    }else if(st.equals("2")){
                        result.setExecutees(vl);
                    }else if(st.equals("3")){
                        result.setRejetees(vl);
                    }
                }else{
                    if(st.equals("1")){
                        result.setEn_cours(vl);
                    }else if(st.equals("2")){
                        result.setExecutees(vl);
                    }else if(st.equals("3")){
                        result.setRejetees(vl);
                    }else if(st.equals("4")){

                    }
                }


            }

            result.setTotal(String.valueOf(total));
            cursor.close();
            return result;
        }
        
        
        
        
        
        
        public boolean insertDemandeAbonnement(Abonnement demande){

            ContentValues values = new ContentValues();

            values.put(TwDatabase.ABDemandes.CODUTIEX, demande.getCODUTIEX());
            values.put(TwDatabase.ABDemandes.CODNATOP, demande.getCODNATOP());
            values.put(TwDatabase.ABDemandes.STATOPER, demande.getSTATOPER());
            values.put(TwDatabase.ABDemandes.NOM, demande.getNOM());
            values.put(TwDatabase.ABDemandes.CIN, demande.getCIN());
            values.put(TwDatabase.ABDemandes.CODE_CLIENT, demande.getCODE_CLIENT());
            values.put(TwDatabase.ABDemandes.CODNATCL, demande.getCODNATCL());
            values.put(TwDatabase.ABDemandes.LIBNATCL, demande.getLIBNATCL());
            values.put(TwDatabase.ABDemandes.RAISSOCI, demande.getRAISSOCI());
            values.put(TwDatabase.ABDemandes.ADRECORR, demande.getADRECORR());
            values.put(TwDatabase.ABDemandes.NUMEDOSS, demande.getNUMEDOSS());
            values.put(TwDatabase.ABDemandes.ANNEDOSS, demande.getANNEDOSS());
            values.put(TwDatabase.ABDemandes.NUMEPOLI, demande.getNUMEPOLI());
            values.put(TwDatabase.ABDemandes.TELECLIE, demande.getTELECLIE());
            values.put(TwDatabase.ABDemandes.NOMPRERE, demande.getNOMPRERE());
            values.put(TwDatabase.ABDemandes.DATDEMAB, demande.getDATDEMAB());
            values.put(TwDatabase.ABDemandes.DATCREAB, demande.getDATCREAB());
            values.put(TwDatabase.ABDemandes.IDENLOCA, demande.getIDENLOCA());
            values.put(TwDatabase.ABDemandes.LIBEGERA, demande.getLIBEGERA());
            values.put(TwDatabase.ABDemandes.CODECLAB, demande.getCODECLAB());
            values.put(TwDatabase.ABDemandes.TYPECLIE, demande.getTYPECLIE());
            values.put(TwDatabase.ABDemandes.ADRELOCA, demande.getADRELOCA());
            values.put(TwDatabase.ABDemandes.CODEAGEN, demande.getCODEAGEN());
            values.put(TwDatabase.ABDemandes.LIBEAGEN, demande.getLIBEAGEN());
            values.put(TwDatabase.ABDemandes.CODELOCA, demande.getCODELOCA());
            values.put(TwDatabase.ABDemandes.LIBELOCA, demande.getLIBELOCA());
            values.put(TwDatabase.ABDemandes.CODESECT, demande.getCODESECT());
            values.put(TwDatabase.ABDemandes.CODEGERA, demande.getCODEGERA());
            values.put(TwDatabase.ABDemandes.CODTAREA, demande.getCODTAREA());
            values.put(TwDatabase.ABDemandes.CODCATAB, demande.getCODCATAB());
            values.put(TwDatabase.ABDemandes.CODNATIN, demande.getCODNATIN());
            values.put(TwDatabase.ABDemandes.NUMOPRAB, demande.getNUMOPRAB());
            values.put(TwDatabase.ABDemandes.DATESAIS, demande.getDATESAIS());
            values.put(TwDatabase.ABDemandes.RESTRAOP, demande.getRESTRAOP());
            values.put(TwDatabase.ABDemandes.DATTRAOP, demande.getDATTRAOP());
            values.put(TwDatabase.ABDemandes.CODUTIMA, demande.getCODUTIMA());
            values.put(TwDatabase.ABDemandes.CODEMPCO, demande.getCODEMPCO());
            values.put(TwDatabase.ABDemandes.NATU_LOT, demande.getNATU_LOT());
            values.put(TwDatabase.ABDemandes.NIVEALIM, demande.getNIVEALIM());
            values.put(TwDatabase.ABDemandes.CODEETAG, demande.getCODEETAG());
            values.put(TwDatabase.ABDemandes.ANDORESI, demande.getANDORESI());
            values.put(ABDemandes.NUDORESI, demande.getNUDORESI());
            values.put(TwDatabase.ABDemandes.AVESANDE, demande.getAVESANDE());
            values.put(TwDatabase.ABDemandes.COMOSTOP, demande.getCOMOSTOP());
            values.put(TwDatabase.ABDemandes.NUMETOUR, demande.getNUMETOUR());
            values.put(TwDatabase.ABDemandes.LONGITUDE, demande.getLONGITUDE());
            values.put(TwDatabase.ABDemandes.LATITUDE, demande.getLATITUDE());
            values.put(TwDatabase.ABDemandes.DOSSIERS, demande.getDossiersJSON());
            values.put(ABDemandes.IMAGE, demande.getIMAGE());


            SQLiteDatabase db = this.getWritableDatabase();

            long newRowId = db.insert(TwDatabase.ABDemandes.TABLE_NAME, null, values);

            db.close();

            return newRowId > 0;
        }

        public boolean insertDemandeBranchement(Branchement demande){

            ContentValues values = new ContentValues();

            values.put(BRDemandes.STATOPER, "1");
            values.put(TwDatabase.BRDemandes.CODEGERA, demande.getCODEGERA());
            values.put(TwDatabase.BRDemandes.LIBEGERA, demande.getLIBEGERA());
            values.put(TwDatabase.BRDemandes.ANNDEMDE, demande.getANNDEMDE());
            values.put(TwDatabase.BRDemandes.NUMDEMDE, demande.getNUMDEMDE());
            values.put(TwDatabase.BRDemandes.CATEDEVI, demande.getCATEDEVI());
            values.put(TwDatabase.BRDemandes.NOM, demande.getNOM());
            values.put(TwDatabase.BRDemandes.LIBCATDE, demande.getLIBCATDE());
            values.put(TwDatabase.BRDemandes.ADRESDEVI, demande.getADRESDEVI());
            values.put(TwDatabase.BRDemandes.DATSAIDE, demande.getDATSAIDE());
            values.put(TwDatabase.BRDemandes.STATDEVI, demande.getSTATDEVI());
            values.put(TwDatabase.BRDemandes.LIBSTADE, demande.getLIBSTADE());
            values.put(TwDatabase.BRDemandes.CODUTIEX, demande.getCODUTIEX());
            values.put(TwDatabase.BRDemandes.NOM_UTIL, demande.getNOM_UTIL());
            values.put(TwDatabase.BRDemandes.LONGITUDE, demande.getLONGITUDE());
            values.put(TwDatabase.BRDemandes.LATITUDE, demande.getLATITUDE());
            values.put(BRDemandes.NUMOPEDE, demande.getNUMOPEDE());


            SQLiteDatabase db = this.getWritableDatabase();

            long newRowId = db.insert(TwDatabase.BRDemandes.TABLE_NAME, null, values);

            db.close();

            return newRowId > 0;
        }


        public static String getToken(Context ctx){
            TwDatabaseHelper dbh = new TwDatabaseHelper(ctx);
            ArrayList res = dbh.query(MetaTable.TABLE_NAME, MetaTable.COL_KEY + " = 'token'", null, null);

            if(res.size() > 0){
                return ((HashMap<String, String>)res.get(0)).get("value");
            }else{
                return null;
            }
        }


        public static boolean setToken(Context ctx, String token){
            TwDatabaseHelper dbh = new TwDatabaseHelper(ctx);
            return dbh.insert(MetaTable.TABLE_NAME, new HashMap<String, String>() {{
                put("key", "token");
                put("value", token);
            }}) > 0;
        }




        public static void ExecuterAbonnement(Context ctx, boolean fromSync, String ANNEDOSS, String NUMEDOSS, String NUMOPRAB, String CODEGERA, String observation, String motif, String nature, String categorie, String emplacement, String nature_lot, String res_doss, String devis, String base64Image, String LATITUDE, String LONGITUDE, String DISJ, Runnable onSuccess, Runnable onOffline, Runnable onFailed){

            int status = 2;
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            Date d = new Date();
            String date = formatter.format(d);
            String token = SharedPrefManager.getInstance(ctx).getToken();
            TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);
            SQLiteDatabase db = dbh.getReadableDatabase();


            String[] rez = res_doss.split("/");
            String ann_res = "", num_rss = "";
            if(rez.length > 1){
                ann_res = rez[0];
                num_rss = rez[1];
            }

            if(LATITUDE == null || LATITUDE.equals("") || LATITUDE == "0"){
                LATITUDE = SharedPrefManager.getInstance(ctx).getPos().get("lat").toString();
                LONGITUDE = SharedPrefManager.getInstance(ctx).getPos().get("lng").toString();
            }

            ContentValues local = new ContentValues();

            local.put("STATOPER", String.valueOf(status));
            local.put("RESTRAOP", observation);
            local.put("DATTRAOP", date);
            local.put("DATESAIS", date);
            local.put("CODUTIMA", SharedPrefManager.getInstance(ctx).getUserID());
            local.put("CODNATIN", nature);
            local.put("CODEMPCO", emplacement);
            local.put("NATU_LOT", nature_lot);
            local.put("CODCATAB", categorie);
            local.put("NIVEALIM", "");
            local.put("CODEETAG", "");
            local.put("ANDORESI", ann_res);
            local.put("NUDORESI", num_rss);
            local.put("AVESANDE", devis);
            local.put("COMOSTOP", motif);
            local.put("LATITUDE", LATITUDE);
            local.put("LONGITUDE", LONGITUDE);
            local.put("IMAGE", base64Image);


            if(!fromSync){
                int lstatus = db.update(TwDatabase.ABDemandes.TABLE_NAME, local, "ANNEDOSS = ? AND NUMEDOSS = ? AND NUMOPRAB = ?", new String[]{ANNEDOSS, NUMEDOSS, NUMOPRAB});

                if(lstatus > 0){
                    onSuccess.run();
                }else{
                    onFailed.run();
                    return;
                }
            }


            Call<OperationResponse> call = RetrofitClient.getApi(token)
                    .executer(
                            "XDEBUG_SESSION=XDEBUG_ECLIPSE",
                            String.valueOf(status),
                            observation,
                            date,
                            nature,
                            categorie,
                            emplacement,
                            "",
                            ann_res,
                            num_rss,
                            NUMOPRAB,
                            CODEGERA,
                            nature_lot,
                            devis,
                            ANNEDOSS,
                            NUMEDOSS,
                            motif,
                            base64Image,
                            LATITUDE,
                            LONGITUDE,
                            DISJ);


            local.put("NUMOPRAB", NUMOPRAB);
            local.put("ANNEDOSS", ANNEDOSS);
            local.put("NUMEDOSS", NUMEDOSS);
            local.put("CODEGERA", CODEGERA);
            local.put("REASON", "");
            local.put("IMG", base64Image);
            local.put("DISJ", DISJ);


            long pid = !fromSync ? db.insert(ABPending.TABLE_NAME, null, local) : 0;

            call.enqueue(new Callback<OperationResponse>() {
                @Override
                public void onResponse(Call<OperationResponse> call, Response<OperationResponse> response) {
                    OperationResponse operationResponse = response.body();
                    if (response.body() != null && response.code() == 200 && response.body().getStatus().equals("SUCCESS")) {

                        SharedPrefManager.getInstance(ctx).setSyncTime(date);
                        if(!fromSync){
                            int r = db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{String.valueOf(pid)});
                            boolean deleted = r > 0;
                        }else{
                            onSuccess.run();
                        }

                    }else{

                        if(!fromSync){
                            ContentValues upd = new ContentValues();
                            upd.put("REASON", response.body() == null ? "500" : response.body().getMsg());
                            db.update(ABPending.TABLE_NAME, upd, ABPending._ID + " = ?", new String[]{String.valueOf(pid)});
                        }


                        onFailed.run();
                    }

                }

                @Override
                public void onFailure(Call<OperationResponse> call, Throwable t) {

                    if(!fromSync){
                        ContentValues upd = new ContentValues();
                        upd.put("REASON", t.getMessage());

                        db.update(ABPending.TABLE_NAME, upd, ABPending._ID + " = ?", new String[]{String.valueOf(pid)});
                    }

                    onOffline.run();

                }
            });

        }


        public static void ExecuterBranchement(Context ctx, boolean fromSync, String ANNDEMDE, String NUMDEMDE, String NUMOPEDE, String CODEGERA, String CATEDEVI, String observation, String motif, String nature, String categorie, String NUMDEVTA, String base64Image, String LATITUDE, String LONGITUDE, Runnable onSuccess, Runnable onOffline, Runnable onFailed){

            int status = 2;
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            Date d = new Date();
            String date = formatter.format(d);
            String token = SharedPrefManager.getInstance(ctx).getToken();
            TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);
            SQLiteDatabase db = dbh.getReadableDatabase();

            if(LATITUDE == null || LATITUDE.equals("") || LATITUDE == "0"){
                LATITUDE = SharedPrefManager.getInstance(ctx).getPos().get("lat").toString();
                LONGITUDE = SharedPrefManager.getInstance(ctx).getPos().get("lng").toString();
            }

            ContentValues local = new ContentValues();

            local.put("STATOPER", String.valueOf(status));
            local.put("OBSEVEDE", observation);
            local.put("DATTRAOP", date);
            local.put("DATESAIS", date);
            local.put("CODUTIMA", SharedPrefManager.getInstance(ctx).getUserID());
            local.put("CODNATIN", nature);
            local.put("CODCATAB", categorie);
            local.put("COMOSTOP", motif);
            local.put("NUMDEVTA", NUMDEVTA);
            local.put(BRDemandes.LATITUDE, LATITUDE);
            local.put(BRDemandes.LONGITUDE, LONGITUDE);
            local.put(BRDemandes.IMAGE, base64Image);



            if(!fromSync){
                int lstatus = db.update(TwDatabase.BRDemandes.TABLE_NAME, local, "ANNDEMDE = ? AND NUMDEMDE = ? AND CODEGERA = ?", new String[]{ANNDEMDE, NUMDEMDE, CODEGERA});


                if(lstatus > 0){
                    onSuccess.run();
                }else{
                    onFailed.run();
                    return;
                }
            }


            Call<OperationResponse> call = RetrofitClient.getApi(token)
                    .executerBr(
                            "XDEBUG_SESSION=XDEBUG_ECLIPSE",
                            String.valueOf(status),
                            observation,
                            date,
                            nature,
                            categorie,
                            CATEDEVI,
                            ANNDEMDE,
                            NUMDEMDE,
                            NUMOPEDE,
                            CODEGERA,
                            motif,
                            base64Image,
                            LATITUDE,
                            LONGITUDE);


            local.put("ANNDEMDE", ANNDEMDE);
            local.put("NUMDEMDE", NUMDEMDE);
            local.put("NUMOPEDE", NUMOPEDE);
            local.put("CODEGERA", CODEGERA);
            local.put("REASON", "");
            local.put("IMG", base64Image);


            long pid = !fromSync ? db.insert(BRPending.TABLE_NAME, null, local) : 0;

            call.enqueue(new Callback<OperationResponse>() {
                @Override
                public void onResponse(Call<OperationResponse> call, Response<OperationResponse> response) {
                    OperationResponse operationResponse = response.body();
                    if (response.body() != null && response.code() == 200 && response.body().getStatus().equals("SUCCESS")) {

                        SharedPrefManager.getInstance(ctx).setSyncTime(date);
                        if(!fromSync){
                            int r = db.delete(BRPending.TABLE_NAME, BRPending._ID + " = ?", new String[]{String.valueOf(pid)});
                            boolean deleted = r > 0;
                        }else{
                            onSuccess.run();
                        }

                    }else{

                        if(!fromSync){
                            ContentValues upd = new ContentValues();
                            upd.put("REASON", response.body() == null ? "500" : response.body().getMsg());

                            db.update(BRPending.TABLE_NAME, upd, BRPending._ID + " = ?", new String[]{String.valueOf(pid)});
                        }


                        onFailed.run();
                    }

                }

                @Override
                public void onFailure(Call<OperationResponse> call, Throwable t) {

                    if(!fromSync){
                        ContentValues upd = new ContentValues();
                        upd.put("REASON", t.getMessage());

                        db.update(BRPending.TABLE_NAME, upd, BRPending._ID + " = ?", new String[]{String.valueOf(pid)});
                    }

                    onOffline.run();

                }
            });

        }

        public static void RejeterBranchement(Context ctx, boolean fromSync, String ANNDEMDE, String NUMDEMDE, String NUMOPEDE, String CODEGERA, String observation, String motif,String base64Image, String LATITUDE, String LONGITUDE, Runnable onSuccess, Runnable onOffline, Runnable onFailed){

            int status = 3;
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            Date d = new Date();
            String date = formatter.format(d);
            String token = SharedPrefManager.getInstance(ctx).getToken();
            TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);
            SQLiteDatabase db = dbh.getReadableDatabase();

            if(LATITUDE == null || LATITUDE.equals("") || LATITUDE == "0"){
                LATITUDE = SharedPrefManager.getInstance(ctx).getPos().get("lat").toString();
                LONGITUDE = SharedPrefManager.getInstance(ctx).getPos().get("lng").toString();
            }

            ContentValues local = new ContentValues();

            local.put("STATOPER", String.valueOf(status));
            local.put("OBSEVEDE", observation);
            local.put("DATTRAOP", date);
            local.put("DATESAIS", date);
            local.put("CODUTIMA", SharedPrefManager.getInstance(ctx).getUserID());
            local.put("COMOSTOP", motif);
            local.put(BRDemandes.LATITUDE, LATITUDE);
            local.put(BRDemandes.LONGITUDE, LONGITUDE);


            if(!fromSync){
                int lstatus = db.update(TwDatabase.BRDemandes.TABLE_NAME, local, "ANNDEMDE = ? AND NUMDEMDE = ? AND CODEGERA = ?", new String[]{ANNDEMDE, NUMDEMDE, CODEGERA});


                if(lstatus > 0){
                    onSuccess.run();
                }else{
                    onFailed.run();
                    return;
                }
            }


            Call<OperationResponse> call = RetrofitClient.getApi(token)
                    .executerBr(
                            "XDEBUG_SESSION=XDEBUG_ECLIPSE",
                            String.valueOf(status),
                            observation,
                            date,
                            "",
                            "",
                            "",
                            ANNDEMDE,
                            NUMDEMDE,
                            NUMOPEDE,
                            CODEGERA,
                            motif,
                            "",
                            LATITUDE,
                            LONGITUDE);


            local.put("ANNDEMDE", ANNDEMDE);
            local.put("NUMDEMDE", NUMDEMDE);
            local.put("NUMOPEDE", NUMOPEDE);
            local.put("CODEGERA", CODEGERA);
            local.put("REASON", "");


            long pid = !fromSync ? db.insert(BRPending.TABLE_NAME, null, local) : 0;

            call.enqueue(new Callback<OperationResponse>() {
                @Override
                public void onResponse(Call<OperationResponse> call, Response<OperationResponse> response) {
                    OperationResponse operationResponse = response.body();
                    if (response.body() != null && response.code() == 200 && response.body().getStatus().equals("SUCCESS")) {

                        SharedPrefManager.getInstance(ctx).setSyncTime(date);
                        if(!fromSync){
                            int r = db.delete(BRPending.TABLE_NAME, BRPending._ID + " = ?", new String[]{String.valueOf(pid)});
                            boolean deleted = r > 0;
                        }else{
                            onSuccess.run();
                        }

                    }else{

                        if(!fromSync){
                            ContentValues upd = new ContentValues();
                            upd.put("REASON", response.body() == null ? "500" : response.body().getMsg());

                            db.update(BRPending.TABLE_NAME, upd, BRPending._ID + " = ?", new String[]{String.valueOf(pid)});
                        }


                        onFailed.run();
                    }

                }

                @Override
                public void onFailure(Call<OperationResponse> call, Throwable t) {

                    if(!fromSync){
                        ContentValues upd = new ContentValues();
                        upd.put("REASON", t.getMessage());

                        db.update(BRPending.TABLE_NAME, upd, BRPending._ID + " = ?", new String[]{String.valueOf(pid)});
                    }

                    onOffline.run();

                }
            });

        }

        public static void NonExecuterBranchement(Context ctx, boolean fromSync, String ANNDEMDE, String NUMDEMDE, String NUMOPEDE, String CODEGERA, String observation, String motif,String base64Image, String LATITUDE, String LONGITUDE, Runnable onSuccess, Runnable onOffline, Runnable onFailed){

            int status = 4;
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            Date d = new Date();
            String date = formatter.format(d);
            String token = SharedPrefManager.getInstance(ctx).getToken();
            TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);
            SQLiteDatabase db = dbh.getReadableDatabase();

            if(LATITUDE == null || LATITUDE.equals("") || LATITUDE == "0"){
                LATITUDE = SharedPrefManager.getInstance(ctx).getPos().get("lat").toString();
                LONGITUDE = SharedPrefManager.getInstance(ctx).getPos().get("lng").toString();
            }

            ContentValues local = new ContentValues();

            local.put("STATOPER", String.valueOf(status));
            local.put("OBSEVEDE", observation);
            local.put("DATTRAOP", date);
            local.put("DATESAIS", date);
            local.put("CODUTIMA", SharedPrefManager.getInstance(ctx).getUserID());
            local.put("COMOSTOP", motif);


            if(!fromSync){
                int lstatus = db.update(TwDatabase.BRDemandes.TABLE_NAME, local, "ANNDEMDE = ? AND NUMDEMDE = ? AND CODEGERA = ?", new String[]{ANNDEMDE, NUMDEMDE, CODEGERA});


                if(lstatus > 0){
                    onSuccess.run();
                }else{
                    onFailed.run();
                    return;
                }
            }


            Call<OperationResponse> call = RetrofitClient.getApi(token)
                    .executerBr(
                            "XDEBUG_SESSION=XDEBUG_ECLIPSE",
                            String.valueOf(status),
                            observation,
                            date,
                            "",
                            "",
                            "",
                            ANNDEMDE,
                            NUMDEMDE,
                            NUMOPEDE,
                            CODEGERA,
                            motif,
                            "",
                            LATITUDE,
                            LONGITUDE);


            local.put("ANNDEMDE", ANNDEMDE);
            local.put("NUMDEMDE", NUMDEMDE);
            local.put("NUMOPEDE", NUMOPEDE);
            local.put("CODEGERA", CODEGERA);
            local.put("REASON", "");


            long pid = !fromSync ? db.insert(BRPending.TABLE_NAME, null, local) : 0;

            call.enqueue(new Callback<OperationResponse>() {
                @Override
                public void onResponse(Call<OperationResponse> call, Response<OperationResponse> response) {
                    OperationResponse operationResponse = response.body();
                    if (response.body() != null && response.code() == 200 && response.body().getStatus().equals("SUCCESS")) {

                        SharedPrefManager.getInstance(ctx).setSyncTime(date);
                        if(!fromSync){
                            int r = db.delete(BRPending.TABLE_NAME, BRPending._ID + " = ?", new String[]{String.valueOf(pid)});
                            boolean deleted = r > 0;
                        }else{
                            onSuccess.run();
                        }

                    }else{

                        if(!fromSync){
                            ContentValues upd = new ContentValues();
                            upd.put("REASON", response.body() == null ? "500" : response.body().getMsg());

                            db.update(BRPending.TABLE_NAME, upd, BRPending._ID + " = ?", new String[]{String.valueOf(pid)});
                        }


                        onFailed.run();
                    }

                }

                @Override
                public void onFailure(Call<OperationResponse> call, Throwable t) {

                    if(!fromSync){
                        ContentValues upd = new ContentValues();
                        upd.put("REASON", t.getMessage());

                        db.update(BRPending.TABLE_NAME, upd, BRPending._ID + " = ?", new String[]{String.valueOf(pid)});
                    }

                    onOffline.run();

                }
            });

        }



        public static void RejeterAbonnement(Context ctx,boolean fromSync, String ANNEDOSS, String NUMEDOSS, String NUMOPRAB, String CODEGERA, String observation, String motif, String base64Image, String LATITUDE, String LONGITUDE,  Runnable onSuccess, Runnable onOffline, Runnable onFailed){

            int status = 3;
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            Date d = new Date();
            String date = formatter.format(d);
            String token = SharedPrefManager.getInstance(ctx).getToken();
            TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);
            SQLiteDatabase db = dbh.getReadableDatabase();

            if(LATITUDE == null || LATITUDE.equals("") || LATITUDE == "0"){
                LATITUDE = SharedPrefManager.getInstance(ctx).getPos().get("lat").toString();
                LONGITUDE = SharedPrefManager.getInstance(ctx).getPos().get("lng").toString();
            }

            ContentValues local = new ContentValues();

            local.put("STATOPER", String.valueOf(status));
            local.put("RESTRAOP", observation);
            local.put("DATTRAOP", date);
            local.put("DATESAIS", date);
            local.put("CODUTIMA", SharedPrefManager.getInstance(ctx).getUserID());
            local.put("COMOSTOP", motif);


            if(!fromSync){
                int lstatus = db.update(TwDatabase.ABDemandes.TABLE_NAME, local, "ANNEDOSS = ? AND NUMEDOSS = ? AND NUMOPRAB = ?", new String[]{ANNEDOSS, NUMEDOSS, NUMOPRAB});


                if(lstatus > 0){
                    onSuccess.run();
                }else{
                    onFailed.run();
                    return;
                }
            }

            Call<OperationResponse> call = RetrofitClient.getApi(token)
                    .executer(
                            "XDEBUG_SESSION=XDEBUG_ECLIPSE",
                            String.valueOf(status),
                            observation,
                            date,
                            null,
                            null,
                            null,
                            null,
                            null,
                            null,
                            NUMOPRAB,
                            CODEGERA,
                            null,
                            null,
                            ANNEDOSS,
                            NUMEDOSS,
                            motif,
                            base64Image,
                            LATITUDE,
                            LONGITUDE,
                            null);


            local.put("NUMOPRAB", NUMOPRAB);
            local.put("ANNEDOSS", ANNEDOSS);
            local.put("NUMEDOSS", NUMEDOSS);
            local.put("CODEGERA", CODEGERA);
            local.put("REASON", "");

            long pid = fromSync ? 0 : db.insert(ABPending.TABLE_NAME, null, local);

            call.enqueue(new Callback<OperationResponse>() {
                @Override
                public void onResponse(Call<OperationResponse> call, Response<OperationResponse> response) {
                    OperationResponse operationResponse = response.body();
                    if (response.body() != null && response.code() == 200 && response.body().getStatus().equals("SUCCESS")) {
                        SharedPrefManager.getInstance(ctx).setSyncTime(date);
                        if(!fromSync){
                            int r = db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{String.valueOf(pid)});
                            boolean deleted = r > 0;
                        }else{
                            onSuccess.run();
                        }

                    }else{

                        if(!fromSync){
                            ContentValues upd = new ContentValues();
                            upd.put("REASON", response.body().getMsg());

                            db.update(ABPending.TABLE_NAME, upd, ABPending._ID + " = ?", new String[]{String.valueOf(pid)});
                        }

                        onFailed.run();
                    }

                }

                @Override
                public void onFailure(Call<OperationResponse> call, Throwable t) {

                    if(!fromSync){
                        ContentValues upd = new ContentValues();
                        upd.put("REASON", t.getMessage());
                        db.update(ABPending.TABLE_NAME, upd, ABPending._ID + " = ?", new String[]{String.valueOf(pid)});
                    }

                    onOffline.run();

                }
            });

        }

        public static void NonExecuteAbonnement(Context ctx,boolean fromSync, String ANNEDOSS, String NUMEDOSS, String NUMOPRAB, String CODEGERA, String observation, String motif, String base64Image, String LATITUDE, String LONGITUDE, Runnable onSuccess, Runnable onOffline, Runnable onFailed){

            int status = 4;
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            Date d = new Date();
            String date = formatter.format(d);
            String token = SharedPrefManager.getInstance(ctx).getToken();
            TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);
            SQLiteDatabase db = dbh.getReadableDatabase();

            if(LATITUDE == null || LATITUDE.equals("") || LATITUDE == "0"){
                LATITUDE = SharedPrefManager.getInstance(ctx).getPos().get("lat").toString();
                LONGITUDE = SharedPrefManager.getInstance(ctx).getPos().get("lng").toString();
            }

            ContentValues local = new ContentValues();

            local.put("STATOPER", String.valueOf(status));
            local.put("RESTRAOP", observation);
            local.put("DATTRAOP", date);
            local.put("DATESAIS", date);
            local.put("CODUTIMA", SharedPrefManager.getInstance(ctx).getUserID());
            local.put("COMOSTOP", motif);


            if(!fromSync){
                int lstatus = db.update(TwDatabase.ABDemandes.TABLE_NAME, local, "ANNEDOSS = ? AND NUMEDOSS = ? AND NUMOPRAB = ?", new String[]{ANNEDOSS, NUMEDOSS, NUMOPRAB});


                if(lstatus > 0){
                    onSuccess.run();
                }else{
                    onFailed.run();
                    return;
                }
            }

            Call<OperationResponse> call = RetrofitClient.getApi(token)
                    .executer(
                            "XDEBUG_SESSION=XDEBUG_ECLIPSE",
                            String.valueOf(status),
                            observation,
                            date,
                            null,
                            null,
                            null,
                            null,
                            null,
                            null,
                            NUMOPRAB,
                            CODEGERA,
                            null,
                            null,
                            ANNEDOSS,
                            NUMEDOSS,
                            motif,
                            base64Image,
                            LATITUDE,
                            LONGITUDE,
                            null);


            local.put("NUMOPRAB", NUMOPRAB);
            local.put("ANNEDOSS", ANNEDOSS);
            local.put("NUMEDOSS", NUMEDOSS);
            local.put("CODEGERA", CODEGERA);
            local.put("REASON", "");

            long pid = fromSync ? 0 : db.insert(ABPending.TABLE_NAME, null, local);

            call.enqueue(new Callback<OperationResponse>() {
                @Override
                public void onResponse(Call<OperationResponse> call, Response<OperationResponse> response) {
                    OperationResponse operationResponse = response.body();
                    if (response.body() != null && response.code() == 200 && response.body().getStatus().equals("SUCCESS")) {
                        SharedPrefManager.getInstance(ctx).setSyncTime(date);
                        if(!fromSync){
                            int r = db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{String.valueOf(pid)});
                            boolean deleted = r > 0;
                        }else{
                            onSuccess.run();
                        }

                    }else{

                        if(!fromSync){
                            ContentValues upd = new ContentValues();
                            upd.put("REASON", response.body().getMsg());

                            db.update(ABPending.TABLE_NAME, upd, ABPending._ID + " = ?", new String[]{String.valueOf(pid)});
                        }

                        onFailed.run();
                    }

                }

                @Override
                public void onFailure(Call<OperationResponse> call, Throwable t) {

                    if(!fromSync){
                        ContentValues upd = new ContentValues();
                        upd.put("REASON", t.getMessage());
                        db.update(ABPending.TABLE_NAME, upd, ABPending._ID + " = ?", new String[]{String.valueOf(pid)});
                    }

                    onOffline.run();

                }
            });

        }

        public static void ReaffecterAbonnement(Context ctx,boolean fromSync, String ANNEDOSS, String NUMEDOSS, String NUMOPRAB, String CODEGERA, String agent, Runnable onSuccess, Runnable onOffline, Runnable onFailed){

            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            Date d = new Date();
            String date = formatter.format(d);
            String token = SharedPrefManager.getInstance(ctx).getToken();
            TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);
            SQLiteDatabase db = dbh.getReadableDatabase();


            ContentValues local = new ContentValues();
            local.put("DATTRAOP", date);
            local.put("DATESAIS", date);
            local.put("CODUTIEX", agent);
            local.put("CODUTIMA", SharedPrefManager.getInstance(ctx).getUserID());


            if(!fromSync){
                int lstatus = db.update(TwDatabase.ABDemandes.TABLE_NAME, local, "ANNEDOSS = ? AND NUMEDOSS = ? AND NUMOPRAB = ?", new String[]{ANNEDOSS, NUMEDOSS, NUMOPRAB});


                if(lstatus > 0){
                    onSuccess.run();
                }else{
                    onFailed.run();
                    return;
                }
            }

            Call<OperationResponse> call = RetrofitClient.getApi(token)
                    .reaffecter(
                            "XDEBUG_SESSION=XDEBUG_ECLIPSE",
                            ANNEDOSS,
                            NUMEDOSS,
                            NUMOPRAB,
                            CODEGERA,
                            agent);


            local.put("NUMOPRAB", NUMOPRAB);
            local.put("ANNEDOSS", ANNEDOSS);
            local.put("NUMEDOSS", NUMEDOSS);
            local.put("CODEGERA", CODEGERA);
            local.put("REASON", "");

            long pid = fromSync ? 0 : db.insert(ABPending.TABLE_NAME, null, local);

            call.enqueue(new Callback<OperationResponse>() {
                @Override
                public void onResponse(Call<OperationResponse> call, Response<OperationResponse> response) {
                    OperationResponse operationResponse = response.body();
                    if (response.body() != null && response.code() == 200 && response.body().getStatus().equals("SUCCESS")) {
                        SharedPrefManager.getInstance(ctx).setSyncTime(date);
                        if(!fromSync){
                            int r = db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{String.valueOf(pid)});
                            boolean deleted = r > 0;
                        }else{
                            onSuccess.run();
                        }

                    }else{

                        if(!fromSync){
                            ContentValues upd = new ContentValues();
                            upd.put("REASON", response.body() != null ? response.body().getMsg() : "ERROR");

                            db.update(ABPending.TABLE_NAME, upd, ABPending._ID + " = ?", new String[]{String.valueOf(pid)});
                        }

                        onFailed.run();
                    }

                }

                @Override
                public void onFailure(Call<OperationResponse> call, Throwable t) {

                    if(!fromSync){
                        ContentValues upd = new ContentValues();
                        upd.put("REASON", t.getMessage());
                        db.update(ABPending.TABLE_NAME, upd, ABPending._ID + " = ?", new String[]{String.valueOf(pid)});
                    }

                    onOffline.run();

                }
            });

        }


        public static void synchroniz(Context ctx, Runnable onStep, Runnable onSuccess, Runnable onFail){

            TwDatabaseHelper dbh = new TwDatabaseHelper(ctx);
            SQLiteDatabase db = dbh.getReadableDatabase();

            boolean finished = true;

            ArrayList<HashMap<String, String>> pendings = dbh.query(ABPending.TABLE_NAME, null, null, null);

            Log.e("#################", "Entred sync" + String.valueOf(pendings.size()));

            for (HashMap<String, String> pending: pendings) {


                finished = false;
                if(pending.get("STATOPER") == null){
                    Log.e("#################", "sent run");
                    TwDatabaseHelper.ReaffecterAbonnement(ctx, true,
                            pending.get("ANNEDOSS"),
                            pending.get("NUMEDOSS"),
                            pending.get("NUMOPRAB"),
                            pending.get("CODEGERA"),
                            pending.get("CODUTIEX"),
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got success");
                                    db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});

                                    onStep.run();
                                    synchroniz(ctx, onStep, onSuccess, onFail);
                                }
                            },
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got offline");
                                    //db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});

                                    onFail.run();
                                }
                            },
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got error");
                                    //db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});

                                    onFail.run();
                                }
                            }
                    );
                }
                else if(pending.get("STATOPER").equals("2")){
                    Log.e("#################", "sent run");
                    TwDatabaseHelper.ExecuterAbonnement(ctx, true,
                            pending.get("ANNEDOSS"),
                            pending.get("NUMEDOSS"),
                            pending.get("NUMOPRAB"),
                            pending.get("CODEGERA"),
                            pending.get("RESTRAOP"),
                            pending.get("COMOSTOP"),
                            pending.get("CODNATIN"),
                            pending.get("CODCATAB"),
                            pending.get("CODEMPCO"),
                            pending.get("NATU_LOT"),
                            pending.get("ANDORESI"),
                            pending.get("AVESANDE"),
                            pending.get("IMG"),
                            pending.get("LATITUDE"),
                            pending.get("LONGITUDE"),
                            pending.get("DISJ"),
                            new Runnable() {
                                @Override
                                public void run() {

                                    Log.e("#################", "sit success");

                                    db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});

                                    onStep.run();
                                    synchroniz(ctx, onStep, onSuccess, onFail);
                                }
                            },
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got offline");
                                    //db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});
                                    onFail.run();
                                }
                            },
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got error");
                                    //db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});
                                    onFail.run();
                                }
                            }
                    );
                }
                else if(pending.get("STATOPER").equals("3")){
                    Log.e("#################", "sent run");
                    TwDatabaseHelper.RejeterAbonnement(ctx, true,
                            pending.get("ANNEDOSS"),
                            pending.get("NUMEDOSS"),
                            pending.get("NUMOPRAB"),
                            pending.get("CODEGERA"),
                            pending.get("RESTRAOP"),
                            pending.get("COMOSTOP"),
                            "",
                            pending.get("LATITUDE"),
                            pending.get("LONGITUDE"),
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got success");
                                    db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});

                                    onStep.run();
                                    synchroniz(ctx, onStep, onSuccess, onFail);
                                }
                            },
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got offline");
                                    //db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});

                                    onFail.run();
                                }
                            },
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got error");
                                    //db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});

                                    onFail.run();
                                }
                            }
                    );
                }
                else if(pending.get("STATOPER").equals("4")){
                    Log.e("#################", "sent run");
                    TwDatabaseHelper.NonExecuteAbonnement(ctx, true,
                            pending.get("ANNEDOSS"),
                            pending.get("NUMEDOSS"),
                            pending.get("NUMOPRAB"),
                            pending.get("CODEGERA"),
                            pending.get("RESTRAOP"),
                            pending.get("COMOSTOP"),
                            "",
                            pending.get("LATITUDE"),
                            pending.get("LONGITUDE"),
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got success");
                                    db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});

                                    onStep.run();
                                    synchroniz(ctx, onStep, onSuccess, onFail);
                                }
                            },
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got offline");
                                    //db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});

                                    onFail.run();
                                }
                            },
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got error");
                                    //db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});

                                    onFail.run();
                                }
                            }
                    );
                }


            }


            Log.e("#################", "end s " + (finished ? "will success" : "will return"));

            if(!finished) return;

            TwSyncher.getNewAbonnement(ctx, db, new Runnable() {
                @Override
                public void run() {
                    synchronizBr(ctx, onStep, onSuccess, onFail);
                }
            }, new Runnable() {
                @Override
                public void run() {
                    synchronizBr(ctx, onStep, onSuccess, onFail);
                }
            });






        }
        public static void synchronizBr(Context ctx, Runnable onStep, Runnable onSuccess, Runnable onFail){

            TwDatabaseHelper dbh = new TwDatabaseHelper(ctx);
            SQLiteDatabase db = dbh.getReadableDatabase();

            boolean finished = true;

            ArrayList<HashMap<String, String>> pendings = dbh.query(BRPending.TABLE_NAME, null, null, null);

            Log.e("#################", "Entred sync br" + String.valueOf(pendings.size()));

            for (HashMap<String, String> pending: pendings) {


                finished = false;
                if(pending.get("STATOPER") == null){
                    Log.e("#################", "sent run");
                    TwDatabaseHelper.ReaffecterAbonnement(ctx, true,
                            pending.get("ANNEDOSS"),
                            pending.get("NUMEDOSS"),
                            pending.get("NUMOPRAB"),
                            pending.get("CODEGERA"),
                            pending.get("CODUTIEX"),
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got success");
                                    db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});

                                    onStep.run();
                                    synchroniz(ctx, onStep, onSuccess, onFail);
                                }
                            },
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got offline");
                                    //db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});

                                    onFail.run();
                                }
                            },
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got error");
                                    //db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});

                                    onFail.run();
                                }
                            }
                    );
                }
                else if(pending.get("STATOPER").equals("2")){
                    Log.e("#################", "sent run");
                    TwDatabaseHelper.ExecuterBranchement(ctx, true,
                            pending.get("ANNDEMDE"),
                            pending.get("NUMDEMDE"),
                            pending.get("NUMOPEDE"),
                            pending.get("CODEGERA"),
                            null,
                            pending.get("OBSEVEDE"),
                            pending.get("COMOSTOP"),
                            pending.get("CODNATIN"),
                            pending.get("CODCATAB"),
                            pending.get("NUMDEVTA"),
                            "",
                            pending.get("LATITUDE"),
                            pending.get("LONGITUDE"),
                            new Runnable() {
                                @Override
                                public void run() {

                                    Log.e("#################", "sit success");

                                    int deleted = db.delete(BRPending.TABLE_NAME, BRPending._ID + " = ?", new String[]{pending.get(BRPending._ID)});

                                    if(deleted < 1){

                                    }

                                    onStep.run();
                                    synchronizBr(ctx, onStep, onSuccess, onFail);
                                }
                            },
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got offline br");
                                    //db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});
                                    onFail.run();
                                }
                            },
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got error br");
                                    //db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});
                                    onFail.run();
                                }
                            }
                    );
                }
                else if(pending.get("STATOPER").equals("3")){
                    Log.e("#################", "sent run");
                    TwDatabaseHelper.RejeterAbonnement(ctx, true,
                            pending.get("ANNEDOSS"),
                            pending.get("NUMEDOSS"),
                            pending.get("NUMOPRAB"),
                            pending.get("CODEGERA"),
                            pending.get("RESTRAOP"),
                            pending.get("COMOSTOP"),
                            "",
                            pending.get("LATITUDE"),
                            pending.get("LONGITUDE"),
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got success");
                                    db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});

                                    onStep.run();
                                    synchroniz(ctx, onStep, onSuccess, onFail);
                                }
                            },
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got offline");
                                    //db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});

                                    onFail.run();
                                }
                            },
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got error");
                                    //db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});

                                    onFail.run();
                                }
                            }
                    );
                }
                else if(pending.get("STATOPER").equals("4")){
                    Log.e("#################", "sent run");
                    TwDatabaseHelper.NonExecuteAbonnement(ctx, true,
                            pending.get("ANNEDOSS"),
                            pending.get("NUMEDOSS"),
                            pending.get("NUMOPRAB"),
                            pending.get("CODEGERA"),
                            pending.get("RESTRAOP"),
                            pending.get("COMOSTOP"),
                            "",
                            pending.get("LATITUDE"),
                            pending.get("LONGITUDE"),
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got success");
                                    db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});

                                    onStep.run();
                                    synchroniz(ctx, onStep, onSuccess, onFail);
                                }
                            },
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got offline");
                                    //db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});

                                    onFail.run();
                                }
                            },
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got error");
                                    //db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});

                                    onFail.run();
                                }
                            }
                    );
                }


            }


            Log.e("#################", "end s " + (finished ? "will success" : "will return"));

            if(!finished) return;

            TwSyncher.getNewBranchement(ctx, db, new Runnable() {
                @Override
                public void run() {
                    onSuccess.run();
                }
            }, new Runnable() {
                @Override
                public void run() {
                    onSuccess.run();
                }
            });






        }

        public static void handleRefreshToken(Context ctx){

            int ctime = (int)System.currentTimeMillis()/1000;
            int ltime = SharedPrefManager.getInstance(ctx).getLoginTime();

            if((ctime - ltime) < 3500){
                return;
            }

            SharedPrefManager pref = SharedPrefManager.getInstance(ctx);

            String username = pref.getUserID();
            String pass = pref.getUserPassword();

            String auth = Base64.encodeToString((username + ":" + pass).trim().getBytes(), Base64.NO_WRAP | Base64.URL_SAFE);
            String imei = NetworkUtility.getIMEI(ctx);

            try {
                Call<LoginResponse> call = RetrofitClient
                        .getApiNoHeaders()
                        .auth("XDEBUG_SESSION=XDEBUG_ECLIPSE", "Basic " + auth, "work_access", imei);

                call.enqueue(new Callback<LoginResponse>() {
                    @Override
                    public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                        LoginResponse s = null;
                        if (response.code() == 200) {
                            s = response.body();
                            pref.saveUser(username, s.getData().token, s.getData().expires.toString(), s.getData().scoop, s.getData().fullname, username, pass);

                            Handler handler1 = new Handler();
                            handler1.postDelayed(new Runnable() {
                                @Override
                                public void run() {

                                    Toast.makeText(ctx, "Token est actualisé avec succès", Toast.LENGTH_LONG).show();

                                }
                            }, 500);


                        } else {

                            TwDatabaseHelper.showError(ctx);

                        }
                    }

                    @Override
                    public void onFailure(Call<LoginResponse> call, Throwable t) {
                        TwDatabaseHelper.showError(ctx);
                    }


                });
            } catch (Exception e) {
                TwDatabaseHelper.showError(ctx);
            }

        }


        public static void showError(Context ctx){
            Intent intent = new Intent(ctx, Error.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            ctx.startActivity(intent);
        }
        
    }
}
