<?php
addJS([
    'assets/js/views/run.js',
]);

viewHeader(
    'Test Run : ' . $run->title,
    'Run Tests and manage Run Reports',
    [
        (object) ['name' => 'Dashboard', 'url' => site_url()],
        (object) ['name' => 'Projects', 'url' => site_url('projects')],
        (object) ['name' => $project->name, 'url' => getProjectUrl($project)],
        (object) ['name' => 'Test Runs', 'url' => getProjectUrl($project, 'runs')],
        (object) ['name' => $run->title, 'url' => ''],
    ], true);

projectMenu('test_runs', $project);
?>



<div class="project_runs_body n_menu" id="run_view">

    <div class="run_list">

    </div>



</div>



<script>
    var project_id = <?= $project->id ?: 0; ?>;
    var run_id = <?= $run->id ?: 0; ?>;
</script>
