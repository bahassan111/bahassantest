package ma.rak.ovr.models;

import io.realm.RealmObject;

public class MotifBr extends RealmObject {

    private int ID;
    private String label;
    private String CODEGERA;
    private String CODSTAOP;


    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getLabel() {
        return label;
    }

    public String getCodegera() {
        return CODEGERA;
    }

    public void setCodegera(String codegera) {
        this.CODEGERA = codegera;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public MotifBr(int ID, String label, String codegera, String codstaop) {
        this.ID = ID;
        this.label = label;
        this.CODEGERA = codegera;
        this.CODSTAOP = codstaop;
    }

    public MotifBr() {
    }

    @Override
    public String toString() {
        return "MotifBr{" +
                "ID=" + ID +
                ", label='" + label + '\'' +
                ", codegera='" + CODEGERA + '\'' +
                ", codstaop='" + CODSTAOP + '\'' +
                '}';
    }

    public String getCodstaop() {
        return CODSTAOP;
    }

    public void setCodstaop(String codstaop) {
        this.CODSTAOP = codstaop;
    }
}
