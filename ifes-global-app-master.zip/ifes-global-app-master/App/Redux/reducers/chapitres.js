import {
  SET_ARTICLE_DETAILS,
  PENDING_FETCH_ARTICLE,
  SUCCESS_FETCH_ARTICLE,
  SEARCH_ARTICLE,
  SUCCESS_SEARCH_ARTICLE,
  PENDING_SEARCH_ARTICLE,
} from "../actions/types";

export default function (
  state = { isLoadingData: false, isDoSearch: false, data: [], keyword: null },
  action
) {
  console.log("Log_action => ", action.type);

  switch (action.type) {
    case PENDING_FETCH_ARTICLE:
      return {
        ...state,
        isLoadingData: true,
      };
    case PENDING_SEARCH_ARTICLE:
      return {
        ...state,
        isDoSearch: true,
      };
    case SET_ARTICLE_DETAILS:
      return { ...state, data: action.payload };

    case SEARCH_ARTICLE:
      return {
        ...state,
        keyword: action.keyword,
      };
    case SUCCESS_FETCH_ARTICLE:
      return {
        ...state,
        isLoadingData: false,
      };
    case SUCCESS_SEARCH_ARTICLE:
      return {
        ...state,
        isDoSearch: false,
      };

    default:
      return state;
  }
}
