$.fn.twTable = (function (op, tt) {
    var IsCommande = typeof op === "string",
        isNew = $(this).find('.tw_datatable').length === 0,
        holder, commande = op;

;

    if(isNew){
        holder = $('<div class="tw_datatable">\n' +
            '            <div class="twdt_head"><div class="twdt_actions"></div><div class="twd_search">\n' +
            '            <input type="search" placeholder="Search .."></div></div><div class="twdt_body">' +
            '<div class="table-responsive">\n' +
            '                    <table class="table twdt_table"><thead></thead><tbody></tbody></table>\n' +
            '                </div>\n' +
            '            </div>' +
            '<div class="twdt_footer"><p></p><div><button type="button" class="btn btn-sm btn-outline-dark">Load more ..</button></div></div>' +
            '        </div>');

        $(this).html(holder);

    }else{
        holder = $(this).find('.tw_datatable');
    }




    var head = holder.find('.twdt_head'),
        actions = holder.find('.twdt_actions'),
        search = holder.find('.twd_search'),
        search_input = search.find('input'),
        body = holder.find('.twdt_body'),
        table = holder.find('.twdt_table'),
        tbody = table.find('tbody'),
        thead = table.find('thead'),
        footer_txt = holder.find('.twdt_footer > p'),
        loadmore = holder.find('.twdt_footer > div'),


        options = {
            columns : [],
            buttons : [],
            key : null,

            dblclick : function(key, tr){},
            order : 0,
            order_dir : 'ASC',
            length : 10,
        }


    ;

    if(isNew){
        if(typeof op === "object"){
            options = $.extend(options, op);
        }
        init();
        getData();
    }else if(IsCommande){
        options = holder.data('options');

        switch (commande) {
            case 'refresh' : {
                table.data('page', 1);
                getData(typeof tt === "function" ? tt : null);
                return $(this);
            }
            case 'select' : {
                tbody.find(`tr[data-trkey="${tt || 0}"]`).removeClass('selected').trigger('click');
                return $(this);
            }
        }

    }



    function init(){

        holder.data('options', options);
        table.data({
            page : 1,
            order : options.order,
            order_dir: options.order_dir,
        });

        var btns = options.buttons || [];
        btns.push({
            icon : 'fas fa-sync',
            color : 'primary',
            global : true,
            action : function () {
                table.data('page', 1);
                getData();
            }
        });

        actions.html('');
        $.each(options.buttons, function (i, button) {
            if(button.separator){
                actions.append('<span class="twdt_btns_sep"></span>');
                return true;
            }

            var btn = $('<button type="button" class="btnx btn btn-sm"></button>').appendTo(actions);

            btn
                .addClass('btn-outline-' + (button.color || 'secondary'))
                .html(button.text || '')
            ;

            if(button.remote){
                btn.addClass('pr').attr('data-remote', button.remote).hide();
            }

            if(button.icon) btn.append(`<i class="${button.icon}"></i>`);
            if(button.global) btn.addClass('g'); else btn.prop('disabled', true);

            btn.on('click', function () {
                holder.trigger('button.clicked', btn);
                (button.action || function(){})(btn.data('key'));
            });

            if(button.condition) {
                btn.addClass('cc').prop('disabled', true);
                holder.on('tr.selected', function (e, key) {
                    var row = $('tr[data-trkey="'+key+'"]').data('row');

                    var show = !!button.condition(row);
                    btn.prop('disabled', !show);
                })
                    .on('tr.unselected', function () {
                        btn.prop('disabled', true);
                    })
            }

            if(button.title){
                btn.attr('title', button.title);
                btn.tooltip({title : button.title, placement : 'top', delay : 400});
            }


        });

        handleEvents();
        initTable();
    }

    function handleEvents() {

        table
            .on('click', 'thead > tr > th.orderable', function () {
                var dir = $(this).hasClass('order_asc') ? 'DESC' : 'ASC';

                table
                    .data('page', 1)
                    .data('order', $(this).index())
                    .data('order_dir', dir);

                getData();
            })
            .on('click', 'tbody > tr', function () {
                var that = $(this);
                var on = that.toggleClass('selected').hasClass('selected');
                that.parent().find('.selected').not(this).removeClass('selected');

                if(on) holder.trigger('tr.selected', that.data('trkey'));
                else holder.trigger('tr.unselected', that);

            })
            .on('dblclick', 'tbody > tr', function () {
                log(this);
                var that = $(this);
                var on = that.addClass('selected').hasClass('selected');
                that.parent().find('.selected').not(this).removeClass('selected');

                holder.trigger('tr.selected', that.data('trkey'));

                (options.dblclick || function(){})(that.data('trkey'), that);

            });

        search_input.on('change keyup', function () {
            table.data('page', 1);
            getData();
        });

        holder
            .on('click', '.twdt_footer > div button', function () {
                table.data('page', (table.data('page') || 1) + 1);
                getData();
            })

            .on('button.clicked', function () {

            })
            .on('tr.selected', function (e, key, tr) {
                actions.find('button').not('.g')
                    .data('key', key)
                    .not('.cc')
                    .prop('disabled', false);
            })
            .on('tr.unselected', function (sender) {
                actions.find('button').not('.g')
                    .data('key', null)
                    .prop('disabled', true);
            })


    }
    function initTable() {

        var tr = $('<tr></tr>');
        $.each(options.columns, function (i, col) {
            var th = $('<th></th>');

            th.html(col.title || '').data('data', col);
            if(col.orderable) th.addClass('orderable');

            tr.append(th);
        });

        thead.append(tr);

    }

    function getData(then) {
        var page = table.data('page') || 1;
        page = parseInt(page);



        table.find('thead > tr > th')
            .removeClass('order_desc order_asc')
            .eq(table.data('order') || 0).addClass('order_' + (table.data('order_dir') || 'ASC').toLowerCase());

        table.find('tr.selected').removeClass('selected');
        holder.trigger('tr.unselected', table);

        setLoading(true, 'Getting data ..');
        var req = $.post(options.url, {

            page : page,
            length : options.length,
            search : search_input.val(),
            order : table.data('order') || 0,
            dir : table.data('order_dir') || 'ASC',
            columns : options.columns,

        }, function (rep) {
            var data = rep.data || [],
                total = rep.total || 0,
                total_filter = rep.total_filter || 0,
                rest = rep.rest || 0;

            if(page === 1) tbody.html('');

            actions.find(`button[data-remote]`).hide();
            if(rep.permissions){
                $.each(rep.permissions, function (i, permission) {
                    log(i, permission);
                    actions.find(`button[data-remote="${permission}"]`).show();
                })
            }

            if(rest > 0) loadmore.show(); else loadmore.hide();
            if(data.length > 0){
                footer_txt.show().html(`Showing ${total - rest} from ${total}`);
            }else{
                if(page === 1) footer_txt.hide();
            }

            $.each(data, function (i, row) {
                var tr = $('<tr></tr>');

                if(options.key) tr.attr('data-trkey', row[options.key]);
                tr.data('row', row);

                $.each(options.columns, function (ii, col) {
                    tr.append(`<td>${row[col.data]}</td>`);
                });

                tbody.append(tr);
            })


        })
            .always(function () {
                setLoading(false);
                (then || function(){})();
            })
            .fail(function () {
                toastr_('Unable to get the data :(', 'error', 'danger', 9000);
            })


    }

    return $(this);

});