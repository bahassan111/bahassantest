<?php
$edit = $edit && isset($project);

$tags_str = "";
if($edit && $tags){
    foreach ($tags as $tag){
        $tags_str .= ($tags_str ? ", " : "") . $tag->tag;
    }
}
?>

<div class="" id="project_form">


    <div class="form-group">
        <label for="name" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Project name</label>
        <input value="<?= $edit ? $project->name : ''; ?>" id="name" type="text" class="form-control" placeholder="">
    </div>
    <div class="form-group">
        <label for="desc" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Description</label>
        <textarea id="desc" class="form-control" placeholder=""><?= $edit ? $project->desc : ''; ?></textarea>
    </div>


    <div class="form-group">
        <label for="tags" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Tags (Separated with space) ex: Java PHP ..</label>
        <input value="<?= $tags_str; ?>" id="tags" type="text" class="form-control" placeholder="PHP JAVASCRIPT ERP CRM ..">
    </div>

    <?php if($edit){?>
        <div class="form-group">
            <label for="color" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Primary Color (used when representing the project)</label>
            <input value="<?= $project->color; ?>" id="color" type="text" class="form-control jscolor" placeholder="">
        </div>
    <?php } ?>

    <div class="form-group">
        <label for="url" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Main URL (if exists)</label>
        <input value="<?= $edit ? $project->url : ''; ?>" id="url" type="text" class="form-control" placeholder="http://">
    </div>

</div>
