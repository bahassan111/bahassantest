// test cases
(function () {
    var view = $('#test_cases_view');
    if(!view.length) return;


    $(document)


        .ready(function () {

            initDatatable('#tests_table', [
                {name : 'title', data : 'title', title : 'Title', orderable : true},
                {name : 'date_modified', data : 'date_modified', title : 'Last Update', orderable : true},
                {name : 'steps', data : 'steps', title : 'Steps', orderable : true},
                {name : 'status', data : 'status', title : 'Status',},
                {name : 'action', data : 'action', title : 'Action', orderable : false, searchable : false},
            ], {
                ajax : site_url + 'project/dt_cases/' + project_id
            });




        });


})();