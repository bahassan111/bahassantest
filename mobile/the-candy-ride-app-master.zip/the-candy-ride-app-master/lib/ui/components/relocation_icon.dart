import 'package:flutter/material.dart';

class RelocationIcon extends StatelessWidget {
  final Function onTap;
  RelocationIcon({@required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.all(10),
        margin: EdgeInsets.only(right: 10, bottom: 10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(50),
          color: Colors.white,
        ),
        child: Icon(
          Icons.gps_fixed,
          size: 25,
        ),
      ),
    );
  }
}
