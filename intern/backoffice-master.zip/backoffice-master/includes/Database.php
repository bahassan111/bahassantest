<?php
defined('BASE') OR die('Direct access is not allowed');

/*
 * @property Mysqli            $ctx
 */
class database{
    private $ctx;
    private $host;
    private $port;
    private $username;
    private $password;
    private $db_name;

    public function __construct($host, $username, $password, $db, $port = false)
    {
        $this->host = $host;
        $this->username = $username;
        $this->password = $password;
        $this->db_name = $db;
        $this->port = $port;


        $this->connect();
    }

    public function connect(){
        if(!$this->isConnected()){
            $this->ctx = new mysqli($this->host, $this->username, $this->password, $this->db_name, $this->port);
            mysqli_set_charset($this->ctx, "utf8");
        }

        return $this;
    }

    public function isConnected(){
        return $this->ctx != null && !$this->ctx->connect_error;
    }

    public function get_context(){
        return $this->ctx;
    }

    public function query($sql_query, $getAsArray = false){
        $query = $this->ctx->query($sql_query);


        $err = mysqli_error($this->ctx);

        $result = [];

        if($query && gettype($query) == 'object'){
            if($getAsArray){
                while ($row = $query->fetch_row()){
                    $result[] = $row;
                }
            }else{
                while ($row = $query->fetch_object()){
                    $result[] = $row;
                }
            }
        }


        return $result;

    }

    public function nonQuery($sql_query){
        $query = $this->ctx->query($sql_query);
        $err = mysqli_error($this->ctx);

        return !!$query;
    }

    public function get($table, $filter = [], $order = false, $order_dir = false, $limit = FALSE, $offset = FALSE){

        $filters = "";
        foreach ($filter as $k => $v) $filters .= ($filters ? ' AND ' : '') . "`$k` = '$v'";

        $q = "SELECT * FROM $table";

        if($filters) $q .= " WHERE $filters";
        if($order) $q .= " ORDER BY $order";
        if($order && $order_dir) $q .= " $order_dir";
        if($offset && $limit) $q .= " LIMIT $offset, $limit";
        elseif ($limit) $q .= " LIMIT $limit";

        return $this->query($q);

    }

    public function insert($table, $data){
        $cols = '';
        $vals = '';

        foreach ($data as $col => $val){
            $val = str_replace("'", "''", $val);
            $cols .= ($cols ? ',' : '') . "`$col`";
            $vals .= ($vals ? ',' : '') . "'$val'";
        }

        $done = $this->nonQuery("INSERT INTO $table ($cols) VALUES ($vals);");

        if($done){
            return $this->ctx->insert_id;
        }else{
            return false;
        }
    }

    public function update($table, $data,$filter = []){
        $cols = '';

        $filters = "";
        foreach ($filter as $k => $v) $filters .= ($filters ? ' AND ' : '') . "`$k` = '$v'";

        $c=0;
        foreach ($data as $col => $val){

            if($c===0)
                $set=" set  ";
            $val = str_replace("'", "''", $val);
            $cols .= ($cols ? ',' : '') . " $set `$col`='$val'";
            $set="";
            $c++;
        }



        $done = $this->nonQuery("UPDATE $table $cols WHERE $filters ;");

        if($done){
            return true;
        }else{
            return false;
        }
    }

}