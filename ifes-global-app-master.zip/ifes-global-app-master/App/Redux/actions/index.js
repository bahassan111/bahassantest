import {
  SET_ARTICLE_DETAILS,
  //SET_ARTICLE_All,
  API,
  FETCH_ARTICLE_DETAILS,
  //SEARCH_CHAPITRE_ALL,
  FETCH_BANNERS,
  SET_BANNERS
} from "./types";

export function fetchArticleDetails() {
  return apiAction({
    url: "http://ifes-esll.com/new/api/includes/encode/index.php/?get=chapitres",
    onSuccess: setArticleDetails,
    onFailure: () => console.log("Error occured loading articles"),
    label: FETCH_ARTICLE_DETAILS
  });
}

export function fetchBanners(id_country) {
  return apiAction({
    url: Config.API_URL+"includes/encode/index.php/?get=banners&id_country="+id_country,
    onSuccess: setBanners,
    onFailure: () => console.log("Error occured loading articles"),
    label: FETCH_BANNERS
  });
}

// Function AChraf
export function searchChapitreAll__(keyword) {
  return apiAction({
    url: "http://ifes-esll.com/new/api/includes/encode/index.php/?get=searchAll&search"+keyword,
    onSuccess: setArticleAll,
    onFailure: () => console.log("Error occured loading All articles"),
    label: SEARCH_CHAPITRE_ALL
  });
}
function setArticleAll__(data) {
  return {
    type: SET_ARTICLE_All,
    payload: data
  };
}

function setBanners(data) {
  return {
    type: SET_BANNERS,
    payload: data
  };
}

function setArticleDetails(data) {
  return {
    type: SET_ARTICLE_DETAILS,
    payload: data
  };
}

function apiAction({
  url = "",
  method = "GET",
  data = null,
  accessToken = null,
  onSuccess = () => {},
  onFailure = () => {},
  label = "",
  headersOverride = null
}) {
  return {
    type: API,
    payload: {
      url,
      method,
      data,
      accessToken,
      onSuccess,
      onFailure,
      label,
      headersOverride
    }
  };
}
