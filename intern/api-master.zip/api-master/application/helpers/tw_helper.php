<?php

function loadView($view, $data = [], $full = true, $return = false){

    $that = get_instance();


    $default = array(
        '_title'        => "Tableau de bord",
        '_page'         => "home",
        '_full'         => $full,
    );




    $dt = array_merge($data, $default);

    $output = '';


    if($full){
        $output .= $that->load->view('segments/header', $dt, true);
        $output .= $that->load->view('segments/topbar', $dt, true);
        $output .= $that->load->view('segments/sidebar', $dt, true);
    }else{
        $output .= getCSS();
    }



    $output .= $that->load->view($view,$dt, true);


    if($full){
        $output .= $that->load->view('segments/footer',$dt, true);
    }else{
        $output .= getJS();
    }



    if(!$return) echo $output;

    return $return ? $output : TRUE;
}

function callback_whenNotLoggedIn()
{
    if(get_instance()->input->post('ajax')) {
        echo 'Erreur : Vous n\'êtes pas connecté, veuillez actualiser cette page pour vous connecter';
        exit(0);
    }else redirect(site_url('login?origins=' . urlencode(($_SERVER['REDIRECT_QUERY_STRING'] ?: '/'))));
}

function callback_whenNoPermission()
{
    if(get_instance()->input->post('ajax')) {
        echo 'Erreur : Vous n\'avez pas la permission requise pour accéder à cette page';
        exit(0);
    }else redirect('forbidden');
}

function callback_whenNoAccessAtALL()
{
    redirect(site_url('_400'));
}

function noIDexception($soft=FALSE)
{
    echo 'Erreur : Aucune élement sélectionnée!';
    if(!$soft) exit(0);
    return true;
}

function assets_version()
{
    return (can_debug() ? rand(0, 9999) : APP_VERSION);
}

function can_debug()
{
    return ENVIRONMENT === 'development';
}

function isAjax(){
    return (get_instance()->input->post('ajax') === 'true');
}

function isLoggedIn()
{
    return get_instance()->ion_auth->logged_in();
}

function get_date($date, $isDATETIME = false, $alt = false)
{
    $datetime_format = "Y-m-d H:i";
    $date_format = "Y-m-d";
    $alt_date = 'Y/m/d';
    $alt_time = 'Y/m/d H:i';

    if (gettype($date) !== "object") {
        if (strpos($date, '-') || strpos($date, '/')) {
            try {
                $that = new DateTime($date);
            } catch (Exception $e) {
                return $date;
            }

            if ($alt) {
                return $that->format($isDATETIME ? $alt_time : $alt_date);
            } else {
                return $that->format($isDATETIME ? $datetime_format : $date_format);
            }
        } else {
            return date($isDATETIME ? $datetime_format : $date_format, $date);
        }
    } else {
        $d = $date->format($isDATETIME ? $datetime_format : $date_format);
        if ($d) return $d;
        else return $date;
    }


}

function clean_string($string)
{
    while (strpos($string, '  ')) {
        $string = str_replace('  ', ' ', $string);
    }
    return trim($string);
}

function imageBase64($filename)
{
    $path = $filename;
    $type = pathinfo($path, PATHINFO_EXTENSION);
    $data = file_get_contents($path);
    $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);

    return $base64;
}

function get_meta($key, $as_object = false, $default = '')
{
    $obj = api_get(array('key' => $key), 'metas');

    if (count($obj) > 0) {
        return ($as_object) ? json_decode($obj) : $obj;
    } else {
        return ($as_object && $default === '') ? (object)array() : $default;
    }

}

function set_meta($key, $value)
{
    $exists = (get_meta($key, false, '') !== '');

    if (gettype($value) == 'array' || gettype($value) == 'object')
        $value = json_encode($value);

    if ($key !== '' && $value !== '') {
        if (!$exists)
            api_post(array('meta_key' => $key, 'meta_value' => $value), 'metas');
        else
            api_put(array('meta_value' => $value), 'metas/?key=' . $key);

        return true;
    }
    return false;
}

function get_name_month($val)
{
    $month = '';
    if ($val == 1) $month = 'Janvier';
    else if ($val == 2) $month = 'Février';
    else if ($val == 3) $month = 'Mars';
    else if ($val == 4) $month = 'Avril';
    else if ($val == 5) $month = 'Mai';
    else if ($val == 6) $month = 'Juin';
    else if ($val == 7) $month = 'Juillet';
    else if ($val == 8) $month = 'Août';
    else if ($val == 9) $month = 'Septembre';
    else if ($val == 10) $month = 'Octobre';
    else if ($val == 11) $month = 'Novembre';
    else if ($val == 12) $month = 'Décembre';

    return $month;


}

function hex2RGB($hexStr, $returnAsString = false, $seperator = ',')
{
    $hexStr = preg_replace("/[^0-9A-Fa-f]/", '', $hexStr); // Gets a proper hex string
    $rgbArray = array();
    if (strlen($hexStr) == 6) { //If a proper hex code, convert using bitwise operation. No overhead... faster
        $colorVal = hexdec($hexStr);
        $rgbArray['red'] = 0xFF & ($colorVal >> 0x10);
        $rgbArray['green'] = 0xFF & ($colorVal >> 0x8);
        $rgbArray['blue'] = 0xFF & $colorVal;
    } elseif (strlen($hexStr) == 3) { //if shorthand notation, need some string manipulations
        $rgbArray['red'] = hexdec(str_repeat(substr($hexStr, 0, 1), 2));
        $rgbArray['green'] = hexdec(str_repeat(substr($hexStr, 1, 1), 2));
        $rgbArray['blue'] = hexdec(str_repeat(substr($hexStr, 2, 1), 2));
    } else {
        return false; //Invalid hex color code
    }
    return $returnAsString ? implode($seperator, $rgbArray) : $rgbArray; // returns the rgb string or the associative array
}

function color_for_str($str, $rgb = false)
{
    $colors = [
        '#5A0007', '#fba400', '#33b101', '#30d272', '#00e4f1',
        '#c5000f', '#ffc24f', '#80e658', '#00d299', '#20b9c1',
        '#ffa0a7', '#bde005', '#528a3b', '#2a8c71', '#009bd8',
        '#888888', '#000000', '#2a7eff', '#b600ff', '#de008e', '#e40e48', '#EF8275', '#8A4F7D'
    ];


    $str = strtolower(trim(str_replace(' ', '', $str)));
    $alpha = "abcdefghijklmnopkrstuvwxyz0123456789";
    $l = strlen($str) ?: 0;
    $k = strtolower(substr($str, 0, 1));
    $k = strpos($alpha, $k) ?: 0;
    $e = strtolower(substr($str, strlen($str) - 1, 1));
    $e = strpos($alpha, $e) ?: 0;
    $index = $l + $k + $e;
    while ($index >= count($colors)) $index = intval($index / 2);
    $val = $colors[intval($index)];
    return $rgb ? hex2RGB($val) : $val;

}

function fromNow($timestamp)
{
    $periods = array("seconde", "minute", "heure", "jour", "semaine", "mois", "année", "décennie");
    $lengths = array("60", "60", "24", "7", "4.35", "12", "10");

    if(!$timestamp) return '';
    $type = gettype($timestamp);
    $f =  $timestamp * 1;
    if(gettype($timestamp) === 'object') {
        $timestamp = $timestamp->getTimestamp();
    }elseif("$f" !== "$timestamp"){
        $timestamp = (new DateTime($timestamp))->getTimestamp();
    }

    $now = time();

    $difference = $now - $timestamp;
    $tense = "ago";

    for ($j = 0; $difference >= $lengths[$j] && $j < count($lengths) - 1; $j++) {
        $difference /= $lengths[$j];
    }

    $difference = round($difference);

    if ($difference != 1) {
        $periods[$j] .= "s";
    }

    return "il y a $difference $periods[$j]";
}

function isLinkOfImage($url){
    $images = ['jpg', 'jpeg', 'png', 'gif', 'bmp'];
    $n = strtolower(basename($url));
    $ext = trim(str_replace(' ', '', str_replace('.', '', substr($n, strlen($n) - 4))));
    foreach ($images as $image){
        if($ext === $image) return true;
    }
    return false;
}

function randomID($length = 20){
    $str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $str .= strtolower($str) . "123456789";
    $id = "";
    while (strlen($id) < $length){
        $id .= $str[rand(0, strlen($str))];
    }

    return $id;
}

function wlog($text){
    $logfile = fopen(APPPATH."the_log.txt", "a+");

    $txt = "[".date('Y-m-d H:i:s')."]\t\t$text\r\n";

    fwrite($logfile, $txt);
    fclose($logfile);
}

function str_contains($string, $search){
    return strpos($string, $search) !== FALSE;
}

function responseJSON($data){
    header('Content-type:application/json');
    echo json_encode($data);
}

function getCSS(){
    $ret = "";
    $that =& get_instance();
    $assets = isset($that->assets) && isset($that->assets->css) ? $that->assets->css : [];
    foreach ($assets as $index => $asset){
        $external = str_contains($asset, 'http');
        $url = ($external!==false) ? $asset : base_url($asset);
        $has_params = str_contains($asset, '?');

        $ret .= '<link rel="stylesheet" type="text/css" href="'.$url.($has_params ? '&' : '?').'v='.assets_version().'">'.PHP_EOL;
    }

    return $ret;
}

function getJS(){
    $ret = "";
    $that =& get_instance();
    $assets = isset($that->assets) && isset($that->assets->js) ? $that->assets->js : [];
    foreach ($assets as $index => $asset){
        $external = str_contains($asset, 'http');
        $url = ($external!==false) ? $asset : base_url($asset);
        $has_params = str_contains($asset, '?');

        $ret .= '<script src="'.$url.($has_params ? '&' : '?').'v='.assets_version().'" data-for="view"></script>';
    }

    return $ret;
}