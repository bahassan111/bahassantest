package ma.rak.ov;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import ma.rak.ov.api.TwDatabase;
import ma.rak.ov.bodyResponse.AbonnementResponse;
import ma.rak.ov.bodyResponse.BranchementResponse;
import ma.rak.ov.models.Abonnement;
import ma.rak.ov.models.Branchement;
import ma.rak.ov.models.Dossier;
import ma.rak.ov.storage.SharedPrefManager;
import ma.rak.ov.ui.main.AffecterFragment;
import ma.rak.ov.ui.main.DemandViewModel;
import ma.rak.ov.ui.main.ExecutionFragment;
import ma.rak.ov.ui.main.RejectFragment;

public class MapsFragment extends Fragment implements LocationListener {

    HashMap<String, HashMap<String, String>> markerMapBr = new HashMap<String, HashMap<String, String>>();
    HashMap<String, HashMap<String, String>> markerMapAb = new HashMap<String, HashMap<String, String>>();
    private PopupWindow mPopupWindow;
    private Activity mActivity;
    private Context mContext;
    private LatLng firstMarker;
    private DemandViewModel demandViewModel;
    ArrayList<HashMap<String, String>> newBrResponse = null;
    ArrayList<HashMap<String, String>> newAbResponse = null;

    private GoogleMap googleMapContext;

    protected Double latitude, longitude;
    TextView hamMenu;
    protected LocationManager locationManager;

    private boolean onLoadMap = false;

    public void showPopup(View v) {
        PopupMenu popup = new PopupMenu(getActivity(), v);
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {

                    case R.id.action_branchement:
                        if (SharedPrefManager.getInstance(getActivity()).isLogged()) {
                            SharedPrefManager.getInstance(getActivity()).operationMode(1);
                            Toast.makeText(getActivity(), R.string.mode_branchement, Toast.LENGTH_SHORT).show();
                            //fetchData(0, googleMapContext);
                            if(hamMenu != null){

                                hamMenu.setText("Branchement");
                            }
                            getActivity().finish();
                            startActivity(getActivity().getIntent());
                        }
                        return true;
                    case R.id.action_abonnements:
                        if (SharedPrefManager.getInstance(getActivity()).isLogged()) {
                            SharedPrefManager.getInstance(getActivity()).operationMode(2);
                            Toast.makeText(getActivity(), R.string.mode_abonnement, Toast.LENGTH_SHORT).show();
                            //fetchData(0, googleMapContext);
                            //hamMenu.setText("Abonnement");
                            getActivity().finish();
                            startActivity(getActivity().getIntent());
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });
        popup.inflate(R.menu.toolbar_menu);
        popup.show();
    }

    public void fetchData(int status, GoogleMap googleMap) {
        googleMapContext = googleMap;
        demandViewModel = ViewModelProviders.of(getActivity()).get(DemandViewModel.class);
        if (SharedPrefManager.getInstance(getActivity()).getMode() == 1) {
            demandViewModel.getBrachments(null, 1, getActivity(), 1, "");
            newBrResponse = new ArrayList<>();
            demandViewModel.BranchementMutableLiveData.observe(getActivity(), new Observer<ArrayList<HashMap<String, String>>>() {
                @Override
                public void onChanged(ArrayList<HashMap<String, String>> branchementResponse) {
                    newBrResponse = branchementResponse;

                    for (HashMap<String, String> item : newBrResponse) {

                        if(item == null || item.get("LONGITUDE") == null || item.get("LATITUDE") == null){
                            continue;
                        }

                        double lng = Double.parseDouble(item.get("LONGITUDE").replace(',', '.'));
                        double lat = Double.parseDouble(item.get("LATITUDE").replace(',', '.'));

                        Marker markerTwo = googleMap
                                .addMarker(new MarkerOptions()
                                        .position(
                                                new LatLng(lat, lng))
                                        .title(item.get("NOM"))
                                        .snippet(item.get("ADRESDEVI")));
                        markerTwo.setIcon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_CYAN));
                        markerTwo.setTag("RAK");
                        markerMapBr.put(markerTwo.getId(), item);

                    }
                }
            });
        } else {
            demandViewModel.getAbonnements(SharedPrefManager.getInstance(getActivity()).getToken(), 1, getContext(), "");
            newAbResponse = new ArrayList<>();
            demandViewModel.AbonnementMutableLiveData.observe(getActivity(), new Observer<ArrayList<HashMap<String, String>>>() {
                @Override
                public void onChanged(ArrayList<HashMap<String, String>> dataList) {

                    int i = 0;
                    for (HashMap<String, String> item : dataList) {

                        if (item.get("LONGITUDE") != null && item.get("LATITUDE") != null) {

                            double lng = Double.parseDouble(item.get("LONGITUDE").replace(',', '.'));
                            double lat = Double.parseDouble(item.get("LATITUDE").replace(',', '.'));

                            Log.e("######### LATLNG ----->", String.valueOf(lng) + " " + String.valueOf(lat));

                            Marker markerTwo = googleMap
                                    .addMarker(new MarkerOptions()
                                            .position(
                                                    new LatLng(lat, lng))
                                            .title(item.get("NOM"))
                                            .snippet(item.get("ADRELOCA")));
                            markerTwo.setTag("RAK");
                            markerTwo.setIcon(BitmapDescriptorFactory.defaultMarker(item.get("CODEGERA").equals("2") ? BitmapDescriptorFactory.HUE_CYAN : BitmapDescriptorFactory.HUE_ORANGE));
                            markerMapAb.put(markerTwo.getId(), item);
                           // Log.i("LngLat", "" + roundAvoid(Double.parseDouble(item.get("LONGITUDE")), 5) + "," + roundAvoid(Double.parseDouble(item.get("LATITUDE")), 4));
                        }
                    }

                }

            });
        }

    }


    private OnMapReadyCallback callback = new OnMapReadyCallback() {


        /**
         * Manipulates the map once available.
         * This callback is triggered when the map is ready to be used.
         * This is where we can add markers or lines, add listeners or move the camera.
         * In this case, we just add a marker near Sydney, Australia.
         * If Google Play services is not installed on the device, the user will be prompted to
         * install it inside the SupportMapFragment. This method will only be triggered once the
         * user has installed Google Play services and returned to the app.
         */
        @Override
        public void onMapReady(GoogleMap googleMap) {

            googleMapContext = googleMap;
            fetchData(0, googleMap);
//            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(firstMarker, 15f));
            if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            googleMap.setMyLocationEnabled(true);


            googleMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
                @Override
                public boolean onMarkerClick(Marker marker) {
                    if (marker.getTag() != null && !marker.getTag().equals("RAK")) {
                        return false;
                    } else {

                        boolean isBR = SharedPrefManager.getInstance(mContext).getMode() == 1;
                        // Initialize a new instance of LayoutInflater service
                        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

                        // Inflate the custom layout/view
                        View customView = inflater.inflate(R.layout.custom_layout, null);
                        HashMap<String, String> clickerItem = (isBR ? markerMapBr : markerMapAb).get(marker.getId());

                        if(clickerItem == null) return false;

                        String scoop = SharedPrefManager.getInstance(mContext).getScoop();

                        TextView client_name = customView.findViewById(R.id.client_name);
                        TextView dossier_id = customView.findViewById(R.id.dossier_id);
                        TextView devi = customView.findViewById(R.id.devi);
                        TextView client_address = customView.findViewById(R.id.client_address);
                        TextView date_operation = customView.findViewById(R.id.date_operation);
                        //TextView client_reference = customView.findViewById(R.id.client_reference);
                        TextView type_id = customView.findViewById(R.id.type_id);
                        //TextView nature_operation = customView.findViewById(R.id.nature_operation);
                        Button operationExecute = customView.findViewById(R.id.operationExecute);
                        Button operationReject = customView.findViewById(R.id.operationReject);
                        Button operationNoExecution = customView.findViewById(R.id.operationNoExecution);
                        Button operationReaf = customView.findViewById(R.id.operationReaf);


                        Intent execution = new Intent(mContext, ExecutionFragment.class);
                        Intent reject = new Intent(mContext, RejectFragment.class);
                        Intent noExecution = new Intent(mContext, RejectFragment.class);
                        Intent affecter = new Intent(mContext, AffecterFragment.class);

                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                        String currentDateandTime = sdf.format(new Date());


                        if (isBR == true) {
                            client_name.setText(clickerItem.get("NOM"));
                            dossier_id.setText(clickerItem.get("NUMDEMDE") + "/" + clickerItem.get("ANNDEMDE"));
                            devi.setText("DEVIS : ");
                            client_address.setText(clickerItem.get("ADRESDEVI"));
                            date_operation.setText(clickerItem.get("DATSAIDE"));
                            //client_reference.setText(clickerItem.get("NUMDEMDE"));
                            //client_reference.setVisibility(View.INVISIBLE);
                            type_id.setVisibility(View.INVISIBLE);
                            //nature_operation.setVisibility(View.INVISIBLE);



                            boolean inHisto = clickerItem.get("STATOPER") != null && Integer.valueOf(clickerItem.get("STATOPER")) > 1;
                            operationExecute.setVisibility(inHisto ? View.INVISIBLE : View.VISIBLE);
                            operationNoExecution.setVisibility(inHisto ? View.INVISIBLE : View.VISIBLE);
                            operationReject.setVisibility(inHisto ? View.INVISIBLE : View.VISIBLE);
                            operationReaf.setVisibility(inHisto ? View.INVISIBLE : (scoop.equals("Superviseur") ? View.VISIBLE : View.INVISIBLE));

                            execution.putExtra("CONSULT", false);
                            reject.putExtra("CONSULT", false);
                            noExecution.putExtra("CONSULT", false);

                            execution.putExtra("br", true);
                            execution.putExtra("status", "3");
                            execution.putExtra("date", currentDateandTime);
                            execution.putExtra("ITEM", clickerItem);


                            reject.putExtra("br", true);
                            reject.putExtra("status", "3");
                            reject.putExtra("date", currentDateandTime);
                            reject.putExtra("ITEM", clickerItem);

                            noExecution.putExtra("br", true);
                            noExecution.putExtra("status", "4");
                            noExecution.putExtra("date", currentDateandTime);
                            noExecution.putExtra("ITEM", clickerItem);

                            affecter.putExtra("br", true);
                            affecter.putExtra("status", "4");
                            affecter.putExtra("date", currentDateandTime);
                            affecter.putExtra("ITEM", clickerItem);

                        } else {
                            client_name.setText(clickerItem.get("NOM"));
                            dossier_id.setText(clickerItem.get("NUMEDOSS") + "/" + clickerItem.get("ANNEDOSS"));
                            client_address.setText(clickerItem.get("ADRELOCA"));
                            date_operation.setText(clickerItem.get("DATDEMAB"));
                            //client_reference.setText(clickerItem.get("NUMOPRAB"));
                            type_id.setText(clickerItem.get(TwDatabase.ABDemandes.TELECLIE));
                            //nature_operation.setText(clickerItem.get("CODNATCL"));

                            String dosss = clickerItem.get("DOSSIERS");
                            ArrayList<Dossier> arrayList = new ArrayList<>();
                            try {
                                JSONArray jdossiers = new JSONArray(dosss);
                                for (int i = 0; i < jdossiers.length(); i++) {
                                    JSONObject doss = jdossiers.getJSONObject(i);
                                    arrayList.add(new Dossier(doss.getString("GERANCE"), doss.getString("NUM"), doss.getString("ADRESSE")));
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                            boolean inHisto = Integer.valueOf(clickerItem.get("STATOPER")) > 1;
                            operationExecute.setVisibility(inHisto ? View.INVISIBLE : View.VISIBLE);
                            operationNoExecution.setVisibility(inHisto ? View.INVISIBLE : View.VISIBLE);
                            operationReject.setVisibility(inHisto ? View.INVISIBLE : View.VISIBLE);
                            operationReaf.setVisibility(inHisto ? View.INVISIBLE : (scoop.equals("Superviseur") ? View.VISIBLE : View.INVISIBLE));

                            execution.putExtra("CONSULT", false);
                            reject.putExtra("CONSULT", false);
                            noExecution.putExtra("CONSULT", false);


                            execution.putExtra("br", false);
                            execution.putExtra("status", "2");
                            execution.putExtra("date", currentDateandTime);
                            execution.putExtra("doss_annee", clickerItem.get("ANNEDOSS"));
                            execution.putExtra("doss_numm", clickerItem.get("NUMEDOSS"));
                            execution.putExtra("num_operation", clickerItem.get("NUMOPRAB"));
                            execution.putExtra("gerance", clickerItem.get("CODEGERA"));
                            execution.putExtra("adreloca", clickerItem.get("ADRELOCA"));
                            execution.putExtra("nature_install", clickerItem.get("NATU_LOT"));
                            execution.putExtra("etage", clickerItem.get("CODEETAG"));
                            execution.putParcelableArrayListExtra("dossier", arrayList);

                            execution.putExtra("ITEM", clickerItem);

                            reject.putExtra("br", false);
                            reject.putExtra("status", "3");
                            reject.putExtra("date", currentDateandTime);
                            reject.putExtra("doss_annee", clickerItem.get("ANNEDOSS"));
                            reject.putExtra("doss_numm", clickerItem.get("NUMEDOSS"));
                            reject.putExtra("num_operation", clickerItem.get("NUMOPRAB"));
                            reject.putExtra("gerance", clickerItem.get("CODEGERA"));
                            reject.putExtra("adreloca", clickerItem.get("ADRELOCA"));
                            reject.putParcelableArrayListExtra("dossier", arrayList);
                            reject.putExtra("ITEM", clickerItem);

                            noExecution.putExtra("br", false);
                            noExecution.putExtra("status", "4");
                            noExecution.putExtra("date", currentDateandTime);
                            noExecution.putExtra("doss_annee", clickerItem.get("ANNEDOSS"));
                            noExecution.putExtra("doss_numm", clickerItem.get("NUMEDOSS"));
                            noExecution.putExtra("num_operation", clickerItem.get("NUMOPRAB"));
                            noExecution.putExtra("gerance", clickerItem.get("CODEGERA"));
                            noExecution.putExtra("adreloca", clickerItem.get("ADRELOCA"));
                            noExecution.putParcelableArrayListExtra("dossier", arrayList);
                            noExecution.putExtra("ITEM", clickerItem);

                            affecter.putExtra("br", false);
                            affecter.putExtra("status", "4");
                            affecter.putExtra("date", currentDateandTime);
                            affecter.putExtra("doss_annee", clickerItem.get("ANNEDOSS"));
                            affecter.putExtra("doss_numm", clickerItem.get("NUMEDOSS"));
                            affecter.putExtra("num_operation", clickerItem.get("NUMOPRAB"));
                            affecter.putExtra("gerance", clickerItem.get("CODEGERA"));
                            affecter.putExtra("AGENT", clickerItem.get("CODUTIEX"));
                            affecter.putExtra("ITEM", clickerItem);
                        }

                        operationExecute.setOnClickListener(v3 -> getActivity().startActivity(execution));

                        operationReject.setOnClickListener(v2 -> getActivity().startActivity(reject));




                        operationReaf.setOnClickListener(v4 -> getActivity().startActivity(affecter));

                        operationNoExecution.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                //noExecution.putExtra("status", "4");
                                mContext.startActivity(noExecution);
                            }
                        });


                        // Initialize a new instance of popup window
                        mPopupWindow = new PopupWindow(
                                customView,
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                true
                        );

                        // Set an elevation value for popup window
                        // Call requires API level 21
                        if (Build.VERSION.SDK_INT >= 21) {
                            mPopupWindow.setElevation(100);
                        }

                        // Get a reference for the custom view close button
                        ImageButton closeButton = (ImageButton) customView.findViewById(R.id.ib_close);

                        // Set a click listener for the popup window close button
                        closeButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                // Dismiss the popup window
                                mPopupWindow.dismiss();
                            }
                        });

                        mPopupWindow.setBackgroundDrawable(new ColorDrawable(Color.argb(80, 59, 59, 59)));

                        ConstraintLayout constraintLayout = (ConstraintLayout) getActivity().findViewById(R.id.constraintLayoutMap);
                        mPopupWindow.showAtLocation(constraintLayout, Gravity.BOTTOM, 0, 0);
                        return false;

                    }

                }

            });


            //kMarker.showInfoWindow();
        }
    };


    public static double roundAvoid(double value, int places) {
        double scale = Math.pow(10, places);
        return Math.round(value * scale) / scale;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        // Get the application context
        mContext = getActivity().getApplicationContext();

        // Get the activity
        mActivity = getActivity();

        TextView hamMenu = getActivity().findViewById(R.id.toolbarUserMenu);
        hamMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopup(v);
            }
        });

        return inflater.inflate(R.layout.fragment_maps, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        SupportMapFragment mapFragment =
                (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);


        locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.


            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);

        mapFragment.getMapAsync(callback);
    }

    @Override
    public void onLocationChanged(Location location) {

        if (this.onLoadMap == false) {
            this.latitude = location.getLatitude();
            this.longitude = location.getLongitude();

            try {
                if (location.getLatitude() != 0 && location.getLongitude() != 0) {
                    LatLng firstMarker = new LatLng(location.getLatitude(), location.getLongitude());
                    Log.i("position", firstMarker.toString());
                    googleMapContext.addMarker(new MarkerOptions().position(firstMarker).title(getString(R.string.myPostion)));

                    googleMapContext.animateCamera(CameraUpdateFactory.newLatLngZoom(firstMarker, 17f));
                    this.onLoadMap = true;
                }
            } catch (Exception e) {
                Log.e("GoogleMapException", e.getMessage());
            }

        }

    }


}