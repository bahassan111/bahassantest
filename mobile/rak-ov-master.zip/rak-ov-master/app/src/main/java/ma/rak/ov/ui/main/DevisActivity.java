package ma.rak.ov.ui.main;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import ma.rak.ov.DevisListAdapter;
import ma.rak.ov.R;
import ma.rak.ov.api.RetrofitClient;
import ma.rak.ov.bodyResponse.DevisResponse;
import ma.rak.ov.storage.SharedPrefManager;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DevisActivity extends AppCompatActivity {

    EditText search;
    Button btn;
    Button extiBtn;
    ListView list;
    TextView label;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_devis);

        search = findViewById(R.id.addr_search);

        btn = findViewById(R.id.srch_btn);
        extiBtn = findViewById(R.id.exitbtn);
        list = findViewById(R.id.list);
        label = findViewById(R.id.label);

        extiBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        Bundle b = getIntent().getExtras();
        String address = b != null ? b.getString("address") : "";
        search.setText(address);

        if(address != null && !address.equals("")){
            rechercher(address);
        }

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rechercher(search.getText().toString());
            }
        });
    }

    public void rechercher(String search){

        if(search.trim().equals("")){
            label.setText("Veuillez spécifier une adresse!");
            return;
        }

        boolean isDossier = false;

        String[] parts = search.split("/");

        if(parts.length == 2){

            try{
                int year = Integer.parseInt(parts[0]);
                int doss = Integer.parseInt(parts[1]);
                Calendar cal = (new GregorianCalendar());
                cal.setTime(new Date());
                int cyear = cal.get(Calendar.YEAR);
                if(year < 1900 || year > cyear){
                    label.setText("Si vous recherchez par numéro de dossier et année, veuillez taper l'année en premier / le numéro de dossier");
                    return;
                }

                isDossier = true;

            }catch (Exception e){

            }

        }

        btn.setText("En cours ..");
        btn.setEnabled(false);
        this.search.setEnabled(false);
        label.setText("Recherche en cours ..");

        list.setAdapter(null);

        Call<DevisResponse> call = RetrofitClient.getApi(SharedPrefManager.getInstance(this).getToken()).devis("XDEBUG_SESSION=XDEBUG_ECLIPSE",search);

        boolean finalIsDossier = isDossier;
        call.enqueue(new Callback<DevisResponse>() {
            @Override
            public void onResponse(Call<DevisResponse> call, Response<DevisResponse> response) {

                btn.setText("Rechercher");
                btn.setEnabled(true);
                DevisActivity.this.search.setEnabled(true);

                if(response.code() != 200){
                    //(Toast.makeText(getApplicationContext(),"Error while running this request!")).show();
                    label.setText("Erreur lors de l'exécution de la requête, réessayez plus tard !");
                    return;
                }

                String inf = finalIsDossier ? "le dossier" : "l'adresse";
                    if(response.body().getDevis().size() == 0){
                    label.setText("Aucun devis trouvé pour "+ inf +" sélectionnée, essayez avec une autre adresse !");
                }else{
                    label.setText(response.body().getDevis().size() +" devis trouvés pour "+ inf +" sélectionnée");
                }

                DevisListAdapter adapter=new DevisListAdapter(DevisActivity.this, response.body().getDevis());
                list.setAdapter(adapter);

            }

            @Override
            public void onFailure(Call<DevisResponse> call, Throwable t) {
                btn.setText("Rechercher");
                btn.setEnabled(true);
                DevisActivity.this.search.setEnabled(true);
                label.setText("Erreur lors de l'exécution de la requête, assurez-vous que vous êtes connecté à Internet");
            }
        });

    }
}