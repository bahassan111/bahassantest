(function () {
    var view = $('#run_view');
    if (!view.length) return;

    var table = $('.run_list');

    $(view)


        .on('click', '.add_run', function () {
            ajaxSideModal('project/one_run/' + project_id, 'Create a Test Run', 'far fa-paper-plane', {
                close_text : 'Cancel',
                size : 'lg',
                confirm_text : 'Save Test Run',
                whenLoaded : function(modal, data){
                    log('?');
                    modal.on('change', '#id_group', function () {

                    })
                },
                whenConfirm : function(modal, data){

                },
                whenError : function(modal, error){},
                whenClosed : function(modal){},

            });
        })
        .ready(function () {

            log(run_id);
            table.twTable({

                url     : site_url + 'project/get_runcases/' + run_id,
                key     : 'id',

                dblclick : function(id, tr){
                    testAcase($(tr).data('row').id_case);
                },
                order : 1,

                columns : [
                    {name : 'id', data : 'ref', title : 'ID', orderable : true, searchable : false},
                    {name : 'order', data : 'order', title : 'Order', orderable : true, searchable : false},
                    {name : 'run_type', data : 'rtype', title : 'Method', orderable : true, searchable : false},
                    {name : 'title', data : 'title', title : 'Test Case', orderable : true, searchable : true},
                    {name : 'priority', data : 'priority_name', title : 'Priority', orderable : true, searchable : true},
                    {name : 'type', data : 'type_name', title : 'Type', orderable : true, searchable : true},
                    {name : 'iterations', data : 'iterations', title : 'Iterations', orderable : false, searchable : false},
                    {name : 'status', data : 'stat', title : 'Status', orderable : true, searchable : true},
                ],

                buttons : [
                    {
                        text : 'Add',
                        icon : 'fas fa-plus',
                        color : 'primary',
                        global : true,
                        action : function(){
                            addCases();
                        },
                    },
                    {
                        separator : true,
                    },


                    {
                        icon : 'fas fa-eye',
                        global : false,
                        action : function(id){
                            var id = $(`[data-trkey="${id}"]`).data('row');
                            id = id ? id.id_case : null;

                            if(id) showCase(id);

                        },
                    },
                    {
                        icon : 'fas fa-times',
                        global : false,
                        action : function(id){
                            deleteRunCase(id)
                        },
                    },
                    {
                        text : 'RUN',
                        icon : 'fas fa-play',
                        color : 'success',
                        global : false,
                        condition : function(row){
                            return row.run_type === 'auto';
                        },
                        action : function(){},
                    },
                    {separator : true},
                    {
                        icon : 'fas fa-arrow-up',
                        global : false,
                        remote : 'edit',
                        condition : function(row){ return row.order > 1},
                        action : function(id){
                            orderRunCase(id, 'UP');
                        },
                    },
                    {
                        icon : 'fas fa-arrow-down',
                        global : false,
                        remote : 'edit',
                        condition : function(row){

                            return row.order < table.find('[data-trkey]').length;
                        },
                        action : function(id){
                            orderRunCase(id, 'DOWN');
                        },
                    },
                ],

            });



        })
    ;


    function addCases() {

        ajaxSideModal('project/add_cases/' + run_id ,'Create a Test Run', 'far fa-paper-plane', {
            close_text : 'Cancel',
            confirm_text : 'Save',
            size: 'md',
            whenLoaded : function(modal, data){
                $('.selectpicker').selectpicker({
                    liveSearch: true,
                    size : 8,
                });

                modal.find('#plan').on('change', function () {
                    var cases = modal.find('#cases').prop('disabled', true).html('');
                    cases.selectpicker('refresh');
                    var val = $(this).val();
                    log(val);

                    post('project/get_plan_cases/' + val + '/' + run_id,{}, function (rep) {
                       var data = rep.data || [];
                       
                       $.each(data, function () {
                           cases.append(`<option selected value="${this.id}">${this.title}</option>`);
                       });

                       cases.prop('disabled', false).selectpicker('refresh');
                    });
                });

                modal.find('form')
                    .validate();
                modal
                    .on('submit', 'form', function (e) {
                        e.preventDefault();
                        var btn = modal.find('.confirm').prop('disabled', true);

                        var form = $(this);

                        if(form.valid()){
                            post('project/save_runcases/' + run_id, form.serialize(), function (rep) {
                                if(rep.status === 'OK'){
                                    toastr_('The Test Cases were successfully added', 'success', 'success', 6000);
                                    modal.sideModal('hide');
                                    table.twTable('refresh');
                                }else{
                                    toastr_(rep.message || 'Error while saving the data', 'error', 'danger', 9000);
                                }
                            })
                        }



                    })
            },
            whenConfirm : function(modal, data){
                modal.find('form').submit();
            },
            whenError : function(modal, error){},
            whenClosed : function(modal){},

        });
    }
    function deleteRunCase(id) {
        ask('Are you sure?', 'Do you really want to delete this Test Case from the list?, this action will clear all the reports.', function (yes) {

            if(yes){

                post('project/delete_runcase/' + id, {}, function (rep) {
                    if(rep.status === 'OK'){
                        toastr_('The Test Case was successfully deleted from this Run!', 'success', 'success');
                        table.twTable('refresh');
                    }else{
                        toastr_("We couldn't remove the selected Test Case", 'error', 'danger');
                    }
                })

            }else{

            }

        }, 'Yes', 'Cancel', true);
    }
    function orderRunCase(id, dir) {
        post('project/order_runcase/' + id + '/' + dir, {}, function (rep) {
            if(rep.status === 'OK'){
                table.twTable('refresh', function () {
                    table.twTable('select', id);
                });
                view.trigger('case_unselected');
            }else{
                toastr_("We couldn't update the selected case", 'error', 'danger');
            }
        })
    }



})();