package ma.rak.ovr.bodyResponse;

import com.google.gson.annotations.SerializedName;

import java.util.List;

import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;
import ma.rak.ovr.models.Branchement;

public class BranchementResponse extends RealmObject {

    @PrimaryKey
    @SerializedName("id")
    private String id;

    @SerializedName("status")
    private String status;

    @SerializedName("last_date")
    private String lastDate;

    @SerializedName("total_operations")
    private int totalOperations;

    @SerializedName("data")
    private RealmList<Branchement> data;

    public BranchementResponse() {
    }

    public BranchementResponse(String id, String status, String lastDate, int totalOperations, RealmList<Branchement> data) {
        this.id = id;
        this.status = status;
        this.lastDate = lastDate;
        this.totalOperations = totalOperations;
        this.data = data;
    }

    public String getStatus() {
        return status;
    }

    public String getLastDate() {
        return lastDate;
    }

    public int getTotalOperations() {
        return totalOperations;
    }

    public List<Branchement> getData() {
        return data;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setLastDate(String lastDate) {
        this.lastDate = lastDate;
    }

    public void setTotalOperations(int totalOperations) {
        this.totalOperations = totalOperations;
    }

    public void setData(RealmList<Branchement> data) {
        this.data = data;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
