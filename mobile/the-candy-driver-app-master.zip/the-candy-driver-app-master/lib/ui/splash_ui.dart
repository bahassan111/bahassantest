import 'package:flutter/material.dart';
import 'package:driver/constants/images.dart';
import 'package:driver/controllers/controllers.dart';

class SplashUI extends StatefulWidget {
  @override
  _SplashUIState createState() => _SplashUIState();
}

class _SplashUIState extends State<SplashUI> {
  double height, width;
  final AuthController languageController = AuthController.to;

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;

    return Scaffold(
      body: SafeArea(
        child: Container(
          width: width,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Image.asset(
                AllImages.splash,
                width: 150,
                fit: BoxFit.cover,
                height: 150,
              ),
              SizedBox(
                height: 20,
              ),
              Image.asset(
                AllImages.theCandy,
                width: (3.5 * width) / 4,
              ),
              SizedBox(
                height: 50,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
