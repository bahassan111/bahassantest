import React, { Component, useState, useEffect, useRef  } from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    ImageBackground,
    ActivityIndicator,
    Button, Dimensions,
    TouchableOpacity,
    Animated, AppState, SafeAreaView,ScrollView,
    BackHandler,Alert
} from "react-native";

import HTMLView from 'react-native-htmlview';
import YoutubePlayer from "react-native-youtube-iframe";
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {updateData} from "../redux/actions/dataAction";
import TopHeader from "../componants/TopHeader";
import css from "../global/GlobalStyle";
import Carousel from 'react-native-snap-carousel';
import GestureRecognizer from 'react-native-swipe-gestures';
import Loader from "./_loader";
import { AntDesign, FontAwesome5 } from '@expo/vector-icons';
import news from "../data/newsDemo";
import storage from "../storage/TwStorage";
import {fetchNewsData} from "../data/NewsData";
import NewsObject from "../data/NewsObject";
import SliderIndicator from "../componants/SliderIndicator";


const win = Dimensions.get('window');
const ofHeight = (p)=> p * win.height / 100;
const ofWidth = (p)=> p * win.width / 100;


function BK(props) {

    useEffect(() => {
        const backAction = () => {
            if(props.onBack){
                props.onBack();
                return true;
            }
            return false;

        };

        const backHandler = BackHandler.addEventListener('hardwareBackPress', backAction);

        return () => backHandler.remove();
    }, []);

    return (
        <View></View>
    );
}


class newsScreen extends Component {


    shuffle = (array) => {
        var currentIndex = array.length, temporaryValue, randomIndex;

        // While there remain elements to shuffle...
        while (0 !== currentIndex) {

            // Pick a remaining element...
            randomIndex = Math.floor(Math.random() * currentIndex);
            currentIndex -= 1;

            // And swap it with the current element.
            temporaryValue = array[currentIndex];
            array[currentIndex] = array[randomIndex];
            array[randomIndex] = temporaryValue;
        }

        return array;
    };

    state = {
        appState: AppState.currentState,
        isModalVisible : false,
        animation: new Animated.Value(0),
        news : [],
        isUp: false,
        stopInd : false,
    };

    componentDidMount() {


        fetchNewsData(this.props.data.language)
            .then((news)=>{

                this.setState({news : news});


            })



    }

    swipedUp = (item) => {
        this.toggleModal();
    };

    render_det = ()=>{
      let item = this.state.news_item;

      return (
          <View>
              <View style={[css.np_body]}>

                  <View style={[css.npb_head]}>
                      <Text style={[css.npb_title]}>{item.title}</Text>
                  </View>

                  <View style={[css.npb_sub]}>
                      <Text style={[css.npb_subtitle]}>{item.date.fromNow()}</Text>
                  </View>

                  <View style={[css.npb_body]}>

                      {(()=>{

                          if(item.video_type === 'youtube'){
                              return (
                                  <YoutubePlayer
                                      height={300}
                                      play={true}
                                      videoId={item.video_id}
                                  />)
                          }else if(item.video_type === 'image'){
                              return (<Image style={{height : 300}} source={{uri : item.image_uri}}/>)
                          }else{
                              return (<HTMLView
                                  value={item.video_url}
                                  stylesheet={StyleSheet.create({

                                  })}
                                  onLinkPress={(url) => console.log('clicked link: ', url)}
                              />);
                          }




                      })()}

                      <View style={[css.npb_content_holder]}>
                          <HTMLView
                              value={item.content}
                              stylesheet={StyleSheet.create({

                              })}
                              onLinkPress={(url) => console.log('clicked link: ', url)}
                          />
                      </View>

                  </View>

              </View>
          </View>
      );
    };

    toggleModal = () => {
        if(!this.state.isModalVisible) this.setState({news_item : null});
        this.setState((prevState) => {
            Animated.spring(this.state.animation, {
                toValue: prevState.isModalVisible ? 0 : 1,
                useNativeDriver: false,
            }).start();
            return {
                isModalVisible: !prevState.isModalVisible,
                stopInd : prevState.isModalVisible
            }
        });


    };

    hideModal = () => {
        this.setState((prevState) => {
            Animated.spring(this.state.animation, {
                toValue: 0,
                useNativeDriver: false,
            }).start();
            return {
                isModalVisible: 0
            }
        })
    };

    renderModal = () => {
        return (
            <View><Text>a</Text></View>
        )
    };

    news_clicked = (item)=>{

        this.toggleModal();

        setTimeout(()=>{
            this.setState({news_item : item});
        }, 1000);


    };


    logoPressed = ()=>{

    };
    menuPressed = ()=>{
        const {navigation} = this.props;

        navigation.toggleDrawer();
    };


    _renderItem = (data) => {

        let item = new NewsObject(data.item);


        return (

            <View style={[css.news_item]}>
                <ImageBackground style={[css.ni_bg]} source={item.image_uri}>

                    {/* <GestureRecognizer
                        onSwipeUp={()=>{this.swipedUp(data.item)}}
                        onSwipe={(i, data)=>{
                            console.log('swipe?');
                        }}
                        config={{
                            velocityThreshold: 0.3,
                            directionalOffsetThreshold: 80
                        }}
                    >



                    </GestureRecognizer>*/}


                    <View style={[css.ni_inner]}>
                        <TouchableOpacity onPress={()=>{this.news_clicked(item)}}>
                            <View style={[css.ni_tags]}>
                                <Text style={[css.ni_tag]}>{item.category}</Text>
                            </View>
                            <View style={[css.ni_title_holder]}>
                                <Text style={[css.ni_title]}>{item.title}</Text>
                            </View>
                            <View style={[css.ni_foot]}>
                                <Text style={[css.ni_foot_txt]}>{item.date.format('DD MMMM YYYY')}</Text>
                            </View>
                        </TouchableOpacity>
                    </View>


                </ImageBackground>
            </View>


        );

    };
    _itemWillShow = (index)=>{

        //console.log('snappped to ', index);

    };
    _onLayout = (v, i)=>{

    };

    timerEnded = (anim, pr)=>{
        anim.setValue(0);

        if('_carousel' in this && this._carousel.snapToNext){
            this._carousel.snapToNext();
            pr.start(()=> this.timerEnded(anim, pr));
        }


    };


    render() {

        return (

            <View style={[css.background]}>
                <TopHeader transparent={true} floatable={true} title={''} onMenu={this.menuPressed} onUser={this.logoPressed}/>

                {
                    (!this.state.news) ? (<Loader/>) : (
                        <View>
                            {true ? (null) : (<SliderIndicator duration={this.props.data.slider_time} onEnd={this.timerEnded} />)}
                            <Carousel
                                onLayout={this._onLayout}
                                onSnapToItem={this._itemWillShow}
                                activeAnimationOptions={null}
                                onPress={this.onPress}
                                layout={'default'} layoutCardOffset={2}
                                ref={(c) => { this._carousel = c; }}
                                data={this.state.news}
                                renderItem={this._renderItem}
                                sliderWidth={ofWidth(100)}
                                itemWidth={ofWidth(100)}
                            />


                            <Animated.View style={[css.modal, {
                                top: this.state.animation.interpolate({
                                    inputRange: [0, 1],
                                    outputRange: [ofHeight(120), 0]
                                })
                            }]}>
                                <View style={css.modal_inside} onPress={this.hideModal}>

                                    <TouchableOpacity style={[css.modal_shadow]} onPress={this.hideModal} />
                                    <ScrollView style={[css.np_inner]}>
                                        <View style={[css.np_sc, (this.state.news_item && this.state.isModalVisible) ? {} : css.np_sc_l]}>
                                            <BK onBack={()=>{
                                                if(this.state.isModalVisible){
                                                    this.hideModal();
                                                }else{

                                                }

                                            }} />
                                            {
                                                (this.state.news_item && this.state.isModalVisible) ? (this.render_det()) : (<Loader/>)
                                            }
                                        </View>


                                        {
                                            !(this.state.news_item && this.state.isModalVisible) ? (null) : (
                                                <View>
                                                    <View style={[css.np_footer]}>
                                                        <Text style={[css.np_footer_txt]}>Partager</Text>
                                                        <TouchableOpacity style={[css.npf_btn]}>
                                                            <AntDesign  name="facebook-square" size={32} color="#2553D8" />
                                                        </TouchableOpacity>
                                                        <TouchableOpacity style={[css.npf_btn]}>
                                                            <AntDesign name="twitter" size={32} color="#00D4FF" />
                                                        </TouchableOpacity>
                                                        <TouchableOpacity style={[css.npf_btn]}>
                                                            <FontAwesome5 name="whatsapp-square" size={32} color="#00E979" />
                                                        </TouchableOpacity>

                                                        <TouchableOpacity style={[css.npf_btn]}>
                                                            <AntDesign name="sharealt" size={32} color="black" />
                                                        </TouchableOpacity>


                                                    </View>
                                                    <View style={[css.np_ac]}>
                                                        <TouchableOpacity onPress={this.hideModal} style={[css.np_ac_btn]}>
                                                            <Text style={[css.np_ac_txt]}>Fermer</Text>
                                                            <AntDesign style={[css.np_ac_icon]} name="closecircle" size={42} color="white" />
                                                        </TouchableOpacity>
                                                    </View>
                                                </View>


                                            )
                                        }
                                    </ScrollView>




                                </View>
                            </Animated.View>
                        </View>
                    )
                }


                {
                    (this.state.isUp) ?
                        (this.renderModal()):
                        (null)
                }

            </View>

        );
    }

}

const styles = StyleSheet.create({

    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    box: {
        backgroundColor: '#61dafb',
        width: 80,
        height: 80,
        borderRadius: 4,
    },


});

const mapDispatchToProps = dispatch => (
    bindActionCreators({
        updateData: updateData,
    }, dispatch)
);

const mapStateToProps = (state) => {
    const { data } = state;
    return { data }
};

export default connect(mapStateToProps, mapDispatchToProps)(newsScreen);
