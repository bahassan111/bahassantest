import 'package:bot_toast/bot_toast.dart';
import 'package:driver/constants/app_themes.dart';
import 'package:driver/constants/helpers/formaters.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:driver/ui/components/components.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class FinishTripDetail extends StatelessWidget {
  static HomeController to = Get.find();
  final MyMapController mapTo = MyMapController.to;

  @override
  Widget build(BuildContext context) {
    print("ride id ${to.rideDetail.id}");
    return Center(
      child: Material(
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 15, horizontal: 30),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                "my_earning".tr,
                style: AppThemes.lightTheme.textTheme.headline1.copyWith(
                  fontSize: 20,
                ),
              ),
              Text(
                "${to.rideDetail.currency} ${numberFormating.format(double.tryParse(to.rideDetail.driverfees))} ",
                style: AppThemes.lightTheme.textTheme.headline1.copyWith(
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(
                height: 15,
              ),
              Row(
                children: [
                  Icon(
                    Icons.circle,
                    size: 13,
                    color: AppThemes.lightdeepPinkDropDownIconColor,
                  ),
                  SizedBox(
                    width: 30,
                  ),
                  Expanded(
                    child: Text(
                      "${to.rideDetail.pickupaddress}",
                      style: AppThemes.lightTheme.textTheme.headline1.copyWith(
                        fontSize: 15,
                      ),
                      maxLines: 2,
                    ),
                  )
                ],
              ),
              SizedBox(
                height: 5,
              ),
              Row(
                children: [
                  Icon(
                    Icons.circle,
                    size: 13,
                    color: AppThemes.lightGreenbackGroundColor,
                  ),
                  SizedBox(
                    width: 30,
                  ),
                  Expanded(
                    child: Text(
                      "${to.rideDetail.dropaddress}",
                      style: AppThemes.lightTheme.textTheme.headline1.copyWith(
                        fontSize: 15,
                      ),
                      maxLines: 2,
                    ),
                  )
                ],
              ),
              SizedBox(
                height: 10,
              ),
              displayDetail(
                  title: "distance".tr + ": ",
                  value: getNumber(double.tryParse(to.rideDetail.distance))
                          .toString() +
                      "km".tr,
                  ispadded: false),
              displayDetail(
                  title: "journey_time".tr + ": ",
                  value: minutesToDateTime(to.rideDetail.duration)
                          .minute
                          .toString() +
                      " min".tr +
                      " 00" +
                      " sec".tr,
                  ispadded: false),
              SizedBox(
                height: 15,
              ),
              Align(
                alignment: Alignment.center,
                child: Text(
                  "fare_details".tr,
                  style: AppThemes.lightTheme.textTheme.headline1.copyWith(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    decoration: TextDecoration.underline,
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "total_fare".tr,
                    style: AppThemes.lightTheme.textTheme.headline1.copyWith(
                      fontSize: 15,
                    ),
                  ),
                  Text(
                    "${to.rideDetail.currency} ${numberFormating.format(double.tryParse(to.rideDetail.driverfees))}",
                    style: AppThemes.lightTheme.textTheme.headline1.copyWith(
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "toll".tr,
                    style: AppThemes.lightTheme.textTheme.headline1.copyWith(
                      fontSize: 15,
                    ),
                  ),
                  Text(
                    "${to.rideDetail.currency} ${numberFormating.format(double.tryParse(to.rideDetail.tolltaxamount))}",
                    style: AppThemes.lightTheme.textTheme.headline1.copyWith(
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
              /* Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "admin_fee".tr,
                    style: AppThemes.lightTheme.textTheme.headline1.copyWith(
                      fontSize: 16,
                    ),
                  ),
                  Text(
                    "${to.rideDetail.currency} ${numberFormating.format(double.tryParse(to.rideDetail.adminfees))}",
                    style: AppThemes.lightTheme.textTheme.headline1.copyWith(
                      fontSize: 16,
                    ),
                  ),
                ],
              ),*/
              to.rideDetail.clientId != '0'
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "fleet_agent_booker_markup".tr,
                          style:
                              AppThemes.lightTheme.textTheme.headline1.copyWith(
                            fontSize: 15,
                          ),
                        ),
                        Text(
                          "${to.rideDetail.currency} ${numberFormating.format(double.tryParse(to.rideDetail.dispatchfees) + double.tryParse(to.rideDetail.gatewayFee) + double.tryParse(to.rideDetail.clientfees))}",
                          style:
                              AppThemes.lightTheme.textTheme.headline1.copyWith(
                            fontSize: 15,
                          ),
                        ),
                      ],
                    )
                  : Container(),
              to.rideDetail.clientId != '0'
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "flee_agent_booker_tax".tr,
                          style:
                              AppThemes.lightTheme.textTheme.headline1.copyWith(
                            fontSize: 15,
                          ),
                        ),
                        Text(
                          "${to.rideDetail.currency} ${numberFormating.format(double.tryParse(to.rideDetail.supplierPartnerTax ?? '0') + double.tryParse(to.rideDetail.agentBookerTax ?? '0'))}",
                          style:
                              AppThemes.lightTheme.textTheme.headline1.copyWith(
                            fontSize: 15,
                          ),
                        ),
                      ],
                    )
                  : Container(),
              to.rideDetail.userId != '0'
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "fleet_markup".tr,
                          style:
                              AppThemes.lightTheme.textTheme.headline1.copyWith(
                            fontSize: 15,
                          ),
                        ),
                        Text(
                          "${to.rideDetail.currency} ${numberFormating.format(double.tryParse(to.rideDetail.dispatchfees) + double.tryParse(to.rideDetail.gatewayFee))}",
                          style:
                              AppThemes.lightTheme.textTheme.headline1.copyWith(
                            fontSize: 15,
                          ),
                        ),
                      ],
                    )
                  : Container(),
              to.rideDetail.userId != '0'
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "fleet_tax".tr,
                          style:
                              AppThemes.lightTheme.textTheme.headline1.copyWith(
                            fontSize: 15,
                          ),
                        ),
                        Text(
                          "${to.rideDetail.currency} ${numberFormating.format(double.tryParse(to.rideDetail.supplierPartnerTax))}",
                          style:
                              AppThemes.lightTheme.textTheme.headline1.copyWith(
                            fontSize: 15,
                          ),
                        ),
                      ],
                    )
                  : Container(),
              /* Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "total_ride_fare".tr,
                    style: AppThemes.lightTheme.textTheme.headline1.copyWith(
                      fontSize: 15,
                    ),
                  ),
                  Text(
                    to.rideDetail.userId != '0'
                        ? "${to.rideDetail.currency} ${numberFormating.format(double.tryParse(to.rideDetail.driverfees) + double.tryParse(to.rideDetail.tolltaxamount) + double.tryParse(to.rideDetail.dispatchfees) + double.tryParse(to.rideDetail.gatewayFee) + double.tryParse(to.rideDetail.supplierPartnerTax))}"
                        : to.rideDetail.clientId == '0'
                            ? "${to.rideDetail.currency} ${numberFormating.format(double.tryParse(to.rideDetail.driverfees) + double.tryParse(to.rideDetail.tolltaxamount))}"
                            : "${to.rideDetail.currency} ${numberFormating.format(double.tryParse(to.rideDetail.driverfees) + double.tryParse(to.rideDetail.tolltaxamount) + double.tryParse(to.rideDetail.dispatchfees) + double.tryParse(to.rideDetail.gatewayFee) + double.tryParse(to.rideDetail.clientfees) + double.tryParse(to.rideDetail.supplierPartnerTax) + double.tryParse(to.rideDetail.agentBookerTax))}",
                    style: AppThemes.lightTheme.textTheme.headline1.copyWith(
                      fontSize: 15,
                    ),
                  ),
                ],
              ),*/
              // todo this is added
              /* to.rideDetail.userId != '0'
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "admin_fee".tr,
                          style:
                              AppThemes.lightTheme.textTheme.headline1.copyWith(
                            fontSize: 15,
                          ),
                        ),
                        Text(
                          "${to.rideDetail.currency} ${numberFormating.format(double.tryParse(to.rideDetail.adminfees))}",
                          style:
                              AppThemes.lightTheme.textTheme.headline1.copyWith(
                            fontSize: 15,
                          ),
                        ),
                      ],
                    )
                  : SizedBox.shrink(),*/
              SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "please_collect".tr + " :",
                    style: AppThemes.lightTheme.textTheme.headline1.copyWith(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    "${to.rideDetail.currency} ${numberFormating.format(double.tryParse(to.rideDetail.totalfare) + double.tryParse(to.rideDetail.tolltaxamount))}",
                    style: AppThemes.lightTheme.textTheme.headline1.copyWith(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 15,
              ),
              RoundButton(
                onTap: () {
                  to.rideDetail = null;
                  mapTo.routeDetail.value = null;
                  mapTo.mapMatchingModel = null;
                  BotToast.cleanAll();
                },
                verticalPadding: 5,
                text: "ok".tr.toUpperCase(),
                textStyle: AppThemes.lightTheme.textTheme.headline6
                    .copyWith(fontSize: 18, fontWeight: FontWeight.w600),
                backgroundColor: AppThemes.lightdeepPinkDropDownIconColor,
              )
            ],
          ),
        ),
      ),
    );
  }

  TimeOfDay minutesToDateTime(String time) {
    if (time == null) {
      return null;
    }
    Duration duration = Duration(minutes: double.tryParse(time).toInt());
    List<String> parts = duration.toString().split(':');
    return TimeOfDay(
        hour: int.tryParse(parts[0]), minute: int.tryParse(parts[1]));
  }

  displayDetail({String title, String value, bool ispadded = true}) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: ispadded ? 20 : 0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 13,
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(fontSize: 13),
              maxLines: 2,
            ),
          ),
        ],
      ),
    );
  }
}
