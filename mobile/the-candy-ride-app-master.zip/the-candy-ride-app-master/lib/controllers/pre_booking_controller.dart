import 'package:bot_toast/bot_toast.dart';
import 'package:get/get.dart';
import 'package:dio/dio.dart' as dio;
import 'package:rider_app/constants/constants.dart';
import 'package:rider_app/controllers/controllers.dart';
import 'package:rider_app/helpers/helpers.dart';
import 'package:rider_app/models/booking.dart';
import 'package:rider_app/models/countryModel.dart';
import 'package:rider_app/models/ride.dart';
import 'package:rider_app/ui/components/components.dart';

class PreBookingController extends GetxController {
  static PreBookingController to = Get.find();
  static AuthController authTo = Get.find();
  List<Booking> bookings = [];
  List<Booking> filterBookings = [];
  Booking booked;
  DateTime selectedDate;
  NetWorkCall networkCall = NetWorkCall();

  Future getBookings() async {
    BotToast.showLoading();
    bookings.clear();
    filterBookings.clear();
    final result = await networkCall
        .postRequestWithResponse(url: Urls.riderCurrentride, json: {
      Params.riderId: authTo.userModel.riderid,
    });

    BotToast.closeAllLoading();
    return result.fold((l) {
      BotToast.showWidget(
        toastBuilder: (_) => ErrorDialog(
          title: "error".tr,
          message: "No prebookings are found".tr,
        ),
      );
    }, (response) {
      response.data['preridedetail'].forEach((e) {
        booked = new Booking();
        booked.id = e['id'] as String;
        booked.userId = e['user_id'] as String;
        booked.driverId = e['driver_id'] as String;
        booked.rideStatus = e['ride_status'] as String;
        booked.dispatchId = e['dispatch_id'] as String;
        booked.countryId = e['country_id'] as String;
        booked.pickupAddress = e['pickupaddress'] as String;
        booked.dropAddress = e['dropaddress'] as String;
        booked.bookingDate = e['book_datetime'] as String;
        bookings.add(booked);
        filterBookings.add(booked);
      });
    });
  }

  Future cancelbooking(String bookId, String countryId) async {
    BotToast.showLoading();
    final dat =
        await networkCall.postRequestWithResponse(url: Urls.cancelride, json: {
      Params.rideId: bookId,
      Params.reason: "No reason",
      Params.statusType: "2",
      Params.countryId: countryId,
      Params.cancelDateTime: "none",
      Params.bookType: 1
    });
    BotToast.closeAllLoading();
    Get.back();
    Get.toNamed('/PreBookingUI');
  }

  filterDate() {
    filterBookings.clear();
    bookings.forEach((element) {
      if (isSameDate(stringToDateTime(element.bookingDate), selectedDate)) {
        filterBookings.add(element);
      }
    });
  }
}
