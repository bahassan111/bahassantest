import PropTypes from "prop-types";

import React, { PureComponent } from "react";
import { DangerZone } from "expo";

const { Lottie } = DangerZone;

import { View } from "react-native-ui-lib";

export class LottieView extends PureComponent {
  state = { animation: null };

  componentWillMount() {
    this._playAnimation();
  }

  _playAnimation = () => {
    if (!this.state.animation) {
      this._loadAnimationAsync();
    } else {
      this.animation.reset();
      this.animation.play();
    }
  };

  _loadAnimationAsync = async () => {
    this.setState({ animation: this.props.source }, this._playAnimation);
  };

  render() {
    return (
      <View row center>
        {this.state.animation && (
          <Lottie
            ref={animation => {
              this.animation = animation;
            }}
            style={{
              width: 100,
              height: 100
            }}
            source={this.state.animation}
            loop={this.props.loop}
          />
        )}
      </View>
    );
  }
}
LottieView.PropsTypes = { source: PropTypes.object, loop: PropTypes.bool };
LottieView.defaultProps = {
  loop: false
};
