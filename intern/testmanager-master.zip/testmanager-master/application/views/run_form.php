<?php
?>

<div class="" id="run_form">


    <form method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="title" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Test Run Title</label>
            <input required id="title" name="title" value="<?= $edit ? $run->title : ''; ?>" type="text" class="form-control form-control-sm" placeholder="Enter a descriptive title ..">
        </div>

        <div class="form-group">
            <label for="type" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Run type</label>
            <select required data-livesearch="false" title="Select a run type" name="type" id="type" class="selectpicker form-control form-control-sm">
                <option <?= $edit && $run->type === 'auto' ? 'selected' : ''; ?> value="auto">Auto</option>
                <option <?= $edit && $run->type === 'manual' ? 'selected' : (!$edit ? 'selected' : ''); ?> value="manual">Manual</option>
                <option <?= $edit && $run->type === 'unit' ? 'selected' : ''; ?> value="unit">Unit Test</option>
            </select>
        </div>

        <input type="hidden" name="id_project" value="<?= $id_project; ?>">
        <div class="form-group">
            <label for="note" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Note (optional)</label>
            <textarea class="form-control form-control-sm" id="note" name="note"><?= $edit ? $run->note : ''; ?></textarea>
        </div>


        <div class="form-group">
            <label for="id_release" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Release</label>
            <select required data-livesearch="true" title="select a project release" name="id_release" id="id_release" class="selectpicker form-control form-control-sm">

                <?php foreach($releases as $release){ ?>
                    <option <?= $edit && $run->id_release == $release->id ? 'selected' : ''; ?> value="<?= $release->id; ?>"><?= $release->name; ?></option>
                <?php } ?>

            </select>
        </div>


        <div class="form-group">
            <label for="assigned_to" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Assign to</label>
            <select required data-livesearch="true" title="select a member" name="assigned_to" id="assigned_to" class="selectpicker form-control form-control-sm">

                <?php foreach($users as $user){ ?>
                    <option <?= $edit && $user->id == $run->assigned_to ? 'selected' : ''; ?> value="<?= $user->id; ?>"><?= $user->username; ?></option>
                <?php } ?>

            </select>
        </div>

        <div class="form-group">
            <label for="date" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Date</label>
            <input type="text" class="form-control form-control-sm datepicker" id="date" name="date" value="<?= $edit ? $run->date : date('Y-m-d'); ?>">
        </div>
    </form>


</div>
