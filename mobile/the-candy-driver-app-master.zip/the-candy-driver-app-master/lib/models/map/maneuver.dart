class Maneuver {
  String type;
  String instruction;
  int bearingAfter;
  int bearingBefore;
  List<double> location;
  String modifier;

  Maneuver(
      {this.type,
      this.instruction,
      this.bearingAfter,
      this.bearingBefore,
      this.location,
      this.modifier});

  Maneuver.fromJson(Map<String, dynamic> json) {
    type = json['type'];
    instruction = json['instruction'];
    bearingAfter = json['bearing_after'];
    bearingBefore = json['bearing_before'];
    location = json['location'].cast<double>();
    modifier = json['modifier'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['type'] = this.type;
    data['instruction'] = this.instruction;
    data['bearing_after'] = this.bearingAfter;
    data['bearing_before'] = this.bearingBefore;
    data['location'] = this.location;
    data['modifier'] = this.modifier;
    return data;
  }
}
