import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rider_app/constants/constants.dart';
import 'package:rider_app/controllers/controllers.dart';

class ProfilePicture extends StatelessWidget {
  final double size;
  final String image;
  const ProfilePicture({this.size, @required this.image});
  static AuthController to = Get.find();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: size,
      width: size,
      decoration: BoxDecoration(
        border: Border.all(
          color: AppThemes.lightDividerColor,
        ),
        shape: BoxShape.circle,
      ),
      child: Container(
        margin: EdgeInsets.all(3),
        decoration: BoxDecoration(
          image: DecorationImage(
            onError: (_, __) {
              print("on error from image");
            },
            image:
                // image != null &&
                //         image.trim() != Urls.imageBaseUrl &&
                //         image.trim() != ''
                //     ? NetworkImage(
                //         image,
                //       )
                //     :
                AssetImage(
              AllImages.adddp,
            ),
          ),
          shape: BoxShape.circle,
        ),
      ),
    );
  }
}
