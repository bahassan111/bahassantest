package ma.rak.ov.models;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class PendingOperation extends RealmObject {
    @PrimaryKey
    private String num_operation;

    private String status;
    private String observation;
    private String motif;
    private String date;
    private String nature_install;
    private String emplacement;
    private String niveau;
    private String etage;
    private String doss_annee;
    private String doss_numm;
    private String gerance;
    private String nature_lot;
    private String photo;
    private String resultat;

    public PendingOperation(String num_operation, String status, String observation, String motif, String date, String nature_install, String emplacement, String niveau, String etage, String doss_annee, String doss_numm, String gerance, String nature_lot, String photo, String resultat) {
        this.num_operation = num_operation;
        this.status = status;
        this.observation = observation;
        this.motif = motif;
        this.date = date;
        this.nature_install = nature_install;
        this.emplacement = emplacement;
        this.niveau = niveau;
        this.etage = etage;
        this.doss_annee = doss_annee;
        this.doss_numm = doss_numm;
        this.gerance = gerance;
        this.nature_lot = nature_lot;
        this.photo = photo;
        this.resultat = resultat;
    }

    public PendingOperation() {
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getObservation() {
        return observation;
    }

    public void setObservation(String observation) {
        this.observation = observation;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getNature_install() {
        return nature_install;
    }

    public void setNature_install(String nature_install) {
        this.nature_install = nature_install;
    }

    public String getEmplacement() {
        return emplacement;
    }

    public void setEmplacement(String emplacement) {
        this.emplacement = emplacement;
    }

    public String getNiveau() {
        return niveau;
    }

    public void setNiveau(String niveau) {
        this.niveau = niveau;
    }

    public String getEtage() {
        return etage;
    }

    public void setEtage(String etage) {
        this.etage = etage;
    }

    public String getDoss_annee() {
        return doss_annee;
    }

    public void setDoss_annee(String doss_annee) {
        this.doss_annee = doss_annee;
    }

    public String getDoss_numm() {
        return doss_numm;
    }

    public void setDoss_numm(String doss_numm) {
        this.doss_numm = doss_numm;
    }

    public String getNum_operation() {
        return num_operation;
    }

    public void setNum_operation(String num_operation) {
        this.num_operation = num_operation;
    }

    public String getGerance() {
        return gerance;
    }

    public void setGerance(String gerance) {
        this.gerance = gerance;
    }

    public String getNature_lot() {
        return nature_lot;
    }

    public void setNature_lot(String nature_lot) {
        this.nature_lot = nature_lot;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getMotif() {
        return motif;
    }

    public void setMotif(String motif) {
        this.motif = motif;
    }

    public String getResultat() {
        return resultat;
    }

    public void setResultat(String resultat) {
        this.resultat = resultat;
    }

    @Override
    public String toString() {
        return "PendingOperation{" +
                "num_operation='" + num_operation + '\'' +
                ", status='" + status + '\'' +
                ", observation='" + observation + '\'' +
                ", motif='" + motif + '\'' +
                ", date='" + date + '\'' +
                ", nature_install='" + nature_install + '\'' +
                ", emplacement='" + emplacement + '\'' +
                ", niveau='" + niveau + '\'' +
                ", etage='" + etage + '\'' +
                ", doss_annee='" + doss_annee + '\'' +
                ", doss_numm='" + doss_numm + '\'' +
                ", gerance='" + gerance + '\'' +
                ", nature_lot='" + nature_lot + '\'' +
                ", photo='" + photo + '\'' +
                ", resultat='" + resultat + '\'' +
                '}';
    }
}
