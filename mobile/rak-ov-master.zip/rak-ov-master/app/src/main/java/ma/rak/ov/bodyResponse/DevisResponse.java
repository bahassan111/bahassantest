package ma.rak.ov.bodyResponse;

import com.google.gson.annotations.SerializedName;

import io.realm.RealmList;
import io.realm.RealmObject;
import ma.rak.ov.models.Agent;
import ma.rak.ov.models.Devis;

public class DevisResponse extends RealmObject {

    @SerializedName("status")
    private String status;

    @SerializedName("data")
    private RealmList<Devis> devis;

    public DevisResponse() {
    }

    public DevisResponse(int id, String status, RealmList<Devis> devis) {
        this.status = status;
        this.devis = devis;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public RealmList<Devis> getDevis() {
        return devis;
    }

    public void setDevis(RealmList<Devis> devis) {
        this.devis = devis;
    }

    @Override
    public String toString() {
        return "DevisResponse{" +
                "status='" + status + '\'' +
                ", agents=" + devis +
                '}';
    }
}
