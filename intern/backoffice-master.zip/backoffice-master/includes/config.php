<?php
global $config;

$config['db_host'] = 'localhost';
$config['db_user'] = 'root';
$config['db_password'] = '';
$config['db_name'] = 'tw_bo';
$config['db_port'] = '3600';


$config['site_url'] = 'http://localhost/twBackoffice';
$config['default_title'] = 'MTIP - BACKOFFICE';
$config['lien_playstore'] = 'https://play.google.com/store/apps/details?id=APPID&hl='.abbrLng();
$config['lien_appstore'] = 'https://apps.apple.com/us/app/';


$config['admin_menu'] = [
    'dashboard' => [
        'url' => 'admin/?page=dashboard',
        'text' => 'Tableau de bord',
        'icon' => 'fa fa-home',
    ],
    'regions' => [
        'url' => 'admin/?page=regions',
        'text' => 'Les régions',
        'icon' => 'fa fa-map',
    ],
    'files' => [
        'url' => 'admin/?page=files',
        'text' => 'Les fichiers',
        'icon' => 'fa fa-download',
    ],

    'system' => [
        'url' => '#',
        'text' => 'System',
        'icon' => 'fas fa-tachometer-alt',
        'items' => [
            'languages_front' => [
                'url' => 'admin/?page=languages_front',
                'text' => 'Traduction système',
                'icon' => 'fa fa-language',
            ],
        ],
    ],
];