import 'package:flutter/material.dart';
import 'package:rider_app/constants/constants.dart';
import 'package:get/get.dart';

class IntroUI extends StatefulWidget {
  @override
  _IntroUIState createState() => _IntroUIState();
}

class _IntroUIState extends State<IntroUI> {
  double height, width;

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;

    return Scaffold(
      body: SafeArea(
        child: Container(
          width: width,
          child: Column(
            children: [
              SizedBox(
                height: 30,
              ),
              Image.asset(
                AllImages.theCandy,
                width: (3 * width) / 4,
              ),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage(
                        AllImages.taxicall,
                      ),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              tagLine(context),
              SizedBox(
                height: 35,
              ),
              Container(
                child: Column(
                  children: [
                    GestureDetector(
                      onTap: () => Get.toNamed('/SignInUI'),
                      child: Container(
                        margin: EdgeInsets.symmetric(horizontal: 35),
                        width: width,
                        padding:
                            EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                        decoration: BoxDecoration(
                          color: AppThemes.lightPinkBackGroundColor,
                          borderRadius: BorderRadius.circular(40),
                        ),
                        child: Center(
                          child: Text(
                            "login".tr,
                            style: Theme.of(context)
                                .textTheme
                                .subtitle1
                                .copyWith(
                                    fontSize: 20, fontWeight: FontWeight.w700),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                            "don’thaveAnAccount".tr,
                            style: Theme.of(context)
                                .textTheme
                                .headline2
                                .copyWith(
                                    fontWeight: FontWeight.w700, fontSize: 15),
                          ),
                        ),
                        GestureDetector(
                          onTap: () => Get.toNamed('/SignUpUI'),
                          child: Text(
                            ' ' + "signUp".tr,
                            style: Theme.of(context)
                                .textTheme
                                .headline5
                                .copyWith(
                                    fontWeight: FontWeight.w700, fontSize: 16),
                          ),
                        ),
                        Text(
                          ' ' + "today".tr + '!',
                          style: Theme.of(context).textTheme.headline2.copyWith(
                              fontWeight: FontWeight.w700, fontSize: 16),
                        )
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 35,
              ),
            ],
          ),
        ),
      ),
    );
  }

  tagLine(context) {
    return Container(
      width: width,
      padding: EdgeInsets.only(left: 35),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "helloNiceToMeetYou".tr,
            style: Theme.of(context).textTheme.headline2.copyWith(fontSize: 14),
          ),
          Text(
            "getMovingWiththeCandy".tr,
            style: Theme.of(context).textTheme.headline2.copyWith(
                fontWeight: FontWeight.w700, fontSize: 20, height: 1.1),
          ),
        ],
      ),
    );
  }
}
