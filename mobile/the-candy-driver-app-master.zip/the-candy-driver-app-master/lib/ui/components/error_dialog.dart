import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:driver/ui/components/components.dart';

class ErrorDialog extends StatelessWidget {
  const ErrorDialog({Key key, this.message, this.title, this.ontap})
      : super(key: key);
  final String title;
  final String message;
  final Function ontap;
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(title,
          style: Theme.of(context).textTheme.headline2.copyWith(fontSize: 18)),
      content: Text(message,
          style: Theme.of(context).textTheme.headline2.copyWith(fontSize: 16)),
      actions: [
        Align(
          alignment: Alignment.center,
          child: Container(
            padding: EdgeInsets.symmetric( horizontal: 10),
            width: 100,
            child: RoundButton(
              onTap: ontap ??
                  () {
                    BotToast.cleanAll();
                  },
              text: "ok".tr,
            ),
          ),
        )
      ],
    );
  }
}
