import 'package:flutter/material.dart';
import 'package:driver/constants/app_themes.dart';

class FormInputField extends StatelessWidget {
  FormInputField(
      {this.controller,
      this.labelText,
      this.validator,
      this.keyboardType = TextInputType.text,
      this.obscureText = false,
      this.minLines,
      this.isReadOnly = false,
      this.iconSuffix,
      this.onChanged,
      this.focusNode,
      this.onSaved,
      this.disableBorderColor});

  final TextEditingController controller;
  final String labelText;
  final bool isReadOnly;
  final FocusNode focusNode;
  final String Function(String) validator;
  final TextInputType keyboardType;
  final bool obscureText;
  final int minLines;
  final Widget iconSuffix;
  final Color disableBorderColor;

  final void Function(String) onChanged;
  final void Function(String) onSaved;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 45,
      child: TextFormField(
        focusNode: focusNode,
        readOnly: isReadOnly,
        style: Theme.of(context).textTheme.headline2.copyWith(
              fontSize: 15,
            ),
        decoration: InputDecoration(
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
                color: disableBorderColor ?? Colors.grey, width: 2.0),
          ),
          focusedBorder: UnderlineInputBorder(
            borderSide:
                BorderSide(color: AppThemes.lightActiveInputBorder, width: 2.0),
          ),
          contentPadding: EdgeInsets.only(bottom: 10),
          suffixIcon: iconSuffix,
          labelText: labelText + " *",
          labelStyle: Theme.of(context).textTheme.headline2.copyWith(
                fontSize: 15,
              ),
        ),
        controller: controller,
        onSaved: onSaved,
        onChanged: onChanged,
        keyboardType: keyboardType,
        obscureText: obscureText,
        validator: validator,
        autocorrect: false,
      ),
    );
  }
}
