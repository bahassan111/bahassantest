<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tasks extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!isLoggedIn()) {
            callback_whenNotLoggedIn();
        }
    }

    public function index()
    {


    }

    public function tasks($id_project)
    {
        if (!$id_project) callback_whenNotFound();
        $project = $this->db->get_where('projects', ['id' => $id_project, 'deleted' => 0])->row();
        if (!$project) callback_whenNotFound();

        $data = [
            'title' => $project->name . ' | Tasks ',
            '_page' => 'tasks',
            '_action' => Pages::ACTION_READ,
            'project' => $project,
        ];

        loadView('tasks', $data);
    }

    public function kanban($id_project)
    {
        if (!$id_project) callback_whenNotFound();
        $project = $this->db->get_where('projects', ['id' => $id_project, 'deleted' => 0])->row();
        if (!$project) callback_whenNotFound();

        $data = [
            '_title' => $project->name . ' | Tasks Kanban ',
            '_page' => 'tasks',
            '_action' => Pages::ACTION_READ,
            'project' => $project,
        ];

        loadView('kanban', $data);
    }

    public function get_list($id_project){
        if(!hasPermission('tasks', 'read')) callback_whenNoPermission();
        $id = userInfo()->id;
        $f = "";

        if(!hasPermission('tasks', 'view_all')){

            $f = " AND (t.id_user = $f OR t.affected_to = $f) ";
        }

        $data = doTwtable("SELECT * FROM tasks t WHERE t.deleted = 0 AND t.id_project = $id_project $f", function(&$row){
            $row->ref = "#t".str_pad($row->id, 4, 0, 0);
        });

        $data->permissions = Pages::get_permissions('tasks');

        responseJSON($data);
    }

    public function one_task($id = FALSE)
    {
        $task = null;
        $id_project = $this->input->post('id_project');
        if (!$id && !$id_project) callback_whenNotFound();
        if ($id) {
            $query = $this->db->query("SELECT * FROM tasks t JOIN users u ON u.id = t.id_user WHERE t.id = $id");
            $task = $query && $query->num_rows() > 0 ? $query->row() : null;
            $task->team = $this->db->query("SELECT u.* FROM tasks_members tm JOIN users u ON u.id = tm.id_user WHERE tm.id_task = $id")->result();
            if ($task) $id_project = $task->id_project;
        }


        $project = $this->alpha->full_project($id_project);

        $data = [
            'edit' => $task ? TRUE : FALSE,
            'task' => $task,
            '_page' => 'tasks',
            'priorities' => $this->alpha->get_priorities(),
            '_action' => $id ? Pages::ACTION_EDIT : Pages::ACTION_ADD,
            'project' => $project,
        ];
        loadView('task_form', $data, FALSE);
    }

    public function save_task($id = FALSE){
        $data = (object)$this->input->post();
        $query = FALSE;
        $data->updated_by = userInfo()->id;
        $data->date_updated = time();

        $users = [];
        foreach ($data->team as $item) $users[] = $item;

        unset($data->team);


        if($id){

            $query = $this->db->update('tasks',$data, ['id' => $id]);


        }else{

            $data->id_user = userInfo()->id;
            $data->date_added = time();
            $data->deleted = 0;


            $query = $this->db->insert('tasks', $data);
            if($query){
                $id = $this->db->insert_id();
            }
        }

        if($id){
            $q = $this->db->delete('tasks_members', ['id_task' => $id]);

            foreach ($users as $user){
                $this->db->insert('tasks_members', ['id_user' => $user, 'id_task' => $id]);
            }
        }



        responseJSON([
            'status' => $query ? 'OK' : 'ERROR',
        ]);

    }

    public function show($id){
        if(!$id) callback_whenNotFound();
        $task = $this->alpha->full_task($id);
        if(!$task) callback_whenNotFound();

        $data = [
            'title' => $task->title,
            '_page' => 'tasks',
            '_action' => Pages::ACTION_READ,
            'task' => $task,
        ];

        loadView('show_task', $data);
    }
}
