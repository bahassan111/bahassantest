﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;

namespace WebSocketsCmd.Meta
{
    public class TwParser
    {
        public static ParseResult parseTLV(string val)
        {
            
            
            var result = new List<TwTAG>();


            if (val.Length < 4) return new ParseResult(result.ToArray(), "");



            var total_length = val.Length - 4;
            
            //A000005200010002010002000201000300020100040004PCAR0005000200A001003200060002300007000205003500040180

            var rest = val;
            
            while (rest.Length > 4)
            {
                var tag = rest.Substring(0, 4);
                var t_len = int.Parse(rest.Substring(4, 4));
                if (rest.Length < (8 + t_len)) break;
                var t_val = rest.Substring(8, t_len);

                Array t_childs = null;

                if (TwParser.isTag(t_val))
                {
                    t_childs = TwParser.parseTLV(t_val).tags;
                }

                if (t_childs != null) t_val = "";

                result.Add(new TwTAG(tag, t_len, t_val, t_childs));
                rest = rest.Substring(8 + t_len);
            }
            
            

            


            return new ParseResult(result.ToArray(), rest);
        }

        public static bool isTag(string val)
        {
            if (val.Length < 9) return false;

            var p_tag = val.Substring(0, 4);
            int p_len;
            var isLengthCorrect = int.TryParse(val.Substring(4, 4), out p_len);
            if (!isLengthCorrect) return false;
            
            if (val.Length < (8 + p_len)) return false;
            var p_val = val.Substring(8, p_len);
            
            FieldInfo[] fieldInfos = (typeof(TwConstants)).GetFields(BindingFlags.Public |
                                                      BindingFlags.Static | BindingFlags.FlattenHierarchy);

            foreach (var field in fieldInfos)
            {
                
                if (field.GetValue(new TwConstants()).ToString() == p_tag)
                {
                    return true;
                }
            }


            return false;
        }

        public static string getTagName(string val)
        {
            FieldInfo[] fieldInfos = (typeof(TwConstants)).GetFields(BindingFlags.Public |
                                                                     BindingFlags.Static | BindingFlags.FlattenHierarchy);

            foreach (var field in fieldInfos)
            {
                
                if (field.GetValue(new TwConstants()).ToString() == val)
                {
                    return field.Name;
                }
            }

            return "";
        }
        
        
    }


    public class ParseResult
    {
        public Array tags;
        public string rest;

        public ParseResult(Array result, string rest)
        {
            this.tags = result;
            this.rest = rest;
        }

        public TwTAG getTag(string TAG)
        {

            var list = all_tags(tags);

            foreach (TwTAG tag in list)
            {
                if (tag.Type == TAG)
                {
                    return tag;
                }
            }

            return null;



            foreach (TwTAG tag in tags)
            {

                if (tag.Type == TAG)
                {
                    return tag;
                }

                foreach (TwTAG child in tag.SubTags)
                {
                    if (child.Type == TAG)
                    {
                        return child;
                    }

                    if (child.SubTags != null)
                    {
                        foreach (TwTAG child2 in child.SubTags)
                        {
                            if (child2.Type == TAG)
                            {
                                return child2;
                            }
                        }
                    }
                }

            }

            return null;
        }

        private List<TwTAG> all_tags(Array tags)
        {
            List<TwTAG> list = new List<TwTAG>();

            if (tags == null) return list;

            foreach (TwTAG tag in tags)
            {
                list.Add(tag);
                foreach (TwTAG t in all_tags(tag.SubTags))
                {
                    list.Add(t);
                }
            }

            return list;
            
        }

        

        public override string ToString()
        {
            var result = "";
            foreach (TwTAG tag in tags)
            {
                result += tag.ToString();
            }
            return result;
        }

        public string ToReadableString()
        {
            var result = "";
            foreach (TwTAG tag in tags)
            {
                result += tag.ToReadableString("");
            }
            return result;
        }
    }
}