import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:dio/dio.dart' as dio;
import 'package:rider_app/constants/constants.dart';
import 'package:rider_app/controllers/auth_controller.dart';
import 'package:rider_app/helpers/helpers.dart';
import 'package:rider_app/models/models.dart';
import 'package:rider_app/models/ride.dart';
import 'package:rider_app/ui/components/components.dart';

class RatingController extends GetxController {
  static AuthController authTo = Get.find();
  int rideId;
  Ride ride;
  NetWorkCall networkCall = NetWorkCall();
  String imagedetails;
  Future riderRetrieveFeedback() async {
    BotToast.showLoading();
    final result = await networkCall.postRequestWithResponse(
      url: Urls.riderRetrieveFeedback,
      json: {
        Params.riderId: authTo.userModel.riderid,
      },
    );

    return result.fold((l) {
      // BotToast.showWidget(
      //   toastBuilder: (_) => ErrorDialog(
      //     message: l ?? "Error while getting feedback",
      //   ),
      // );
      BotToast.closeAllLoading();
    }, (response) {
      if (response.data['ratingdetails'].toString().toLowerCase() == "null") {
        BotToast.showWidget(
          toastBuilder: (_) => SuccessDialog(
            title: "rate".tr,
            message: "youAlreadyRatedAllRide".tr,
            ontap: () {
              BotToast.cleanAll();
              Get.back();
            },
          ),
        );
      } else {
        rideId = int.parse(response.data['ratingdetails']['booking_id']);
      }
      BotToast.closeAllLoading();
    });
  }

  Future getRideDetail() async {
    print("getRideDetail $rideId");
    BotToast.showLoading();
    final result = await networkCall.postRequestWithResponse(
      url: Urls.rideDetail,
      json: {
        Params.riderId: authTo.userModel.riderid,
        Params.rideId: rideId,
      },
    );
    return result.fold((l) {
      // BotToast.showWidget(
      //   toastBuilder: (_) => SuccessDialog(
      //     title: "rate".tr,
      //     message: "youAlreadyRatedAllRide".tr,
      //     ontap: () {
      //       BotToast.cleanAll();
      //       Get.back();
      //     },
      //   ),
      // );
      BotToast.closeAllLoading();
    }, (response) {
      if (response.statusCode == 200 &&
          response.data['myridedetails'] != null) {
        ride = Ride.fromJson(response.data['myridedetails']);
        ride.carCategory = response.data['car_category'];
        imagedetails = response.data['imagedetails'];
        print("imagedetails $imagedetails");
      } else {
        BotToast.showWidget(
          toastBuilder: (_) => SuccessDialog(
            title: "rate".tr,
            message: "youAlreadyRatedAllRide".tr,
            ontap: () {
              BotToast.cleanAll();
              Get.back();
            },
          ),
        );
      }
      BotToast.closeAllLoading();
    });
  }

  Future riderFeedBack(double rating, String comment) async {
    BotToast.showLoading();
    print(
        "${ride.driverId} ${authTo.userModel.riderid} $comment ${rating.toInt()}");
    final result = await networkCall.postRequestWithResponse(
      url: Urls.feedbackride,
      json: {
        Params.riderId: authTo.userModel.riderid,
        Params.rideId: rideId,
        Params.driverId: ride.driverId,
        Params.feedback: comment,
        Params.rating: rating.toInt(),
      },
    );

    return result.fold((l) {
      // BotToast.showWidget(
      //   toastBuilder: (_) => SuccessDialog(
      //     title: "rate".tr,
      //     message: l ?? "error in rider feedbakc",
      //     ontap: () {
      //       BotToast.cleanAll();
      //       Get.back();
      //     },
      //   ),
      // );
      BotToast.closeAllLoading();
    }, (r) {
      print("respoinse ${r.data}");
      BotToast.closeAllLoading();
    });
  }
}
