<?php
addJS([
    'assets/js/views/releases.js',
]);

viewHeader(
    'Releases',
    'Versions control for milestones',
    [
        (object) ['name' => 'Dashboard', 'url' => site_url()],
        (object) ['name' => 'Projects', 'url' => site_url('projects')],
        (object) ['name' => $project->name, 'url' => getProjectUrl($project)],
        (object) ['name' => 'Releases', 'url' => ''],
    ], true);

projectMenu('releases', $project);
?>



<div class="project_releases_body n_menu">

    <div class="releases_list">

    </div>



</div>



<script>
    var project_id = <?= $project->id ?: 0; ?>;
</script>
