import {values} from "lodash";

let Utils = {
    realmToPOJO : function(realmObject) {
        return values(JSON.parse(JSON.stringify(realmObject)));
    }

  };
  
  module.exports = Utils;