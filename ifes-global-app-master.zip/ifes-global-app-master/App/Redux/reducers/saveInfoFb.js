import {

  PENDING_LOGIN_FB,
  SET_LOGIN_FB,
  SUCCESS_LOGIN_FB

} from "../actions/types";

export default function(
  state = { isLoadingData: false, isDoSearch: false, data: [], keyword: null },
  action
) {

  console.log("Log_action_LOGIN => ", action.type);

  switch (action.type) {
    case PENDING_LOGIN_FB:
      return {
        ...state,
        isLoadingData: true
      };

    case SET_LOGIN_FB:
      return { ...state, data: action.payload };

    case SUCCESS_LOGIN_FB:
      return {
        ...state,
        isLoadingData: false
      };

    default:
      return state;
  }

}
