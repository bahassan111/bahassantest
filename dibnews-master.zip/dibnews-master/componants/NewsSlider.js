import React, {Component, useState, useEffect, useRef} from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    ImageBackground,
    ActivityIndicator,
    Button, Dimensions,
    TouchableOpacity,
    Animated, AppState, SafeAreaView, ScrollView,
    BackHandler, Alert, Share, Platform
} from "react-native";


import HTMLView from 'react-native-htmlview';
import YoutubePlayer from "react-native-youtube-iframe";
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {updateData} from "../redux/actions/dataAction";
import TopHeader from "../componants/TopHeader";
import css, {sizes} from "../global/GlobalStyle";
import Carousel from 'react-native-snap-carousel';
import GestureRecognizer from 'react-native-swipe-gestures';
import Loader from "../screens/_loader";
import {AntDesign, FontAwesome5} from '@expo/vector-icons';
import news from "../data/newsDemo";
import storage from "../storage/TwStorage";
import {fetchNewsByCatData, fetchNewsData, testGetPosts, fetchArticle} from "../data/NewsData";
import NewsObject from "../data/NewsObject";
import SliderIndicator from "../componants/SliderIndicator";
import Helper from "../global/Helper";
import { Entypo, FontAwesome } from '@expo/vector-icons';
import * as Sharing from 'expo-sharing';
import {Video} from "expo-av";



const win = Dimensions.get('window');
const ofHeight = (p) => p * win.height / 100;
const ofWidth = (p) => p * win.width / 100;


function BK(props) {

    useEffect(() => {
        const backAction = () => {
            if (props.onBack) {
                props.onBack();
                return true;
            }
            return false;

        };

        const backHandler = BackHandler.addEventListener('hardwareBackPress', backAction);

        return () => backHandler.remove();
    }, []);

    return (
        <View></View>
    );
}


class NewsSlider extends Component {

    state = {
        isModalVisible: false,
        animation: new Animated.Value(0),
        news: [],
        isUp: false,
        stopInd: false,
        category: null,
        page: 1,
        loading: true,
        modal_sc : null,
        onModal : null,
    };

    rtlFixer = ()=>{
        return (<Text style={{color:'rgba(52, 52, 52, 0)'}}>ـ</Text>);
    };

    componentDidUpdate(prevProps, prevState, snapshot) {
        if(this.props.cat && this.state.category && this.props.cat.id !== this.state.category.id){
            this.init();
        }
        this.checkNotifClick();
    }


    componentDidMount() {

        this.init();
        this.setState({onModal : (this.props.onModal || function(){})});
    }

    checkNotifClick = ()=>{
        setTimeout(()=>{
            console.log('id => ');
            storage.getStorage('notif_id', 0).then(nid =>{
                nid *= 1;
                console.log('id => ', nid);

                if(nid>0){

                    storage.setStorage('notif_id', "");

                    fetchArticle(nid).then(r => {
                        if(r){
                            let article = r[0];
                            console.log('post => ', article);
                            let itm = new NewsObject(article);
                            this.news_clicked(itm);
                        }
                    })

                }

            })

        }, 1000);
    };

    init = ()=>{

        const {cat} = this.props;
        let func = fetchNewsData;

        if(cat){
            this.setState({category : cat});
            func = fetchNewsByCatData(this.props.data.language, cat.id);
        }else{
            func = fetchNewsData(this.props.data.language);
        }

        this.setState({loading:true});
        func
            .then((news) => {
                console.log('got news');
                if(news.length === 0){

                    news = [
                        {
                            nodata:true
                        }
                    ];

                }

                //news.push({end:true});

                this.setState({news: news, loading: false});
            })
            .catch(()=>{
                console.log('got err');
                this.props.err();
            })

    };

    swipedUp = (item) => {
        this.toggleModal();
    };

    render_det = () => {
        let item = this.state.news_item;


        return (
            <View>
                <View style={[css.np_body]}>

                    <View style={[css.npb_head, {minHeight : 70}]}>
                        <Text style={[css.npb_title]}><Text style={{color:'rgba(255, 255, 255, 0)', fontSize:1}}>ـ</Text>{item.title}</Text>
                        <TouchableOpacity onPress={async ()=>{


                            this.toggleModal();

                        }} style={[css.npf_btn, styles.float_share, {height : 42, width: 42, textAlign: 'center',}]}>
                            {/*<Text style={{marginRight: 12, fontSize: sizes.xs, fontWeight: 'normal'}}>Fermer</Text>*/}
                            <AntDesign name="close" size={24} color="#000"/>
                        </TouchableOpacity>
                        <TouchableOpacity onPress={async ()=>{


                            try {
                                const result = await Share.share({
                                    //title: this.state.news_item.title,
                                    message: `Lire la suite sur DIBNEWS : ${this.state.news_item.title}\r\n \r\n${this.state.news_item.web}`,
                                    url: this.state.news_item.web,
                                });

                                if (result.action === Share.sharedAction) {
                                    // Partagé
                                } else if (result.action === Share.dismissedAction) {
                                    // matpartajatch
                                }
                            } catch (error) {
                                //alert(error.message);
                            }

                        }} style={[css.npf_btn, styles.float_share2, {zIndex: 9}]}>
                            <Text style={{marginRight: 12, fontSize: sizes.xs, fontWeight: 'normal'}}>Partager</Text>
                            <FontAwesome name="share-square-o" size={24} color="black" />
                        </TouchableOpacity>
                    </View>

                    <View style={[css.npb_sub]}>
                        <Text style={[css.npb_subtitle]}>{item.date.fromNow()}</Text>
                    </View>

                    <View style={[css.npb_body]}>

                        {(() => {


                            if (item.video_type === 'youtube') {
                                return (
                                    <View style={{backgroundColor: '#000', alignItems: 'center', justifyContent: 'center',}}>
                                        <YoutubePlayer
                                            height={((1280 / 720) * ofWidth(100)) - ofHeight(10)}
                                            width={ofWidth(90)}
                                            /*style={{minHeight: (720 / 1280) * ofWidth(100)}}*/
                                            play={true}
                                            videoId={item.video_id} />
                                    </View>
                                    )
                            } else if (item.video_type === 'image') {
                                return (<Image style={{height: (ofHeight(100) / ofWidth(100)) * ofWidth(80), marginBottom: 18}} source={item.image_uri}/>)
                            }else if (item.video_type === 'local') {

                                return (
                                    <View style={{backgroundColor: '#000', alignItems: 'center', justifyContent: 'center', position:'relative'}}>
                                        <Video
                                            source={{ uri: item.video_url}}
                                            useNativeControls={true}
                                            rate={1.0}
                                            volume={1.0}
                                            isMuted={false}
                                            resizeMode="contain"
                                            shouldPlay={true}
                                            isLooping={false}
                                            style={{backgroundColor: '#000', width: ofWidth(90), height: ((1280 / 720) * ofWidth(100)) - ofHeight(10) }}
                                        />
                                    </View>
                                )
                            } else {
                                return (<HTMLView
                                    value={item.video_url}
                                    stylesheet={StyleSheet.create({})}
                                    onLinkPress={(url) => console.log('clicked link: ', url)}
                                />);
                            }


                        })()}

                        {
                            <View style={[css.npb_content_holder]}>
                                <HTMLView
                                    value={item.content}
                                    stylesheet={StyleSheet.create({})}
                                    onLinkPress={(url) => console.log('clicked link: ', url)}
                                />
                            </View>
                        }

                    </View>

                </View>
            </View>
        );
    };

    toggleModal = () => {
        if (!this.state.isModalVisible) this.setState({news_item: null});
        this.setState((prevState) => {
            Animated.spring(this.state.animation, {
                toValue: prevState.isModalVisible ? 0 : 1,
                useNativeDriver: false,
            }).start(()=>{
                if(!prevState.isModalVisible && this.state.modal_sc){

                    /*setTimeout(()=>{
                        this.state.modal_sc.scrollTo({x : 0, y: ofHeight(5), animated:true});
                        setTimeout(()=>{
                            this.state.modal_sc.scrollTo({x : 0, y: ofHeight(0), animated:true});
                        }, 400)
                    }, 400);*/
                }
            });

            this.state.onModal(!prevState.isModalVisible);


            return {
                isModalVisible: !prevState.isModalVisible,
                stopInd: prevState.isModalVisible
            }
        });


    };

    hideModal = () => {
        this.state.onModal(false);
        this.setState((prevState) => {
            Animated.spring(this.state.animation, {
                toValue: 0,
                useNativeDriver: false,
            }).start();
            return {
                isModalVisible: 0
            }
        })
    };

    renderModal = () => {
        return (
            <View><Text>a</Text></View>
        )
    };

    news_clicked = (item) => {

        this.toggleModal();

        testGetPosts().then(online => {
            console.log('testing connection ' + (online ? 'OK' : 'ERR'));
            if(!online) this.props.err();

        });

        setTimeout(() => {
            this.setState({news_item: item});
        }, 1000);


    };


    logoPressed = () => {

    };
    menuPressed = () => {
        const {navigation} = this.props;

        navigation.toggleDrawer();
    };


    _renderItem = (data, i) => {



        if('nodata' in data.item){

            return (<View style={styles.nodata}>
                <Entypo style={this.props.data.theme === 'dark' ? styles.nodata_icon_w : styles.nodata_icon} name="globe" size={42} color="black" />
                <Text style={this.props.data.theme === 'dark' ? styles.nodata_text_w : styles.nodata_text}>Aucune actualité trouvée dans cette section</Text>
            </View>)

        }

        let item = new NewsObject(data.item);


        return (

            <View style={[css.news_item]}>
                <ImageBackground style={[css.ni_bg]} source={item.image_uri}>


                    <View style={[css.ni_inner]}>
                        <TouchableOpacity style={[css.ni_inner_tc]} onPress={() => {
                            this.news_clicked(item)
                        }}>
                            <View style={[css.ni_tags]}>
                                <Text style={[css.ni_tag]}>{item.category}</Text>
                            </View>
                            <View style={[css.ni_title_holder]}>
                                <Text style={[css.ni_title]}><Text style={{color:'rgba(255, 255, 255, 0)', fontSize:1}}>ـ</Text>{item.title}</Text>
                            </View>
                            <View style={[css.ni_foot]}>
                                <Text style={[css.ni_foot_txt]}>{item.date.format('DD MMMM YYYY')}</Text>
                            </View>
                        </TouchableOpacity>
                    </View>


                </ImageBackground>
            </View>


        );

    };
    _itemWillShow = (index, b) => {

        //console.log('snappped to ', index);

    };
    _onLayout = (v, i) => {

    };


    render() {

        return (

            <View>

                {
                    (this.state.loading) ? (<View style={{marginTop : ofHeight(15), textAlign: 'center'}}><Loader/><Text style={{textAlign:'center',}}>Chargement des vidéos ..</Text></View>) : (
                        <View>
                            <Carousel
                                onLayout={this._onLayout}
                                onSnapToItem={this._itemWillShow}
                                activeAnimationOptions={null}
                                onPress={this.onPress}
                                layout={'default'} layoutCardOffset={2}
                                ref={(c) => {
                                    this._carousel = c;
                                }}
                                data={this.state.news}
                                renderItem={this._renderItem}
                                sliderWidth={ofWidth(100)}
                                itemWidth={ofWidth(100)}
                            />


                            <Animated.View style={[css.modal, {
                                top: this.state.animation.interpolate({
                                    inputRange: [0, 1],
                                    outputRange: [ofHeight(120), 0]
                                })
                            }]}>
                                <View style={css.modal_inside} onPress={this.hideModal}>

                                    <TouchableOpacity style={[css.modal_shadow]} onPress={this.hideModal}/>
                                    <ScrollView ref={ref => {this.setState({modal_sc : ref})}} style={[css.np_inner]}>
                                        <View
                                            style={[css.np_sc, (this.state.news_item && this.state.isModalVisible) ? {} : css.np_sc_l]}>
                                            <BK onBack={() => {
                                                if (this.state.isModalVisible) {
                                                    this.hideModal();
                                                } else {

                                                }

                                            }}/>
                                            {
                                                (this.state.news_item && this.state.isModalVisible) ? (this.render_det()) : (
                                                    <Loader/>)
                                            }
                                        </View>


                                        {
                                            !(false && (this.state.news_item && this.state.isModalVisible)) ? (null) : (
                                                <View>
                                                    <View style={[css.np_footer]}>

                                                    </View>
                                                    <View style={[css.np_ac]}>
                                                        <TouchableOpacity onPress={this.hideModal}
                                                                          style={[css.np_ac_btn]}>
                                                            <Text style={[css.np_ac_txt]}>Fermer</Text>
                                                            <AntDesign style={[css.np_ac_icon]} name="closecircle"
                                                                       size={42} color="white"/>
                                                        </TouchableOpacity>
                                                    </View>
                                                </View>


                                            )
                                        }
                                    </ScrollView>


                                </View>
                            </Animated.View>
                        </View>
                    )
                }


                {
                    (this.state.isUp) ?
                        (this.renderModal()) :
                        (null)
                }

            </View>

        );
    }

}

const styles = StyleSheet.create({

    float_share: {
        position: 'absolute',
        right:0,
        top: 0,
        padding: 4,
    },
    float_share2: {
        position: 'absolute',
        right:0,
        top: 42,
        padding: 4,
        paddingRight: 14,
    },
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    box: {
        backgroundColor: '#61dafb',
        width: 80,
        height: 80,
        borderRadius: 4,
    },

    nodata: {
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 120
    },
    nodata_text: {
        color: '#494949',
    },
    nodata_icon: {
        color : '#585858',
        marginBottom: 32,
    },
    nodata_text_w: {
        color: '#dedede',
    },
    nodata_icon_w: {
        color : '#f6f6f6',
        marginBottom: 32,
    },

});

const mapDispatchToProps = dispatch => (
    bindActionCreators({
        updateData: updateData,
    }, dispatch)
);

const mapStateToProps = (state) => {
    const {data} = state;
    return {data}
};

export default connect(mapStateToProps, mapDispatchToProps)(NewsSlider);
