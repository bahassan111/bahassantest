import 'package:bot_toast/bot_toast.dart';
import 'package:driver/controllers/auth_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:driver/ui/components/components.dart';

class CustomeAlertDoaligWithTwoOption extends StatelessWidget {
  const CustomeAlertDoaligWithTwoOption({Key key, this.message, this.title})
      : super(key: key);
  final String title;
  final String message;
  static AuthController to = Get.find();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(title,
          style: Theme.of(context).textTheme.headline2.copyWith(fontSize: 18)),
      content: Text(message,
          style: Theme.of(context).textTheme.headline2.copyWith(fontSize: 16)),
      actions: [
        Align(
          alignment: Alignment.center,
          child: Container(
            padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
            width: 100,
            child: RoundButton(
              onTap: () async {
                bool isSuccess = await to.logoutFromOtherDevices(
                  email: to.emailController.text.trim(),
                  password: to.passwordController.text.trim(),
                );
                if (isSuccess) {
                  await to.signIn(
                    email: to.emailController.text.trim(),
                    password: to.passwordController.text.trim(),
                  );
                }
                BotToast.cleanAll();
              },
              text: "ok".tr,
            ),
          ),
        ),
        Align(
          alignment: Alignment.center,
          child: Container(
            padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
            width: 100,
            child: RoundButton(
              onTap: () {
                BotToast.cleanAll();
              },
              text: "cancel".tr,
            ),
          ),
        )
      ],
    );
  }
}
