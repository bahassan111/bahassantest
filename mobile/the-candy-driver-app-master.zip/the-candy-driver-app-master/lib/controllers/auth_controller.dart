import 'dart:convert';
import 'dart:io';
import 'package:bot_toast/bot_toast.dart';
import 'package:device_info/device_info.dart';
import 'package:driver/constants/helpers/helpers.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:dio/dio.dart' as dio;
import 'package:image_picker/image_picker.dart';

import 'package:driver/constants/constants.dart';
import 'package:driver/models/models.dart';
import 'package:driver/ui/components/components.dart';

import 'controllers.dart';

class AuthController extends GetxController {
  static AuthController to = Get.find();
  static HomeController homeTo = Get.find();
  static PreBookingController preTo = Get.find();

  String currency;
  UserModel userModel;
  NetWorkCall netWorkCall = NetWorkCall();
  Validator validator = Validator();
  final store = GetStorage();
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging();
  static final DeviceInfoPlugin deviceInfoPlugin = DeviceInfoPlugin();

  List<CountryModel> countries = [];
  List<VehicleCategorytype> vehiclecategories = [];
  List<VehicleType> vehicleType = [];
  List<Fleet> fleets = [];
  List<String> colors = [
    "White",
    "Black",
    "Grey",
    "Silver",
    "Red",
    "Blue",
    "Brown",
    "Green",
    "Beige",
    "Orange",
    "Gold",
    "Yellow",
    "Purple",
  ];

  String deviceId;
  int deviceType;
  String tokenId;

  Fleet selectedFleet;

  TextEditingController fnameController = TextEditingController();
  TextEditingController lnameController = TextEditingController();
  TextEditingController stateController = TextEditingController();
  TextEditingController postCodeController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController personalMobileNumberController =
      TextEditingController();
  CountryModel selectedCountry;
  DateTime drivingLicenseExp;
  DateTime vocationalLicenseExp;
  PickedFile userProfileImg;
  PickedFile drivingLicenseImg;
  PickedFile vocationalLicenseImg;

  TextEditingController plateNumberController = TextEditingController();
  VehicleType selectedVehicleType;
  VehicleCategorytype selectedVehicleCategorytype;
  PickedFile vehicleInsuranceImg;
  PickedFile vehiclePermitImg;
  DateTime yearOfReg;
  DateTime insuranceExp;
  DateTime permitExp;
  TextEditingController vehicleModelController = TextEditingController();
  String selectedColor;

  TextEditingController bankNameController = TextEditingController();
  TextEditingController accoutNameController = TextEditingController();
  TextEditingController accountNumberController = TextEditingController();

  TextEditingController contactPersonNameController = TextEditingController();
  TextEditingController emergencyMobileNumberController =
      TextEditingController();
  TextEditingController alternateNumberController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();

  bool isTermAndConditionAccept = false;

  @override
  void onReady() {
    getUserFromLocalStore();
    initPlatformState();
    notificationInit();
    getCountries();
    getVehicleCategory();
    getFleets();
   
    super.onReady();
  }

  getUserFromLocalStore() async {
    if (store.hasData('user')) {
      userModel = UserModel.fromJson(await store.read('user'));
      final isBlock = await driverBlockCheck();
      print("isBlock $isBlock");
      if (isBlock != null) {
        BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
            title: "error".tr,
            message: isBlock,
          ),
        );
        await logout();
        return;
      }
      Future.delayed(Duration(seconds: 3));
        preTo.showNotif();
      Get.offAndToNamed('/HomeUI');
      print("driver id : ${userModel.id}, fleety id: ${userModel.fleetid}");
      if (store.hasData("current_ride")) {
        print(
            "current_ride ${store.hasData("current_ride")} ${store.read("current_ride")} ");

        homeTo.rideDetail =
            RideDetailModel.fromJson(json.decode(store.read("current_ride")));

        print("ride status ${homeTo.rideDetail.rideStatus}");
        print("ride arrivaltime ${homeTo.rideDetail.driverArrivaltime}");

        if (homeTo.rideDetail.rideStatus == "1" &&
            homeTo.rideDetail.driverArrivaltime == null) {
          homeTo.homeScreenStatus.value = HomeScreenStatus.Procced;
        } else if (homeTo.rideDetail.rideStatus == "1" &&
            homeTo.rideDetail.driverArrivaltime != null) {
          homeTo.homeScreenStatus.value = HomeScreenStatus.IhaveArrived;
        } else if (homeTo.rideDetail.rideStatus == "3") {
          homeTo.startCountingCharterTime();
          homeTo.homeScreenStatus.value = HomeScreenStatus.StartTrip;
        }
      }
    } else {
      Get.offAndToNamed('/IntroUI');
    }
  }

  signIn({String email, String password}) async {
    BotToast.showLoading();

    final result = await netWorkCall.postRequestWithResponse(
      url: Urls.login,
      json: {
        Params.username: email,
        Params.password: password,
        Params.deviceId: deviceId,
        Params.deviceType: deviceType,
        Params.tokenId: tokenId,
      },
    );
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return;
    }, (response) async {
      if (response == null) {
        BotToast.showWidget(
            toastBuilder: (_) => ErrorDialog(
                  title: "Error".tr,
                  message: "unexcpected error occured",
                ));
        BotToast.closeAllLoading();
        return;
      }
      if (response.data['responsecode'] != 1) {
        if (response.data['response'] == "Password does not match" ||
            response.data['response'] == "Email id is not valid" ||
            response.data['response'] == "Your accout is not verified" ||
            response.data['response'] ==
                "You have been blocked either for document expired or any other reason for more details contact info@thecandytech.com") {
          BotToast.showWidget(
            toastBuilder: (_) => ErrorDialog(
              title: "alert".tr,
              message: response.data['response'],
            ),
          );
        } else {
          BotToast.showWidget(
            toastBuilder: (_) => CustomeAlertDoaligWithTwoOption(
              title: "alert".tr,
              message: "logout_all_other_device".tr,
            ),
          );
        }
      } else {
        userModel = UserModel.fromJson(response.data['alldetail'][0]);
        await store.write('user', userModel.toJson());
        getCurrency(int.tryParse(userModel.country));
        homeTo.changeDriverOnlineStatus(status: true);

        Get.offAllNamed('/HomeUI');
      }
      BotToast.closeAllLoading();
    });
  }

  Future logoutFromOtherDevices({String email, String password}) async {
    BotToast.showLoading();
    final result = await netWorkCall.postRequestWithResponse(
      url: Urls.driverUninstallapp,
      json: {
        Params.username: email,
        Params.password: password,
      },
    );
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return false;
    }, (response) {
      if (response.data['responsecode'] != 1) {
        BotToast.showWidget(
          toastBuilder: (_) => CustomeAlertDoaligWithTwoOption(
            title: "alert".tr,
            message: "fail_logout_all_other_device".tr,
          ),
        );
        return false;
      }
      BotToast.closeAllLoading();
      return true;
    });
  }

  Future driverBlockCheck() async {
    print("to.userModel.id ${to.userModel.id}");
    final result = await netWorkCall.postRequestWithResponse(
      url: Urls.driverBlockCheck,
      json: {
        Params.driverId: to.userModel.id,
      },
    );
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return;
    }, (response) {
      if (response?.statusCode == 200) {
        if (response.data['responsecode'] == 1) {
          return response.data['response'];
        }
      }
      return;
    });
  }

  Future getCurrency(int countryId) async {
    print("countryId $countryId");
    final result = await netWorkCall.postRequestWithResponse(
      url: Urls.currency,
      json: {
        Params.countryId: countryId,
      },
    );
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return;
    }, (response) async {
      if (response?.statusCode == 200) {
        await store.write('currency', response.data['currency']);
        currency = response.data['currency'];
      }
    });
  }

  singUp() async {
    BotToast.showLoading();
    dio.MultipartFile userProfile;
    dio.MultipartFile drivingLicense;
    dio.MultipartFile vocationalLicense;
    dio.MultipartFile vehicleInsurance;
    dio.MultipartFile vehiclePermit;
    if (userProfileImg != null) {
      print(
          "getFileName(userProfileImg.path ${getFileName(userProfileImg.path)}");
      userProfile = await dio.MultipartFile.fromFile(
        userProfileImg.path,
        filename: getFileName(userProfileImg.path),
      ).onError((error, stackTrace) {
        print("image read issue $error");
        print("image stack $stackTrace");
        return;
      });
    }
    if (drivingLicenseImg != null) {
      drivingLicense = await dio.MultipartFile.fromFile(drivingLicenseImg.path,
          filename: getFileName(drivingLicenseImg.path));
    }
    if (vocationalLicenseImg != null) {
      vocationalLicense = await dio.MultipartFile.fromFile(
          vocationalLicenseImg.path,
          filename: getFileName(vocationalLicenseImg.path));
    }

    if (vehicleInsuranceImg != null) {
      vehicleInsurance = await dio.MultipartFile.fromFile(
        vehicleInsuranceImg.path,
        filename: getFileName(vehicleInsuranceImg.path),
      );
    }

    if (vehiclePermitImg != null) {
      vehiclePermit = await dio.MultipartFile.fromFile(vehiclePermitImg.path,
          filename: getFileName(vehiclePermitImg.path));
    }
    print("selectedCountry ${selectedCountry.id}");
    Map<String, dynamic> jsonData = {
      if (userModel != null) Params.driverId: userModel.id,
      Params.fleetId: selectedFleet.id,
      Params.userImage: userProfile,
      Params.fname: fnameController.text.trim(),
      Params.lname: lnameController.text.trim(),
      if (userModel == null) Params.country: selectedCountry.id,
      if (userModel != null) Params.countryId: selectedCountry.id,
      Params.currency: currency,
      Params.state: stateController.text.trim(),
      Params.postcode: postCodeController.text.trim(),
      Params.address: addressController.text.trim(),
      Params.email: emailController.text.trim(),
      Params.mobileNo: personalMobileNumberController.text.trim(),
      if (userModel == null) Params.drivingLicense: drivingLicense,
      if (userModel == null)
        Params.drivingLicenseExpiry: formateDateToYYYYMMDD(drivingLicenseExp),
      if (userModel == null) Params.vocationalLi: vocationalLicense,
      if (userModel == null)
        Params.vocationalLicenseExpiry:
            formateDateToYYYYMMDD(vocationalLicenseExp),
      Params.plateNo: plateNumberController.text.trim(),
      // following are swap but its true for back end
      Params.vehicleType: selectedVehicleCategorytype.id,
      Params.vehicleCategory: selectedVehicleType.id,
      Params.yearOfRreg: yearOfReg.year, //formateDateToYYYYMMDD(yearOfReg),
      if (userModel == null) Params.insurance: vehicleInsurance,
      if (userModel == null)
        Params.vehicleInsuranceExpiry: formateDateToYYYYMMDD(insuranceExp),
      if (userModel == null) Params.permit: vehiclePermit,
      if (userModel == null)
        Params.vehiclePermitExpiry: formateDateToYYYYMMDD(permitExp),
      Params.bankName: bankNameController.text.trim(),
      Params.acName: accoutNameController.text.trim(),
      Params.aNo: accountNumberController.text.trim(),
      Params.emgContact: emergencyMobileNumberController.text.trim(),
      Params.emgPerson: contactPersonNameController.text.trim(),
      Params.altEmgContact: alternateNumberController.text.trim(),
      Params.vehicleModel: vehicleModelController.text.trim(),
      Params.vehicleColor: selectedColor,
      if (userModel == null) Params.password: passwordController.text.trim(),
      if (userModel == null)
        Params.confirmPassword: confirmPasswordController.text.trim(),
      Params.deviceId: deviceId,
      Params.deviceType: deviceType,
    };
    print("json $jsonData");
    if (userModel == null) {
      final result = await netWorkCall.postRequestUsingFormData(
        url: Urls.driverProfile,
        data: dio.FormData.fromMap(jsonData),
      );
      result.fold((l) {
        BotToast.showWidget(
            toastBuilder: (_) => ErrorDialog(
                  title: "Error".tr,
                  message: l ?? "unexcpected error occured",
                ));
        BotToast.closeAllLoading();
        return;
      }, (response) {
        print("response ${response.responsecode} ${response.response}");
        BotToast.closeAllLoading();
        if (response.responsecode == 0) {
          BotToast.showWidget(
            toastBuilder: (_) => ErrorDialog(
              title: "error".tr,
              message: response.response,
            ),
          );
        } else {
          clearSignUpForm();
          BotToast.showWidget(
            toastBuilder: (_) => SuccessDialog(
              title: "success".tr,
              message: response.response,
              ontap: () {
                BotToast.cleanAll();
                Get.offAllNamed('/LoginUI');
              },
            ),
          );
        }
      });
    } else {
      print("update");
      final result = await netWorkCall.postRequestWithResponse(
        url: Urls.driverUpdateprofile,
        json: jsonData,
      );
      result.fold((l) {
        BotToast.showWidget(
            toastBuilder: (_) => ErrorDialog(
                  title: "Error".tr,
                  message: l ?? "unexcpected error occured",
                ));
        BotToast.closeAllLoading();
        return;
      }, (response) async {
        BotToast.closeAllLoading();
        print("response.data $response");
        if (response.data['responsecode'] == 1) {
          userModel.firstname = fnameController.text.trim();
          userModel.lastname = lnameController.text.trim();
          userModel.fleetid = selectedFleet.id;
          userModel.address = addressController.text.trim();
          userModel.postcode = postCodeController.text.trim();
          userModel.state = stateController.text.trim();
          userModel.country = selectedCountry.id;
          userModel.mobile = personalMobileNumberController.text.trim();

          userModel.email = emailController.text.trim();
          userModel.plateNo = plateNumberController.text.trim();
          userModel.carcategory = selectedVehicleCategorytype.name;
          userModel.vehicletype = selectedVehicleType.categoryName;
          userModel.yearofreg = yearOfReg.year.toString();

          userModel.bankname = bankNameController.text.trim();
          userModel.accountname = accoutNameController.text.trim();
          userModel.accountno = accountNumberController.text.trim();
          userModel.emergencypserson = contactPersonNameController.text.trim();
          userModel.alternateEmgNum = alternateNumberController.text.trim();
          userModel.emergencycontact =
              emergencyMobileNumberController.text.trim();
          userModel.currency = currency;
          await store.write('user', userModel.toJson());

          BotToast.showWidget(
            toastBuilder: (_) => ErrorDialog(
              title: "success".tr,
              message: "profile_updated".tr,
              ontap: () {
                BotToast.cleanAll();
                logout();
              },
            ),
          );
        } else {
          BotToast.showWidget(
            toastBuilder: (_) => ErrorDialog(
              title: "error".tr,
              message: response.data,
            ),
          );
        }
      });
    }
  }

  logout() async {
    BotToast.showLoading();
    store.erase();
    final result = await netWorkCall.postRequest(
      url: Urls.logout,
      json: {
        Params.id: int.tryParse(userModel.id),
      },
    );
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return;
    }, (responseModel) async {
      await homeTo.changeDriverOnlineStatus(status: false);
      print(
          "responseModel ${responseModel.responsecode} ${responseModel.response}");
      userModel = null;
      BotToast.closeAllLoading();
      Get.offAllNamed('/IntroUI');
    });
  }

  forgotPassword(String email) async {
    BotToast.showLoading();
    final result = await netWorkCall.postRequest(
      url: Urls.forgotPassword,
      json: {
        Params.email: email,
      },
    );
    result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return;
    }, (response) {
      BotToast.closeAllLoading();
      if (response.responsecode == 0) {
        BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
            title: "error".tr,
            message: response.response,
          ),
        );
      } else {
        BotToast.showWidget(
          toastBuilder: (_) => SuccessDialog(
            message: "password_send".tr,
            ontap: () {
              BotToast.cleanAll();
              Get.back();
            },
          ),
        );
        BotToast.showText(text: response.response);
        Get.back();
      }
    });
  }

  getCountries() async {
    final result = await netWorkCall.getRequest(url: Urls.country);
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return [];
    }, (response) {
      if (response != null) {
        final data = response.data;
        data['countries'].forEach((e) {
          countries.add(CountryModel.fromJson(e));
        });
      }
      return countries;
    });
  }

  getFleets() async {
    final result = await netWorkCall.getRequest(url: Urls.getFleet);
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return [];
    }, (response) {
      if (response != null) {
        final data = response.data;
        data['fleet'].forEach((e) {
          fleets.add(Fleet.fromJson(e));
        });
      }
      return fleets;
    });
  }

  getVehicleCategory() async {
    final result = await netWorkCall.getRequest(url: Urls.vehicleCategory);
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return [];
    }, (response) {
      if (response != null) {
        final data = response.data;
        data['response'].forEach((e) {
          vehiclecategories.add(VehicleCategorytype.fromJson(e));
        });
      }
      return vehiclecategories;
    });
  }

  Future getVehicleType(int id) async {
    final result = await netWorkCall.postRequestWithResponse(
      url: Urls.vehicleSubtype,
      json: {Params.id: id},
    );
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return [];
    }, (response) {
      if (response != null) {
        final data = response.data;
        data['response'].forEach((e) {
          vehicleType.add(VehicleType.fromJson(e));
        });
      }
      return vehicleType;
    });
  }

  Future<void> initPlatformState() async {
    try {
      if (Platform.isAndroid) {
        final androidInfo = await deviceInfoPlugin.androidInfo;
        deviceId = androidInfo.androidId;
        deviceType = 1;
      } else if (Platform.isIOS) {
        final iosInfo = await deviceInfoPlugin.iosInfo;
        deviceId = iosInfo.identifierForVendor;
        deviceType = 2;
      }
    } on PlatformException {
      print("device id not found");
    }
  }

  Future<void> notificationInit() async {
    await Firebase.initializeApp();

    var initializationSettingsAndroid =
        AndroidInitializationSettings('app_icon');
    var initializationSettingsIOS = IOSInitializationSettings();
    var initializationSettings = InitializationSettings(
      iOS: initializationSettingsIOS,
      android: initializationSettingsAndroid,
    );
    flutterLocalNotificationsPlugin.initialize(initializationSettings,
        onSelectNotification: onSelectNotification);

    _firebaseMessaging.configure(
      onBackgroundMessage:
          Platform.isAndroid ? myBackgroundMessageHandler : null,
      onMessage: (Map<String, dynamic> message) async {
        print("onMessage: $message");
        homeTo.getTrip();
           showNotificationWithDefaultSound(message, );
      },
      onLaunch: (Map<String, dynamic> message) async {
        print("onLaunch: $message");
        homeTo.getTrip();
        showNotificationWithDefaultSound(message );
      },
      onResume: (Map<String, dynamic> message) async {
        print("onResume: $message");
        homeTo.getTrip();
      },
    );
    _firebaseMessaging.requestNotificationPermissions(
        const IosNotificationSettings(
            sound: true, badge: true, alert: true, provisional: true));
    _firebaseMessaging.onIosSettingsRegistered
        .listen((IosNotificationSettings settings) {
      print("Settings registered: $settings");
    });
    await _firebaseMessaging.requestNotificationPermissions();
    tokenId = await _firebaseMessaging.getToken();
    print("tokenId $tokenId");
  }

  Future<dynamic> onSelectNotification(String payload) async {
    print("click $payload");
    homeTo.getTrip();
  }

  clearSignUpForm() {
    selectedFleet = null;
    userProfileImg = null;
    fnameController.clear();
    lnameController.clear();
    selectedCountry = null;
    currency = null;
    stateController.clear();
    postCodeController.clear();
    addressController.clear();
    emailController.clear();
    personalMobileNumberController.clear();
    drivingLicenseImg = null;
    drivingLicenseExp = null;
    vocationalLicenseImg = null;
    vocationalLicenseExp = null;

    plateNumberController.clear();
    selectedVehicleCategorytype = null;
    selectedVehicleType = null;
    yearOfReg = null;
    vehicleInsuranceImg = null;
    insuranceExp = null;
    permitExp = null;
    vehiclePermitImg = null;

    bankNameController.clear();
    accountNumberController.clear();
    accoutNameController.clear();

    emergencyMobileNumberController.clear();
    contactPersonNameController.clear();
    alternateNumberController.clear();
    passwordController.clear();
    confirmPasswordController.clear();

    isTermAndConditionAccept = false;
  }
}
