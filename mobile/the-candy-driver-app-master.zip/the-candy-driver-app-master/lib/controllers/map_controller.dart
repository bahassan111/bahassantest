import 'dart:async';

import 'package:bot_toast/bot_toast.dart';
import 'package:driver/constants/constants.dart';
import 'package:driver/constants/helpers/helpers.dart';
import 'package:driver/models/models.dart';
import 'package:driver/ui/components/components.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import "package:latlong/latlong.dart";
import 'controllers.dart';
import 'package:dio/dio.dart' as dio;

class MyMapController extends GetxController {
  static MyMapController to = Get.find();
  static HomeController homeTo = Get.find();
  static AuthController authTo = Get.find();

  NetWorkCall netWorkCall = NetWorkCall();
  MapMatchingModel mapMatchingModel;
  //RouteDetailModel routeDetail;
  ValueNotifier<RouteDetailModel> routeDetail =
      ValueNotifier(RouteDetailModel());
  final databaseRef =
      FirebaseDatabase.instance.reference(); //database reference object
  List<OnlineDrivesModel> onlineDrivers = [];

  Future getAllDriverFromFirebase() async {
    final data = await databaseRef.once();
    print("all drivers ${data.value.runtimeType} ${data.value} ");
    print("list ${data.value.keys.toList()}");
    onlineDrivers.clear();

    // databaseRef.onValue.listen((event) {
    //   Map data = event.snapshot.value;

    // });
    data.value.keys.toList().forEach((e) {
      print("${authTo.userModel.id != e} ${authTo.userModel.id} $e");
      if (authTo.userModel.id != e) {
        onlineDrivers.add(OnlineDrivesModel.fromJson(data.value[e]));
        if (authTo.userModel.fleetid != onlineDrivers.last.fleetId) {
          onlineDrivers.removeLast();
        }
      }
    });
  }

  // following function will call basic route for path
  Future getRouteBetweenPath() async {
    if (homeTo.currentLocation == null) {
      Position position = await Geolocator.getCurrentPosition();

      homeTo.currentLocation = LatLng(position.latitude, position.longitude);
    }
    String pickAndDropPins =
        '${homeTo.currentLocation.longitude},${homeTo.currentLocation.latitude};${homeTo.rideDetail.pickuplong},${homeTo.rideDetail.pickuplat};${homeTo.rideDetail.droplong},${homeTo.rideDetail.droplat}';
    String directionUrl = Urls.getNavigationUrl(pickAndDropPins);
    print("url $directionUrl");
    final result = await netWorkCall.getRequest(
      url: directionUrl,
    );
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
    }, (response) async {
      if (response?.statusCode == 200) {
        if (routeDetail == null) {
          routeDetail = ValueNotifier(RouteDetailModel.fromJson(response.data));
        }
        routeDetail.value = RouteDetailModel.fromJson(response.data);

        if (routeDetail.value.code == "Ok") {
          // print("get path ${routeDetail.routes.first.legs.length}");
          await getMapMatchingPoints();
        } else {
          pathNotFound();
        }
      } else {
        pathNotFound();
      }
    });
  }

  // this method will get detail points of path
  Future getMapMatchingPoints() async {
    String points = '';
    List<MapMatchingModel> allMapMatching = [];
    // it 100 is limit to pass points, so to make api will not break set to 90
    int i = 0;

    for (int leg = 0; leg < routeDetail.value.routes.first.legs.length; leg++) {
      for (int step = 0;
          step < routeDetail.value.routes.first.legs[leg].steps.length;
          step++) {
        for (int intersection = 0;
            intersection <
                routeDetail.value.routes.first.legs[leg].steps[step]
                    .intersections.length;
            intersection++) {
          if (i < 90) {
            points +=
                '${routeDetail.value.routes.first.legs[leg].steps[step].intersections[intersection].location.first},${routeDetail.value.routes.first.legs[leg].steps[step].intersections[intersection].location.last};';
          } else {
            i = 0;
            points +=
                '${routeDetail.value.routes.first.legs[leg].steps[step].intersections[intersection].location.first},${routeDetail.value.routes.first.legs[leg].steps[step].intersections[intersection].location.last}';
            MapMatchingModel model = await getMapMatchingBetweenPoints(points);
            points = "";
            if (model != null) {
              allMapMatching.add(model);
            }
          }
          i++;
        }
      }
    }
    points += '${homeTo.rideDetail.droplong},${homeTo.rideDetail.droplat}';
    MapMatchingModel model = await getMapMatchingBetweenPoints(points);
    if (model != null) {
      allMapMatching.add(model);
    }

    mapMatchingModel = null;
    print("allMapMatching ${allMapMatching.length}");
    allMapMatching.forEach((element) {
      if (mapMatchingModel == null) {
        mapMatchingModel = element;
      } else {
        mapMatchingModel.matchings.first.geometry.coordinates
            .addAll(element.matchings.first.geometry.coordinates);
        mapMatchingModel.matchings.first.duration +=
            element.matchings.first.duration;
        mapMatchingModel.matchings.first.distance +=
            element.matchings.first.distance;
      }
    });

    /* String points = '';
    // it 100 is limit to pass points, so to make api will not break set to 90
    int i = 0;

    routeDetail.value.routes.first.legs.forEach((leg) {
      leg.steps.forEach((step) {
        step.intersections.forEach((inter) {
          if (i < 90) {
            points += '${inter.location.first},${inter.location.last};';
          }
          i++;
        });
      });
    });
    points += '${homeTo.rideDetail.droplong},${homeTo.rideDetail.droplat}';

    //  print("total poins $i object $points");
    String mapMatchingUrl = Urls.getMapMatchingUrl(points);
    print("mapMatchingUrl $mapMatchingUrl");
    dio.Response response = await NetWorkCall.getRequest(
      url: mapMatchingUrl,
    );
    print("response?.statusCode ${response?.statusCode}");
    print("response.data ${response.data}");

    if (response?.statusCode == 200) {
      if (response.data['code'] == "NoMatch") {
        pathNotFound();
      } else if (routeDetail.value.code == "Ok") {
        mapMatchingModel = MapMatchingModel.fromJson(response.data);
        // print("cordinates ${mapMatchingModel.matchings.first.geometry.coordinates}");
      } else {
        pathNotFound();
      }
    } else {
      pathNotFound();
    }*/
  }

  getMapMatchingBetweenPoints(String points) async {
    String mapMatchingUrl = Urls.getMapMatchingUrl(points);

    MapMatchingModel matchingModel;
    final result = await netWorkCall.getRequest(
      url: mapMatchingUrl,
    );
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
    }, (response) {
      print("response?.statusCode ${response?.statusCode}");
      print("response.data ${response?.data}");

      if (response?.statusCode == 200) {
        if (response.data['code'] == "NoMatch") {
          pathNotFound();
        } else if (routeDetail.value.code == "Ok") {
          matchingModel = MapMatchingModel.fromJson(response.data);
          return matchingModel;
          // print("cordinates ${mapMatchingModel.matchings.first.geometry.coordinates}");
        } else {
          pathNotFound();
        }
      } else {
        pathNotFound();
      }
    });
  }

  pathNotFound() {
    BotToast.showWidget(
      toastBuilder: (_) => ErrorDialog(
        title: "error".tr,
        message: "weDoNotHaveRideForSelectedLocation".tr,
      ),
    );
  }
}
