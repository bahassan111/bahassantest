import React, { Component } from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    ImageBackground,
    ActivityIndicator,
    ScrollView, SafeAreaView, Dimensions, TouchableOpacity
} from "react-native";
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {updateData} from "../redux/actions/dataAction";
import {sizes, colors} from "../global/GlobalStyle";
import TwButton from "../componants/TwButton";
import { AntDesign } from '@expo/vector-icons';
import { CommonActions } from '@react-navigation/native';
import i18n from 'i18n-js';
const win = Dimensions.get('window');
const ofHeight = (p)=> p * win.height / 100;
const ofWidth = (p)=> p * win.width / 100;

class setupScreen extends Component {

    state = {
        step : 1,
        step_text : i18n.t('start_btn'),
        language : this.props.data.language,
        layout : this.props.data.layout,
        theme : this.props.data.theme,
    };

    componentDidMount() {

    }

    goNext = ()=>{
        const { navigation } = this.props;

        navigation.dispatch(
            CommonActions.reset({
                index: 1,
                routes: [
                    { name: 'main' },
                ],
            })
        );
    };



    nextStep = (back) => {
        let {step, step_text} = this.state;

        if(back && step > 1) step--;
        else step++;

        switch (step) {
            case 1 :
                step_text = i18n.t('start_btn');
                break;
            case 2 :
                step_text = i18n.t('save_language');
                break;
            case 9 :
                step_text = i18n.t('save_layout');
                break;
            case 3 :
                step_text = i18n.t('finish_btn');
                break;
            case 4 :
                setTimeout(()=>{
                    this.goNext();
                }, 2000);
                step_text = i18n.t('finish_btn');
                break;
        }

        this.setState({step, step_text});

    };

    _changeLanguage = (lang)=>{

        let data = this.props.data;
        data.language = lang;
        this.props.updateData(data);
        i18n.locale = lang;
        this.setState({language : lang});

    };

    _changeLayout = (layout)=>{

        let data = this.props.data;
        data.layout = layout;
        this.props.updateData(data);
        this.setState({layout : layout});

    };

    _changeTheme = (theme)=>{

        let data = this.props.data;
        data.theme = theme;
        this.props.updateData(data);
        this.setState({theme : theme});

    };


    render() {
        return (

            <View style={styles.whole}>
                <ImageBackground source={require('../assets/state-shape-bg.png')} style={styles.bg}>

                    <ScrollView style={styles.scroll}>

                        <SafeAreaView style={styles.sc}>
                            {/*Welcome*/}
                            {(this.state.step !== 1) ? (null) : (
                                <View style={styles.upper}>
                                    <View style={styles.top_part}>
                                        <Image style={styles.logo} source={require('../assets/full_logo.jpg')}/>
                                        <Text style={styles.tp_title}>{i18n.t('welcome_title')}</Text>
                                        <Text style={styles.tp_text}>{i18n.t('welcome_text')}</Text>
                                    </View>

                                </View>
                            )}

                            {/*Language*/}
                            {(this.state.step !== 2) ? (null) : (
                                <View style={styles.upper}>
                                    <View style={styles.top_part}>
                                        <Text style={[styles.tp_text, {marginBottom: 18,}]}>{i18n.t('select_your_language')} :</Text>


                                        <TouchableOpacity onPress={()=>{this._changeLanguage('fr')}} style={[styles.row_sel, this.state.language === 'fr' ? styles.row_sel_a : {}]}>
                                            <View style={[styles.row_sel_icon]}>
                                                <AntDesign name={this.state.language === 'fr' ? 'checkcircle' : 'checkcircleo'} size={24} color="black" />
                                            </View>
                                            <View style={[styles.row_sel_detail]}>
                                                <Text style={[styles.row_sel_text]}>Français</Text>
                                            </View>
                                        </TouchableOpacity>

                                        <TouchableOpacity onPress={()=>{this._changeLanguage('ar')}} style={[styles.row_sel, this.state.language === 'ar' ? styles.row_sel_a : {}]}>
                                            <View style={[styles.row_sel_icon]}>
                                                <AntDesign name={this.state.language === 'ar' ? 'checkcircle' : 'checkcircleo'} size={24} color="black" />
                                            </View>
                                            <View style={[styles.row_sel_detail]}>
                                                <Text style={[styles.row_sel_text]}>Arabe (عربية)</Text>
                                            </View>
                                        </TouchableOpacity>

                                        <TouchableOpacity onPress={()=>{this._changeLanguage('en')}} style={[styles.row_sel, this.state.language === 'en' ? styles.row_sel_a : {}]}>
                                            <View style={[styles.row_sel_icon]}>
                                                <AntDesign name={this.state.language === 'en' ? 'checkcircle' : 'checkcircleo'} size={24} color="black" />
                                            </View>
                                            <View style={[styles.row_sel_detail]}>
                                                <Text style={[styles.row_sel_text]}>Anglais (English)</Text>
                                            </View>
                                        </TouchableOpacity>


                                    </View>

                                </View>
                            )}
                            {(this.state.step !== 9) ? (null) : (
                                <View style={styles.upper}>
                                    <View style={styles.top_part}>
                                        <Text style={styles.tp_title}>{i18n.t('select_layout')}</Text>
                                        <Text style={styles.tp_text}>{i18n.t('layouts_description')}</Text>
                                    </View>

                                    <View style={[styles.lsels]}>
                                        <TouchableOpacity onPress={()=>{this._changeLayout('layout1')}} style={[styles.lsel, this.state.layout === 'layout1' ? styles.lsel_a : {}]}>

                                            <Image style={[styles.lsel_image]} source={require('../assets/LAYOUT1.gif')}/>

                                            <View style={[styles.lsel_details]}>
                                                <AntDesign style={[styles.lsel_icon, this.state.layout === 'layout1' ? styles.lsel_ai : {}]} name="checkcircleo" size={24} color="black" />
                                                <Text style={[styles.lsel_text]}>{i18n.t('modern_mode')}</Text>
                                            </View>


                                        </TouchableOpacity>



                                        <TouchableOpacity onPress={()=>{this._changeLayout('layout2')}} style={[styles.lsel, this.state.layout === 'layout2' ? styles.lsel_a : {}]}>

                                            <Image style={[styles.lsel_image]} source={require('../assets/LAYOUT2.gif')}/>

                                            <View style={[styles.lsel_details]}>
                                                <AntDesign style={[styles.lsel_icon, this.state.layout === 'layout2' ? styles.lsel_ai : {}]} name="checkcircleo" size={24} color="black" />
                                                <Text style={[styles.lsel_text]}>{i18n.t('stack_mode')}</Text>
                                            </View>


                                        </TouchableOpacity>
                                    </View>

                                </View>
                            )}
                            {(this.state.step !== 3) ? (null) : (
                                <View style={styles.upper}>
                                    <View style={styles.top_part}>
                                        <Text style={styles.tp_title}>{i18n.t('select_theme')}</Text>
                                        <Text style={styles.tp_text}>{i18n.t('themes_description')}</Text>
                                    </View>

                                    <View style={[styles.lsels]}>
                                        <TouchableOpacity onPress={()=>{this._changeTheme('light')}} style={[styles.lsel, this.state.theme === 'light' ? styles.lsel_a : {}]}>

                                            <Image style={[styles.lsel_image]} source={(this.state.layout === 'layout1' ? require('../assets/LAYOUT1_LIGHT.png') : require('../assets/LAYOUT2_LIGHT.png'))}/>

                                            <View style={[styles.lsel_details]}>
                                                <AntDesign style={[styles.lsel_icon, this.state.theme === 'light' ? styles.lsel_ai : {}]} name="checkcircleo" size={24} color="black" />
                                                <Text style={[styles.lsel_text]}>{i18n.t('theme_light')}</Text>
                                            </View>


                                        </TouchableOpacity>



                                        <TouchableOpacity onPress={()=>{this._changeTheme('dark')}} style={[styles.lsel, this.state.theme === 'dark' ? styles.lsel_a : {}]}>

                                            <Image style={[styles.lsel_image]} source={(this.state.layout === 'layout1' ? require('../assets/LAYOUT1_DARK.png') : require('../assets/LAYOUT2_DARK.png'))}/>

                                            <View style={[styles.lsel_details]}>
                                                <AntDesign style={[styles.lsel_icon, this.state.theme === 'dark' ? styles.lsel_ai : {}]} name="checkcircleo" size={24} color="black" />
                                                <Text style={[styles.lsel_text]}>{i18n.t('theme_dark')}</Text>
                                            </View>


                                        </TouchableOpacity>
                                    </View>

                                </View>
                            )}
                            {(this.state.step !== 4) ? (null) : (
                                <View style={styles.upper}>
                                    <View style={styles.top_part}>
                                        <Image style={styles.logo} source={require('../assets/success.gif')}/>
                                        <Text style={styles.tp_title}>{i18n.t('setup_final_message')}</Text>
                                        {/*<Text style={styles.tp_text}>Start by costumizing your application, press on the customize button bellow to begin..</Text>*/}
                                    </View>

                                </View>
                            )}

                            {
                                (this.state.step === 5) ? (null) : (
                                    <View>
                                        <View style={styles.steps}>
                                            <View style={[styles.step, this.state.step === 1 ? styles.step_a : {}]}/>
                                            <View style={[styles.step, this.state.step === 2 ? styles.step_a : {}]}/>
                                            <View style={[styles.step, this.state.step === 3 ? styles.step_a : {}]}/>
                                            <View style={[styles.step, this.state.step === 4 ? styles.step_a : {}]}/>
                                            <View style={[styles.step, this.state.step === 5 ? styles.step_a : {}]}/>
                                        </View>
                                        <View style={styles.footers}>

                                            <TwButton onPress={()=>this.nextStep(false)} style={{minWidth: 320}} title={this.state.step_text}/>

                                            {
                                                (this.state.step === 1) ? (null) : (
                                                    <TwButton small={true} onPress={()=>this.nextStep(true)} style={{minWidth: 320, marginTop: 20,}} icon={'leftcircleo'} title={i18n.t('go_back')} flip={true} full={false}/>
                                                )
                                            }

                                        </View>
                                    </View>
                                )
                            }
                        </SafeAreaView>




                    </ScrollView>


                </ImageBackground>

            </View>

        );
    }

}

const styles = StyleSheet.create({
    lsels : {
        flexDirection: 'row',
        //flex: 2,
        //backgroundColor: 'rgba(3,178,255,0.25)',
    },
    lsel : {
        paddingHorizontal: 12,
        paddingVertical: 4,
        margin: 8,
        alignItems: 'center',
        borderRadius: 8,
        flex: 1,
        maxWidth: 280,

    },
    lsel_a : {
       backgroundColor: 'rgba(3,178,255,0.25)',
    },
    lsel_ai : {
        opacity: 1,
        color: '#03b2ff',
    },
    lsel_icon : {
        opacity: .2,
        marginBottom: 12,
    },
    lsel_image : {
        width: 120,
        height: 200,
        resizeMode: 'contain',
    },
    lsel_text : {
        paddingTop: 6,
        //backgroundColor: '#ccc',
    },
    lsel_details : {
        //flexDirection: 'row',
        alignItems: 'center',
        padding: 8,
        marginVertical: 12,
    },
    row_sel: {
        flexDirection: 'row',
        borderColor : '#4b4b4b',
        borderWidth: 2,
        borderRadius : 8,
        height: 42,
        width: 320,
        marginVertical: 12,
    },
    row_sel_a: {
        borderColor: '#03b2ff',
        backgroundColor: "rgba(3,178,255,0.09)",
        //color : "#fff",
    },
    row_sel_icon: {
        height: 40,
        width: 64,
        alignItems: 'center',
        justifyContent: 'center',
    },
    row_sel_detail: {
        //height : 46,
        flex: 1,
        height: "100%",
        justifyContent : 'center',
        alignItems : 'center',
        //backgroundColor: '#ccc',
    },
    row_sel_text: {
        width: "100%",
        paddingHorizontal: 12,
    },
    footers : {
        //flexDirection: 'row',
        alignItems:'center',
        justifyContent:'center',
        padding: 12,
        //minHeight: ofHeight(16),
        //backgroundColor: '#ccc',
        flex: 1,
    },
    steps : {
        flexDirection: 'row',
        alignItems:'center',
        justifyContent:'center',
        padding: 12,
    },
    upper : {
        flex:3,
        alignItems : 'center',
        justifyContent : 'center',
    },
    step : {
        width: 12,
        height: 12,
        backgroundColor: 'rgba(0,0,0,0.11)',
        borderRadius: 6,
        margin: 6,
    },
    step_a : {
        backgroundColor: colors.primary3,
        borderRadius: 6,
    },
    scroll : {
        width: ofWidth(100)
    },
    logo : {
        height: ofHeight(18),
        resizeMode: 'contain',
        borderRadius: ofHeight(3),
        marginBottom: ofHeight(3),
    },
    tp_title : {
        fontSize: sizes.lg,
        textAlign: 'center',
        fontWeight: 'bold',
    },
    tp_text : {
        fontSize: sizes.md,
        textAlign: 'center',
        overflow: 'scroll',
    },
    top_part: {
        //minHeight: ofHeight(50),
        //backgroundColor: 'rgba(204,204,204,0.27)',
        alignItems: 'center',
        justifyContent: 'center',
        flex:2,
    },
    sc : {
        //flexDirection: 'column',
        //alignItems: 'center',
        justifyContent: 'center',
        paddingVertical : ofHeight(4),
        paddingHorizontal : ofWidth(4),
        //backgroundColor: '#ccc',
        minHeight: ofHeight(100),
    },
    bg:{
        flex:1,
        resizeMode: "center",
        justifyContent: "center",
        width: ofWidth(100),
    },
    whole: {
        display:'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height:'100%',
        backgroundColor: '#fff',
        width: ofWidth(100),
    },

});

const mapDispatchToProps = dispatch => (
    bindActionCreators({
        updateData: updateData,
    }, dispatch)
);

const mapStateToProps = (state) => {
    const { data } = state;
    return { data }
};

export default connect(mapStateToProps, mapDispatchToProps)(setupScreen);
