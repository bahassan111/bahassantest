package ma.rak.ovr;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import ma.rak.ovr.bodyResponse.ReclamationResponse;
import ma.rak.ovr.models.Reclamation;
import ma.rak.ovr.storage.SharedPrefManager;
import ma.rak.ovr.ui.main.AffecterFragment;
import ma.rak.ovr.ui.main.DemandViewModel;
import ma.rak.ovr.ui.main.ExecutionFragment;
import ma.rak.ovr.ui.main.RejectFragment;

public class MapsFragment extends Fragment implements LocationListener {

    HashMap<String, HashMap<String, String>> markerMapBr = new HashMap<String, HashMap<String, String>>();
    HashMap<String, HashMap<String, String>> markerMapAb = new HashMap<String, HashMap<String, String>>();
    private PopupWindow mPopupWindow;
    private Activity mActivity;
    private Context mContext;
    private DemandViewModel demandViewModel;
    ArrayList<HashMap<String, String>> newBrResponse = null;
    ArrayList<HashMap<String, String>> newAbResponse = null;

    private GoogleMap googleMapContext;

    protected Double latitude, longitude;
    protected LocationManager locationManager;

    private boolean onLoadMap = false;

    public void fetchData(int status, GoogleMap googleMap) {
        googleMapContext = googleMap;
        demandViewModel = ViewModelProviders.of(getActivity()).get(DemandViewModel.class);
            demandViewModel.getAbonnements(SharedPrefManager.getInstance(getActivity()).getToken(), status, getContext());
            newAbResponse = new ArrayList<>();
            demandViewModel.AbResponseMutableLiveData.observe(getActivity(), new Observer<ArrayList<HashMap<String, String>>>() {
                @Override
                public void onChanged(ArrayList<HashMap<String, String>> dataList) {

                    int i = 0;
                    for (HashMap<String, String> item : dataList) {

                        if (item.get("LONGITUDE") != null && item.get("LATITUDE") != null) {

                            Marker markerTwo = googleMap
                                    .addMarker(new MarkerOptions()
                                            .position(
                                                    new LatLng(roundAvoid(Double.parseDouble(item.get("LONGITUDE")), 5), roundAvoid(Double.parseDouble(item.get("LATITUDE")), 4))
                                            )
                                            .title(item.get("NOM"))
                                            .snippet(item.get("ADRELOCA")));
                            markerTwo.setTag("RAK");
                            markerTwo.setIcon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_CYAN));
                            markerMapAb.put(markerTwo.getId(), item);
                            Log.i("LngLat", "" + roundAvoid(Double.parseDouble(item.get("LONGITUDE")), 5) + "," + roundAvoid(Double.parseDouble(item.get("LATITUDE")), 4));
                        }
                    }

                }

            });

    }


    private OnMapReadyCallback callback = new OnMapReadyCallback() {


        /**
         * Manipulates the map once available.
         * This callback is triggered when the map is ready to be used.
         * This is where we can add markers or lines, add listeners or move the camera.
         * In this case, we just add a marker near Sydney, Australia.
         * If Google Play services is not installed on the device, the user will be prompted to
         * install it inside the SupportMapFragment. This method will only be triggered once the
         * user has installed Google Play services and returned to the app.
         */
        @Override
        public void onMapReady(GoogleMap googleMap) {

            googleMapContext = googleMap;
            fetchData(1, googleMap);
//            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(firstMarker, 15f));
            if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            googleMap.setMyLocationEnabled(true);


            googleMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
                @Override
                public boolean onMarkerClick(Marker marker) {
                    if (marker.getTag() != null && !marker.getTag().equals("RAK")) {
                        return false;
                    } else {
                        // Initialize a new instance of LayoutInflater service
                        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

                        // Inflate the custom layout/view
                        View customView = inflater.inflate(R.layout.custom_layout, null);


                        TextView dossier_id = customView.findViewById(R.id.dossier_id);
                        TextView gerance = customView.findViewById(R.id.gerance);
                        TextView client_name = customView.findViewById(R.id.client_name);
                        TextView client_address = customView.findViewById(R.id.client_address);

                        TextView agence = customView.findViewById(R.id.agence);
                        TextView localiteSecteur = customView.findViewById(R.id.localite_secteur);
                        TextView reclamationAdresse = customView.findViewById(R.id.reclamation_adresse);
                        TextView numCompteur = customView.findViewById(R.id.num_compteur);
                        TextView dateReclamation = customView.findViewById(R.id.date_reclamation);
                        TextView emetteur = customView.findViewById(R.id.emetteur);
                        TextView destinataire = customView.findViewById(R.id.destinataire);

                        Button btnTraiter = customView.findViewById(R.id.btn_traiter);
                        Button btnOthers = customView.findViewById(R.id.btn_others);


                        Intent execution = new Intent(mContext, ExecutionFragment.class);
                        Intent reject = new Intent(mContext, RejectFragment.class);
                        Intent noExecution = new Intent(mContext, RejectFragment.class);
                        Intent affecter = new Intent(mContext, AffecterFragment.class);

                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                        String currentDateandTime = sdf.format(new Date());
                        HashMap<String, String> clickerItem = markerMapAb.get(marker.getId());

                            if(clickerItem == null) return false;

                            client_name.setText(clickerItem.get("NOMPRECL"));
                            dossier_id.setText(clickerItem.get("NUMDOSRE"));
                            client_address.setText(clickerItem.get("ADRERECL"));
                            dateReclamation.setText(clickerItem.get("DATCREDO"));
                            agence.setText(clickerItem.get("CODEAGEN"));
                            numCompteur.setText(clickerItem.get("REFECOMP"));

                            reclamationAdresse.setText(clickerItem.get("ADRERECL"));
                            localiteSecteur.setText(clickerItem.get("CODESECT"));

                            execution.putExtra("status", clickerItem.get("STATUS"));
                            execution.putExtra("date", currentDateandTime);
                            execution.putExtra("dossier_id", clickerItem.get("NUMDOSRE"));
                            execution.putExtra("gerance", clickerItem.get("CODEGERA"));
                            execution.putExtra("adreloca", clickerItem.get("ADRERECL"));
                            execution.putExtra("ITEM", clickerItem);

                            execution.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);



                        btnOthers.setOnClickListener(v -> {
                            ActionBottomDialogFragment addPhotoBottomDialogFragment =
                                    new ActionBottomDialogFragment(clickerItem);
                            addPhotoBottomDialogFragment.show(getActivity().getSupportFragmentManager(),
                                    ActionBottomDialogFragment.TAG);
                        });

                        btnTraiter.setOnClickListener(v3 -> mContext.startActivity(execution));

//                        operationExecute.setOnClickListener(v3 -> getActivity().startActivity(execution));
//
//                        operationReject.setOnClickListener(v2 -> getActivity().startActivity(reject));
//
//
//                        String scoop = SharedPrefManager.getInstance(getContext()).getScoop();
//
//                        if (scoop.equals("Superviseur")) {
//                            operationReaf.setVisibility(View.VISIBLE);
//                        } else {
//                            operationReaf.setVisibility(View.INVISIBLE);
//                        }
//
//                        operationReaf.setOnClickListener(v4 -> getActivity().startActivity(affecter));
//
//                        operationNoExecution.setOnClickListener(new View.OnClickListener() {
//                            @Override
//                            public void onClick(View v) {
//                                noExecution.putExtra("status", "4");
//                                getActivity().startActivity(noExecution);
//                            }
//                        });


                /*
                    public PopupWindow (View contentView, int width, int height)
                        Create a new non focusable popup window which can display the contentView.
                        The dimension of the window must be passed to this constructor.

                        The popup does not provide any background. This should be handled by
                        the content view.

                    Parameters
                        contentView : the popup's content
                        width : the popup's width
                        height : the popup's height
                */
                        // Initialize a new instance of popup window
                        mPopupWindow = new PopupWindow(
                                customView,
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT,
                                true
                        );

                        // Set an elevation value for popup window
                        // Call requires API level 21
                        if (Build.VERSION.SDK_INT >= 21) {
                            mPopupWindow.setElevation(100);
                        }

                        // Get a reference for the custom view close button
                        ImageButton closeButton = customView.findViewById(R.id.ib_close);

                        // Set a click listener for the popup window close button
                        closeButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                // Dismiss the popup window
                                mPopupWindow.dismiss();
                            }
                        });

                /*
                    public void showAtLocation (View parent, int gravity, int x, int y)
                        Display the content view in a popup window at the specified location. If the
                        popup window cannot fit on screen, it will be clipped.
                        Learn WindowManager.LayoutParams for more information on how gravity and the x
                        and y parameters are related. Specifying a gravity of NO_GRAVITY is similar
                        to specifying Gravity.LEFT | Gravity.TOP.

                    Parameters
                        parent : a parent view to get the getWindowToken() token from
                        gravity : the gravity which controls the placement of the popup window
                        x : the popup's x location offset
                        y : the popup's y location offset
                */
                        // Finally, show the popup window at the center location of root relative layout
                        ConstraintLayout constraintLayout = (ConstraintLayout) getActivity().findViewById(R.id.constraintLayoutMap);
                        mPopupWindow.showAtLocation(constraintLayout, Gravity.BOTTOM, 0, 0);

                        Log.v("MyActivity", marker.getId());
                        return false;

                    }

                }

            });


            //kMarker.showInfoWindow();
        }
    };


    public static double roundAvoid(double value, int places) {
        double scale = Math.pow(10, places);
        return Math.round(value * scale) / scale;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        // Get the application context
        mContext = getActivity().getApplicationContext();

        // Get the activity
        mActivity = getActivity();

//        TextView hamMenu = getActivity().findViewById(R.id.toolbarUserMenu);
//        hamMenu.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                showPopup(v);
//            }
//        });

        return inflater.inflate(R.layout.fragment_maps, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        SupportMapFragment mapFragment =
                (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);


        locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.


            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);

        mapFragment.getMapAsync(callback);
    }

    @Override
    public void onLocationChanged(Location location) {

        if (this.onLoadMap == false) {
            this.latitude = location.getLatitude();
            this.longitude = location.getLongitude();

            try {
                if (location.getLatitude() != 0 && location.getLongitude() != 0) {
                    LatLng firstMarker = new LatLng(location.getLatitude(), location.getLongitude());
                    Log.i("position", firstMarker.toString());
                    googleMapContext.addMarker(new MarkerOptions().position(firstMarker).title(getString(R.string.myPostion)));

                    googleMapContext.animateCamera(CameraUpdateFactory.newLatLngZoom(firstMarker, 17f));
                    this.onLoadMap = true;
                }
            } catch (Exception e) {
                Log.e("GoogleMapException", e.getMessage());
            }

        }

    }


}