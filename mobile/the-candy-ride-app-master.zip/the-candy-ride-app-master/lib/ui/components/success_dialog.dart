import 'package:flutter/material.dart';
import 'package:rider_app/ui/components/components.dart';
import 'package:get/get.dart';

class SuccessDialog extends StatelessWidget {
  const SuccessDialog({Key key, this.message, this.title, this.ontap})
      : super(key: key);
  final String title;
  final String message;
  final Function ontap;
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(title ?? "",
          style: Theme.of(context).textTheme.headline2.copyWith(fontSize: 18)),
      content: Text(message,
          style: Theme.of(context).textTheme.headline2.copyWith(fontSize: 16)),
      actions: [
        Align(
          alignment: Alignment.center,
          child: Container(
            padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
            width: 100,
            child: RoundButton(
              onTap: ontap,
              text: "ok".tr,
            ),
          ),
        )
      ],
    );
  }
}
