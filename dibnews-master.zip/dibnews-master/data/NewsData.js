import API from "../storage/TwAPIClient";
import storage from "../storage/TwStorage";
import moment from "moment-with-locales-es6";
import Helper from "../global/Helper";
import Constants from "expo-constants";

export function fetchNewsData(lang, forceLocal){

    return new Promise(((resolve, reject) => {

        API.Query('posts', {
            /*rnd : Helper.random(111111,999999),*/
            per_page : "100",
            lang : lang,
        })
            .then((rep)=>{

                if(rep.message){
                    reject();
                    return;
                }

                resolve(rep);
            })
            .catch(()=>{
                reject();
            })





    }));

}

export function testGetPosts(){

    return new Promise(((resolve, reject) => {

        API.Query('posts', {
            rnd : Helper.random(111111,999999),
            per_page : "1",
        })
            .then((rep)=>{
                if(rep.message){
                    resolve(false);
                }
                resolve(true);
            })
            .catch(()=>{
                resolve(false);
            })





    }));

}

export function fetchNewsByCatData(lang, catid, forceLocal){

    return new Promise(((resolve, reject) => {

        API.Query('posts', {
            categories : catid,
            /*rnd : Helper.random(111111,999999),*/
            per_page : "100",
            lang : lang,
        })
            .then((rep)=>{
                if(rep.message){
                    reject();
                    return;
                }

                resolve(rep);
            })
            .catch(()=>{
                reject();
            })





    }));

}
export function fetchArticle(id){



    return new Promise(((resolve, reject) => {

        if(id < 1) reject('');

        API.Query('posts', {
            include : id,
        })
            .then((rep)=>{
                if(rep.message){
                    reject();
                    return;
                }

                resolve(rep);
            })
            .catch(()=>{
                reject();
            })





    }));

}

export function fetchCategories(lang, forceLocal){

    return new Promise(((resolve, reject) => {

        API.Query('categories', {
            per_page : "100",
            lang : lang,
        })
            .then((rep)=>{
                try {
                    //rep = JSON.parse(rep);
                    rep.map((item, i)=>{
                        item.color = Helper.randomColor();
                        return item;
                    });
                }catch (e) {
                    reject(e);
                    return;
                }


                storage.setStorage('cats', rep);

                resolve(rep);
            })
            .catch((e)=>{
                reject(e);
            })





    }));

}

export function updateNotifStatus(enabled) {
    let uid = Constants.installationId;

    return fetch(`https://dibnews.ma/MOBILE_API/Root/update_notif?uid=${uid}&enabled=${enabled ? 1 : 0}`);
}

export function updateNotifCategoryStatus(cat, enabled) {
    let uid = Constants.installationId;

    return fetch(`https://dibnews.ma/MOBILE_API/Root/update_cat_notif?uid=${uid}&cat=${cat}&enabled=${enabled ? 1 : 0}`);
}

