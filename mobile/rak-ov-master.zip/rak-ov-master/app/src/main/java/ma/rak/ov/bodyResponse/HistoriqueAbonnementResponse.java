package ma.rak.ov.bodyResponse;

import com.google.gson.annotations.SerializedName;

import java.util.List;
import java.util.UUID;

import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;
import ma.rak.ov.models.Abonnement;
import ma.rak.ov.models.Branchement;

public class HistoriqueAbonnementResponse extends RealmObject {

    @PrimaryKey

    @SerializedName("id")
    private String id = UUID.randomUUID().toString();

    @SerializedName("status")
    private String status;

    @SerializedName("last_date")
    private String lastDate;

    @SerializedName("total_operations")
    private int totalOperations;

    @SerializedName("data")
    private RealmList<Abonnement> data;

    public HistoriqueAbonnementResponse() {
    }

    public HistoriqueAbonnementResponse(String id, String status, String lastDate, int totalOperations, RealmList<Abonnement> data) {
        this.id = id;
        this.status = status;
        this.lastDate = lastDate;
        this.totalOperations = totalOperations;
        this.data = data;
    }

    public String getStatus() {
        return status;
    }

    public String getLastDate() {
        return lastDate;
    }

    public int getTotalOperations() {
        return totalOperations;
    }

    public List<Abonnement> getData() {
        return data;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setLastDate(String lastDate) {
        this.lastDate = lastDate;
    }

    public void setTotalOperations(int totalOperations) {
        this.totalOperations = totalOperations;
    }

    public void setData(RealmList<Abonnement> data) {
        this.data = data;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
