<?php

require_once 'TwClient.php';

class TwTester
{
    public const METHOD_POST = 'POST';
    public const METHOD_GET = 'GET';
    public const METHOD_PUT = 'PUT';
    public const METHOD_DELETE = 'DELETE';
    public const DATATYPE_JSON = 'json';
    public const DATATYPE_HTML = 'html';
    public const DATATYPE_XML = 'xml';
    public const DATATYPE_TEXT = 'text';

    public const COOKIES_NO = 0;
    public const COOKIES_USE = 1;
    public const COOKIES_CLEAR = 2;

    protected $client;

    public function __construct()
    {
        $this->client = new TwClient(TRUE);
    }

    public function run($case)
    {

        $that =& get_instance();
        $rep = (object)[
            'result' => 'UNHANDLED',
            'runtime' => microtime(TRUE),
            'props' => [],
        ];

        if(!$case->use_cookies) $ck = self::COOKIES_NO;
        elseif($case->clear_cookies) $ck = self::COOKIES_CLEAR;
        else $ck = self::COOKIES_USE;

        $query = $this->request($case->method, $case->url, $case->params, $case->headers, null, $case->id_plan, $ck);


        $rep->runtime = round(microtime(TRUE) - $rep->runtime, 3);
        $rep->query = $query;
        foreach ($case->asserts as $assr) {
            $assert = asserts($assr->id_assert);

            $handler = $assert->handler;
            $reflection = new ReflectionFunction($handler);
            $arguments  = $reflection->getParameters();

            switch (count($arguments)){
                case 2 : $result = $handler($query, $assr->value1); break;
                case 3 : $result = $handler($query, $assr->value1, $assr->value2); break;
                case 4 : $result = $handler($query, $assr->value1, $assr->value2, $assr->value3); break;
                case 5 : $result = $handler($query, $assr->value1, $assr->value2, $assr->value3, $assr->value4); break;
                default: $result = $handler($query);
            }



            $response = new stdClass();
            $response->result = $result->result ? 'PASSED' : 'FAILED';
            $response->id = $assr->id;
            $response->self = asserts($assr->id_assert);
            $response->props = $result;
            $rep->asserts[] = $response;
        }
        $stat = $rep->result;
        foreach ($rep->asserts as $assert) {
            if ($assert->result === "FAILED") {
                $stat = "FAILED";
                break;
            } elseif ($assert->result === "PASSED") {
                $stat = "PASSED";
            } else {
                $stat = "UNHANDLED";
                break;
            }
        }
        $rep->result = $stat;
        return $rep;
    }

    public function request($method, $url, $params, $header, $datatype, $project_id = FALSE, $cookies = self::COOKIES_NO)
    {

        $response = $this->query($url, $method, $this->fixArray($params), $header, $project_id, $cookies);
        if ($response === null) return null;

        return $response;

    }

    protected function query($url, $method, $params, $headers, $project_id = FALSE, $cookies = self::COOKIES_NO)
    {

        return $this->client->request($method, $url, $params, $headers, $cookies, $project_id);

    }



    protected function fixArray($array){
        if(gettype($array) != 'array'){
            if(gettype($array) === 'string') {
                $o = json_decode($array);
                if($o){
                    return $this->fixArray($o);
                }
                return [$array];
            }

            $arr = [];
            foreach ($array as $k => $v){
                $arr[$k] = $v;
            }
            return $arr;
        }

        return $array;
    }



}