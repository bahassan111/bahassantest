package ma.rak.ovr.ui.main;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.HashMap;

import io.realm.Realm;
import io.realm.RealmList;
import io.realm.Sort;
import io.realm.exceptions.RealmException;
import ma.rak.ovr.LoginActivity;
import ma.rak.ovr.api.RetrofitClient;
import ma.rak.ovr.api.TwDatabase;
import ma.rak.ovr.bodyResponse.SettingsResponse;
import ma.rak.ovr.bodyResponse.StatistiqueResponse;
import ma.rak.ovr.models.Categorie;
import ma.rak.ovr.models.CategorieBr;
import ma.rak.ovr.models.Emplacement;
import ma.rak.ovr.models.Motif;
import ma.rak.ovr.models.MotifBr;
import ma.rak.ovr.models.Nature;
import ma.rak.ovr.models.NatureBr;
import ma.rak.ovr.models.Resultat;
import ma.rak.ovr.storage.SharedPrefManager;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DemandViewModel extends ViewModel {

    public MutableLiveData<ArrayList<HashMap<String, String>>> BranchementMutableLiveData = new MutableLiveData<>();
    public MutableLiveData<ArrayList<HashMap<String, String>>> BrResponseMutableLiveData = new MutableLiveData<>();

    public MutableLiveData<ArrayList<HashMap<String, String>>> AbonnementMutableLiveData = new MutableLiveData<>();
    public MutableLiveData<ArrayList<HashMap<String, String>>> AbResponseMutableLiveData = new MutableLiveData<>();

    public MutableLiveData<StatistiqueResponse> StResponseMutableLiveData = new MutableLiveData<>();
    public MutableLiveData<SettingsResponse> SettingsMutableLiveData = new MutableLiveData<>();

    public MutableLiveData<ArrayList<HashMap<String, String>>> AgentsMutableLiveData = new MutableLiveData<>();

    Realm realm;

    public DemandViewModel() {
        super();
    }

    public void getBrachments(String token, int page, Context ctx, int status) {
        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);

        ArrayList demandes = dbh.query(TwDatabase.Demandes.TABLE_NAME, "STATUS = " + String.valueOf(status), null, TwDatabase.Demandes.DATCREDO + " DESC");

        BranchementMutableLiveData.setValue(demandes);
        BrResponseMutableLiveData.setValue(demandes);
    }

    public void getHistoriquesBr(String token, Context ctx) {

        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);

        ArrayList demandes = dbh.query(TwDatabase.Demandes.TABLE_NAME, "STATDEVI not in (1, 2)", null, TwDatabase.Demandes.DATCREDO + " DESC");


        BranchementMutableLiveData.setValue(demandes);
        BrResponseMutableLiveData.setValue(demandes);

    }

    public void getAbonnements(String token, int status, Context ctx) {

        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);

        ArrayList<HashMap<String, String>> demandes = dbh.query(TwDatabase.Demandes.TABLE_NAME, "STATUS = ?", new String[]{String.valueOf(status)}, TwDatabase.Demandes.DATCREDO + " DESC");


        AbonnementMutableLiveData.setValue(demandes);
        AbResponseMutableLiveData.setValue(demandes);

    }

    public void getStatistique(String token, Context context) {
        realm = Realm.getDefaultInstance();

        try {

            Call<StatistiqueResponse> call = RetrofitClient.getApi(token).statstiques();
            call.enqueue(new Callback<StatistiqueResponse>() {
                @Override
                public void onResponse(Call<StatistiqueResponse> call, Response<StatistiqueResponse> response) {
                    if (response.code() == 403) {
                        SharedPrefManager.getInstance(context).clear();
                        Intent intent = new Intent(context, LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

                        context.startActivity(intent);
                    }
                    StResponseMutableLiveData.setValue(response.body());
                    try {
                        realm.executeTransaction(realm -> {
                            //realm.copyToRealmOrUpdate(response.body());
                        });
                    } catch (RealmException realmException) {
                        Log.e("newStatistiqueResponse", realmException.getMessage());
                    } finally {
                        realm.close();
                    }
                }

                @Override
                public void onFailure(Call<StatistiqueResponse> call, Throwable t) {
                    Log.i("onFailure", t.getMessage().toString());

                    realm.executeTransaction(new Realm.Transaction() {
                        @Override
                        public void execute(Realm realm) {
                            StatistiqueResponse realmResponse = realm.where(StatistiqueResponse.class).sort("createdAt", Sort.DESCENDING).findFirst();
                            if (realmResponse != null)
                                StResponseMutableLiveData.setValue(realmResponse);
                        }
                    });

                }
            });
        } catch (IllegalArgumentException e) {
            Log.i("onFailure", e.getMessage().toString());
            realm.close();
        }
    }

    ;

    public void getSettings(String token, Context mContext, String gerance) {

        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(mContext);

        ArrayList<HashMap<String, String>> results = dbh.query(TwDatabase.Results.TABLE_NAME, "1=1", new String[]{}, TwDatabase.Results.LIBRESRE);

        RealmList<Resultat> _results = new RealmList<Resultat>();
        for (HashMap<String, String> mot : results) {
            _results.add(new Resultat(mot.get(TwDatabase.Results.CODRESRE), mot.get(TwDatabase.Results.LIBRESRE)));
        }




        SettingsResponse rep = new SettingsResponse("SUCCESS", new RealmList<>(), new RealmList<>(), _results);


        SettingsMutableLiveData.setValue(rep);
    }

    public void getAgents(Context ctx) {

        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);
        SQLiteDatabase db = dbh.getReadableDatabase();

        ArrayList<HashMap<String, String>> agents = dbh.query(TwDatabase.ALLAgents.TABLE_NAME, null, null, TwDatabase.ALLAgents.COL_LABEL + " ASC");

        AgentsMutableLiveData.setValue(agents);
    }
}
