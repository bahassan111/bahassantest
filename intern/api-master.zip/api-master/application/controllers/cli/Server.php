<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH.'libraries/Workerman/Autoloader.php';


use Workerman\Worker;
use Workerman\Timer;

class Server extends TwController
{
    private $ssl_context = [];
    private $use_ssl;
    private $worker;

    public $address;
    public $port;

    public $connexions = [];
    public $chatters = [];

    private $last_q;
    private $last_c;

    private $_ticks = [];

    public function __construct()
    {
        parent::__construct();
        define('GLOBAL_START', 1);

        $this->address = $this->config->item('signaling_address');
        $this->port = $this->config->item('signaling_port');
        $this->use_ssl = $this->config->item('use_ssl');
        if($this->use_ssl){
            $this->ssl_context = $this->config->item('ssl_context');
        }
    }

    protected function getUser($connection){
        foreach ($this->chatters as $id => $chatter){
            foreach ($chatter->connections as $cnx){
                if($cnx->id === $connection->id) return $chatter->user;
            }
        }

        return null;
    }

    public function start()
    {
        $this->worker = new Worker('websocket://0.0.0.0:'.$this->port, $this->ssl_context);
        $worker = $this->worker;


        if ($this->ssl_context) {
            $this->worker->transport = 'ssl';
        }

        $worker->onWorkerStart = function ($worker){
            Timer::add(2, function(){ $this->atick(); }, [], TRUE);
        };

        $worker->count = 1;

        $worker->name = 'Twins Messenger';

        $worker->onConnect = function ($connection){
            $this->connexions[] = $connection;
        };

        $worker->onMessage = function ($c, $d){$this->onMessage($c, $d);};

        $worker->onClose = function($connection){
            $this->onClose($connection);
        };

        //cleanup
        $this->db->truncate('_pending_login');


        Worker::runAll();

    }

    function atick(){
        foreach ($this->_ticks as $id => $tick){

            try{
                $result = $tick();

                if($result === TRUE){
                    unset($this->_ticks[$id]);
                }
            }catch (Exception $exception){

            }

        }
    }

    function onMessage($connection, $data)
    {
        $data = (object) json_decode($data, true);

        $commande = $data->cmd;

        if(method_exists($this, '_' . $commande)){

            return $this->{'_' . $commande}($connection, $data);

        }

        switch ($data->cmd) {
            case 'subscribe':
                $subject = $data['subject'];
                $this->subscribe($subject, $connection);
                break;



        }
    }

    function onClose($connection){
        $this->destry_connection($connection);
    }

    function addTick($id, $cb){
        $this->_ticks[$id] = $cb;
    }

    function subscribe($subject, $connection) {
        $connection->subjects[$subject] = $subject;

    }

    function unsubscribe($subject, $connection) {

    }

    function publish($subject, $event, $data, $exclude) {

    }

    function direct($connection, $subject, $payload){
        $connection->send(json_encode([
            'subject' => $subject,
            'data' => $payload
        ]));
    }

    function toUser($user_id, $subject, $payload){

        if(is_array($user_id)){
            foreach ($user_id as $u) $this->toUser($u, $subject, $payload);
        }

        foreach ($this->chatters as $chatter){
            if($chatter->user->id === $user_id){
                foreach ($chatter->connections as $connection){
                    $this->direct($connection, $subject, $payload);
                }
            }
        }

    }

    function destry_connection ($connection) {
        foreach ($this->chatters as $chatter) {
            foreach ($chatter->connections as $i => $c){
                if($c->id === $connection->id){
                    $c->destroy();
                    unset($chatter->connections[$i]);
                }
            }
        }
    }

    protected function decodeSession($data)
    {

        $return_data = [];
        $offset = 0;
        while ($offset < strlen($data)) {
            if (!strstr(substr($data, $offset), "|")) {

            }
            $pos = strpos($data, "|", $offset);
            $num = $pos - $offset;
            $varname = substr($data, $offset, $num);
            $offset += $num + 1;
            $row = unserialize(substr($data, $offset));
            $return_data[$varname] = $row;
            $offset += strlen(serialize($row));
        }

        return (object) $return_data;

    }

    /**
     * @param Workerman\Connection\UdpConnection $connection
     * @param int $id
     * @return mixed kolchiii
     */
    function newConnection($connection, $id){

        if(isset($this->chatters[$id])){
            $this->chatters[$id]->connections[] = $connection;
        }else{
            $this->chatters[$id] = (object)['user' => $this->db->get_where('users', ['id' => $id])->row() ,'connections' => [$connection]];
        }

    }






    function _login_url($connection, $data){

        $key = random_string('alnum', 64);

        $this->db->insert('_pending_login', ['key' => $key]);

        $rep = (object)[
            'url' => site_url('Messenger/enter/' . $key)
        ];

        $this->addTick('login' . $key, function()use ($key, $connection){

            $q = $this->db->get_where('_pending_login', ['key' => $key]);

            if($q && $q->num_rows() > 0){
                $userid = $q->row()->user_id;
                if(!$userid) return false;

                $q = $this->db->get_where('users', ['id' => $userid]);
                $user = $q && $q->num_rows() ? $q->row() : null;

                if($user){

                    $this->db->delete('_pending_login', ['key' => $key]);

                    $this->_connect($connection, (object)['data' => $userid]);
                }
            }

            return true;

        });

        $this->direct($connection, 'login_url', $rep);
    }

    function _connect($connection, $payload){

        $user_id = $payload->data;

        $q = $this->db->get_where('users', ['id' => $user_id]);
        $user = $q && $q->num_rows() ? $q->row() : null;

        if($user){

            $this->newConnection($connection, $user_id);

            $this->direct($connection, 'entered', (object)[
                'user' => $user
            ]);

            $this->direct($connection, 'contacts', (object)['users' => $this->messenger->getContacts($user_id)]);
            $this->direct($connection, 'groups', (object)['groups' => $this->messenger->getGroups($user_id)]);
            $this->direct($connection, 'chats', (object)['chats' => $this->messenger->getLastChats($user_id)]);


        }else{
            $this->direct($connection, 'error', (object)[
                'code' => 4,
                'message' => 'No user found',
            ]);
        }



    }

    function _chat_start($connection, $payload){

        $user_id = $payload->data['user'];
        $user = $this->getUser($connection);

        $dist = $this->db->get_where('users', ['id' => $user_id])->row();

        $this->direct($connection, 'chat_start', (object)['user' => $dist]);


        $chats = $this->db->query("SELECT * FROM chats WHERE (id_user = '$user_id' AND id_dist = '{$user->id}') OR (id_dist = '$user_id' AND id_user = '{$user->id}') ORDER BY id DESC limit 50")->result();


        $chats = array_reverse($chats);

        $this->direct($connection, 'conversation', ['chats' => $chats]);



    }

    function _send_message($connection, $payload){

        $dist_id = $payload->data['to'];
        $group_id = $payload->data['id_group'];
        $message = $payload->data['message'];
        $tid = $payload->data['tid'];
        $date = $payload->data['date'];
        $user = $this->getUser($connection);

        $msg_data = [
            'id_user' => $user->id,
            'id_dist' => $dist_id,
            'id_group' => $group_id,
            'text' => $message,
            'id_media' => null,
            'deleted' => 0,
            'last_edit' => null,
            'date' => date('Y-m-d H:i:s'),
            'read' => 0,
            'read_date' => null,
        ];

        $q = $this->db->insert('chats', $msg_data);

        if($q){
            $msg_id = $this->db->insert_id();
            $msg_data['id'] = $msg_id;
            $msg_data['tid'] = $tid;
            $this->toUser([$user->id, $dist_id], 'message_sent', $msg_data);
        }else{
            $this->direct($connection, 'message_failed', ['tid' => $tid]);
        }
    }

    function _msg_read($connection, $payload){

        $id = $payload->data['id'];
        $date = $payload->data['date'];
        $user = $this->getUser($connection);

        $q = $this->db->update('chats', ['read' => 1, 'read_date' => $date], ['id' => $id]);

        $q = $q ? $this->db->get_where('chats', ['id' => $id]) : null;
        $chat = $q && $q->num_rows() ? $q->row() : null;

        if($chat){
            $this->toUser([$chat->user_id, $chat->id_dist], 'message_read', ['id' => $id]);
        }



    }

}
