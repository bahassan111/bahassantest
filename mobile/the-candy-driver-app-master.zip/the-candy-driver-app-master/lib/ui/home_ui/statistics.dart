import 'dart:ui';

import 'package:audioplayers/audio_cache.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:driver/constants/constants.dart';
import 'package:driver/constants/images.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Statistics extends StatefulWidget {
  const Statistics({Key key}) : super(key: key);

  @override
  _StatisticsState createState() => _StatisticsState();
}

class _StatisticsState extends State<Statistics> {
  static HomeController to = Get.find();
  AudioCache cache = AudioCache();
  AudioPlayer player;
  @override
  void initState() {
    super.initState();
    to.getDriverStatistics().then((value) {
      setState(() {});
    });
    to.getDriverIsOnlineOrNot().then((value) {
      setState(() {});
    });
  }

  playtone() async {
    player =
        await cache.play(Tones.driverOnlineTone).onError((error, stackTrace) {
      return null;
    }).whenComplete(() {});
  }

  @override
  void dispose() {
    player?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.vertical(
        top: Radius.circular(10),
      ),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.vertical(
            top: Radius.circular(10),
          ),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(5),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Row(
                    children: [
                      SizedBox(
                        width: 30,
                      ),
                      Switch(
                        value: to.isDriverOnline,
                        onChanged: (value) async {
                          playtone();

                          setState(() {
                            to.isDriverOnline = value;
                            to.changeDriverOnlineStatus(
                                status: to.isDriverOnline);
                          });
                        },
                      ),
                    ],
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      "you are ".tr +
                          (to.isDriverOnline ? "online".tr : "offline".tr),
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ),
            Divider(
              thickness: 1,
              height: 0,
            ),
            SizedBox(
              height: 10,
            ),
            IntrinsicHeight(
              child: Row(
                children: [
                  statisticItem(context,
                      image: AllImages.acceptanceIcon,
                      title: "acceptance".tr,
                      value: "${to.driverStatistics?.myacceptance ?? 0} %"),
                  VerticalDivider(
                    thickness: 1,
                  ),
                  statisticItem(context,
                      image: AllImages.ratingIcon,
                      title: "rating".tr,
                      value: "${to.driverStatistics?.myRating ?? 0}"),
                  VerticalDivider(
                    thickness: 1,
                  ),
                  statisticItem(context,
                      image: AllImages.cancelIcon,
                      title: "cancelleation".tr,
                      value: "${to.driverStatistics?.mycancellation ?? 0} %")
                ],
              ),
            ),
            SizedBox(
              height: 15,
            ),
          ],
        ),
      ),
    );
  }

  statisticItem(context, {String title, String image, String value}) {
    return Expanded(
      flex: 1,
      child: Column(
        children: [
          Image.asset(
            image,
            height: 25,
            width: 25,
            fit: BoxFit.cover,
          ),
          SizedBox(
            height: 13,
          ),
          Text(
            value,
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
          ),
          Text(
            title,
            style: Theme.of(context).textTheme.headline3.copyWith(
                  fontSize: 13,
                ),
          ),
        ],
      ),
    );
  }
}
