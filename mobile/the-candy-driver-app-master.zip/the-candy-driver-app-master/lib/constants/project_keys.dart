class ProjectKeys {
  static String openStreetMapKey = "0125df3588f94413b319d6a86fb31196";
  static String mapBoxKey =
      "pk.eyJ1IjoidGhlY2FuZHkiLCJhIjoiY2tmdGh4aDAyMHdiYzJ6bXp6aHp6M253ayJ9.AyIsbpxLgpq_8mCpy1-IUA";
}
