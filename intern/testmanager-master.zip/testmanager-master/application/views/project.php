<?php

addJS([
    'assets/js/views/project.js',
]);

if(!isset($project)) callback_whenNotFound();


viewHeader(
        $project->name,
        'Project dashboard',
        [
            (object) ['name' => 'Dashboard', 'url' => site_url()],
            (object) ['name' => 'Projects', 'url' => site_url('projects')],
            (object) ['name' => $project->name, 'url' => ''],
        ], true);

projectMenu('dashboard', $project);
?>





<div class="project_body n_menu">

    <div class="project_stats_top">
        <div class="pst_stat">
            <span class="i"><i class="fas fa-tasks"></i></span>
            <b>0</b>
            <label>Tasks</label>
        </div>
        <div class="pst_stat">
            <span class="i"><i class="fas fa-hdd"></i></span>
            <b>0</b>
            <label>Files</label>
        </div>
        <div class="pst_stat">
            <span class="i"><i class="fas fa-cogs"></i></span>
            <b><?= $stats->plans; ?></b>
            <label>Test Plans</label>
        </div>
        <div class="pst_stat">
            <span class="i"><i class="fas fa-flask"></i></span>
            <b><?= $stats->cases; ?></b>
            <label>Test Cases</label>
        </div>
        <div class="pst_stat">
            <span class="i"><i class="fas fa-code-branch"></i></span>
            <b><?= $stats->miles; ?></b>
            <label>Releases</label>
        </div>
        <div class="pst_stat b">
            <span class="i"><i class="fas fa-code-branch"></i></span>
            <b><?= $stats->last_mile ?: '(EMPTY)'; ?></b>
            <label>Current Release</label>
        </div>
    </div>



    <div class="project_inner_body">

        <div class="panel">
            <div class="panel_head">
                <div class="panel_title">
                    <span class="i"><i class="fas fa-list"></i></span>
                    <h3>Activities</h3>
                </div>

                <div class="panel_actions">
                    <button class="btnx btn btn-sm btn-outline-dark refresh_activity"><i class="fas fa-sync"></i></button>
                </div>

            </div>
            <div class="panel_body">
                <div class="nodata">No activity</div>
            </div>
            <div class="panel_foot"></div>
        </div>
        <div class="panel">
            <div class="panel_head">
                <div class="panel_title">
                    <span class="i"><i class="fas fa-list"></i></span>
                    <h3>Team</h3>
                </div>

                <div class="panel_actions">

                </div>

            </div>
            <div class="panel_body">

                <div class="project_members">

                </div>


            </div>
            <div class="panel_foot"></div>
        </div>


    </div>


</div>

<script>
    var project_id = <?= $project->id ?: 0 ?>;
</script>

