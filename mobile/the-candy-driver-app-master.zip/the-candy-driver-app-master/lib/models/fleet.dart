class Fleet {
  String id;
  String displayName;

  Fleet({this.id, this.displayName});

  Fleet.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    displayName = json['display_name'];
  }
}
