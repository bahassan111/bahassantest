import 'dart:convert';

import 'package:driver/constants/helpers/formaters.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:driver/models/instant_booking_ride.dart';
import 'package:driver/models/notification/notification.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';

FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

    PreBookingController preTo = Get.find();

Future<dynamic> myBackgroundMessageHandler(Map<String, dynamic> message) async {
  HomeController homeTo = HomeController();
  showNotificationWithDefaultSound(message, );
  homeTo.getTrip();

  Get.snackbar("myBackgroundMessageHandler", "$message");
  print("BACKKKKKK");
  if (message.containsKey('data')) {
    final dynamic data = message['data'];
    print("data $data");
    homeTo.getTrip();
  }

  if (message.containsKey('notification')) {
    final dynamic notification = message['notification'];
    print("data $notification");
    homeTo.getTrip();
  }
}

Future showNotificationWithDefaultSound(
    Map<dynamic, dynamic> message, ) async {
  //tone.mp3
  NotificationResponse notificationResponse =
      NotificationResponse.fromJsonMap(jsonDecode(jsonEncode(message)));
  var androidPlatformChannelSpecifics = AndroidNotificationDetails(
    'your channel id',
    'your channel name',
    'your channel description',
    color:
        notificationResponse.notificationDataModel?.color ?? Color(0xff203E78),
    importance: Importance.max,
    icon: "logo",
    priority: Priority.high,
    playSound: true,
    sound: RawResourceAndroidNotificationSound('tone'),
  );
  var iOSPlatformChannelSpecifics = IOSNotificationDetails(
    sound: 'tone',
  );
  var platformChannelSpecifics = NotificationDetails(
    android: androidPlatformChannelSpecifics,
    iOS: iOSPlatformChannelSpecifics,
  );
   var prebook = await preTo.getUpbookings() ;
        if(prebook.length > 0 && prebook[0] is RideDetailModel) {
          print("XXXXXX" + prebook.toString() );
          print ("XXXX" + ((strinToDateTime((prebook[0] as RideDetailModel).bookDate)).difference(DateTime.now()).inMinutes.toString()) );
       if ((strinToDateTime((prebook[0] as RideDetailModel).bookDate)).difference(DateTime.now()).inMinutes <40  && message["notification"]["body"].indexOf("You have recieved auto booking") != -1)
   { return;}
   else { if (flutterLocalNotificationsPlugin != null )
    await flutterLocalNotificationsPlugin.show(
      0,
      notificationResponse.notification != null
          ? notificationResponse.notificationDataModel.title
          : "New Notification",
      notificationResponse.notification != null
          ? notificationResponse.notificationDataModel.body
          : "",
      platformChannelSpecifics,
      payload: 'Default_Sound',
    );}
        }
        else {if (flutterLocalNotificationsPlugin != null )
    await flutterLocalNotificationsPlugin.show(
      0,
      notificationResponse.notification != null
          ? notificationResponse.notificationDataModel.title
          : "New Notification",
      notificationResponse.notification != null
          ? notificationResponse.notificationDataModel.body
          : "",
      platformChannelSpecifics,
      payload: 'Default_Sound',
    );}
}

Future notificationOnMessage(Map<String, dynamic> message) async {
  print("notificationOnMessage $message");
}
    