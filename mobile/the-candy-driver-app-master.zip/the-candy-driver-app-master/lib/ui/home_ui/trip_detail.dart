import 'dart:async';
import 'dart:convert';

import 'package:audioplayers/audio_cache.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:bot_toast/bot_toast.dart';
import 'package:driver/constants/constants.dart';
import 'package:driver/constants/helpers/helpers.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:driver/ui/components/components.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:url_launcher/url_launcher.dart';

class TripDetail extends StatefulWidget {
  @override
  _TripDetailState createState() => _TripDetailState();
}

class _TripDetailState extends State<TripDetail> {
  static HomeController to = Get.find();
  static AuthController authTo = Get.find();
  static MyMapController mapTo = Get.find();
  static PreBookingController preTo = Get.find();
  final store = GetStorage();

  Timer _timer;
  int _start = 10;
  AudioCache cache = AudioCache();
  AudioPlayer player;
  @override
  void initState() {
    super.initState();
    startTimer();
  }

  startTone() async {
    player = await cache.play(Tones.bookingCancel).onError((error, stackTrace) {
      return null;
    }).whenComplete(() {});
  }

  void startTimer() async {
    const oneSec = const Duration(milliseconds: 300);
    _timer = new Timer.periodic(
      oneSec,
      (Timer timer) async {
        if (_start == 0) {
          setState(() {
            timer.cancel();
          });
        } else {
          alreadyAssignToSomeOneElseCheck();
        }
      },
    );
  }

  alreadyAssignToSomeOneElseCheck() async {
    final status = await to.driverAlreadyassignRide();
    print("to.rideDetail.rideStatus $status ${status.runtimeType}");
    if (int.tryParse(status.toString()) >= 1) {
      _timer?.cancel();
      startTone();
      BotToast.showWidget(
        toastBuilder: (_) => SuccessDialog(
          title: "alert".tr,
          message: "This ride is Already assigned to another driver",
          ontap: () {
            to.rideDetail = null;
            mapTo.mapMatchingModel = null;
            mapTo.routeDetail.value = null;
            to.homeScreenStatus.value = HomeScreenStatus.None;
            store.remove("current_ride");
            player.stop();
            BotToast.cleanAll();
          },
        ),
      );
      return true;
    }
    return false;
  }

  @override
  void dispose() {
    _timer?.cancel();
    player?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          SizedBox(
            height: 10,
          ),
          displayDetail(
            title: "booking_date".tr + ": ",
            value: datedayddMMMyyyy(
              strinToDateTime(to.rideDetail.bookDate),
            ),
          ),
          SizedBox(height: 2),
          displayDetail(
            title: "booking_number".tr + ": ",
            value: getBookType(to.rideDetail.bookType) +
                to.rideDetail.id +
                to.rideDetail.categoryCode,
          ),
          SizedBox(height: 2),
          displayDetail(
            title: "charter_time".tr + ": ",
            value: to.rideDetail.waitingTime + " " + "hours".tr,
            fontColor: AppThemes.lightdeepPinkDropDownIconColor,
          ),
          Divider(
            thickness: 1,
            color: Colors.black,
          ),
          tripDetail(
            context,
            name: to.rideDetail.fullname,
            number: to.rideDetail.mobile,
            currency: to.rideDetail.currency,
            totalfare: to.rideDetail.totalfare,
          ),
          Divider(
            thickness: 1,
            color: Colors.black,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                Text(
                  "remark".tr + ": ",
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                ),
                Expanded(
                  child: Text(
                    to.rideDetail.note,
                    style: TextStyle(fontSize: 14),
                  ),
                ),
              ],
            ),
          ),
          pickUpDetails(),
          SizedBox(
            height: 10,
          ),
        ],
      ),
    );
  }

  pickUpDetails() {
    return Container(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            height: 10,
          ),
          Text(
            "pick_up_location".tr,
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
          ),
          SizedBox(
            height: 5,
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              to.rideDetail.pickupaddress,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                Expanded(
                  child: RoundButton(
                    text: "proceed".tr,
                    onTap: () async {
                      preTo.procededPreBooking = true;
                      _timer.cancel();
                      BotToast.showLoading();
                      bool isAlreadyAssign =
                          await alreadyAssignToSomeOneElseCheck();
                      print("isAlreadyAssign $isAlreadyAssign");
                      if (!isAlreadyAssign) {
                        // to.selectedJobType = "IB";
                        BotToast.cleanAll();
                        await to.changeRideStatus(
                          rideId: int.tryParse(to.rideDetail.id),
                          statusType: 1,
                          bookType: int.tryParse(to.rideDetail.bookType),
                          driverId: int.tryParse(authTo.userModel.id),
                          startTime: null,
                          driverArrivaltime: null,
                          countryId: int.tryParse(to.rideDetail.countryId),
                          navigateTo: HomeScreenStatus.Procced,
                        );
                        to.rideDetail.rideStatus = '1';
                        store.write(
                          "current_ride",
                          json.encode(
                            to.rideDetail.toJson(),
                          ),
                        );
                      } else {
                        store.remove("current_ride");
                      }
                    },
                    textStyle: AppThemes.lightTheme.textTheme.headline1
                        .copyWith(fontSize: 15, fontWeight: FontWeight.w600),
                  ),
                ),
                SizedBox(
                  width: 30,
                ),
                Expanded(
                  child: RoundButton(
                    text: "cancel".tr,
                    onTap: () {
                      to.cancelRide(
                          countryId: int.tryParse(to.rideDetail.countryId),
                          rideId: int.tryParse(to.rideDetail.id));
                      to.rideDetail = null;
                      to.homeScreenStatus.value = HomeScreenStatus.None;
                      BotToast.showWidget(
                        toastBuilder: (_) => SuccessDialog(
                          title: "alert".tr,
                          message: "ride_cancel".tr,
                          ontap: () {
                            to.rideDetail = null;
                            mapTo.mapMatchingModel = null;
                            mapTo.routeDetail.value = null;
                            to.homeScreenStatus.value = HomeScreenStatus.None;
                            store.remove("current_ride");
                            BotToast.cleanAll();
                          },
                        ),
                      );
                    },
                    textStyle: AppThemes.lightTheme.textTheme.headline1
                        .copyWith(fontSize: 15, fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  tripDetail(context,
      {String name, String number, String currency, String totalfare}) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          Image.asset(
            AllImages.passangerIcon,
            height: 40,
            fit: BoxFit.cover,
          ),
          SizedBox(
            width: 10,
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                name,
                style: AppThemes.lightTheme.textTheme.headline1
                    .copyWith(fontSize: 15),
              ),
              GestureDetector(
                onTap: () async {
                  String url = 'tel:' + to.rideDetail.mobile.toString();
                  if (await canLaunch(url)) {
                    await launch(url);
                  }
                },
                child: Text(
                  number,
                  style: AppThemes.lightTheme.textTheme.headline5.copyWith(
                    fontSize: 15,
                  ),
                ),
              ),
            ],
          ),
          Spacer(),
          Image.asset(
            AllImages.money,
            height: 35,
          ),
          SizedBox(
            width: 15,
          ),
          Text(
            (currency ?? "no currency") +
                " " +
                (double.tryParse(totalfare)?.toStringAsFixed(2) ?? "") +
                '',
            style: TextStyle(fontSize: 15),
          ),
          SizedBox(
            width: 20,
          ),
        ],
      ),
    );
  }

  displayDetail({String title, String value, Function onTap, Color fontColor}) {
    return GestureDetector(
      onTap: onTap != null ? onTap : () {},
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 20),
        child: Row(
          children: [
            Text(
              title,
              style: TextStyle(
                  fontSize: 15, fontWeight: FontWeight.bold, color: fontColor),
            ),
            Expanded(
              child: Text(
                value,
                style: TextStyle(fontSize: 14, color: fontColor),
                maxLines: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
