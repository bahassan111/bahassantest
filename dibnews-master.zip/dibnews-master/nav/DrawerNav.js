import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import MenuDrawer from "../componants/MenuDrawer";
import newsScreen from "../screens/newsScreen";
import cardsScreen from "../screens/cardsScreen";
import displayScreen from "../screens/displayScreen";
import catScreen from "../screens/catScreen";
import modernScreen from "../screens/modernScreen";
import cardsLightScreen from "../screens/cardsLightScreen";
import mainScreen from "../screens/mainScreen";
import categoryScreen from "../screens/categoryScreen";
import settingsScreen from "../screens/settingsScreen";
import aboutScreen from "../screens/aboutScreen";
import errorScreen from "../screens/errorScreen";

const DrawerNav = ()=>{
    const Drawer = createDrawerNavigator();


      return (
          <Drawer.Navigator openByDefault={false} drawerType={'slide'} initialRouteName="model" drawerContent={(props) => <MenuDrawer {...props} />}>
              <Drawer.Screen name="news" component={mainScreen} />
              <Drawer.Screen name="news2" component={cardsScreen} />
              <Drawer.Screen name="display" component={displayScreen} />
              <Drawer.Screen name="category" component={categoryScreen} />
              <Drawer.Screen name="news_light" component={cardsLightScreen} />
              <Drawer.Screen name="settings" component={settingsScreen} />
              <Drawer.Screen name="about" component={aboutScreen} />
              <Drawer.Screen name="error" component={errorScreen} />
          </Drawer.Navigator>

      );
};

export default DrawerNav;
