package ma.rak.ov.api;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Debug;
import android.util.Log;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import ma.rak.ov.bodyResponse.AbonnementResponse;
import ma.rak.ov.bodyResponse.AgentsResponse;
import ma.rak.ov.bodyResponse.BranchementResponse;
import ma.rak.ov.bodyResponse.HistoriqueAbonnementResponse;
import ma.rak.ov.bodyResponse.HistoriqueBranchementResponse;
import ma.rak.ov.bodyResponse.SettingsResponse;
import ma.rak.ov.models.Abonnement;
import ma.rak.ov.models.Agent;
import ma.rak.ov.models.Branchement;
import ma.rak.ov.models.Categorie;
import ma.rak.ov.models.CategorieBr;
import ma.rak.ov.models.Emplacement;
import ma.rak.ov.models.Motif;
import ma.rak.ov.models.MotifBr;
import ma.rak.ov.models.Nature;
import ma.rak.ov.models.NatureBr;
import ma.rak.ov.storage.SharedPrefManager;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TwSyncher {

    public static void init(Context ctx, Runnable onStep, Runnable onSuccess, Runnable onFailed, int index){

        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);
        SQLiteDatabase db = dbh.getWritableDatabase();



        if(index == 0){
            InitAgents(ctx, db, new Runnable() {
                @Override
                public void run() {
                    onStep.run();
                    init(ctx, onStep, onSuccess, onFailed, index+1);
                }
            }, new Runnable() {
                @Override
                public void run() {
                    onFailed.run();
                }
            });



        }else if(index == 1){
            InitSettings(ctx, db, new Runnable() {
                @Override
                public void run() {
                    onStep.run();
                    init(ctx, onStep, onSuccess, onFailed, index+1);
                }
            }, new Runnable() {
                @Override
                public void run() {
                    onFailed.run();
                }
            });
        }else if(index == 2){
            InitAbonnement(ctx, db, new Runnable() {
                @Override
                public void run() {
                    onStep.run();
                    init(ctx, onStep, onSuccess, onFailed, index+1);
                }
            }, new Runnable() {
                @Override
                public void run() {
                    onFailed.run();
                }
            });
        }else if(index == 3){
            InitBranchement(ctx, db, new Runnable() {
                @Override
                public void run() {
                    onStep.run();
                    init(ctx, onStep, onSuccess, onFailed, index+1);
                }
            }, new Runnable() {
                @Override
                public void run() {
                    onFailed.run();
                }
            });
        }else if(index == 4){
            InitAbonnementHistory(ctx, db, new Runnable() {
                @Override
                public void run() {
                    onStep.run();
                    init(ctx, onStep, onSuccess, onFailed, index+1);
                }
            }, new Runnable() {
                @Override
                public void run() {
                    onFailed.run();
                }
            });
        }else if(index == 5){
            InitBranchementHistory(ctx, db, new Runnable() {
                @Override
                public void run() {
                    onStep.run();
                    init(ctx, onStep, onSuccess, onFailed, index+1);
                }
            }, new Runnable() {
                @Override
                public void run() {
                    onFailed.run();
                }
            });
        }else{

            onSuccess.run();
        }





    }

    public static boolean isAgentsInit(Context ctx){
        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);
        return dbh.query(TwDatabase.ALLAgents.TABLE_NAME, null, null, null).size() > 0;
    }

    public static boolean isSettingsInit(Context ctx){
        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);
        return dbh.query(TwDatabase.ABMotifs.TABLE_NAME, null, null, null).size() > 0;
    }

    public static boolean isAbonnementInit(Context ctx){
        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);
        return dbh.query(TwDatabase.ABDemandes.TABLE_NAME, null, null, null).size() > 0;
    }

    public static boolean isBranchementInit(Context ctx){
        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);
        return dbh.query(TwDatabase.BRDemandes.TABLE_NAME, null, null, null).size() > 0;
    }

    public static boolean isBranchementHistoryInit(Context ctx){
        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);
        return dbh.query(TwDatabase.BRDemandes.TABLE_NAME, "STATDEVI not in (1, 2)", null, null).size() > 0;
    }

    public static boolean isAbonnementHistoryInit(Context ctx){
        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);
        return dbh.query(TwDatabase.ABDemandes.TABLE_NAME, "STATOPER != 1", null, null).size() > 0;
    }

    public static void InitAgents(Context ctx, SQLiteDatabase db, Runnable onSuccess, Runnable onFail){

        if(isAgentsInit(ctx)){
            onSuccess.run();
            return;
        }

        Log.e("xxxxxxxxxx", SharedPrefManager.getInstance(ctx).getToken());

        Call<AgentsResponse> call = RetrofitClient.getApi(SharedPrefManager.getInstance(ctx).getToken()).agents();

        call.enqueue(new Callback<AgentsResponse>() {
            @Override
            public void onResponse(Call<AgentsResponse> call, Response<AgentsResponse> response) {

                if(response.code() != 200){
                    onFail.run();
                    return;
                }

                for (Agent agent : response.body().getAgents()) {
                    ContentValues values = new ContentValues();
                    values.put(TwDatabase.ALLAgents.COL_KEY, agent.getCODEUTIL());
                    values.put(TwDatabase.ALLAgents.COL_LABEL, agent.getNOM_UTIL());
                    values.put(TwDatabase.ALLAgents.COL_TYPE, agent.getCODEPROF());
                    values.put(TwDatabase.ALLAgents.CODE_TSP, agent.getCODE_TSP());
                    values.put(TwDatabase.ALLAgents.COL_IMEI, agent.getIMEI());

                    long newRowId = db.insert(TwDatabase.ALLAgents.TABLE_NAME, null, values);
                    boolean inserted = newRowId > 0;
                }

                onSuccess.run();

            }

            @Override
            public void onFailure(Call<AgentsResponse> call, Throwable t) {
                onFail.run();
            }
        });

    }

    public static void InitSettings(Context ctx, SQLiteDatabase db, Runnable onSuccess, Runnable onFailed){

        if(isSettingsInit(ctx)){
            onSuccess.run();
            return;
        }

        Call<SettingsResponse> call = RetrofitClient.getApi(SharedPrefManager.getInstance(ctx).getToken()).settingsAb();

        call.enqueue(new Callback<SettingsResponse>() {
            @Override
            public void onResponse(Call<SettingsResponse> call, Response<SettingsResponse> response) {

                if(response.code() != 200){
                    onFailed.run();
                    return;
                }

                for (Categorie cat : response.body().getCategorie()) {
                    ContentValues values = new ContentValues();
                    values.put(TwDatabase.ABCats.COL_KEY, cat.getID());
                    values.put(TwDatabase.ABCats.COL_LABEL, cat.getLabel());
                    values.put(TwDatabase.ABCats.COL_GERANCE, cat.getCodegera());
                    long newRowId = db.insert(TwDatabase.ABCats.TABLE_NAME, null, values);
                }

                for (Nature nat : response.body().getNature()) {
                    ContentValues values = new ContentValues();
                    values.put(TwDatabase.ABNatures.COL_KEY, nat.getID());
                    values.put(TwDatabase.ABNatures.COL_LABEL, nat.getLabel());
                    values.put(TwDatabase.ABNatures.COL_GERANCE, nat.getCodegera());
                    values.put(TwDatabase.ABNatures.CODCATAB, nat.getCODCATAB());

                    long newRowId = db.insert(TwDatabase.ABNatures.TABLE_NAME, null, values);
                }

                for (Motif mot : response.body().getMotif()) {
                    ContentValues values = new ContentValues();
                    values.put(TwDatabase.ABMotifs.COL_KEY, mot.getID());
                    values.put(TwDatabase.ABMotifs.COL_LABEL, mot.getLabel());
                    values.put(TwDatabase.ABMotifs.COL_GERANCE, mot.getCodegera());

                    long newRowId = db.insert(TwDatabase.ABMotifs.TABLE_NAME, null, values);
                }

                for (Emplacement emp : response.body().getEmplacement()) {
                    ContentValues values = new ContentValues();
                    values.put(TwDatabase.ABEmplacements.COL_KEY, emp.getID());
                    values.put(TwDatabase.ABEmplacements.COL_LABEL, emp.getLabel());

                    long newRowId = db.insert(TwDatabase.ABEmplacements.TABLE_NAME, null, values);
                }



                for (MotifBr mot : response.body().getBranchement().getMotif()) {
                    ContentValues values = new ContentValues();
                    values.put(TwDatabase.BRMotifs.COL_KEY, mot.getID());
                    values.put(TwDatabase.BRMotifs.COL_LABEL, mot.getLabel());
                    values.put(TwDatabase.BRMotifs.COL_GERANCE, mot.getCodegera());
                    values.put(TwDatabase.BRMotifs.CODSTAOP, mot.getCodstaop());

                    long newRowId = db.insert(TwDatabase.BRMotifs.TABLE_NAME, null, values);
                }
                for (NatureBr nat : response.body().getBranchement().getNature()) {
                    ContentValues values = new ContentValues();
                    values.put(TwDatabase.BRNatures.COL_KEY, nat.getID());
                    values.put(TwDatabase.BRNatures.COL_LABEL, nat.getLabel());
                    values.put(TwDatabase.BRNatures.CODCATAB, nat.getCODCATAB());
                    values.put(TwDatabase.BRNatures.CODNATIN, nat.getCODNATIN());
                    values.put(TwDatabase.BRNatures.CALICOMP, nat.getCALICOMP());
                    values.put(TwDatabase.BRNatures.NOMBFILS, nat.getNOMBFILS());
                    values.put(TwDatabase.BRNatures.INTENSIT, nat.getINTENSIT());
                    values.put(TwDatabase.BRNatures.TENSELEC, nat.getTENSELEC());
                    values.put(TwDatabase.BRNatures.PUISSANC, nat.getPUISSANC());

                    long newRowId = db.insert(TwDatabase.BRNatures.TABLE_NAME, null, values);
                }
                for (CategorieBr cat : response.body().getBranchement().getCategorie()) {
                    ContentValues values = new ContentValues();
                    values.put(TwDatabase.BRCats.COL_KEY, cat.getID());
                    values.put(TwDatabase.BRCats.COL_LABEL, cat.getLabel());
                    values.put(TwDatabase.BRCats.COL_GERANCE, cat.getCODEGERA());
                    long newRowId = db.insert(TwDatabase.BRCats.TABLE_NAME, null, values);
                }




                onSuccess.run();

            }

            @Override
            public void onFailure(Call<SettingsResponse> call, Throwable t) {
                onFailed.run();
            }
        });

    }

    public static void InitAbonnement(Context ctx, SQLiteDatabase db, Runnable onSuccess, Runnable onFailed){

        if(isAbonnementInit(ctx)){
            onSuccess.run();
            return;
        }




        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);

        Call<AbonnementResponse> call = RetrofitClient.getApi(SharedPrefManager.getInstance(ctx).getToken()).abonnemnts(1);

        call.enqueue(new Callback<AbonnementResponse>() {
            @Override
            public void onResponse(Call<AbonnementResponse> call, Response<AbonnementResponse> response) {

                if(response.code() != 200){
                    onFailed.run();
                    return;
                }



                for (Abonnement ab : response.body().getData()) {
                    dbh.insertDemandeAbonnement(ab);
                }

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String currentDateandTime = sdf.format(new Date());
                SharedPrefManager.getInstance(ctx).setFetchTime(currentDateandTime);

                onSuccess.run();
            }

            @Override
            public void onFailure(Call<AbonnementResponse> call, Throwable t) {
                onFailed.run();
            }
        });
    }

    public static void InitAbonnementHistory(Context ctx, SQLiteDatabase db, Runnable onSuccess, Runnable onFailed){



        if(isAbonnementHistoryInit(ctx)){
            onSuccess.run();
            return;
        }

        if(true){
            onSuccess.run();
            return;
        }else{
            TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);

            Call<HistoriqueAbonnementResponse> call = RetrofitClient.getApi(SharedPrefManager.getInstance(ctx).getToken()).historiquesAb(1);

            call.enqueue(new Callback<HistoriqueAbonnementResponse>() {
                @Override
                public void onResponse(Call<HistoriqueAbonnementResponse> call, Response<HistoriqueAbonnementResponse> response) {

                    if(response.code() != 200){
                        onFailed.run();
                        return;
                    }

                    for (Abonnement ab : response.body().getData()) {
                        dbh.insertDemandeAbonnement(ab);
                    }

                    onSuccess.run();
                }

                @Override
                public void onFailure(Call<HistoriqueAbonnementResponse> call, Throwable t) {
                    onFailed.run();
                }
            });
        }


    }




    public static void InitBranchement(Context ctx, SQLiteDatabase db, Runnable onSuccess, Runnable onFailed){

        if(isBranchementInit(ctx)){
            onSuccess.run();
            return;
        }

        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);

        Call<BranchementResponse> call = RetrofitClient.getApi(SharedPrefManager.getInstance(ctx).getToken()).branchements(1);

        call.enqueue(new Callback<BranchementResponse>() {
            @Override
            public void onResponse(Call<BranchementResponse> call, Response<BranchementResponse> response) {

                if(response.code() != 200){
                    onFailed.run();
                    return;
                }


                for (Branchement ab : response.body().getData()) {
                    dbh.insertDemandeBranchement(ab);
                }

                onSuccess.run();
            }

            @Override
            public void onFailure(Call<BranchementResponse> call, Throwable t) {
                onFailed.run();
            }
        });
    }
    public static void InitBranchementHistory(Context ctx, SQLiteDatabase db, Runnable onSuccess, Runnable onFailed){

        if(isBranchementHistoryInit(ctx)){
            onSuccess.run();
            return;
        }

        if(true){
            onSuccess.run();
            return;
        }else{
            TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);

            Call<HistoriqueBranchementResponse> call = RetrofitClient.getApi(SharedPrefManager.getInstance(ctx).getToken()).historiquesBr(1);

            call.enqueue(new Callback<HistoriqueBranchementResponse>() {
                @Override
                public void onResponse(Call<HistoriqueBranchementResponse> call, Response<HistoriqueBranchementResponse> response) {

                    if(response.code() != 200){
                        onFailed.run();
                        return;
                    }

                    for (Branchement ab : response.body().getData()) {
                        dbh.insertDemandeBranchement(ab);
                    }

                    onSuccess.run();
                }

                @Override
                public void onFailure(Call<HistoriqueBranchementResponse> call, Throwable t) {
                    onFailed.run();
                }
            });
        }


    }



    public static void getNewAbonnement(Context ctx, SQLiteDatabase db, Runnable onSuccess, Runnable onFailed){

        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);

        String last_date = SharedPrefManager.getInstance(ctx).getFetchTime();
        if(last_date == null || last_date.equals("")){
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            last_date = sdf.format(new Date());
        }

        Call<AbonnementResponse> call = RetrofitClient.getApi(SharedPrefManager.getInstance(ctx).getToken()).new_abonnemnts(last_date);

        call.enqueue(new Callback<AbonnementResponse>() {
            @Override
            public void onResponse(Call<AbonnementResponse> call, Response<AbonnementResponse> response) {

                if(response.code() != 200){
                    onFailed.run();
                    return;
                }


                //Toast.makeText(ctx, "Found new " + String.valueOf(response.body().getData().size()) + " new operations", Toast.LENGTH_LONG).show();

                for (Abonnement ab : response.body().getData()) {

                    boolean exists = dbh.query(TwDatabase.ABDemandes.TABLE_NAME, "ANNEDOSS = ? AND NUMEDOSS = ? AND NUMOPRAB = ? AND CODEGERA = ?", new String[]{ab.getANNEDOSS(), ab.getNUMEDOSS(), ab.getNUMOPRAB(), ab.getCODEGERA()}, null).size() > 0;

                    if(exists){
                        dbh.getWritableDatabase().delete(TwDatabase.ABDemandes.TABLE_NAME,"ANNEDOSS = ? AND NUMEDOSS = ? AND NUMOPRAB = ? AND CODEGERA = ?", new String[]{ab.getANNEDOSS(), ab.getNUMEDOSS(), ab.getNUMOPRAB(), ab.getCODEGERA()});
                    }

                    dbh.insertDemandeAbonnement(ab);
                }

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String currentDateandTime = sdf.format(new Date());
                SharedPrefManager.getInstance(ctx).setFetchTime(currentDateandTime);

                onSuccess.run();
            }

            @Override
            public void onFailure(Call<AbonnementResponse> call, Throwable t) {
                onFailed.run();
            }
        });
    }
    public static void getNewBranchement(Context ctx, SQLiteDatabase db, Runnable onSuccess, Runnable onFailed){

        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);

        String last_date = SharedPrefManager.getInstance(ctx).getFetchTime();
        if(last_date == null || last_date.equals("")){
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            last_date = sdf.format(new Date());
        }

        Call<BranchementResponse> call = RetrofitClient.getApi(SharedPrefManager.getInstance(ctx).getToken()).new_branchement(last_date);

        call.enqueue(new Callback<BranchementResponse>() {
            @Override
            public void onResponse(Call<BranchementResponse> call, Response<BranchementResponse> response) {

                if(response.code() != 200){
                    onFailed.run();
                    return;
                }


                //Toast.makeText(ctx, "Found new " + String.valueOf(response.body().getData().size()) + " new operations", Toast.LENGTH_LONG).show();

                for (Branchement ab : response.body().getData()) {

                    boolean exists = dbh.query(TwDatabase.BRDemandes.TABLE_NAME, "ANNDEMDE = ? AND NUMDEMDE = ? AND NUMOPEDE = ? AND CODEGERA = ?", new String[]{ab.getANNDEMDE(), ab.getNUMDEMDE(), ab.getNUMOPEDE(), ab.getCODEGERA()}, null).size() > 0;

                    if(exists){
                        dbh.getWritableDatabase().delete(TwDatabase.BRDemandes.TABLE_NAME,"ANNDEMDE = ? AND NUMDEMDE = ? AND NUMOPEDE = ? AND CODEGERA = ?", new String[]{ab.getANNDEMDE(), ab.getNUMDEMDE(), ab.getNUMOPEDE(), ab.getCODEGERA()});
                    }

                    dbh.insertDemandeBranchement(ab);
                }

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String currentDateandTime = sdf.format(new Date());
                SharedPrefManager.getInstance(ctx).setFetchTime(currentDateandTime);

                onSuccess.run();
            }

            @Override
            public void onFailure(Call<BranchementResponse> call, Throwable t) {
                onFailed.run();
            }
        });
    }

}
