package ma.rak.ov.adapter;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Parcelable;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import ma.rak.ov.R;
import ma.rak.ov.models.Abonnement;
import ma.rak.ov.models.Branchement;
import ma.rak.ov.models.Dossier;
import ma.rak.ov.storage.SharedPrefManager;
import ma.rak.ov.ui.main.AffecterFragment;
import ma.rak.ov.ui.main.ExecutionFragment;
import ma.rak.ov.ui.main.RejectFragment;

import static ma.rak.ov.R.drawable.bg_electricite;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;

    private FragmentActivity mContext;
    private List<Branchement> branchementList;
    private List<Abonnement> abonnementList;
    private final String TAG = getClass().getSimpleName();

    private PopupWindow mPopupWindow;


    public RecyclerViewAdapter(FragmentActivity mContext, List<Branchement> branchementList, List<Abonnement> abonnementList) {
        this.mContext = mContext;
        this.branchementList = branchementList;
        this.abonnementList = abonnementList;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_pending_list, parent, false);
            return new ItemViewHolder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_loading, parent, false);
            return new LoadingViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int position) {

        if (viewHolder instanceof ItemViewHolder) {

            populateItemRows((ItemViewHolder) viewHolder, position);
        } else if (viewHolder instanceof LoadingViewHolder) {
            showLoadingView((LoadingViewHolder) viewHolder, position);
        }

    }

    @Override
    public int getItemCount() {
        if (branchementList != null)
            return branchementList.size();
        else if (abonnementList != null)
            return abonnementList.size();
        else
            return 0;
    }

    public void addAllAb(List<Abonnement> items) {
        for (Abonnement item : items)
            addAb(item);
    }

    public void addAb(Abonnement item) {
        abonnementList.add(item);
        notifyItemInserted(abonnementList.size() - 1);
    }

    public void addAllBr(List<Branchement> items) {
        for (Branchement item : items)
            addBr(item);
    }

    public void addBr(Branchement item) {
        branchementList.add(item);
        notifyItemInserted(branchementList.size() - 1);
    }

    public void setList(List<Branchement> branchementList, List<Abonnement> abonnementList) {
        this.branchementList = branchementList;
        this.abonnementList = abonnementList;
        notifyDataSetChanged();
    }

    public void clear() {
        this.branchementList = null;
        this.abonnementList = null;
        notifyDataSetChanged();
    }

    /**
     * The following method decides the type of ViewHolder to display in the RecyclerView
     *
     * @param position
     * @return
     */
    @Override
    public int getItemViewType(int position) {
        if (branchementList != null) {
            return branchementList.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
        } else if (abonnementList != null) {
            return abonnementList.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
        }

        return VIEW_TYPE_ITEM;
    }


    private class ItemViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView tvItem;
        public final View mView;
        public final TextView mContentView, mAddressView, mSectorView, mLIBEGERA;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            mView = itemView;
            mContentView = (TextView) itemView.findViewById(R.id.client_name);
            mAddressView = (TextView) itemView.findViewById(R.id.client_address);
            mSectorView = (TextView) itemView.findViewById(R.id.client_sector);
            mLIBEGERA = (TextView) itemView.findViewById(R.id.LIBEGERA);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            Log.d(TAG, "Clicked!" + position);
            final View customView = LayoutInflater.from(mContext).inflate(R.layout.custom_layout, null);

            TextView client_name = customView.findViewById(R.id.client_name);
            TextView dossier_id = customView.findViewById(R.id.dossier_id);
            TextView client_address = customView.findViewById(R.id.client_address);
            TextView date_operation = customView.findViewById(R.id.date_operation);
            //TextView client_reference = customView.findViewById(R.id.client_reference);
            TextView type_id = customView.findViewById(R.id.type_id);
            //TextView nature_operation = customView.findViewById(R.id.nature_operation);
            Button operationExecute = customView.findViewById(R.id.operationExecute);
            Button operationReject = customView.findViewById(R.id.operationReject);
            Button operationNoExecution = customView.findViewById(R.id.operationNoExecution);
            Button operationReaf = customView.findViewById(R.id.operationReaf);


            Intent execution = new Intent(mContext, ExecutionFragment.class);
            Intent reject = new Intent(mContext, RejectFragment.class);
            Intent noExecution = new Intent(mContext, RejectFragment.class);
            Intent affecter = new Intent(mContext, AffecterFragment.class);

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String currentDateandTime = sdf.format(new Date());


            mPopupWindow = new PopupWindow(
                    customView,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    true
            );


            if (SharedPrefManager.getInstance(mContext).getMode() == 1) {

                Branchement clickerItem = branchementList.get(position);

                client_name.setText(clickerItem.getNOM());
                dossier_id.setText(clickerItem.getNUMDEMDE());
                client_address.setText(clickerItem.getADRESDEVI());
                date_operation.setText(clickerItem.getDATSAIDE());
                //client_reference.setText(clickerItem.getCODEGERA());
                type_id.setText(clickerItem.getSTATDEVI());
                //nature_operation.setText(clickerItem.getCATEDEVI());
            } else {
                Abonnement clickerItem = abonnementList.get(position);

                client_name.setText(clickerItem.getNOM());
                dossier_id.setText(clickerItem.getNUMEDOSS());
                client_address.setText(clickerItem.getADRELOCA());
                date_operation.setText(clickerItem.getDATDEMAB());
                //client_reference.setText(clickerItem.getNUMETOUR());
                type_id.setText(clickerItem.getTYPECLIE());
                //nature_operation.setText(clickerItem.getCODNATCL());

                ArrayList<Dossier> doss = null;
                
                for(int i=0; i<clickerItem.getDOSSIERS().size(); i++){
                    doss.add(clickerItem.getDOSSIERS().get(i));
                }


                execution.putExtra("status", "2");
                execution.putExtra("date", currentDateandTime);
                execution.putExtra("doss_annee", clickerItem.getANNEDOSS());
                execution.putExtra("doss_numm", clickerItem.getNUMEDOSS());
                execution.putExtra("num_operation", clickerItem.getNUMETOUR());
                execution.putExtra("gerance", clickerItem.getCODEGERA());
                execution.putExtra("adreloca", clickerItem.getADRELOCA());
                execution.putParcelableArrayListExtra("dossier", doss);

                reject.putExtra("status", "3");
                reject.putExtra("date", currentDateandTime);
                reject.putExtra("doss_annee", clickerItem.getANNEDOSS());
                reject.putExtra("doss_numm", clickerItem.getNUMEDOSS());
                reject.putExtra("num_operation", clickerItem.getNUMETOUR());
                reject.putExtra("gerance", clickerItem.getCODEGERA());
                reject.putExtra("adreloca", clickerItem.getADRELOCA());

                noExecution.putExtra("status", "4");
                noExecution.putExtra("date", currentDateandTime);
                noExecution.putExtra("doss_annee", clickerItem.getANNEDOSS());
                noExecution.putExtra("doss_numm", clickerItem.getNUMEDOSS());
                noExecution.putExtra("num_operation", clickerItem.getNUMETOUR());
                noExecution.putExtra("gerance", clickerItem.getCODEGERA());
                noExecution.putExtra("adreloca", clickerItem.getADRELOCA());

                affecter.putExtra("status", "4");
                affecter.putExtra("date", currentDateandTime);
                affecter.putExtra("doss_annee", clickerItem.getANNEDOSS());
                affecter.putExtra("doss_numm", clickerItem.getNUMEDOSS());
                affecter.putExtra("num_operation", clickerItem.getNUMETOUR());
                affecter.putExtra("gerance", clickerItem.getCODEGERA());
                affecter.putExtra("adreloca", clickerItem.getADRELOCA());
            }

            operationExecute.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mPopupWindow.dismiss();
                    mContext.startActivity(execution);
                }
            });

            operationReject.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mPopupWindow.dismiss();
                    mContext.startActivity(reject);
                }
            });


            String scoop = SharedPrefManager.getInstance(mContext).getScoop();

            if (scoop.equals("Superviseur")) {
                operationReaf.setVisibility(View.VISIBLE);
            } else {
                operationReaf.setVisibility(View.INVISIBLE);
            }

            operationReaf.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mPopupWindow.dismiss();
                    mContext.startActivity(affecter);
                }
            });

            operationNoExecution.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mPopupWindow.dismiss();
                    noExecution.putExtra("status", "4");
                    mContext.startActivity(noExecution);
                }
            });


            // Initialize a new instance of popup window


            // Set an elevation value for popup window
            // Call requires API level 21
            if (Build.VERSION.SDK_INT >= 21) {
                mPopupWindow.setElevation(100);
            }

            // Get a reference for the custom view close button
            ImageButton closeButton = (ImageButton) customView.findViewById(R.id.ib_close);

            // Set a click listener for the popup window close button
            closeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // Dismiss the popup window
                    mPopupWindow.dismiss();
                }
            });

            mPopupWindow.setBackgroundDrawable(new ColorDrawable(Color.argb(80, 59, 59, 59)));

            ConstraintLayout constraintLayout = (ConstraintLayout) mContext.findViewById(R.id.constraintLayoutMap);
            mPopupWindow.showAtLocation(customView, Gravity.BOTTOM, 0, 0);
        }
    }

    private class LoadingViewHolder extends RecyclerView.ViewHolder {

        ProgressBar progressBar;

        public LoadingViewHolder(@NonNull View itemView) {
            super(itemView);
            progressBar = itemView.findViewById(R.id.progressBar);
        }
    }

    private void showLoadingView(LoadingViewHolder viewHolder, int position) {
        //ProgressBar would be displayed

    }

    private void populateItemRows(ItemViewHolder viewHolder, int position) {

//        String item = mItemList.get(position);
//        viewHolder.tvItem.setText(item);
        if (branchementList != null) {
            Branchement branchement = branchementList.get(position);
            viewHolder.mContentView.setText(branchement.getNOM() + " #" + branchement.getNUMDEMDE());
            viewHolder.mAddressView.setText(branchement.getADRESDEVI());
            viewHolder.mLIBEGERA.setText(branchement.getLIBEGERA());
            if (branchement.getCODEGERA().equals("2"))
                viewHolder.mLIBEGERA.setBackground(ContextCompat.getDrawable(this.mContext, bg_electricite));
            viewHolder.mSectorView.setText("Secteur : 000 | Tournée: 000 | Ordre: 0  ");
//            notifyItemChanged(holder.getAdapterPosition());

        }

        if (abonnementList != null) {
            Abonnement abonnement = abonnementList.get(position);
            viewHolder.mContentView.setText(abonnement.getNOM() + " #" + abonnement.getNUMETOUR());
            viewHolder.mAddressView.setText(abonnement.getADRELOCA());
            viewHolder.mLIBEGERA.setText(abonnement.getLIBEGERA());
            if (abonnement.getCODEGERA().equals("2"))
                viewHolder.mLIBEGERA.setBackground(ContextCompat.getDrawable(this.mContext, bg_electricite));
            viewHolder.mSectorView.setText("Secteur : " + abonnement.getCODESECT() + " | Tournée: " + abonnement.getNUMETOUR() + " | Ordre: 0  ");
//            notifyItemChanged(holder.getAdapterPosition());

        }

    }


}