<?php

class MessengerModel extends CI_Model{


    public function __construct()
    {
        parent::__construct();
    }


    public function getContacts($user){

        $q = $this->db->query("SELECT * FROM users u WHERE u.work_group = 1 AND u.deleted = 0 AND u.enabled = 1 AND u.id != ?", [$user]);

        $list = $q ? $q->result() : [];

        $q = $this->db->query("SELECT uc.* FROM users u JOIN user_contacts c ON c.id_user = u.id JOIN users uc ON uc.id = c.id_contact WHERE u.id = ? AND uc.deleted = 0 AND uc.enabled = 1 AND uc.work_group = 0", [$user]);

        $list = array_merge($list, $q ? $q->result() : []);

        return $list;
    }


    public function getGroups($user){

        $q = $this->db->query("SELECT * FROM user_groups ug LEFT JOIN `groups` g ON g.id = ug.id_group OR g.public = 1 WHERE ug.id_user = ?", [$user]);

        $list = $q ? $q->result() : [];

        return $list;
    }


    public function getLastChats($user){

        $q = $this->db->query("
        SELECT u.id, u.username, u.fullname, u.image, c.id_user, c.id_dist FROM chats c JOIN users u ON u.id = c.id_dist WHERE c.id_user = ? AND c.id_group is null GROUP BY u.id
        UNION ALL 
        SELECT u.id, u.username, u.fullname, u.image, c.id_user, c.id_dist FROM chats c JOIN users u ON u.id = c.id_user WHERE c.id_dist = ? AND c.id_group is null GROUP BY u.id", [$user, $user]);

        $list = $q ? $q->result() : [];

        foreach ($list as $row){

            $q = $this->db->query("SELECT * FROM chats WHERE id_dist = $row->id_dist AND id_user = $row->id_user ORDER BY id DESC limit 1");
            $row->last = $q ? $q->row() : null;

            if($row->last){
                $row->last->text = str_replace('\r\n', ' ', substr($row->last->text, 0, 20));
            }

        }

        return $list;
    }



}