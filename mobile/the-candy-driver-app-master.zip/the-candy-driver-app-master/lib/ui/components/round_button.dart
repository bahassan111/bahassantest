import 'package:driver/constants/constants.dart';
import 'package:flutter/material.dart';

class RoundButton extends StatelessWidget {
  final String text;
  final Function onTap;
  final Color backgroundColor;
  final TextStyle textStyle;
  final double verticalPadding;
  RoundButton(
      {this.text,
      this.onTap,
      this.backgroundColor,
      this.textStyle,
      this.verticalPadding = 13});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: verticalPadding),
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          color: backgroundColor ?? AppThemes.lightRounderButtonColor,
        ),
        child: Center(
          child: Text(
            text,
            style: textStyle ??
                Theme.of(context).textTheme.subtitle1.copyWith(
                    fontFamily: 'NunitoSans',
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w700),
          ),
        ),
      ),
    );
  }
}
