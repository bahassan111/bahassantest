import {
  SET_FONT_SIZE,
  FETCH_FONT_SUCCESS,
  FETCH_FONTSIZE_SUCCESS,
  INCREASE_FONT_SIZE,
  DECREASE_FONT_SIZE,
  CHANGE_LANG_SUCCESS
} from "@redux/actions/types";

const initialState = {
  fontSize: 12,
  lang: null
};

export default (state = initialState, action) => {

  switch (action.type) {
    case SET_FONT_SIZE:
      return {
        ...state,
        fontSize: action.fontSize
      };

    case FETCH_FONT_SUCCESS:
      return {
        ...state,
        fontSize: action.fontSize,
        lang: action.lang,
        hasIntro: action.hasIntro
      };

    case FETCH_FONTSIZE_SUCCESS:
      return {
        ...state,
        fontSize: action.fontSize,
        lang: action.lang,
        hasIntro: action.hasIntro
      };

    case CHANGE_LANG_SUCCESS:
      return {
        ...state,
        lang: action.lang
      };

    case INCREASE_FONT_SIZE:
      return {
        ...state,
        fontSize: action.fontSize !== 28 ? action.fontSize + 4 : action.fontSize
      };
    case DECREASE_FONT_SIZE:
      return {
        fontSize: action.fontSize !== 12 ? action.fontSize - 4 : action.fontSize
      };

    default:
      return state;
  }
};
