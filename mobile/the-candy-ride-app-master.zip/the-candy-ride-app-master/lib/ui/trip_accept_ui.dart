import 'dart:async';
import 'dart:typed_data';
import 'dart:ui';
import 'package:audioplayers/audio_cache.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:bot_toast/bot_toast.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:logger/logger.dart';
import 'package:rider_app/constants/app_themes.dart';
import 'package:rider_app/constants/constants.dart';
import 'package:rider_app/controllers/controllers.dart';
import 'components/components.dart';
import 'package:get/get.dart';
import "package:latlong/latlong.dart";
import 'package:esys_flutter_share/esys_flutter_share.dart';
import 'package:vector_math/vector_math.dart' as fv;

class TripAceeptUI extends StatefulWidget {
  final int tripId;
  const TripAceeptUI({Key key, this.tripId}) : super(key: key);

  @override
  _TripAceeptUIState createState() => _TripAceeptUIState();
}

class _TripAceeptUIState extends State<TripAceeptUI> {
  bool isRiderCancleChanceAvailable = true;
  static TripAcceptController to = Get.find();
  static HomeController homeTo = Get.find();
  AudioCache cache = AudioCache();
  AudioPlayer player;
  void startTone() async {
    print("hani bdit");
    try {
      player = await cache
          .play(
        "images/instant_booking_tone.mp3",
      )
          .onError((error, stackTrace) {
        print("loop error $error");
        return null;
      }).whenComplete(() {
        print("loop complete");
      });
    } catch (e) {
      print("from play tone catch " + e.toString());
    }
  }

  int i = 0;
  Timer _timer;
  final MapController mapController = MapController();
  Timer _timerForGettingUpdatedStatus;
  var _firebaseRef = FirebaseDatabase().reference();
  GlobalKey globalKey = GlobalKey();
  LatLng currentDriverPosition;
  LatLng previousDriverPosition;
  @override
  void initState() {
    to.ride = null;
    to.driverImage = null;
    to.driverRating = null;
    to.tripId = widget.tripId;
    // to.rideStatus.addListener(() {
    //   Logger().d(to.rideStatus.value + " ride status from accept ui");
    //   if (to.rideStatus.value == RideStatus.driverArrived)
    //     to.getRideDetail().then((value) {
    //       Get.offAndToNamed('/TripStart');
    //     });
    // });
    Geolocator.getCurrentPosition().then((pos) {
      if (pos != null) {
        to.currentLocation = LatLng(pos.latitude, pos.longitude);
        setState(() {});
      }
    });
    to.getRideDetail(isShowLoadingIndicator: true).then((value) {
      if (to.ride == null) {
        return;
      }
      print("to.ride.rideStatus ${to.ride.rideStatus}");

      if (to.ride.rideStatus != '1') {
        Get.offAndToNamed('/TripStart');
      }

      setState(() {
        // trip is accepted then
        if (to.ride.driverArrivaltime == null) {
          print("to.ride.driverArrivaltime ${to.ride.driverArrivaltime}");
          setState(() {
            isRiderCancleChanceAvailable = false;
          });
        }
      });
    });

    _timerForGettingUpdatedStatus = Timer.periodic(Duration(seconds: 5), (_) {
      if (to.ride == null) {
        _timerForGettingUpdatedStatus?.cancel();
        _timer?.cancel();
        return;
      }
      to.getRideDetail().then((value) {
        // remove cancel opion if drive is arrive
        if (to.ride.driverArrivaltime != null) {
          if (mounted) {
            setState(() {
              isRiderCancleChanceAvailable = true;

              if (i == 0) {
                startTone();
                i++;
                Future.delayed(Duration(seconds: 5), () => player.stop());
              }
            });
          }
        }

        // move to start screen as driver start the trip
        if (to?.ride?.rideStatus != '1') {
          _timerForGettingUpdatedStatus?.cancel();
          _timer?.cancel();
          Get.offAndToNamed('/TripStart');
        }
      });
    });

    super.initState();
  }

  @override
  void dispose() {
    _timerForGettingUpdatedStatus?.cancel();
    _timer?.cancel();
    super.dispose();
  }

  Future<Uint8List> _capturePng() async {
    RenderRepaintBoundary boundary;
    try {
      boundary = globalKey.currentContext.findRenderObject();
    } catch (e) {}
    if (boundary == null) {
      print("Waiting for boundary to be painted.");
      await Future.delayed(const Duration(milliseconds: 20));
      return _capturePng();
    }
    try {
      var image = await boundary.toImage(pixelRatio: 3.0);
      var byteData = await image.toByteData(format: ImageByteFormat.png);

      return byteData.buffer.asUint8List();
    } catch (e) {}

    return null;
  }

  shareImage() async {
    BotToast.showLoading();
    var pngBytes = await _capturePng();
    print("pngBytes $pngBytes");
    try {
      await Share.file(
        'Trip detail',
        'tripdetail.png',
        pngBytes,
        'image/png',
        // text:
        //     "Driver name: ${to.ride.fname + " " + to.ride.lname}\n Vehicle Registration No: ${to.ride.plateNo}\n Trip ID: ${homeTo.tripId(
        //   id: to.ride.id,
        //   bookingType: to.ride.bookType,
        //   type: to.carType,
        // )}\n Driver Number: ${to.ride.driverMobile}",
      );
    } catch (e) {
      BotToast.showText(text: "shareImage $e");
    }
    BotToast.cleanAll();
  }

  reCenterMapPosition({double currentZoom}) async {
    mapController.move(currentDriverPosition, currentZoom ?? 17);
    mapController.rotate(0);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: RepaintBoundary(
        key: globalKey,
        child: Container(
          child: Column(
            children: [
              Expanded(
                  child: StreamBuilder<Position>(
                      stream: Geolocator.getCurrentPosition().asStream(),
                      builder: (context, snapshot) {
                        if (!snapshot.hasData) {
                          Geolocator.getCurrentPosition().then((pos) {
                            if (pos != null) {
                              to.currentLocation =
                                  LatLng(pos.latitude, pos.longitude);
                              mapController.move(to.currentLocation, 17);
                              mapController.rotate(0);
                              setState(() {});
                            }
                          });
                          return Center(child: CircularProgressIndicator());
                        }

                        return Container(
                            child: StreamBuilder(
                                stream: _firebaseRef
                                    .child(to?.ride?.driverId.toString() ?? -1)
                                    .onValue,
                                builder: (context, snapshot) {
                                  if (snapshot.hasData &&
                                      snapshot?.data?.snapshot?.value != null &&
                                      snapshot.data != null) {
                                    if (previousDriverPosition != null) {
                                      if ((previousDriverPosition.latitude -
                                                      (snapshot?.data?.snapshot
                                                              ?.value['lat'] ??
                                                          0.0))
                                                  .abs() >
                                              0.00001000 &&
                                          (previousDriverPosition.longitude -
                                                      (snapshot?.data?.snapshot
                                                              ?.value['lng'] ??
                                                          0.0))
                                                  .abs() >
                                              0.00001000) {
                                        reCenterMapPosition();
                                      }
                                    }
                                    previousDriverPosition =
                                        currentDriverPosition;
                                    if (snapshot?.data?.snapshot?.value != null)
                                      currentDriverPosition = LatLng(
                                          (snapshot?.data?.snapshot
                                                  ?.value['lat'] ??
                                              0.0),
                                          (snapshot?.data?.snapshot
                                                  ?.value['lng'] ??
                                              0.0));
                                  }

                                  // return
                                  return Stack(
                                    children: [
                                      FlutterMap(
                                        mapController: mapController,
                                        options: MapOptions(
                                          center: to.currentLocation,
                                          zoom: 17.0,
                                        ),
                                        layers: [
                                          TileLayerOptions(
                                            errorImage:
                                                AssetImage(AllImages.adddp),
                                            errorTileCallback: (tile, d) {
                                              print(
                                                  "from error tile call back 230 trip start " +
                                                      tile.toString() +
                                                      " " +
                                                      d.toString());
                                            },
                                            urlTemplate:
                                                Urls.mapBoxThirPartyUrl,
                                            additionalOptions: {
                                              'accessToken':
                                                  ProjectKeys.mapBoxKey,
                                              "id": "mapbox.mapbox-streets-v8",
                                            },
                                          ),
                                          PolylineLayerOptions(
                                            polylines:
                                                to?.routeDetail?.code == 'Ok'
                                                    ? [
                                                        Polyline(
                                                          points: [
                                                            ...to
                                                                    .mapMatchingModel
                                                                    ?.matchings
                                                                    ?.first
                                                                    ?.geometry
                                                                    ?.coordinates ??
                                                                []
                                                          ],
                                                          strokeWidth: 5,
                                                          color: AppThemes
                                                              .lightpauaBackGroundColor,
                                                        )
                                                      ]
                                                    : [],
                                            polylineCulling: true,
                                          ),
                                          MarkerLayerOptions(
                                            markers: to.ride == null
                                                ? []
                                                : [
                                                    if (snapshot?.data?.snapshot
                                                            ?.value !=
                                                        null)
                                                      Marker(
                                                        width: 40.0,
                                                        height: 40.0,
                                                        point: LatLng(
                                                          snapshot
                                                              ?.data
                                                              ?.snapshot
                                                              ?.value['lat'],
                                                          snapshot
                                                              ?.data
                                                              ?.snapshot
                                                              ?.value['lng'],
                                                        ),
                                                        builder: (ctx) =>
                                                            Transform.rotate(
                                                          angle: fv.radians((snapshot
                                                                          ?.data
                                                                          ?.snapshot
                                                                          ?.value[
                                                                      "bearing"] ??
                                                                  0.0) +
                                                              0.0),
                                                          child: Image.asset(
                                                              AllImages.newCar),
                                                        ),
                                                      ),
                                                    Marker(
                                                      width: 50.0,
                                                      height: 50.0,
                                                      point: LatLng(
                                                          double.parse(to
                                                              .ride.pickuplat),
                                                          double.parse(to.ride
                                                              .pickuplong)),
                                                      builder: (ctx) =>
                                                          Image.asset(
                                                              AllImages.pin),
                                                    ),
                                                    Marker(
                                                      width: 50.0,
                                                      height: 50.0,
                                                      point: LatLng(
                                                        double.parse(
                                                            to.ride.droplat),
                                                        double.parse(
                                                            to.ride.droplong),
                                                      ),
                                                      builder: (ctx) =>
                                                          Image.asset(AllImages
                                                              .pinGreen),
                                                    )
                                                  ],
                                          ),
                                        ],
                                      ),
                                      Align(
                                        alignment: Alignment.bottomRight,
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.end,
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            GestureDetector(
                                              onTap: shareImage,
                                              child: Container(
                                                padding: EdgeInsets.all(10),
                                                margin: EdgeInsets.only(
                                                    right: 10, bottom: 0),
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(50),
                                                  color: Colors.white,
                                                ),
                                                child: Icon(
                                                  Icons.share,
                                                  size: 25,
                                                ),
                                              ),
                                            ),
                                            to.mapMatchingModel?.matchings !=
                                                        null &&
                                                    to.ride != null
                                                ? TripDetail(
                                                    destination:
                                                        to.ride?.dropaddress ??
                                                            "NA",
                                                    distance: (double.parse(to
                                                                    .ride
                                                                    ?.distance)
                                                                .toPrecision(2))
                                                            .toString() +
                                                        " kms".tr,
                                                    time: (double.parse(to.ride
                                                                    ?.duration)
                                                                .toPrecision(2))
                                                            .toString() +
                                                        " mins".tr,
                                                  )
                                                : SizedBox.shrink()
                                          ],
                                        ),
                                      )
                                    ],
                                    // );
                                    // }),
                                    // );
                                    // },
                                  );
                                }));
                      })),
              Container(
                child: to.ride == null
                    ? Container()
                    : Column(
                        children: [
                          DriverDetail(),
                          VehicaleDetail(vehicleAdditionalInfo: Get.parameters),
                          Container(
                            color: Colors.white,
                            height: 15,
                          ),
                          isRiderCancleChanceAvailable
                              ? Container(
                                  width: MediaQuery.of(context).size.width,
                                  padding: EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                    border: Border(
                                      top: BorderSide(
                                        color:
                                            AppThemes.lightpauaBackGroundColor,
                                        width: 5,
                                      ),
                                    ),
                                  ),
                                  child: Center(
                                    child: Text(
                                      "wishYouASafeRide".tr,
                                      style: Theme.of(context)
                                          .textTheme
                                          .headline5
                                          .copyWith(
                                              fontSize: 18,
                                              fontWeight: FontWeight.w700),
                                    ),
                                  ),
                                )
                              : SquareButton(
                                  buttonColor:
                                      AppThemes.lightPinkBackGroundColor,
                                  onTap: () async {
                                    _timer?.cancel();
                                    await to.cancelTrip();
                                    Get.offAllNamed('/HomeUI');
                                  },
                                  text: "cancelTrip".tr,
                                )
                        ],
                      ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
