<?php ?>

<div class="view_header<?= $hasMenu ? ' n_menu' : '' ?>">
    <div class="page_title">
        <div class="bread_crumb">
            <?php foreach($crumb as $i => $item){ if($i === (count($crumb) -1)) continue; ?>
                <span><a href="<?= $item->url ?>"><?= $item->name; ?></a></span>
            <?php } ?>
            <span><?= $crumb[count($crumb) - 1]->name; ?></span>
        </div>
        <?php if($view){?><h3><?= $view; ?></h3><?php } ?>
        <?php if($desc){?><p><?= $desc; ?></p><?php } ?>
    </div>

    <div class="page_actions">
        <button data-editproject class="btn btn-outline-dark btn-sm"><i class="fas fa-pencil-alt"></i></button>
        <button data-editproject class="btn btn-outline-dark btn-sm"><i class="far fa-trash-alt"></i></button>
        <button data-editproject class="btn btn-outline-dark btn-sm"><i class="fas fa-lock"></i></button>
        <button data-editproject class="btn btn-outline-dark btn-sm"><i class="fas fa-sync"></i></button>
        <div class="btn-group hidden">
            <button type="button" class="btn btn-outline-info btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Project Dashboard
            </button>
            <div class="dropdown-menu dropdown-menu-right">
                <button class="dropdown-item" type="button">Test Plans</button>
                <button class="dropdown-item" type="button">Test Runs</button>
                <button class="dropdown-item" type="button">Tasks</button>
            </div>
        </div>
    </div>

</div>
