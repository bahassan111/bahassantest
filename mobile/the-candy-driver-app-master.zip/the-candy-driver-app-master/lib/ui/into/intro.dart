import 'package:driver/constants/constants.dart';
import 'package:driver/models/menuItemModel.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class IntroUI extends StatefulWidget {
  @override
  _IntroUIState createState() => _IntroUIState();
}

class _IntroUIState extends State<IntroUI> {
  double height, width;
  int pageIndex = 0;
  PageController _pageController = PageController();
  List<MenuItemModel> items = [
    MenuItemModel(
      title: "itro_title_1",
      subTitle: "itro_subtitle_1",
      image: AllImages.mobility,
    ),
    MenuItemModel(
        title: "itro_title_2",
        subTitle: "itro_subtitle_2",
        image: AllImages.groupCar),
    MenuItemModel(
        title: "itro_title_3",
        subTitle: "itro_subtitle_3",
        image: AllImages.diffplat),
    MenuItemModel(
        title: "itro_title_4",
        subTitle: "itro_subtitle_4",
        image: AllImages.maxearn),
  ];

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 10,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20),
              child: Image.asset(
                AllImages.theCandy,
                width: (2.5 * width) / 4,
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Container(
              height: 160,
              padding: EdgeInsets.symmetric(horizontal: 20),
              width: double.infinity,
              child: PageView(
                controller: _pageController,
                children: items
                    .map((e) => Container(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                e.title.tr,
                                style: Theme.of(context)
                                    .textTheme
                                    .headline2
                                    .copyWith(
                                      fontSize: 20,
                                    ),
                              ),
                              SizedBox(
                                height: 15,
                              ),
                              Text(
                                e.subTitle.tr,
                                style: Theme.of(context)
                                    .textTheme
                                    .headline3
                                    .copyWith(
                                      fontSize: 16,
                                    ),
                              )
                            ],
                          ),
                        ))
                    .toList(),
                onPageChanged: (index) {
                  setState(() {
                    pageIndex = index;
                  });
                },
              ),
            ),
            Container(
              height: 20,
              padding: EdgeInsets.symmetric(horizontal: 30),
              child: ListView.builder(
                itemCount: items.length,
                scrollDirection: Axis.horizontal,
                shrinkWrap: true,
                itemBuilder: (context, index) {
                  return Container(
                    padding: EdgeInsets.only(right: 14),
                    child: Icon(
                      Icons.circle,
                      color: pageIndex == index
                          ? AppThemes.lightSelectedIntro
                          : Colors.grey.withOpacity(0.3),
                      size: 12,
                    ),
                  );
                },
              ),
            ),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage(
                      items[pageIndex].image,
                    ),
                  ),
                ),
                child: Align(
                  alignment: Alignment.bottomLeft,
                  child: GestureDetector(
                    onTap: () {
                      if (pageIndex != 3) {
                        setState(() {
                          pageIndex++;
                          _pageController.animateToPage(pageIndex,
                              duration: Duration(milliseconds: 500),
                              curve: Curves.easeIn);
                        });
                      } else {
                        Get.offAndToNamed('/LanguageUI');
                      }
                    },
                    child: Container(
                      padding:
                          EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                      margin: EdgeInsets.only(left: 30, bottom: 30),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(50),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            pageIndex != 3 ? "got_it".tr : "lets_started".tr,
                            style: TextStyle(
                              fontSize: 16,
                            ),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Icon(
                            Icons.arrow_forward,
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
