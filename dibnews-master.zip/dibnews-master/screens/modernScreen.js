import React, { Component, useState, useEffect, useRef  } from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    ImageBackground,
    ActivityIndicator,
    Button, Dimensions,
    TouchableOpacity,
    Animated, AppState, SafeAreaView,ScrollView,
    BackHandler,Alert
} from "react-native";

import HTMLView from 'react-native-htmlview';
import YoutubePlayer from "react-native-youtube-iframe";
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {updateData} from "../redux/actions/dataAction";
import TopHeader from "../componants/TopHeader";
import css, {colors, sizes} from "../global/GlobalStyle";
import Carousel from 'react-native-snap-carousel';
import GestureRecognizer from 'react-native-swipe-gestures';
import Loader from "./_loader";
import {AntDesign, FontAwesome5, FontAwesome, MaterialIcons} from '@expo/vector-icons';
import news from "../data/newsDemo";
import modern from "../global/StyleModern";


const win = Dimensions.get('screen');
const ofHeight = (p)=> p * win.height / 100;
const ofWidth = (p)=> p * win.width / 100;


class modernScreen extends Component {

    state = {
        sport : news.sport.reverse(),
        buzz : news.buzz.reverse(),
        videos : news.videos,
        sorted : news.sorted.reverse(),
    };


    componentDidMount() {

    }
    logoPressed = ()=>{

    };
    menuPressed = ()=>{
        const {navigation} = this.props;

        navigation.toggleDrawer();
    };

    viewItem = (item, isVideo)=>{
        const {navigation} = this.props;

        navigation.navigate('display', {item, isVideo});
    };

    viewCategory = (items, title)=>{
        const {navigation} = this.props;

        navigation.navigate('category', {items: items, name : title});
    };

    _renderItem = (data, isVideo) => {
        let image = {uri:data.item.image};
        return (

            <View style={[styles.ci]}>
                <ImageBackground resizeMode={'cover'} style={[styles.ci_bg]} source={image}>

                    <TouchableOpacity onPress={()=>{this.viewItem(data.item, isVideo)}} style={[styles.ci_inner]}>
                        {
                            (!isVideo) ? (null) : (
                                <View style={[styles.ci_play]}>
                                    <FontAwesome5 style={[styles.ci_play_icon]} name="play" size={24} />
                                </View>
                            )
                        }
                        <View style={[styles.ci_inner_h]}>
                            <View style={[styles.ci_title_holder]}>
                                <Text style={[styles.ci_title]}>{data.item.title}</Text>
                            </View>
                            <View style={[styles.ci_foot]}>
                                <Text style={[styles.ci_foot_txt]}>{data.item.date}</Text>
                            </View>
                        </View>
                    </TouchableOpacity>


                </ImageBackground>
            </View>


        );

    };
    _renderVideo = (data) => {
        return this._renderItem(data, true);
    };

    _renderCircles = ()=>{
        let cirecles = [];

        this.state.buzz.map((item)=>{

            cirecles.push(
                <View style={[modern.circle_outer]}>
                    <ImageBackground resizeMode={'cover'} source={{uri:item.image}} style={[modern.circle]}>

                        <View style={[modern.circle_inside]}>

                        </View>

                    </ImageBackground>
                    <Text style={[modern.circle_text]}>Buzz</Text>

                </View>
            )

        });

        return cirecles;
    };

    render() {

        return (

            <View style={[css.background, {height:'100%', position:'relative', backgroundColor: '#fff'}]}>
                <TopHeader transparent={false} semi_transparent={false} floatable={false} title={"Démo 3 de l'écran de d'accueil"} onMenu={this.menuPressed} onUser={this.logoPressed}/>

                <SafeAreaView style={[styles.scrollholder]}>
                    <ScrollView style={[styles.sections]}>

                        <SafeAreaView style={[styles.sections]}>

                            <View style={[modern.circles_header]}>
                                <ScrollView horizontal={true} style={[modern.circles_scroll]}>
                                    <View style={[modern.circles]}>

                                        <View style={[modern.circle_outer]}>
                                            <ImageBackground resizeMode={'cover'} source={{uri:this.state.buzz[3].image}} style={[modern.circle]}/>
                                            <Text style={[modern.circle_text]}>Vidéos</Text>
                                        </View>
                                        <View style={[modern.circle_outer]}>
                                            <ImageBackground resizeMode={'cover'} source={{uri:this.state.buzz[0].image}} style={[modern.circle]}/>
                                            <Text style={[modern.circle_text]}>Buzz</Text>
                                        </View>
                                        <View style={[modern.circle_outer]}>
                                            <ImageBackground resizeMode={'cover'} source={{uri:this.state.sport[0].image}} style={[modern.circle]}/>
                                            <Text style={[modern.circle_text]}>Sport</Text>
                                        </View>
                                        <View style={[modern.circle_outer]}>
                                            <ImageBackground resizeMode={'cover'} source={{uri:this.state.buzz[1].image}} style={[modern.circle]}/>
                                            <Text style={[modern.circle_text]}>TV</Text>
                                        </View>
                                        <View style={[modern.circle_outer]}>
                                            <ImageBackground resizeMode={'cover'} source={{uri:this.state.buzz[2].image}} style={[modern.circle]}/>
                                            <Text style={[modern.circle_text]}>Tourisme</Text>
                                        </View>

                                    </View>
                                </ScrollView>
                            </View>

                            <View style={[modern.headline]}>
                                <Text style={[modern.headline_title]}>{this.state.sorted[1].title}</Text>
                                <Text style={[modern.headline_date]}>Aujourd'hui</Text>
                                <ImageBackground style={[modern.headline_image]} resizeMode={'cover'} source={{uri: this.state.sorted[1].image}}/>

                                <Text style={[modern.headline_exerpt]}>{this.state.sorted[1].excerpt}</Text>
                            </View>

                            <View style={[modern.headline]}>

                                <Text style={[modern.sep_title]}>Articles populaires</Text>

                            </View>

                        </SafeAreaView>

                    </ScrollView>
                </SafeAreaView>






            </View>

        );
    }

}

const styles = StyleSheet.create({
    scrollholder : {
        flex:1,
    },
    sections : {
        flex:1,
    },
});

const mapDispatchToProps = dispatch => (
    bindActionCreators({
        updateData: updateData,
    }, dispatch)
);

const mapStateToProps = (state) => {
    const { data } = state;
    return { data }
};

export default connect(mapStateToProps, mapDispatchToProps)(modernScreen);
