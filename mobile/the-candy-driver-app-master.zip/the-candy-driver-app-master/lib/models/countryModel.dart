class CountryModel {
  String countryName;
  String id;

  CountryModel({this.countryName, this.id});

  CountryModel.fromJson(Map<String, dynamic> json) {
    countryName = json['countryName'];
    id = json['id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['countryName'] = this.countryName;
    data['id'] = this.id;
    return data;
  }
}
