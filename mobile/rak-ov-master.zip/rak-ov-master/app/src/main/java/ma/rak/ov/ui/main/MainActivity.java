package ma.rak.ov.ui.main;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.Manifest.permission.CAMERA;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import java.util.Timer;
import java.util.TimerTask;

import ma.rak.ov.BranchementFragment;
import ma.rak.ov.DashboardFragment;
import ma.rak.ov.ForgetPasswordFragment;
import ma.rak.ov.HistoriqueFragment;
import ma.rak.ov.ListDemandeFragment;
import ma.rak.ov.LoginActivity;
import ma.rak.ov.MapsFragment;
import ma.rak.ov.R;
import ma.rak.ov.api.RetrofitClient;
import ma.rak.ov.api.TwDatabase;
import ma.rak.ov.storage.RealmBackupRestore;
import ma.rak.ov.storage.SharedPrefManager;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, PopupMenu.OnMenuItemClickListener {
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;
    Fragment dashboard;
    TextView username, username2, lastsync1, lastsync2;
    public boolean showHisto = false;
    DemandViewModel demandViewModel;
    private static final String BRANCHEMENT_TAG = "BRANCHEMENT_TAG";
    private static final String DASHBOARD_TAG = "DASHBOARD_TAG";
    private static final String MAPS_TAG = "MAPS_TAG";
    public final ListDemandeFragment listDemandeFragment = new ListDemandeFragment();
    BranchementFragment branchementFragment = null;
    DashboardFragment dashboardFragment = null;
    MapsFragment mapsFragment = null;
    ForgetPasswordFragment forgetPasswordFragment = null;
    AdminFragment adminFragment = null;
    HistoriqueFragment historiqueFragment = null;

    ImageView syncimg;
    TextView syncNotif;
    RelativeLayout syncholder;
    boolean synching = false;
    int passSync = 0;

    TextView hamMenu = null;

    private static final int PERMISSION_REQUEST_CODE = 200;
    private View view;

    @Override
    protected void onStart() {
        super.onStart();
        new RealmBackupRestore(this).checkStoragePermissions(this);
        if (!SharedPrefManager.getInstance(this).isLogged()) {
            Intent intent = new Intent(this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

            startActivity(intent);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        View parentLayout = findViewById(android.R.id.content);
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        toolbar.setNavigationIcon(R.drawable.ic_baseline_menu_24);

        getSupportActionBar().setDisplayShowTitleEnabled(false);

        syncholder = findViewById(R.id.syncholder);
        syncNotif = findViewById(R.id.synccount);

        syncimg = findViewById(R.id.syncimg);
        syncimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                syncIt();
            }
        });


        navigationView.bringToFront();
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setCheckedItem(R.id.nav_dashboard);

        View headerView = navigationView.getHeaderView(0);

        username = (TextView) headerView.findViewById(R.id.userName);

        lastsync1 = (TextView) headerView.findViewById(R.id.last_sync_1);


        username.setText(SharedPrefManager.getInstance(this).getFullName() + " | " + SharedPrefManager.getInstance(this).getUserName());


        lastsync1.setText("Dérniere synchronisation : " + SharedPrefManager.getInstance(this).getSyncTime());

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!drawerLayout.isDrawerOpen(GravityCompat.START))
                    drawerLayout.openDrawer(GravityCompat.START);
                else drawerLayout.closeDrawer(GravityCompat.END);
            }
        });

        hamMenu = findViewById(R.id.toolbarUserMenu);
        hamMenu.setText(SharedPrefManager.getInstance(this).getMode() == 1 ? "Branchement" : "Abonnement");
        hamMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // If the navigation drawer is not open then open it, if its already open then close it.
//                Toast.makeText(MainActivity.this, "Toolbar", Toast.LENGTH_SHORT).show();
                showPopup(v);
            }
        });

        view = parentLayout;
        dashboard = new DashboardFragment();
        loadFragment(dashboard, DASHBOARD_TAG);

        if (checkPermission()) {

            //Snackbar.make(view, "Permission already granted.", Snackbar.LENGTH_LONG).show();

        } else {

            //Snackbar.make(view, "Please request permission.", Snackbar.LENGTH_LONG).show();
            requestPermission();
        }

        if (checkSync() > 0) {
            syncIt();
        }

        new Timer().scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                int total_sync = checkSync();
                if (total_sync > 0) {
                    passSync += 1;
                    syncholder.setVisibility(View.VISIBLE);
                    syncNotif.setText(String.valueOf(total_sync));
                } else {
                    passSync = 0;
                    syncholder.setVisibility(View.INVISIBLE);
                }


                if (passSync > 4 && !synching) {
                    syncIt();
                }
            }
        }, 0, 5000);

        int ctime = (int) System.currentTimeMillis() / 1000;
        int ltime = SharedPrefManager.getInstance(this).getLoginTime();

        TwDatabase.TwDatabaseHelper.handleRefreshToken(this);


    }

    public int checkSync() {
        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(this);

        return
                dbh.query(TwDatabase.ABPending.TABLE_NAME, null, null, null).size()
                        +
                        dbh.query(TwDatabase.BRPending.TABLE_NAME, null, null, null).size();
    }

    public void syncIt() {

        if (synching) return;

        synching = true;
        //syncNotif.setText("Synching ..");

        RotateAnimation rotate = new RotateAnimation(0, 180, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        rotate.setDuration(200);
        rotate.setRepeatCount(Animation.INFINITE);
        rotate.setInterpolator(new LinearInterpolator());


        syncimg.startAnimation(rotate);


        Log.e("#################", "Going sync");
        TwDatabase.TwDatabaseHelper.synchroniz(this, new Runnable() {
            @Override
            public void run() { // STEP

                Log.e("#################", "got step");

            }
        }, new Runnable() { // SUCCESS
            @Override
            public void run() {

                Log.e("#################", "Success");
                syncimg.clearAnimation();
                synching = false;
                syncholder.setVisibility(View.INVISIBLE);

                Toast.makeText(MainActivity.this, "synchronisation terminée!", Toast.LENGTH_LONG).show();

            }
        }, new Runnable() { // fAIL
            @Override
            public void run() {
                Log.e("#################", "Fail");
                syncimg.clearAnimation();
                synching = false;
            }
        });

    }

    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(getApplicationContext(), ACCESS_FINE_LOCATION);
        int result1 = ContextCompat.checkSelfPermission(getApplicationContext(), CAMERA);

        return result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermission() {

        ActivityCompat.requestPermissions(this, new String[]{ACCESS_FINE_LOCATION, CAMERA}, PERMISSION_REQUEST_CODE);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0) {

                    boolean locationAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean cameraAccepted = grantResults[1] == PackageManager.PERMISSION_GRANTED;

                    if (locationAccepted && cameraAccepted)
                        Snackbar.make(view, "Permission Granted, Now you can access location data and camera.", Snackbar.LENGTH_LONG).show();
                    else {

                        Snackbar.make(view, "Permission Denied, You cannot access location data and camera.", Snackbar.LENGTH_LONG).show();

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (shouldShowRequestPermissionRationale(ACCESS_FINE_LOCATION)) {
                                showMessageOKCancel("You need to allow access to both the permissions",
                                        new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                    requestPermissions(new String[]{ACCESS_FINE_LOCATION, CAMERA},
                                                            PERMISSION_REQUEST_CODE);
                                                }
                                            }
                                        });
                                return;
                            }
                        }

                    }
                }


                break;
        }
    }


    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(MainActivity.this)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }


    protected void loadFragment(Fragment fragment, String FRAGMENT_TAG) {


        FragmentManager supportFragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = supportFragmentManager.beginTransaction();
        Fragment inputFragment = supportFragmentManager.findFragmentByTag(FRAGMENT_TAG);

        if (inputFragment == null) {

            fragmentTransaction.replace(R.id.frame, fragment, FRAGMENT_TAG).addToBackStack(null).commit();

        } else {

            fragmentTransaction.replace(R.id.frame, inputFragment, FRAGMENT_TAG).addToBackStack(null).commit();

        }
        if (Build.VERSION.SDK_INT >= 26) {
            fragmentTransaction.setReorderingAllowed(false);
        }
        drawerLayout.closeDrawer(GravityCompat.START);

    }

    public void showPopup(View v) {
        PopupMenu popup = new PopupMenu(this, v);
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.toolbar_menu);
        popup.show();
    }

    public void showFragment(Fragment fragmentToShow) {
        // Create transactionns
        FragmentTransaction transaction = getSupportFragmentManager()
                .beginTransaction()
                .setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.slide_out_right);

        // Hide all of the fragments
        for (Fragment fragment : getSupportFragmentManager().getFragments()) {
            transaction.hide(fragment);
        }

        if (fragmentToShow.isAdded()) {
            // When fragment was previously added - show it
            transaction.show(fragmentToShow);
        } else {
            // When fragment is adding first time - add it
            transaction.add(R.id.frame, fragmentToShow);

        }

        transaction.commit();
    }

    public boolean onMenuItemClick(MenuItem item) {

        switch (item.getItemId()) {

            case R.id.action_branchement:
                if (SharedPrefManager.getInstance(this).isLogged()) {
                    SharedPrefManager.getInstance(this).operationMode(1);
                    hamMenu.setText("Branchement");
                    Toast.makeText(this, R.string.mode_branchement, Toast.LENGTH_SHORT).show();

                    finish();
                    startActivity(getIntent());
                }
                return true;
            case R.id.action_abonnements:
                if (SharedPrefManager.getInstance(this).isLogged()) {
                    SharedPrefManager.getInstance(this).operationMode(2);
                    hamMenu.setText("Abonnement");
                    Toast.makeText(this, R.string.mode_abonnement, Toast.LENGTH_SHORT).show();

                    finish();
                    startActivity(getIntent());
                }
                return true;
            default:
                return false;
        }
    }

    private void logout() {
        String host = SharedPrefManager.getInstance(this).getBaseUrl();
        SharedPrefManager.getInstance(this).clear();
        RetrofitClient.resetInstance();
        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        SharedPrefManager.getInstance(this).saveBaseUrl(host);


        startActivity(intent);
    }

    @Override
    public void onSaveInstanceState(Bundle outState, PersistableBundle outPersistentState) {
        super.onSaveInstanceState(outState, outPersistentState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Fragment fragment = null;
        switch (item.getItemId()) {
            case R.id.nav_logout:
                logout();
                break;

            case R.id.nav_demandes_liste:
                showHisto = false;
                showFragment(listDemandeFragment);
                break;
            case R.id.nav_dashboard:
                if (dashboardFragment == null)
                    dashboard = new DashboardFragment();
                //loadFragment(dashboard, FRAGMENT_TAG);
                showFragment(dashboard);
                break;
            case R.id.nav_demandes:
                if (mapsFragment == null)
                    mapsFragment = new MapsFragment();
                showFragment(mapsFragment);
                break;

            case R.id.nav_historique:
                showHisto = true;
                showFragment(listDemandeFragment);
                break;
            case R.id.nav_devis:
                startActivity(new Intent(this, DevisActivity.class));
                break;
            case R.id.nav_change_password:
                if (forgetPasswordFragment == null)
                    forgetPasswordFragment = new ForgetPasswordFragment();
                showFragment(forgetPasswordFragment);
                break;
            default:
                break;
        }

        drawerLayout.closeDrawers();

        return true;
    }
}