import {
    PENDING_DELETE_COMMENT,

    PENDING_LOGIN_FB, SET_COMMENT_DELETE,
    SET_LOGIN_FB, SUCCESS_DELETE_COMMENT,
    SUCCESS_LOGIN_FB

} from "../actions/types";

export default function(
    state = { isLoadingData: false, isDoSearch: false, data: [], keyword: null },
    action
) {

    console.log("Log_action_LOGIN => ", action.type);

    switch (action.type) {
        case PENDING_DELETE_COMMENT:
            return {
                ...state,
                isLoadingData: true
            };

        case SET_COMMENT_DELETE:
            return { ...state, data: action.payload };

        case SUCCESS_DELETE_COMMENT:
            return {
                ...state,
                isLoadingData: false
            };

        default:
            return state;
    }

}
