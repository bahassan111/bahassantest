package ma.rak.ovr;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.PopupMenu;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.HashMap;

import ma.rak.ovr.adapter.DemandesAdapter;
import ma.rak.ovr.storage.SharedPrefManager;
import ma.rak.ovr.ui.main.DemandViewModel;
import ma.rak.ovr.ui.main.MainActivity;

public class ArchivedListFragment extends Fragment implements
        AdapterView.OnItemSelectedListener {

    public RecyclerView recyclerView;
    private SwipeRefreshLayout swipeContainer;
    private FrameLayout progressOverlay;
    private TabLayout tabLayout;
    private ArrayList<HashMap<String, String>> branchementsList = null;
    private ArrayList<HashMap<String, String>> abonnementList = null;

    String[] status = {"Exécutées", "Rejetées", "Non Exécutés"};
    int archivePosition = 1;
    int spinnerPosition = 0;

    private TextView listTitle, notFoundMsg;
    private Spinner spinner;
    TextView hamMenu;

    private DemandViewModel demandViewModel;

    DemandesAdapter demandeAdapter = null;

    ArrayList<HashMap<String, String>> newBrResponse = null;
    ArrayList<HashMap<String, String>> newAbResponse = null;
    private String token = "";


    public static ArchivedListFragment newInstance() {
        return new ArchivedListFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_pending_list_list, container, false);
        listTitle = (TextView) rootView.findViewById(R.id.listTitle);
        tabLayout = (TabLayout) getActivity().findViewById(R.id.tab_layout);
        progressOverlay = rootView.findViewById(R.id.progress_overlay);
        progressOverlay.setVisibility(View.VISIBLE);

        if(((MainActivity)getActivity()).showHisto){
            TabLayout.Tab tab = tabLayout.getTabAt(1);
            tab.select();
        }

        spinner = (Spinner) rootView.findViewById(R.id.status_spinner);
        spinner.setOnItemSelectedListener(this);

        //spinner.setVisibility(View.INVISIBLE);
        /*if (SharedPrefManager.getInstance(getActivity()).getMode() == 1) {
            spinner.setVisibility(View.INVISIBLE);
        } else {
            spinner.setVisibility(View.VISIBLE);
            progressOverlay.setVisibility(View.INVISIBLE);
        }*/


//        hamMenu = getActivity().findViewById(R.id.toolbarUserMenu);
//        hamMenu.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                // If the navigation drawer is not open then open it, if its already open then close it.
////                Toast.makeText(MainActivity.this, "Toolbar", Toast.LENGTH_SHORT).show();
//                showPopup(v);
//            }
//        });

//        recyclerView = getActivity().findViewById(R.id.list);
        recyclerView = rootView.findViewById(R.id.list);
        swipeContainer = rootView.findViewById(R.id.swipeContainer);
        swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                // Your code to refresh the list here.
                // Make sure you call swipeContainer.setRefreshing(false)
                // once the network request has completed successfully.
                fetchData(archivePosition, token);
                // ...the data has come back, add new items to your adapter...
                // Now we call setRefreshing(false) to signal refresh has finished
                swipeContainer.setRefreshing(false);

            }
        });
        // Configure the refreshing colors
        swipeContainer.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light);

        //Creating the ArrayAdapter instance having the country list
        ArrayAdapter aa = new ArrayAdapter(getActivity(), android.R.layout.simple_spinner_item, status);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        aa.notifyDataSetChanged();
        //Setting the ArrayAdapter data on the Spinner
        spinner.setAdapter(aa);
//        spinner.setSelection(spinnerPosition);


        return rootView;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    public void showPopup(View v) {
        PopupMenu popup = new PopupMenu(getActivity(), v);
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {

                    case R.id.action_branchement:
                        if (SharedPrefManager.getInstance(getActivity()).isLogged()) {
                            SharedPrefManager.getInstance(getActivity()).operationMode(1);
                            Toast.makeText(getActivity(), R.string.mode_branchement, Toast.LENGTH_SHORT).show();
                            fetchData(archivePosition, token);
                            //spinner.setVisibility(View.INVISIBLE);
                            hamMenu.setText("Branchement");
                            getActivity().finish();
                            startActivity(getActivity().getIntent());
                        }
                        return true;
                    case R.id.action_abonnements:
                        if (SharedPrefManager.getInstance(getActivity()).isLogged()) {
                            SharedPrefManager.getInstance(getActivity()).operationMode(2);
                            Toast.makeText(getActivity(), R.string.mode_abonnement, Toast.LENGTH_SHORT).show();
                            fetchData(archivePosition, token);
                            //spinner.setVisibility(View.VISIBLE);
                            hamMenu.setText("Abonnement");
                            getActivity().finish();
                            startActivity(getActivity().getIntent());
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });
        popup.inflate(R.menu.toolbar_menu);
        popup.show();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        //spinner.setVisibility(View.INVISIBLE);
        demandViewModel = ViewModelProviders.of(this).get(DemandViewModel.class);
        if (SharedPrefManager.getInstance(getActivity()).getMode() == 1) {
            demandViewModel.getBrachments(token, 1, getActivity(), 0);
        } else {
            demandViewModel.getAbonnements(token, 0, getActivity());
        }
        fetchData(archivePosition, token);
    }

    public void fetchData(int status, String token) {
        progressOverlay.setVisibility(View.VISIBLE);
        demandeAdapter = new DemandesAdapter(getActivity(), branchementsList, abonnementList);

        if (SharedPrefManager.getInstance(getActivity()).getMode() == 1) {
            listTitle.setText(getString(R.string.listTitleBrH));

            demandViewModel.getBrachments(token, 1, getActivity(), status);
            newBrResponse = new ArrayList<>();
            demandViewModel.BrResponseMutableLiveData.observe(getActivity(), new Observer<ArrayList<HashMap<String, String>>>() {
                @Override
                public void onChanged(ArrayList<HashMap<String, String>> branchementResponse) {
                    newBrResponse = branchementResponse;
                    demandeAdapter.setList(branchementResponse, null);
                    tabLayout.getTabAt(1).setText("Traités (" + branchementResponse.size() + ")   ");
                }

            });
            if (newBrResponse != null && newBrResponse.size()  > 0) {
                    tabLayout.getTabAt(1).setText("Traités (" + newBrResponse.size() + ")   ");

            }


        } else {
            listTitle.setText(getString(R.string.listTitleAbH));
            //spinner.setVisibility(View.INVISIBLE);
            demandViewModel.getAbonnements(token, status, getActivity());
            newAbResponse = new ArrayList<>();
            demandViewModel.AbResponseMutableLiveData.observe(getActivity(), new Observer<ArrayList<HashMap<String, String>>>() {
                @Override
                public void onChanged(ArrayList<HashMap<String, String>> abonnementResponse) {
                    demandeAdapter.setList(null, abonnementResponse);
                    newAbResponse = abonnementResponse;
                    tabLayout.getTabAt(1).setText("Traités (" + newAbResponse.size() + ")   ");

                }
            });
            if (newAbResponse != null && newAbResponse.size() > 0) {

                tabLayout.getTabAt(1).setText("Traités (" + newAbResponse.size() + ")   ");
            }

        }
        progressOverlay.setVisibility(View.INVISIBLE);
        recyclerView.setAdapter(demandeAdapter);
//        notFoundMsg.setVisibility(demandeAdapter.getItemCount() > 0 ? View.INVISIBLE : View.VISIBLE);
    }

    //Performing action onItemSelected and onNothing selected
    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id) {

        spinnerPosition = position;
        if (position == 0) {
            archivePosition = 2;
        } else if (position == 1) {
            archivePosition = 3;
        }else if (position == 2) {
            archivePosition = 4;
        }

        fetchData(archivePosition, token);

//        Toast.makeText(getActivity(), "" + archivePosition, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }

}