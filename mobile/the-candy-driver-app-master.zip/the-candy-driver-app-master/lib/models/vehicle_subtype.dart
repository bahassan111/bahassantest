class VehicleType {
  String id;
  String categoryName;
  String typeId;

  VehicleType({this.id, this.categoryName, this.typeId});

  VehicleType.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    categoryName = json['category_name'];
    typeId = json['type_id'];
  }
}
