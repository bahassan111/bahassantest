import Model from '../model'
export default class User extends Model {
  static schema = {
    name: 'User',
    primaryKey: 'email',
    properties: {
      email : 'string',
      name : 'string'
    }
  }
}