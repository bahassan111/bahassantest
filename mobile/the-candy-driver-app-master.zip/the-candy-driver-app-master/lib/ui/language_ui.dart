import 'package:driver/constants/constants.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:driver/models/models.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class LanguageUI extends StatefulWidget {
  @override
  _LanguageUIState createState() => _LanguageUIState();
}

class _LanguageUIState extends State<LanguageUI> {
  double height, width;
  final LanguageController languageController = LanguageController.to;

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            SizedBox(
              height: 30,
            ),
            Image.asset(
              AllImages.theCandy,
              width: (3 * width) / 4,
            ),
            Text(
              "chooseLanguage".tr,
              style:
                  Theme.of(context).textTheme.headline1.copyWith(fontSize: 20),
            ),
            SizedBox(
              height: 10,
            ),
            Expanded(
              child: ListView.builder(
                itemCount: languageController.languages.length,
                itemBuilder: (context, index) {
                  return languageItem(
                      languageController.languages[index], index);
                },
              ),
            )
          ],
        ),
      ),
    );
  }

  languageItem(LanguageModel languageModel, int index) {
    return Container(
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(
            color: AppThemes.lightAthensGrayBorderColor,
          ),
          bottom: index == languageController.languages.length - 1
              ? BorderSide(
                  color: AppThemes.lightAthensGrayBorderColor,
                )
              : BorderSide(color: Colors.transparent),
        ),
      ),
      padding: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
      child: Row(
        children: [
          Text(
            languageModel.name,
            style: Theme.of(context).textTheme.headline1.copyWith(
                  fontSize: 15,
                ),
          ),
          Spacer(),
          GestureDetector(
            onTap: () async {
              await languageController.setDefaultLanguage(
                languageModel.language,
                languageModel.country,
              );
              Get.toNamed('/LoginUI');
            },
            child: Container(
              padding: EdgeInsets.all(5),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppThemes.lightravenBackGroundColor,
              ),
              child: Center(
                child: Icon(
                  Icons.arrow_forward_ios,
                  size: 11,
                  color: AppThemes.lightravenIconColor,
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
