﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CCISFMMND
{
    public partial class DbExplore : Form
    {
        public DB db;
        public RIBClass selected;
        public DbExplore()
        {
            InitializeComponent();
            db = new DB();
        }


        void fixC()
        {
            list.Columns[0].Width = list.Width / 2;
            list.Columns[1].Width = list.Width / 2;
        }
        private void DbExplore_Load(object sender, EventArgs e)
        {

            init();
            fixC();
        }

        public void init()
        {
            list.Items.Clear();
            var ribs = db.getRIBS();

            foreach (var row in ribs)
            {
                var ne = new Telerik.WinControls.UI.ListViewDataItem(row.Nom, new string[] { row.Nom, row.RIB });


                ne.Tag = row;
                list.Items.Add(ne);

            }
        }

        private void DbExplore_Resize(object sender, EventArgs e)
        {
            fixC();
        }

        private void nom_TextChanged(object sender, EventArgs e)
        {



            foreach (var item in list.Items)
            {
                var d = (RIBClass)item.Tag;

                if (d.Nom.ToLower().Contains(nom.Text.ToLower().Trim()) || d.RIB.Contains(nom.Text.ToLower().Trim()))
                {
                    item.Visible = true;
                }
                else
                {
                    item.Visible = false;
                }
            }
        }

        private void list_SelectedItemChanged(object sender, EventArgs e)
        {
            if (list.SelectedItem != null) del.Enabled = true;
        }

        private void del_Click(object sender, EventArgs e)
        {
            var s = list.SelectedItem;
            var lasti = list.SelectedIndex;

            if (s != null)
            {
                var r = (RIBClass)s.Tag;
                db.delRIB(r.Nom, r.RIB, r.AMT);
                init();
                nom.Text = "";
                if (list.Items.Count >= (lasti + 1))
                {
                    list.SelectedIndex = lasti;
                }
                else
                {
                    list.SelectedIndex = 0;
                }
            }
        }

        private void list_ItemMouseClick(object sender, Telerik.WinControls.UI.ListViewItemEventArgs e)
        {
            
        }

        private void list_ItemMouseDoubleClick(object sender, Telerik.WinControls.UI.ListViewItemEventArgs e)
        {
            selected = (RIBClass)list.SelectedItem.Tag;
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }
    }
}
