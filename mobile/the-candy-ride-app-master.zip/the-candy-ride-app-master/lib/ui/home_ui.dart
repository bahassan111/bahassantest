import 'dart:async';

import 'package:bot_toast/bot_toast.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import "package:latlong/latlong.dart";
import 'package:flutter_map/flutter_map.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:rider_app/constants/constants.dart';
import 'package:rider_app/controllers/controllers.dart';
import 'package:rider_app/helpers/helpers.dart';
import '../models/models.dart';
import 'components/components.dart';
import 'package:vector_math/vector_math.dart' as vm;

class HomeUI extends StatefulWidget {
  @override
  _HomeUIState createState() => _HomeUIState();
}

class _HomeUIState extends State<HomeUI> {
  bool isMenuShow = false;
  double height, width;
  static AuthController authTo = Get.find();
  static HomeController to = Get.find();
  LatLng previousLtnLng;
  var _firebaseRef = FirebaseDatabase().reference();
  TripAcceptController tripTo = TripAcceptController();
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey();
  bool isLocationPermission = false;
  StreamSubscription onlineDriversStream;
  MapController mapController;
  List onlineDrivers = [];
  @override
  void initState() {
    super.initState();
    onlineDriversStream = _firebaseRef.onValue.listen((event) {
      onlineDrivers = [];
      event.snapshot.value.keys.toList().forEach((e) {
        onlineDrivers.add(event.snapshot.value[e]);
      });
      if (mounted) setState(() {});
    });
    AlertDialog(
      title: Text("Location permission"),
      content: Text(
          "The Candy Rider app collects location data to identify nearby customers and drivers, even when the app is closed or not in use"),
      actions: [
        TextButton(
          onPressed: () {},
          child: Text('OK'),
        )
      ],
    );

    mapController = MapController();
    locationPermissioncheck().then((value) {
      if (value) {
        setState(() {
          isLocationPermission = value;
        });
      }
    });
    to.pickUpController.addListener(() {
      if (to.pickUpController.text.trim() != '') {
        to.getSuggestionLocations(to.pickUpController.text.trim());
      }
    });
    to.dropAtController.addListener(() {
      if (to.dropAtController.text.trim() != '') {
        to.getSuggestionLocations(to.pickUpController.text.trim());
        if (to.pickUpController.text.trim() != '') {
          if (mounted) {
            setState(() {
              to.status = Status.locationSelect;
            });
          }
        } else {
          setState(() {
            to.status = Status.none;
          });
        }
      } else {
        to.status = Status.none;
      }
    });
  }

  reCenterMapPosition() async {
    await Future.delayed(Duration(milliseconds: 500));
    if (mapController != null) {
      mapController?.move(to.currentLocation, 17);
      mapController?.rotate(0);
    }
  }

  @override
  void dispose() {
    onlineDriversStream?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return WillPopScope(
      onWillPop: () async {
        BotToast.showLoading();
        bool isAnyRide = await tripTo.isAnyRide();
        BotToast.closeAllLoading();

        if (isAnyRide) {
          bool isOkay = await showDialog(
              context: context,
              barrierDismissible: false, // user must tap button!
              builder: (BuildContext context) {
                return OptionDialog(
                  title: "exit".tr,
                  message: "exitAppMessage".tr,
                  onCancel: () {
                    Get.back(result: false);
                  },
                  onOkay: () {
                    Get.back(result: true);
                  },
                );
              });
          return isOkay;
        } else {
          return true;
        }
      },
      child: Scaffold(
        key: scaffoldKey,
        body: SingleChildScrollView(
          child: Container(
            height: height,
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                CustomeAppBar(
                  updateMenuPosition: () => setState(() {
                    isMenuShow = !isMenuShow;
                  }),
                  isMenuShow: isMenuShow,
                  title: "whereAreYouGoing".tr,
                ),
                Expanded(
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Expanded(
                            child: Container(
                              color: Colors.grey,
                              child: Stack(
                                children: [
                                  isLocationPermission
                                      ? StreamBuilder<Position>(
                                          stream: Geolocator.getPositionStream(
                                              intervalDuration:
                                                  Duration(seconds: 5)),
                                          builder: (context, snapshot) {
                                            if (!snapshot.hasData ||
                                                snapshot.data == null) {
                                              Geolocator.getCurrentPosition()
                                                  .then((pos) {
                                                if (pos != null) {
                                                  to.currentLocation = LatLng(
                                                      pos.latitude,
                                                      pos.longitude);
                                                  if (mounted) setState(() {});
                                                  reCenterMapPosition();
                                                }
                                                print(
                                                    pos.toString() + " pos --");
                                                to.pickUpController.text = '';
                                              });
                                              return Center(
                                                  child:
                                                      CircularProgressIndicator());
                                            }
                                            if (previousLtnLng != null) {
                                              if ((previousLtnLng.latitude -
                                                              (snapshot?.data
                                                                      ?.latitude ??
                                                                  to?.currentLocation
                                                                      ?.latitude))
                                                          .abs() >
                                                      0.00001000 &&
                                                  (previousLtnLng.longitude -
                                                              (snapshot?.data
                                                                      ?.longitude ??
                                                                  to.currentLocation
                                                                      ?.longitude))
                                                          .abs() >
                                                      0.00001000) {
                                                reCenterMapPosition();
                                              }
                                            }
                                            previousLtnLng = to.currentLocation;
                                            if (snapshot.hasData &&
                                                snapshot.data != null)
                                              to.currentLocation = LatLng(
                                                  (snapshot?.data?.latitude ??
                                                      to.currentLocation
                                                          .latitude),
                                                  (snapshot?.data?.longitude ??
                                                      to.currentLocation
                                                          .longitude));

                                            if (to.pickUpController.text
                                                        .trim() ==
                                                    '' &&
                                                !to.pickUpFocusNode.hasFocus &&
                                                to.currentLocation != null) {
                                              placemarkFromCoordinates(
                                                      (snapshot?.data
                                                              ?.latitude ??
                                                          to.currentLocation
                                                              ?.latitude),
                                                      (snapshot?.data
                                                              ?.longitude ??
                                                          to.currentLocation
                                                              ?.longitude))
                                                  .then((value) {
                                                reCenterMapPosition();
                                                if (mounted) {
                                                  setState(() {
                                                    to.pickUpController.text =
                                                        value.first.street ??
                                                            value.first
                                                                .locality ??
                                                            '';
                                                  });
                                                }
                                              });
                                            }

                                            return Stack(
                                              children: [
                                                Container(
                                                    child: FlutterMap(
                                                  mapController: mapController,
                                                  options: MapOptions(
                                                      center:
                                                          to.currentLocation,
                                                      zoom: 17.0,
                                                      onTap: (LatLng value) {
                                                        print(value);
                                                        setState(() {
                                                          to.pickUp =
                                                              Features(center: [
                                                            value.longitude +
                                                                0.0,
                                                            value.latitude + 0.0
                                                          ]);
                                                          mapController.move(
                                                              LatLng(
                                                                  value.latitude +
                                                                      0.0,
                                                                  value.longitude +
                                                                      0.0),
                                                              17);
                                                          placemarkFromCoordinates(
                                                                  value.latitude +
                                                                      0.0,
                                                                  value.longitude +
                                                                      0.0)
                                                              .then((value) {
                                                            if (mounted) {
                                                              setState(() {
                                                                to.pickUpController
                                                                    .text = value
                                                                        .first
                                                                        .street ??
                                                                    value.first
                                                                        .locality ??
                                                                    '';
                                                              });
                                                            }
                                                          });
                                                          if (to.dropAt !=
                                                              null) {
                                                            to
                                                                .getRouteBetweenPath()
                                                                .then((value) {
                                                              setState(() {});
                                                            });
                                                          }
                                                        });
                                                        print(
                                                            value.runtimeType);
                                                      }),
                                                  layers: [
                                                    TileLayerOptions(
                                                      urlTemplate: Urls
                                                          .mapBoxThirPartyUrl,
                                                      additionalOptions: {
                                                        'accessToken':
                                                            ProjectKeys
                                                                .mapBoxKey,
                                                        "id":
                                                            "mapbox.mapbox-streets-v8",
                                                      },
                                                    ),
                                                    PolylineLayerOptions(
                                                      polylines: to?.routeDetail
                                                                  ?.code ==
                                                              'Ok'
                                                          ? [
                                                              Polyline(
                                                                points: [
                                                                  ...to
                                                                          .mapMatchingModel
                                                                          ?.matchings
                                                                          ?.first
                                                                          ?.geometry
                                                                          ?.coordinates ??
                                                                      []
                                                                ],
                                                                strokeWidth: 5,
                                                                color: AppThemes
                                                                    .lightpauaBackGroundColor,
                                                              )
                                                            ]
                                                          : [],
                                                      polylineCulling: true,
                                                    ),
                                                    MarkerLayerOptions(
                                                      markers: [
                                                        // Marker(
                                                        //     width: 50.0,
                                                        //     height: 50.0,
                                                        //     point: to
                                                        //         .currentLocation,
                                                        //     builder: (ctx) =>
                                                        //         Image.asset(
                                                        //             AllImages
                                                        //                 .pin)),
                                                        if (snapshot.hasData)
                                                          for (int i = 0;
                                                              i <
                                                                  onlineDrivers
                                                                      .length;
                                                              i++)
                                                            Marker(
                                                              width: 30.0,
                                                              height: 30.0,
                                                              point: LatLng(
                                                                  onlineDrivers[
                                                                              i]
                                                                          [
                                                                          "lat"] ??
                                                                      0.0,
                                                                  onlineDrivers[
                                                                              i]
                                                                          [
                                                                          "lng"] ??
                                                                      0.0),
                                                              builder: (_) =>
                                                                  Transform
                                                                      .rotate(
                                                                angle: vm.radians(
                                                                    onlineDrivers[i]
                                                                            [
                                                                            "bearing"] ??
                                                                        0.0),
                                                                child: Image.asset(
                                                                    AllImages
                                                                        .newCar),
                                                              ),
                                                            ),
                                                        Marker(
                                                          width: 50.0,
                                                          height: 50.0,
                                                          point: to.pickUp !=
                                                                  null
                                                              ? LatLng(
                                                                  to.pickUp
                                                                      .center[1],
                                                                  to.pickUp
                                                                      .center[0],
                                                                )
                                                              : to.currentLocation,
                                                          builder: (ctx) =>
                                                              Image.asset(
                                                                  AllImages
                                                                      .pin),
                                                        ),
                                                        if (to.dropAt != null)
                                                          Marker(
                                                            width: 50.0,
                                                            height: 50.0,
                                                            point: LatLng(
                                                              to.dropAt.center[
                                                                      1] +
                                                                  0.0,
                                                              to.dropAt.center[
                                                                      0] +
                                                                  0.0,
                                                            ),
                                                            builder: (ctx) =>
                                                                Image.asset(
                                                                    AllImages
                                                                        .pinGreen),
                                                          )
                                                      ],
                                                    ),
                                                  ],
                                                )),
                                                Align(
                                                  alignment:
                                                      Alignment.bottomRight,
                                                  child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment.end,
                                                    children: [
                                                      RelocationIcon(
                                                        onTap:
                                                            reCenterMapPosition,
                                                      ),
                                                      to.mapMatchingModel !=
                                                                  null &&
                                                              to.dropAtController
                                                                      .text
                                                                      .trim() !=
                                                                  ""
                                                          ? TripDetail(
                                                              destination: to
                                                                  .dropAtController
                                                                  .text,
                                                              distance: (to
                                                                              .mapMatchingModel
                                                                              .matchings
                                                                              .first
                                                                              .distance /
                                                                          1000)
                                                                      .toPrecision(
                                                                          2)
                                                                      .toString() +
                                                                  " kms".tr,
                                                              time: (to.mapMatchingModel.matchings.first
                                                                              .duration /
                                                                          60)
                                                                      .toPrecision(
                                                                          2)
                                                                      .toString() +
                                                                  " mins".tr,
                                                            )
                                                          : Container(),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            );
                                          },
                                        )
                                      : Container(),
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      to.status == Status.payment ||
                                              to.status ==
                                                  Status
                                                      .vehiclecategorySelect ||
                                              to.status == Status.chooseFare
                                          ? Container()
                                          : PickUpDrop(
                                              onDropAtSuggestionSelected:
                                                  (Features feature) {
                                                to.dropAtController.text =
                                                    feature.placeName;
                                                to.dropAt = feature;
                                                to
                                                    .getRouteBetweenPath()
                                                    .then((value) {
                                                  setState(() {});
                                                });
                                              },
                                              onPickUpSuggestionSelected:
                                                  (Features feature) {
                                                print(
                                                    "points ${feature.center}");
                                                to.pickUpController.text =
                                                    feature.placeName;
                                                to.pickUp = feature;
                                                // find path if destination location is selected
                                                if (to.dropAt != null) {
                                                  to
                                                      .getRouteBetweenPath()
                                                      .then((value) {});
                                                }
                                                setState(() {});
                                              },
                                              pickUpFocusNode:
                                                  to.pickUpFocusNode,
                                              dropAtController:
                                                  to.dropAtController,
                                              pickUpController:
                                                  to.pickUpController,
                                              prebook: () {
                                                if (to.dropAtController.text !=
                                                    '') {
                                                  setState(() {
                                                    to.status =
                                                        Status.dateTimeSelect;
                                                  });
                                                }
                                              },
                                            ),
                                      to.status == Status.locationSelect ||
                                              to.status == Status.dateTimeSelect
                                          ? CharterTime()
                                          : Container(),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                          to.status == Status.locationSelect
                              ? Align(
                                  alignment: Alignment.bottomCenter,
                                  child: Note(
                                    onSubmit: () {
                                      to.getVehicles().then((value) {
                                        setState(() {
                                          to.status = Status.vehicleSelect;
                                        });
                                      });
                                    },
                                  ),
                                )
                              : Container(),
                          to.status == Status.dateTimeSelect
                              ? Align(
                                  alignment: Alignment.bottomCenter,
                                  child: SetPickUpWindow(
                                    setPickUpWindow: () {
                                      setState(() {
                                        to.status = Status.locationSelect;
                                      });
                                    },
                                  ),
                                )
                              : Container(),
                          to.status == Status.vehicleSelect
                              ? Align(
                                  alignment: Alignment.bottomCenter,
                                  child: ChooseAVehicle(
                                    onVehicleSelected: (String id) {
                                      to.getVehicleCategory(id).then((value) {
                                        setState(() {
                                          to.status =
                                              Status.vehiclecategorySelect;
                                        });
                                      });
                                    },
                                  ),
                                )
                              : Container(),
                          to.status == Status.chooseFare
                              ? Align(
                                  alignment: Alignment.bottomCenter,
                                  child: ChooseYourFare(
                                    onFareSelected: (Fleet selectedFleet) {
                                      setState(() {
                                        to.selectedFleet = selectedFleet;
                                        print(
                                            "selectedFleet ${to.selectedFleet.fleetId}");
                                        to.status = Status.payment;
                                      });
                                    },
                                  ),
                                )
                              : Container(),
                        ],
                      ),
                      to.status == Status.vehiclecategorySelect
                          ? Align(
                              alignment: Alignment.center,
                              child: VehicleCategory(
                                onClosrButtonClick: () {
                                  setState(() {
                                    to.status = Status.vehicleSelect;
                                  });
                                },
                                onVehicleCategorySelected: () {
                                  to
                                      .getZones(
                                          int.parse(authTo.userModel.country))
                                      .then((value) {
                                    to.getFleets().then((value) {
                                      setState(() {
                                        if (to.availableFleets.length == 0) {
                                          to.status = Status.vehicleSelect;
                                        } else {
                                          to.status = Status.chooseFare;
                                        }
                                      });
                                    });
                                  });
                                },
                              ),
                            )
                          : Container(),
                      to.status == Status.payment
                          ? Align(
                              alignment: Alignment.center,
                              child: ConfirmPaymentMethod(
                                onConfirmPayment: () {
                                  print("to ${to.selectedFleet.fleetId}");

                                  to.rideBooking().then((value) {
                                    print("ride booking " + value.toString());
                                    setState(() {
                                      to.dropAtController.text = '';
                                      to.status = Status.none;
                                    });
                                  }).catchError((onError) {
                                    print("_______" + onError.toString());
                                  });
                                },
                              ),
                            )
                          : Container(),
                      CustomDrawer(
                        updateMenuPosition: () => setState(() {
                          isMenuShow = false;
                        }),
                        isMenuShow: isMenuShow,
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
