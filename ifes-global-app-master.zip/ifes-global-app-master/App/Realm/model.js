import Realm from 'realm'
import DB from './'
export default class Model extends Realm.Object {
  /**
   * Get all Object of class
   * 
   * @static
   * @returns {Realm.Results}
   * @memberof Model
   */
  static all () {
    return DB.db.objects(this.schema.name);
  }

    /**
   * 
   * 
   * @static
   * @param {(array|any)} data 
   * @memberof Model
   */
  static insert (data, object) {
    DB.db.write(() => {
      if (Array.isArray(data)) {
        data.forEach(this.doInsert.bind(this));
        return ;
      }
      this.doInsert(data, object);
    });
  }

  static delete (data, object) {
    DB.db.write(() => {
      this.doDelete(data, object);
    });
  }

  static toggleAction (data, object){
    DB.db.write(() => {
      this.removeOrInsert(data, object);
    });
  }

  static removeOrInsert (data, object){
    if(this.all().filtered(`id = ${data.id}`).length > 0 ){
      let filterTodo = this.all().filtered(`id = ${data.id}`);
      DB.db.delete(filterTodo);
    }else{
      this.doInsert(data, object);
    }
    
  }

  static doInsert (data, object) {
    DB.db.create(this.schema.name, data, this.hasPrimary(data));
  }

  static doDelete (data, object) {
    let filterTodo = this.all().filtered(`id = ${data.id}`);
    
    DB.db.delete(filterTodo);
  }

  static hasPrimary (data) {
    return !!this.schema.primaryKey && !!data[this.schema.primaryKey];
  }
} 