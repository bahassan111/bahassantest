package ma.rak.ovr;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.tabs.TabLayout;

import java.util.List;

import io.realm.Realm;
import ma.rak.ovr.adapter.DemandesAdapter;
import ma.rak.ovr.bodyResponse.AbonnementResponse;
import ma.rak.ovr.bodyResponse.BranchementResponse;
import ma.rak.ovr.models.Abonnement;
import ma.rak.ovr.models.Branchement;
import ma.rak.ovr.storage.SharedPrefManager;
import ma.rak.ovr.ui.main.DemandViewModel;

public class BranchementFragment extends Fragment {

    public RecyclerView recyclerView;
    private SwipeRefreshLayout swipeContainer;
    private List<Branchement> branchementsList = null;
    private List<Abonnement> abonnementList = null;

    private DemandViewModel demandViewModel;
    Realm realm;
    DemandesAdapter demandeAdapter = null;


    BranchementResponse newBrResponse = null;
    AbonnementResponse newAbResponse = null;
    private TextView listTitle, notFoundMsg;
    private TabLayout tabLayout;
    TextView hamMenu;

    boolean isLoading;
    int page = 0;


    String token = SharedPrefManager.getInstance(getActivity()).getToken();

    public static BranchementFragment newInstance() {
        return new BranchementFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_list_demande, container, false);
        tabLayout = (TabLayout) getActivity().findViewById(R.id.tab_layout);
//        hamMenu = getActivity().findViewById(R.id.toolbarUserMenu);
//        hamMenu.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                // If the navigation drawer is not open then open it, if its already open then close it.
////                Toast.makeText(MainActivity.this, "Toolbar", Toast.LENGTH_SHORT).show();
//                showPopup(v);
//            }
//        });


//        recyclerView = getActivity().findViewById(R.id.list);
        recyclerView = rootView.findViewById(R.id.list);
        swipeContainer = rootView.findViewById(R.id.swipeContainer);
        swipeContainer.setOnRefreshListener(() -> {
            // Your code to refresh the list here.
            // Make sure you call swipeContainer.setRefreshing(false)
            // once the network request has completed successfully.
            fetchData(0, token, page);
            // ...the data has come back, add new items to your adapter...
            // Now we call setRefreshing(false) to signal refresh has finished
            swipeContainer.setRefreshing(false);
        });
        // Configure the refreshing colors
        swipeContainer.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light);

        return rootView;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        realm.close();
    }

    public void showPopup(View v) {
        PopupMenu popup = new PopupMenu(getActivity(), v);
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {

                    case R.id.action_branchement:
                        if (SharedPrefManager.getInstance(getActivity()).isLogged()) {
                            SharedPrefManager.getInstance(getActivity()).operationMode(1);
                            Toast.makeText(getActivity(), R.string.mode_branchement, Toast.LENGTH_SHORT).show();
                            fetchData(0, token, page);

                            hamMenu.setText("Branchement");
                            getActivity().finish();
                            startActivity(getActivity().getIntent());
                        }
                        return true;
                    case R.id.action_abonnements:
                        if (SharedPrefManager.getInstance(getActivity()).isLogged()) {
                            SharedPrefManager.getInstance(getActivity()).operationMode(2);
                            Toast.makeText(getActivity(), R.string.mode_abonnement, Toast.LENGTH_SHORT).show();
                            fetchData(0, token, page);
                            hamMenu.setText("Abonnement");
                            getActivity().finish();
                            startActivity(getActivity().getIntent());
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });
        popup.inflate(R.menu.toolbar_menu);
        popup.show();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        realm = Realm.getDefaultInstance();

        demandViewModel = ViewModelProviders.of(this).get(DemandViewModel.class);
        if (SharedPrefManager.getInstance(getActivity()).getMode() == 1) {
            demandViewModel.getBrachments(token, 1, getActivity(), 0);
        } else {
            demandViewModel.getAbonnements(token, 0, getContext());
        }
        fetchData(0, token, page);

        recyclerView.setAdapter(demandeAdapter);
        initScrollListener();

    }

    public void fetchData(int status, String token, int page) {
//        progressOverlay.setVisibility(View.VISIBLE);
        /*demandeAdapter = new DemandesAdapter(getActivity(), branchementsList, abonnementList);
        if (SharedPrefManager.getInstance(getActivity()).getMode() == 1) {
            listTitle.setText(getString(R.string.listArchiveBr));

            demandViewModel.getBrachments(token, page);
            newBrResponse = new BranchementResponse();
            demandViewModel.BrResponseMutableLiveData.observe(getActivity(), new Observer<BranchementResponse>() {
                @Override
                public void onChanged(BranchementResponse branchementResponse) {
                    newBrResponse = branchementResponse;
                    demandeAdapter.setList(branchementResponse.getData(), null);
                    tabLayout.getTabAt(1).setText("Traitée (" + branchementResponse.getData().size() + ")");
                }

            });
            if (newBrResponse != null && newBrResponse.getData() != null) {

                tabLayout.getTabAt(1).setText("Traitée (" + newBrResponse.getData().size() + ")");

                try {
                    realm.executeTransaction(realm -> {

                        realm.copyToRealm(newBrResponse);
                    });
                } catch (RealmException realmException) {
                    Log.e("demandesResponse", realmException.getMessage());
                } finally {
//                realm.close();
                }
            }

        } else {
            listTitle.setText(getString(R.string.listArchiveAb));
            demandViewModel.getAbonnements(token, status, getContext());
            newAbResponse = new AbonnementResponse();
            demandViewModel.AbResponseMutableLiveData.observe(getActivity(), new Observer<ArrayList>() {
                @Override
                public void onChanged(ArrayList data) {
                    demandeAdapter.setList(null, data);
                    //newAbResponse = abonnementResponse;
                    tabLayout.getTabAt(1).setText("En instance (" + newAbResponse.getData().size() + ")");
                }

            });
            if (newAbResponse != null && newAbResponse.getData() != null) {
                tabLayout.getTabAt(1).setText("Traitée (" + newAbResponse.getData().size() + ")");

                try {
                    realm.executeTransaction(realm -> {
                        realm.copyToRealm(newAbResponse);
                    });
                } catch (RealmException realmException) {
                    Log.e("abonnementResponse", realmException.getMessage());
                } finally {
//                realm.close();
                }
            }

        }*/


    }

    private void initScrollListener() {
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();


                if (!isLoading) {
                    if (linearLayoutManager != null && linearLayoutManager.findLastCompletelyVisibleItemPosition() == branchementsList.size() - 1) {
                        //bottom of list!
                        loadMore();
                        isLoading = true;
                    }
                }
            }
        });

    }

    private void loadMore() {
        branchementsList.add(null);
        demandeAdapter.notifyItemInserted(branchementsList.size() - 1);


        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                branchementsList.remove(branchementsList.size() - 1);
                int scrollPosition = branchementsList.size();
                demandeAdapter.notifyItemRemoved(scrollPosition);
                int currentSize = scrollPosition;
                int nextLimit = currentSize + 10;
                int nextPage = page + 1;

                while (currentSize - 1 < nextLimit) {
                    fetchData(0, token, nextPage);
                    currentSize++;
                }

                demandeAdapter.notifyDataSetChanged();
                isLoading = false;
            }
        }, 2000);


    }

}