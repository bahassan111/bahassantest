import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rider_app/controllers/controllers.dart';
import '../../constants/app_themes.dart';

class ChooseAVehicle extends StatelessWidget {
  const ChooseAVehicle({this.onVehicleSelected});
  final Function onVehicleSelected;
  static HomeController to = Get.find();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: AppThemes.lightWhitebackGroundColor,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(10),
            topRight: Radius.circular(10),
          )),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(height: 5),
          Container(
            width: 75,
            child: Divider(
              color: AppThemes.lightPinkBackGroundColor,
              thickness: 3,
            ),
          ),
          Text(
            "chooseAVehicle".tr,
            style: Theme.of(context)
                .textTheme
                .headline2
                .copyWith(fontSize: 16, fontWeight: FontWeight.w700),
          ),
          SizedBox(height: 5),
          Container(
            height: 90,
            child: ListView.builder(
              itemCount: to.typesOfVehicle.length,
              scrollDirection: Axis.horizontal,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () {
                    to.selectedTypeOfVehicle = to.typesOfVehicle[index];
                    onVehicleSelected(to.typesOfVehicle[index].id);
                  },
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                    decoration: BoxDecoration(
                        border: Border(
                      top: BorderSide(
                        color: AppThemes.lightMenuIconBorder,
                      ),
                      right: BorderSide(
                        color: AppThemes.lightMenuIconBorder,
                      ),
                      bottom: BorderSide(
                        color: AppThemes.lightMenuIconBorder,
                      ),
                    )),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Image.network(
                          to.typesOfVehicle[index].icon,
                          height: 40,
                        ),
                        SizedBox(height: 5),
                        Text(
                          to.typesOfVehicle[index].name,
                          maxLines: 1,
                          style: Theme.of(context).textTheme.headline2.copyWith(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                              ),
                        ),
                        SizedBox(height: 5),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
