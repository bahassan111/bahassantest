(function () {
    var view = $('#test_a_case_view');
    if (!view.length) return;

    var btn = $('.runtestcase'), holder = $('.result_holder');

    log(view, btn);

    $(view)
        .on('click', '.runtestcase', function () {

            log('ui');
            btn.prop('disabled', true);


            holder.find('p').show().html('Running ..');
            holder.find('ul').html('');

            post('project/do_test/' + case_id, {}, function (rep) {
                var id = randomID(20);

                holder.find('ul')
                    .append(`<li class="f"><span class="t">Result</span><span class="v">${rep.status}</span></li>`)
                    .append(`<li class="f"><span class="t">Text</span><span class="v">${rep.result}</span></li>`)
                    .append(`<li class="f"><span class="t">Runtime</span><span class="v">${rep.runtime}</span></li>`)
                    .append(`<li class="f mt-4 border-bottom"><span class="t">Asserts</span><span class="v"></span></li>`);

                $.each(rep.asserts, function (i, assert) {
                    holder.find('ul').append(`<li class="f pl-3"><span class="t">${assert.self.title}</span><span class="v">${assert.status}</span></li>`);
                });

                holder.find('ul').append(`<li class="f"><span class="t">Response Header</span></li>`);
                holder.find('ul').append(`<li class="f"><div style="width: 100%"><a id="h${id}" href="javascript:void(0);">Show response header</a></div></li>`);
                holder.find('ul').append(`<li class="f"><span class="t">Response Body</span></li>`);
                holder.find('ul').append(`<li class="f"><div style="width: 100%"><a id="b${id}" href="javascript:void(0);">Show response body</a></div></li>`);

                //holder.find('.txtcoderesponse')[0].innerText = rep.query.body;


                holder.on('click', '#h'+id, function () {
                    var div = $(this).parent().html('');
                    $.each(rep.query.headers, function (k, v) {
                        div.append(`<div>${k} : ${v}</div>`);
                    });
                });

                holder.on('click', '#b'+id, function () {
                    var div = $(this).parent().html('<pre><textarea style="height: 260px;width: 100%;">Loading ..</textarea></pre>');
                    setTimeout(function () {


                        div.find('textarea')[0].innerText = rep.query.body;

                    }, 300);

                });

            }, function () {
                btn.prop('disabled', false);
                holder.find('p').hide();
            }, function () {

            })

        })
        .ready(function () {

            btn.trigger('click');
        })
    ;



})();