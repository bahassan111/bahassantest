import React, { PureComponent } from "react";
import {AsyncStorage, Platform} from "react-native";
import { View, TextField,Text ,TouchableOpacity } from "react-native-ui-lib";

import Colors from "../constants/Colors";
import Icon from "../constants/Icons";

import { connect } from "react-redux";

import { searchChapitre,searchChapitreAll } from "../Redux/actions/ChapitresActions";
import I18n from "../commons/i18n";
class SearchBar extends PureComponent {
  state = {
      search:''
  };

    async componentDidMount() {

        let search=await AsyncStorage.getItem('search');
        this.setState({search:search});
    }

    async componentDidUpdate(prevProps, prevState) {


        let search=await AsyncStorage.getItem('search');
        this.setState({search:search});

        console.log('search,search');
        console.log(search);
    }


    render() {

    const { navigate } = this.props.navigation;
    let check_page = false;
    if(this.props.navigation.state.routeName === 'Search') {check_page = true;}
    else if(this.props.navigation.state.routeName === 'DetailChapitre') {check_page = true;}
    else { check_page = false; }
    return (
      <View row flex centerV>
        <View row flex centerV paddingH-15
              style={{
                  display: check_page  ?'none':'flex',
                  width:100,
                  paddingRight:20,
                  paddingLeft:20,
              }}
        >
            {/*<Icon
            name="ion-ios7-search"
            iconSize={20}
            style={{
              marginBottom: Platform.OS == "android" ? 5 : 0,
            }}
            color={Colors.tabBar}
          />

          <Text
            text70={Platform.OS == "android"}
            text80={Platform.OS == "ios"}
            containerStyle={{ marginTop: 20, paddingHorizontal: 5, flex: 1 }}
            style={{
              color: Colors.tabBar,
              textAlign: this.props.lang == "ar" ? "right" : "left",
            }}
            clearButtonMode={"while-editing"}
          >
            {I18n.t("Commons.search", { locale: this.props.lang })}
          </Text>*/}


            <TouchableOpacity style={{
                flex:1,justifyContent:'space-evenly',alignItems:'center',flexDirection: 'row'
            }}
                              onPress={() => navigate('Search')}
                              >
                    <Icon
                        style={{
                            textAlign: this.props.lang == "ar" ? "right" : "left",
                        }}
                        name="ion-ios7-search"
                        iconSize={30}
                        color={Colors.tabBar}
                    />
                    <Text
                        text70={Platform.OS == "android"}
                        text80={Platform.OS == "ios"}
                        containerStyle={{ marginTop: 20, paddingHorizontal: 5, flex: 1 }}
                        style={{
                            color: Colors.tabBar,
                            textAlign: this.props.lang == "ar" ? "right" : "left",
                        }}
                        clearButtonMode={"while-editing"}
                    >
                        {this.state.search}
                    </Text>

            </TouchableOpacity>

          {/* <TouchableOpacity onPress={() => null}>
            <Icon name="ion-close-round" iconSize={15} color={Colors.tabBar} />
          </TouchableOpacity> */}
        </View>
      </View>
    );
  }
}

const mapStateToProps = state => {
  const lang = state.fontSize.lang;

  return { lang };
};

export default connect(
  mapStateToProps,
  { searchChapitre,searchChapitreAll }
)(SearchBar);
