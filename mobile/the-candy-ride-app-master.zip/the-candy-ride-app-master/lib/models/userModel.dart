class UserModel {
  String riderid;
  String fullname;
  String country;
  String email;
  String password;
  String userImage;
  String mobile;

  UserModel(
      {this.riderid,
      this.fullname,
      this.country,
      this.email,
      this.password,
      this.userImage,
      this.mobile});

  UserModel.fromJson(Map<String, dynamic> json) {
    riderid = json['riderid'];
    fullname = json['fullname'];
    country = json['country'];
    email = json['email'];
    password = json['password'];
    userImage = json['user_image'];
    mobile = json['mobile'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['riderid'] = this.riderid;
    data['fullname'] = this.fullname;
    data['country'] = this.country;
    data['email'] = this.email;
    data['password'] = this.password;
    data['user_image'] = this.userImage;
    data['mobile'] = this.mobile;
    return data;
  }
}
