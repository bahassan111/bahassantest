<?php
addJS(['assets/js/test_a_case.js']);

$case->params = json_decode($case->params) ?: [];
$case->headers = json_decode($case->headers) ?: [];
?>
<div id="test_a_case_view">
    <div class="group scase_dets">
        <label>Details</label>
        <ul>
            <li><span class="t">Method</span><span class="v"><?= $case->method; ?></span></li>
            <li><span class="t">URL</span><span class="v"><?= $case->url; ?></span></li>
        </ul>
    </div>
    <?php if($case->headers){?>
        <div class="group scase_dets">
            <label>Headers</label>
            <ul>
                <?php foreach($case->headers as $header => $val){ ?>
                    <li><span class="t"><?= $header; ?></span><span class="v"><?= $val; ?></span></li>
                <?php } ?>
            </ul>
        </div>
    <?php } ?>
    <?php if($case->params){?>
        <div class="group scase_dets">
            <label>Parametres</label>
            <ul>
                <?php foreach($case->params as $header => $val){ ?>
                    <li><span class="t"><?= $header; ?></span><span class="v"><?= $val; ?></span></li>
                <?php } ?>
            </ul>
        </div>
    <?php } ?>
    <div class="text-sm-center pb-3 pt-3">
        <button class="btn btn-sm btn-outline-success runtestcase">Run a test  <i class="fas fa-play"></i></button>
    </div>

    <div class="group scase_dets result_holder">
        <label>Result</label>
        <p class="text-sm-center">Run a test first..</p>
        <ul>

        </ul>
    </div>
</div>


<script>
    var case_id = <?= $case->id ?: 0 ?>;
</script>