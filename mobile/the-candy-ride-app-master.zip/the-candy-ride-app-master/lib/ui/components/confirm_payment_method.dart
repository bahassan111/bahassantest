import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../constants/app_themes.dart';

class ConfirmPaymentMethod extends StatelessWidget {
  const ConfirmPaymentMethod({this.onConfirmPayment});
  final Function onConfirmPayment;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 230,
      margin: EdgeInsets.symmetric(horizontal: 30),
      decoration: BoxDecoration(
          color: AppThemes.lightWhitebackGroundColor,
          borderRadius: BorderRadius.all(
            Radius.circular(15),
          ),
          boxShadow: [
            BoxShadow(
                color: AppThemes.lightBlackbackGroundColor.withOpacity(0.3),
                offset: Offset(0, 3),
                blurRadius: 0,
                spreadRadius: 3)
          ]),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(height: 10),
          Text(
            "confirmPaymentMethod".tr,
            style: Theme.of(context).textTheme.headline2.copyWith(
                  fontSize: 16,
                ),
          ),
          Divider(
            color: AppThemes.lightPinkBackGroundColor,
            thickness: 3,
          ),
          MediaQuery.removePadding(
            context: context,
            removeTop: true,
            child: ListView.builder(
              itemCount: 1,
              shrinkWrap: true,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: onConfirmPayment,
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 13),
                    decoration: BoxDecoration(
                        border: Border(
                      bottom: BorderSide(
                        color: AppThemes.lightDividerColor,
                      ),
                    )),
                    child: Center(
                      child: Text(
                        "Cash/Pilot Pay",
                        style: Theme.of(context).textTheme.headline2.copyWith(
                              fontSize: 14,
                            ),
                      ),
                    ),
                  ),
                );
              },
            ),
          )
        ],
      ),
    );
  }
}
