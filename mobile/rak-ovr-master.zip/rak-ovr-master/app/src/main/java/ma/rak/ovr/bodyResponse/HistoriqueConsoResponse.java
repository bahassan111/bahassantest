package ma.rak.ovr.bodyResponse;

import com.google.gson.annotations.SerializedName;

import io.realm.RealmList;
import io.realm.RealmObject;
import ma.rak.ovr.models.Resultat;
import ma.rak.ovr.models.Stade;
import ma.rak.ovr.models.Statuses;

public class HistoriqueConsoResponse extends RealmObject {

    @SerializedName("status")
    private String status;

    @SerializedName("statuses")
    private RealmList<Statuses> statuses;

    @SerializedName("stades")
    private RealmList<Stade> stades;

    @SerializedName("results")
    private RealmList<Resultat> results;

    public HistoriqueConsoResponse(){}

    public HistoriqueConsoResponse(String status, RealmList<Statuses> statuses, RealmList<Stade> stades, RealmList<Resultat> results) {
        this.status = status;
        this.statuses = statuses;
        this.stades = stades;
        this.results = results;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public RealmList<Statuses> getStatuses() {
        return statuses;
    }

    public void setStatuses(RealmList<Statuses> statuses) {
        this.statuses = statuses;
    }

    public RealmList<Stade> getStades() {
        return stades;
    }

    public void setStades(RealmList<Stade> stades) {
        this.stades = stades;
    }

    public RealmList<Resultat> getResults() {
        return results;
    }

    public void setResults(RealmList<Resultat> results) {
        this.results = results;
    }

    @Override
    public String toString() {
        return "SettingsResponse{" +
                "status='" + status + '\'' +
                ", statuses=" + statuses +
                ", stades=" + stades +
                ", results=" + results +
                '}';
    }
}
