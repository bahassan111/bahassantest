<?php
?>

<div id="files_view">

    <div class="dt_section">

        <div class="dt_head">
            <div class="t">
                <h3>Toutes les fichiers</h3>
            </div>
            <div class="a">
                <button class="button default" data-table="regions_tbl" id="reload_table"><i class="fas fa-sync-alt"></i> </button>
                <button class="button primary" id="add_file">Ajouter ficher <i class="fas fa-plus"></i> </button>
            </div>
        </div>

        <div class="dt_inner">
            <?= datatable('files_tbl', 4); ?>
        </div>

    </div>

</div>
