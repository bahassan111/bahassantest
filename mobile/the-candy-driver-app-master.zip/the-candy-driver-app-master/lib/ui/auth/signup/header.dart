import 'dart:io';

import 'package:driver/constants/helpers/helpers.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:driver/models/models.dart';
import 'package:flutter/material.dart';
import 'package:driver/constants/constants.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

class Header extends StatefulWidget {
  @override
  _HeaderState createState() => _HeaderState();
}

class _HeaderState extends State<Header> {
  final AuthController authController = AuthController.to;

  double height, width;

  @override
  void initState() {
    super.initState();
    if (authController.userModel != null) {
      // set fleet
      authController.fleets.forEach((element) {
        if (element.id == authController.userModel.fleetid) {
          authController.selectedFleet = element;
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        SizedBox(
          height: 20,
        ),
        Container(
          height: 80,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage(AllImages.theCandy),
              fit: BoxFit.fitHeight,
            ),
          ),
        ),
        Text(
          "register_message".tr,
          style: Theme.of(context).textTheme.headline1.copyWith(
                fontSize: 20,
                fontWeight: FontWeight.w500,
              ),
        ),
        SizedBox(
          height: 15,
        ),
        Container(
          height: 38.0,
          width: width,
          margin: EdgeInsets.symmetric(horizontal: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(40),
            border: Border.all(
              color: AppThemes.lightInputBorderColor,
            ),
          ),
          child: Center(
            child: PopupMenuButton<Fleet>(
              itemBuilder: (context) {
                return authController.fleets.map((fleet) {
                  return PopupMenuItem(
                    value: fleet,
                    child: Text(
                      fleet.displayName,
                      style: Theme.of(context)
                          .textTheme
                          .headline1
                          .copyWith(fontSize: 16),
                    ),
                  );
                }).toList();
              },
              child: Stack(
                children: <Widget>[
                  Center(
                    child: Text(
                      authController.selectedFleet != null
                          ? authController.selectedFleet.displayName
                          : "choose_your_fleet".tr,
                      style: Theme.of(context)
                          .textTheme
                          .headline2
                          .copyWith(fontSize: 18, fontWeight: FontWeight.w500),
                    ),
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Padding(
                      padding: const EdgeInsets.only(right: 15),
                      child: Icon(
                        Icons.keyboard_arrow_down_outlined,
                        size: 30,
                        color: AppThemes.lightdeepPinkDropDownIconColor,
                      ),
                    ),
                  ),
                ],
              ),
              onSelected: (fleet) {
                setState(() {
                  authController.selectedFleet = fleet;
                });
              },
            ),
          ),
        ),
        SizedBox(
          height: 30,
        ),
        GestureDetector(
          onTap: () async {
            if (authController.userModel == null) {
              PickedFile image = await imgFromGallery(context);
              if (image != null) {
                setState(() {
                  authController.userProfileImg = image;
                });
              }
            }
          },
          child: Container(
            height: 100,
            width: 100,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: authController.userProfileImg != null
                    ? FileImage(File(authController.userProfileImg.path))
                    : authController.userModel != null
                        ? NetworkImage(authController.userModel.profilephoto)
                        : AssetImage(
                            AllImages.uploadPhoto,
                          ),
                fit: BoxFit.fitWidth,
              ),
              shape: BoxShape.circle,
            ),
            child: authController.userProfileImg != null ||
                    authController.userModel != null
                ? Container()
                : Stack(
                    children: [
                      Center(
                        child: Text(
                          "upload_message".tr,
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 12),
                        ),
                      ),
                      Align(
                        alignment: Alignment.bottomRight,
                        child: Icon(
                          Icons.add,
                          color: AppThemes.lightdeepPinkDropDownIconColor,
                          size: 30,
                        ),
                      ),
                    ],
                  ),
          ),
        )
      ],
    );
  }
}
