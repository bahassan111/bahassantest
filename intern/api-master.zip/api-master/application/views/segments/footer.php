<?php

echo getJS();

?>


</body>
</html>
