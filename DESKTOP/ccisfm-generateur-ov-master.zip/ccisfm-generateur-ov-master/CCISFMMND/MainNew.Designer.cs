﻿namespace CCISFMMND
{
    partial class MainNew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Telerik.WinControls.UI.ListViewDetailColumn listViewDetailColumn1 = new Telerik.WinControls.UI.ListViewDetailColumn("Column 0", "Column 0");
            Telerik.WinControls.UI.ListViewDetailColumn listViewDetailColumn2 = new Telerik.WinControls.UI.ListViewDetailColumn("Column 1", "Column 1");
            Telerik.WinControls.UI.ListViewDetailColumn listViewDetailColumn3 = new Telerik.WinControls.UI.ListViewDetailColumn("Column 0", "NOM & Prénom");
            Telerik.WinControls.UI.ListViewDetailColumn listViewDetailColumn4 = new Telerik.WinControls.UI.ListViewDetailColumn("Column 1", "RIB");
            Telerik.WinControls.UI.ListViewDetailColumn listViewDetailColumn5 = new Telerik.WinControls.UI.ListViewDetailColumn("Column 2", "Montant");
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainNew));
            this.param = new Telerik.WinControls.UI.RadGroupBox();
            this.radButton2 = new Telerik.WinControls.UI.RadButton();
            this.radButton1 = new Telerik.WinControls.UI.RadButton();
            this.radLabel9 = new Telerik.WinControls.UI.RadLabel();
            this.p_user = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.radLabel8 = new Telerik.WinControls.UI.RadLabel();
            this.p_tel = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.radLabel7 = new Telerik.WinControls.UI.RadLabel();
            this.p_code = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.radLabel3 = new Telerik.WinControls.UI.RadLabel();
            this.p_address = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.total = new Telerik.WinControls.UI.RadLabel();
            this.remise = new Telerik.WinControls.UI.RadDropDownList();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.fluentTheme1 = new Telerik.WinControls.Themes.FluentTheme();
            this.office2013LightTheme1 = new Telerik.WinControls.Themes.Office2013LightTheme();
            this.radPanel1 = new Telerik.WinControls.UI.RadPanel();
            this.seg = new Telerik.WinControls.UI.RadListView();
            this.ramt = new Telerik.WinControls.UI.RadLabel();
            this.nom = new Telerik.WinControls.UI.RadTextBox();
            this.add = new Telerik.WinControls.UI.RadButton();
            this.radLabel2 = new Telerik.WinControls.UI.RadLabel();
            this.save = new Telerik.WinControls.UI.RadButton();
            this.date = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.radGroupBox2 = new Telerik.WinControls.UI.RadGroupBox();
            this.list = new Telerik.WinControls.UI.RadListView();
            this.radLabel6 = new Telerik.WinControls.UI.RadLabel();
            this.amt = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.rib = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.radLabel5 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel4 = new Telerik.WinControls.UI.RadLabel();
            this.itemm = new Telerik.WinControls.UI.RadContextMenu(this.components);
            this.itemedit = new Telerik.WinControls.UI.RadMenuItem();
            this.radMenuSeparatorItem1 = new Telerik.WinControls.UI.RadMenuSeparatorItem();
            this.del_item = new Telerik.WinControls.UI.RadMenuItem();
            this.radMenuSeparatorItem2 = new Telerik.WinControls.UI.RadMenuSeparatorItem();
            this.delall = new Telerik.WinControls.UI.RadMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fichierToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sauvgarderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.importerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.quitterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.outilsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.baseDeDonnéeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.themeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.defaultToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.blackToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.noirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fluentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.crystalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.desertToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.crystalTheme1 = new Telerik.WinControls.Themes.CrystalTheme();
            this.desertTheme1 = new Telerik.WinControls.Themes.DesertTheme();
            this.office2013DarkTheme1 = new Telerik.WinControls.Themes.Office2013DarkTheme();
            this.visualStudio2012DarkTheme1 = new Telerik.WinControls.Themes.VisualStudio2012DarkTheme();
            this.historiqueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.param)).BeginInit();
            this.param.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radButton2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p_user)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p_tel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p_code)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p_address)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.total)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.remise)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel1)).BeginInit();
            this.radPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.seg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ramt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.add)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.save)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.date)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox2)).BeginInit();
            this.radGroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.list)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.amt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rib)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // param
            // 
            this.param.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.param.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.param.Controls.Add(this.radButton2);
            this.param.Controls.Add(this.radButton1);
            this.param.Controls.Add(this.radLabel9);
            this.param.Controls.Add(this.p_user);
            this.param.Controls.Add(this.radLabel8);
            this.param.Controls.Add(this.p_tel);
            this.param.Controls.Add(this.radLabel7);
            this.param.Controls.Add(this.p_code);
            this.param.Controls.Add(this.radLabel3);
            this.param.Controls.Add(this.p_address);
            this.param.HeaderText = "  Parametres  ";
            this.param.Location = new System.Drawing.Point(119, 538);
            this.param.Name = "param";
            this.param.Size = new System.Drawing.Size(431, 35);
            this.param.TabIndex = 99;
            this.param.Text = "  Parametres  ";
            this.param.ThemeName = "Office2013Light";
            this.param.Visible = false;
            // 
            // radButton2
            // 
            this.radButton2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.radButton2.Location = new System.Drawing.Point(15, -18);
            this.radButton2.Name = "radButton2";
            this.radButton2.Size = new System.Drawing.Size(186, 38);
            this.radButton2.TabIndex = 28;
            this.radButton2.Text = "Annuler";
            this.radButton2.Click += new System.EventHandler(this.radButton2_Click);
            // 
            // radButton1
            // 
            this.radButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.radButton1.Location = new System.Drawing.Point(231, -18);
            this.radButton1.Name = "radButton1";
            this.radButton1.Size = new System.Drawing.Size(186, 38);
            this.radButton1.TabIndex = 27;
            this.radButton1.Text = "Enregistrer les parametres";
            this.radButton1.Click += new System.EventHandler(this.radButton1_Click_1);
            // 
            // radLabel9
            // 
            this.radLabel9.AutoSize = false;
            this.radLabel9.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel9.Location = new System.Drawing.Point(275, 96);
            this.radLabel9.Name = "radLabel9";
            this.radLabel9.Size = new System.Drawing.Size(209, 18);
            this.radLabel9.TabIndex = 26;
            this.radLabel9.Text = "Utilisateur :";
            this.radLabel9.Visible = false;
            // 
            // p_user
            // 
            this.p_user.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_user.Location = new System.Drawing.Point(275, 120);
            this.p_user.Name = "p_user";
            this.p_user.Padding = new System.Windows.Forms.Padding(4);
            this.p_user.Size = new System.Drawing.Size(209, 28);
            this.p_user.TabIndex = 25;
            this.p_user.TabStop = false;
            this.p_user.Text = "Monsieur ZIANE Mohammed";
            // 
            // radLabel8
            // 
            this.radLabel8.AutoSize = false;
            this.radLabel8.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel8.Location = new System.Drawing.Point(275, 38);
            this.radLabel8.Name = "radLabel8";
            this.radLabel8.Size = new System.Drawing.Size(209, 18);
            this.radLabel8.TabIndex = 24;
            this.radLabel8.Text = "Tél :";
            this.radLabel8.Visible = false;
            // 
            // p_tel
            // 
            this.p_tel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_tel.Location = new System.Drawing.Point(275, 62);
            this.p_tel.Mask = "#### ## ## ##";
            this.p_tel.MaskType = Telerik.WinControls.UI.MaskType.Standard;
            this.p_tel.Name = "p_tel";
            this.p_tel.Padding = new System.Windows.Forms.Padding(4);
            this.p_tel.Size = new System.Drawing.Size(209, 28);
            this.p_tel.TabIndex = 23;
            this.p_tel.TabStop = false;
            this.p_tel.Text = "0535 62 31 83";
            // 
            // radLabel7
            // 
            this.radLabel7.AutoSize = false;
            this.radLabel7.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel7.Location = new System.Drawing.Point(15, 128);
            this.radLabel7.Name = "radLabel7";
            this.radLabel7.Size = new System.Drawing.Size(209, 18);
            this.radLabel7.TabIndex = 22;
            this.radLabel7.Text = "Code :";
            this.radLabel7.Visible = false;
            // 
            // p_code
            // 
            this.p_code.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_code.Location = new System.Drawing.Point(15, 152);
            this.p_code.Name = "p_code";
            this.p_code.Padding = new System.Windows.Forms.Padding(4);
            this.p_code.Size = new System.Drawing.Size(209, 28);
            this.p_code.TabIndex = 21;
            this.p_code.TabStop = false;
            this.p_code.Text = "1005 TR FES";
            // 
            // radLabel3
            // 
            this.radLabel3.AutoSize = false;
            this.radLabel3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel3.Location = new System.Drawing.Point(15, 38);
            this.radLabel3.Name = "radLabel3";
            this.radLabel3.Size = new System.Drawing.Size(209, 18);
            this.radLabel3.TabIndex = 20;
            this.radLabel3.Text = "Adresse :";
            this.radLabel3.Visible = false;
            // 
            // p_address
            // 
            this.p_address.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p_address.Location = new System.Drawing.Point(15, 62);
            this.p_address.Multiline = true;
            this.p_address.Name = "p_address";
            this.p_address.Padding = new System.Windows.Forms.Padding(4);
            // 
            // 
            // 
            this.p_address.RootElement.StretchVertically = true;
            this.p_address.Size = new System.Drawing.Size(209, 56);
            this.p_address.TabIndex = 19;
            this.p_address.TabStop = false;
            this.p_address.Text = "73 chambre de commerce dindustrie et de services de";
            // 
            // total
            // 
            this.total.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.total.AutoSize = false;
            this.total.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.total.Location = new System.Drawing.Point(12, 535);
            this.total.Name = "total";
            this.total.Size = new System.Drawing.Size(450, 43);
            this.total.TabIndex = 7;
            this.total.Tag = "0";
            this.total.Text = "0 DH";
            // 
            // remise
            // 
            this.remise.AutoSize = false;
            this.remise.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.remise.Location = new System.Drawing.Point(442, 36);
            this.remise.Name = "remise";
            this.remise.Size = new System.Drawing.Size(232, 32);
            this.remise.TabIndex = 0;
            // 
            // radLabel1
            // 
            this.radLabel1.AutoSize = false;
            this.radLabel1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel1.Location = new System.Drawing.Point(439, 12);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(164, 18);
            this.radLabel1.TabIndex = 4;
            this.radLabel1.Text = "Numéro de Remise :";
            // 
            // radPanel1
            // 
            this.radPanel1.Controls.Add(this.param);
            this.radPanel1.Controls.Add(this.seg);
            this.radPanel1.Controls.Add(this.total);
            this.radPanel1.Controls.Add(this.remise);
            this.radPanel1.Controls.Add(this.ramt);
            this.radPanel1.Controls.Add(this.nom);
            this.radPanel1.Controls.Add(this.radLabel1);
            this.radPanel1.Controls.Add(this.add);
            this.radPanel1.Controls.Add(this.radLabel2);
            this.radPanel1.Controls.Add(this.save);
            this.radPanel1.Controls.Add(this.date);
            this.radPanel1.Controls.Add(this.radGroupBox2);
            this.radPanel1.Controls.Add(this.radLabel6);
            this.radPanel1.Controls.Add(this.amt);
            this.radPanel1.Controls.Add(this.rib);
            this.radPanel1.Controls.Add(this.radLabel5);
            this.radPanel1.Controls.Add(this.radLabel4);
            this.radPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.radPanel1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radPanel1.Location = new System.Drawing.Point(0, 24);
            this.radPanel1.Name = "radPanel1";
            this.radPanel1.Size = new System.Drawing.Size(778, 585);
            this.radPanel1.TabIndex = 1;
            // 
            // seg
            // 
            listViewDetailColumn1.HeaderText = "Column 0";
            listViewDetailColumn2.HeaderText = "Column 1";
            this.seg.Columns.AddRange(new Telerik.WinControls.UI.ListViewDetailColumn[] {
            listViewDetailColumn1,
            listViewDetailColumn2});
            this.seg.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seg.ItemSpacing = -1;
            this.seg.Location = new System.Drawing.Point(423, 173);
            this.seg.Name = "seg";
            this.seg.ShowColumnHeaders = false;
            this.seg.Size = new System.Drawing.Size(87, 32);
            this.seg.TabIndex = 16;
            this.seg.ViewType = Telerik.WinControls.UI.ListViewType.DetailsView;
            this.seg.Visible = false;
            this.seg.SelectedItemChanged += new System.EventHandler(this.seg_SelectedItemChanged);
            this.seg.ItemMouseClick += new Telerik.WinControls.UI.ListViewItemEventHandler(this.seg_ItemMouseClick);
            this.seg.KeyUp += new System.Windows.Forms.KeyEventHandler(this.seg_KeyUp);
            this.seg.Leave += new System.EventHandler(this.seg_Leave);
            // 
            // ramt
            // 
            this.ramt.AutoSize = false;
            this.ramt.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ramt.Location = new System.Drawing.Point(15, 187);
            this.ramt.Name = "ramt";
            this.ramt.Size = new System.Drawing.Size(224, 18);
            this.ramt.TabIndex = 17;
            this.ramt.Text = "Dernier montant : ";
            this.ramt.Visible = false;
            this.ramt.Click += new System.EventHandler(this.ramt_Click);
            this.ramt.DoubleClick += new System.EventHandler(this.ramt_DoubleClick);
            // 
            // nom
            // 
            this.nom.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nom.Location = new System.Drawing.Point(15, 36);
            this.nom.Name = "nom";
            this.nom.Padding = new System.Windows.Forms.Padding(4);
            this.nom.Size = new System.Drawing.Size(370, 30);
            this.nom.TabIndex = 1;
            this.nom.TextChanged += new System.EventHandler(this.nom_TextChanged_1);
            this.nom.KeyUp += new System.Windows.Forms.KeyEventHandler(this.nom_KeyUp);
            this.nom.Leave += new System.EventHandler(this.nom_Leave);
            // 
            // add
            // 
            this.add.Enabled = false;
            this.add.Location = new System.Drawing.Point(245, 158);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(140, 28);
            this.add.TabIndex = 4;
            this.add.Text = "Ajouter sur la tableau";
            this.add.ThemeName = "VisualStudio2012Dark";
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // radLabel2
            // 
            this.radLabel2.AutoSize = false;
            this.radLabel2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel2.Location = new System.Drawing.Point(439, 74);
            this.radLabel2.Name = "radLabel2";
            this.radLabel2.Size = new System.Drawing.Size(209, 18);
            this.radLabel2.TabIndex = 18;
            this.radLabel2.Text = "Date :";
            this.radLabel2.Visible = false;
            // 
            // save
            // 
            this.save.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.save.Enabled = false;
            this.save.Location = new System.Drawing.Point(597, 535);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(173, 38);
            this.save.TabIndex = 13;
            this.save.Text = "Sauvgarder";
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // date
            // 
            this.date.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date.Location = new System.Drawing.Point(442, 98);
            this.date.Mask = "d";
            this.date.MaskType = Telerik.WinControls.UI.MaskType.DateTime;
            this.date.Name = "date";
            this.date.Padding = new System.Windows.Forms.Padding(4);
            this.date.SelectedText = "21";
            this.date.SelectionLength = 2;
            this.date.Size = new System.Drawing.Size(232, 28);
            this.date.TabIndex = 15;
            this.date.TabStop = false;
            this.date.Text = "21/06/2021";
            // 
            // radGroupBox2
            // 
            this.radGroupBox2.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.radGroupBox2.Controls.Add(this.list);
            this.radGroupBox2.HeaderText = "  Liste  ";
            this.radGroupBox2.Location = new System.Drawing.Point(3, 226);
            this.radGroupBox2.Name = "radGroupBox2";
            this.radGroupBox2.Size = new System.Drawing.Size(772, 303);
            this.radGroupBox2.TabIndex = 11;
            this.radGroupBox2.Text = "  Liste  ";
            // 
            // list
            // 
            this.list.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            listViewDetailColumn3.HeaderText = "NOM & Prénom";
            listViewDetailColumn4.HeaderText = "RIB";
            listViewDetailColumn5.HeaderText = "Montant";
            this.list.Columns.AddRange(new Telerik.WinControls.UI.ListViewDetailColumn[] {
            listViewDetailColumn3,
            listViewDetailColumn4,
            listViewDetailColumn5});
            this.list.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.list.ItemSpacing = -1;
            this.list.Location = new System.Drawing.Point(5, 21);
            this.list.MultiSelect = true;
            this.list.Name = "list";
            this.list.ShowGridLines = true;
            this.list.Size = new System.Drawing.Size(762, 277);
            this.list.TabIndex = 0;
            this.list.ViewType = Telerik.WinControls.UI.ListViewType.DetailsView;
            this.list.ItemMouseDown += new Telerik.WinControls.UI.ListViewItemMouseEventHandler(this.list_ItemMouseDown);
            this.list.ItemMouseClick += new Telerik.WinControls.UI.ListViewItemEventHandler(this.list_ItemMouseClick);
            this.list.ItemEditing += new Telerik.WinControls.UI.ListViewItemEditingEventHandler(this.list_ItemEditing);
            // 
            // radLabel6
            // 
            this.radLabel6.AutoSize = false;
            this.radLabel6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel6.Location = new System.Drawing.Point(12, 134);
            this.radLabel6.Name = "radLabel6";
            this.radLabel6.Size = new System.Drawing.Size(343, 18);
            this.radLabel6.TabIndex = 10;
            this.radLabel6.Text = "&Montant :";
            // 
            // amt
            // 
            this.amt.Culture = new System.Globalization.CultureInfo("ar-MA");
            this.amt.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amt.Location = new System.Drawing.Point(15, 158);
            this.amt.Mask = "f";
            this.amt.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            this.amt.Name = "amt";
            this.amt.Padding = new System.Windows.Forms.Padding(4);
            this.amt.Size = new System.Drawing.Size(224, 28);
            this.amt.TabIndex = 3;
            this.amt.TabStop = false;
            this.amt.Text = "0.00";
            this.amt.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.amt.ThemeName = "Office2013Light";
            this.amt.Click += new System.EventHandler(this.amt_Click);
            // 
            // rib
            // 
            this.rib.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rib.Location = new System.Drawing.Point(15, 96);
            this.rib.MaskType = Telerik.WinControls.UI.MaskType.Standard;
            this.rib.Name = "rib";
            this.rib.Padding = new System.Windows.Forms.Padding(4);
            this.rib.Size = new System.Drawing.Size(370, 28);
            this.rib.TabIndex = 2;
            this.rib.TabStop = false;
            this.rib.Text = "____________";
            this.rib.KeyUp += new System.Windows.Forms.KeyEventHandler(this.rib_KeyUp);
            this.rib.Click += new System.EventHandler(this.rib_Click);
            this.rib.TextChanged += new System.EventHandler(this.rib_TextChanged);
            // 
            // radLabel5
            // 
            this.radLabel5.AutoSize = false;
            this.radLabel5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel5.Location = new System.Drawing.Point(12, 72);
            this.radLabel5.Name = "radLabel5";
            this.radLabel5.Size = new System.Drawing.Size(343, 18);
            this.radLabel5.TabIndex = 7;
            this.radLabel5.Text = "&RIB :";
            // 
            // radLabel4
            // 
            this.radLabel4.AutoSize = false;
            this.radLabel4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel4.Location = new System.Drawing.Point(12, 12);
            this.radLabel4.Name = "radLabel4";
            this.radLabel4.Size = new System.Drawing.Size(358, 18);
            this.radLabel4.TabIndex = 5;
            this.radLabel4.Text = "Nom && Prénom :";
            // 
            // itemm
            // 
            this.itemm.Items.AddRange(new Telerik.WinControls.RadItem[] {
            this.itemedit,
            this.radMenuSeparatorItem1,
            this.del_item,
            this.radMenuSeparatorItem2,
            this.delall});
            // 
            // itemedit
            // 
            this.itemedit.Name = "itemedit";
            this.itemedit.Text = "Modifier";
            // 
            // radMenuSeparatorItem1
            // 
            this.radMenuSeparatorItem1.Name = "radMenuSeparatorItem1";
            this.radMenuSeparatorItem1.Text = "radMenuSeparatorItem1";
            this.radMenuSeparatorItem1.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // del_item
            // 
            this.del_item.Image = null;
            this.del_item.Name = "del_item";
            this.del_item.Text = "Supprimer";
            // 
            // radMenuSeparatorItem2
            // 
            this.radMenuSeparatorItem2.Name = "radMenuSeparatorItem2";
            this.radMenuSeparatorItem2.Text = "radMenuSeparatorItem2";
            this.radMenuSeparatorItem2.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // delall
            // 
            this.delall.Name = "delall";
            this.delall.Text = "Supprimer touts";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fichierToolStripMenuItem,
            this.outilsToolStripMenuItem,
            this.historiqueToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(778, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fichierToolStripMenuItem
            // 
            this.fichierToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sauvgarderToolStripMenuItem,
            this.toolStripSeparator2,
            this.importerToolStripMenuItem,
            this.toolStripSeparator1,
            this.quitterToolStripMenuItem});
            this.fichierToolStripMenuItem.Name = "fichierToolStripMenuItem";
            this.fichierToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.fichierToolStripMenuItem.Text = "Fichier";
            // 
            // sauvgarderToolStripMenuItem
            // 
            this.sauvgarderToolStripMenuItem.Name = "sauvgarderToolStripMenuItem";
            this.sauvgarderToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.sauvgarderToolStripMenuItem.Text = "Sauvgarder";
            this.sauvgarderToolStripMenuItem.Click += new System.EventHandler(this.sauvgarderToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(130, 6);
            // 
            // importerToolStripMenuItem
            // 
            this.importerToolStripMenuItem.Name = "importerToolStripMenuItem";
            this.importerToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.importerToolStripMenuItem.Text = "Importer";
            this.importerToolStripMenuItem.Click += new System.EventHandler(this.importerToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(130, 6);
            // 
            // quitterToolStripMenuItem
            // 
            this.quitterToolStripMenuItem.Name = "quitterToolStripMenuItem";
            this.quitterToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.quitterToolStripMenuItem.Text = "Quitter";
            this.quitterToolStripMenuItem.Click += new System.EventHandler(this.quitterToolStripMenuItem_Click);
            // 
            // outilsToolStripMenuItem
            // 
            this.outilsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionsToolStripMenuItem,
            this.toolStripSeparator4,
            this.baseDeDonnéeToolStripMenuItem,
            this.toolStripSeparator3,
            this.themeToolStripMenuItem});
            this.outilsToolStripMenuItem.Name = "outilsToolStripMenuItem";
            this.outilsToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.outilsToolStripMenuItem.Text = "Outils";
            this.outilsToolStripMenuItem.Click += new System.EventHandler(this.outilsToolStripMenuItem_Click);
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.optionsToolStripMenuItem.Text = "Options";
            this.optionsToolStripMenuItem.Click += new System.EventHandler(this.optionsToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(154, 6);
            // 
            // baseDeDonnéeToolStripMenuItem
            // 
            this.baseDeDonnéeToolStripMenuItem.Name = "baseDeDonnéeToolStripMenuItem";
            this.baseDeDonnéeToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.baseDeDonnéeToolStripMenuItem.Text = "Base de donnée";
            this.baseDeDonnéeToolStripMenuItem.Click += new System.EventHandler(this.baseDeDonnéeToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(154, 6);
            // 
            // themeToolStripMenuItem
            // 
            this.themeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.defaultToolStripMenuItem,
            this.blackToolStripMenuItem,
            this.noirToolStripMenuItem,
            this.fluentToolStripMenuItem,
            this.crystalToolStripMenuItem,
            this.desertToolStripMenuItem});
            this.themeToolStripMenuItem.Name = "themeToolStripMenuItem";
            this.themeToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.themeToolStripMenuItem.Text = "Theme";
            // 
            // defaultToolStripMenuItem
            // 
            this.defaultToolStripMenuItem.Name = "defaultToolStripMenuItem";
            this.defaultToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.defaultToolStripMenuItem.Text = "Default";
            this.defaultToolStripMenuItem.Click += new System.EventHandler(this.defaultToolStripMenuItem_Click);
            // 
            // blackToolStripMenuItem
            // 
            this.blackToolStripMenuItem.Name = "blackToolStripMenuItem";
            this.blackToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.blackToolStripMenuItem.Text = "Black";
            this.blackToolStripMenuItem.Click += new System.EventHandler(this.blackToolStripMenuItem_Click);
            // 
            // noirToolStripMenuItem
            // 
            this.noirToolStripMenuItem.Name = "noirToolStripMenuItem";
            this.noirToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.noirToolStripMenuItem.Text = "Gris";
            this.noirToolStripMenuItem.Click += new System.EventHandler(this.noirToolStripMenuItem_Click);
            // 
            // fluentToolStripMenuItem
            // 
            this.fluentToolStripMenuItem.Name = "fluentToolStripMenuItem";
            this.fluentToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.fluentToolStripMenuItem.Text = "Fluent";
            this.fluentToolStripMenuItem.Click += new System.EventHandler(this.fluentToolStripMenuItem_Click);
            // 
            // crystalToolStripMenuItem
            // 
            this.crystalToolStripMenuItem.Name = "crystalToolStripMenuItem";
            this.crystalToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.crystalToolStripMenuItem.Text = "Crystal";
            this.crystalToolStripMenuItem.Click += new System.EventHandler(this.crystalToolStripMenuItem_Click);
            // 
            // desertToolStripMenuItem
            // 
            this.desertToolStripMenuItem.Name = "desertToolStripMenuItem";
            this.desertToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.desertToolStripMenuItem.Text = "Desert";
            this.desertToolStripMenuItem.Click += new System.EventHandler(this.desertToolStripMenuItem_Click);
            // 
            // historiqueToolStripMenuItem
            // 
            this.historiqueToolStripMenuItem.Name = "historiqueToolStripMenuItem";
            this.historiqueToolStripMenuItem.Size = new System.Drawing.Size(74, 20);
            this.historiqueToolStripMenuItem.Text = "Historique";
            this.historiqueToolStripMenuItem.Click += new System.EventHandler(this.historiqueToolStripMenuItem_Click);
            // 
            // MainNew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(778, 609);
            this.Controls.Add(this.radPanel1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainNew";
            this.Text = "CCIS OV Generateur";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainNew_FormClosed);
            this.Load += new System.EventHandler(this.MainNew_Load);
            this.Shown += new System.EventHandler(this.MainNew_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.param)).EndInit();
            this.param.ResumeLayout(false);
            this.param.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radButton2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p_user)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p_tel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p_code)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p_address)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.total)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.remise)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radPanel1)).EndInit();
            this.radPanel1.ResumeLayout(false);
            this.radPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.seg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ramt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.add)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.save)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.date)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox2)).EndInit();
            this.radGroupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.list)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.amt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rib)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Telerik.WinControls.UI.RadGroupBox param;
        private Telerik.WinControls.Themes.FluentTheme fluentTheme1;
        private Telerik.WinControls.Themes.Office2013LightTheme office2013LightTheme1;
        private Telerik.WinControls.UI.RadPanel radPanel1;
        private Telerik.WinControls.UI.RadDropDownList remise;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadLabel total;
        private Telerik.WinControls.UI.RadLabel radLabel4;
        private Telerik.WinControls.UI.RadMaskedEditBox rib;
        private Telerik.WinControls.UI.RadLabel radLabel5;
        private Telerik.WinControls.UI.RadLabel radLabel6;
        private Telerik.WinControls.UI.RadMaskedEditBox amt;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox2;
        private Telerik.WinControls.UI.RadListView list;
        private Telerik.WinControls.UI.RadButton save;
        private Telerik.WinControls.UI.RadButton add;
        private Telerik.WinControls.UI.RadTextBox nom;
        private Telerik.WinControls.UI.RadListView seg;
        private Telerik.WinControls.UI.RadContextMenu itemm;
        private Telerik.WinControls.UI.RadMenuItem del_item;
        private Telerik.WinControls.UI.RadLabel ramt;
        private Telerik.WinControls.UI.RadLabel radLabel2;
        private Telerik.WinControls.UI.RadLabel radLabel3;
        private Telerik.WinControls.UI.RadMaskedEditBox p_address;
        private Telerik.WinControls.UI.RadLabel radLabel7;
        private Telerik.WinControls.UI.RadMaskedEditBox p_code;
        private Telerik.WinControls.UI.RadLabel radLabel8;
        private Telerik.WinControls.UI.RadMaskedEditBox p_tel;
        private Telerik.WinControls.UI.RadLabel radLabel9;
        private Telerik.WinControls.UI.RadMaskedEditBox p_user;
        private Telerik.WinControls.UI.RadButton radButton1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fichierToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sauvgarderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importerToolStripMenuItem;
        private Telerik.WinControls.UI.RadButton radButton2;
        private Telerik.WinControls.UI.RadMaskedEditBox date;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private Telerik.WinControls.Themes.CrystalTheme crystalTheme1;
        private Telerik.WinControls.Themes.DesertTheme desertTheme1;
        private System.Windows.Forms.ToolStripMenuItem outilsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem themeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem defaultToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fluentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem crystalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem desertToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem noirToolStripMenuItem;
        private Telerik.WinControls.Themes.Office2013DarkTheme office2013DarkTheme1;
        private Telerik.WinControls.Themes.VisualStudio2012DarkTheme visualStudio2012DarkTheme1;
        private System.Windows.Forms.ToolStripMenuItem blackToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem quitterToolStripMenuItem;
        private Telerik.WinControls.UI.RadMenuItem delall;
        private Telerik.WinControls.UI.RadMenuItem itemedit;
        private Telerik.WinControls.UI.RadMenuSeparatorItem radMenuSeparatorItem1;
        private Telerik.WinControls.UI.RadMenuSeparatorItem radMenuSeparatorItem2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem baseDeDonnéeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem historiqueToolStripMenuItem;
    }
}