package ma.rak.ov.api;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class TwHelper {

    public static String getKeyOf(HashMap map, String value, String def){
        Iterator it = map.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry)it.next();
            if(pair.getValue().equals(value)){
                return  pair.getKey().toString();
            }
        }

        return def;
    }

}
