import {
  SET_FONT_SIZE,
  FETCH_FONT_SUCCESS,
  CHANGE_LANG_SUCCESS,
} from "./types";

const fontText = {
  fontSize: 14,
  fontSizeMin: 14,
  fontSizeMax: 24,
  fontWeight: 400,
};

import * as SQLite from "expo-sqlite";
import I18n from "../../commons/i18n";

const db = SQLite.openDatabase("ifes.db");

export function fetchFontSize(langue) {
  return (dispath) => {
    let value = fontText.fontSize;
    let Db_fontWeight = fontText.fontWeight;
    let lang = null;
    if (langue) {
      db.transaction(
        (tx) => {
          tx.executeSql(
            "select * from parametres where id=1 order by id desc ",
            [],
            (tx, results) => {
              console.log("result fetchFontSize", langue);
              var len = results.rows.length;
              var rows = [];
              for (let i = 0; i < len; i++) {
                let row = results.rows.item(i);
                rows.push(row);
              }
              value = rows[0].fontSize !== null ? rows[0].fontSize : value;
              Db_fontWeight =
                rows[0].fontWeight !== null
                  ? rows[0].fontWeight
                  : Db_fontWeight;
              lang = rows[0].lang;
              dispath({
                type: FETCH_FONT_SUCCESS,
                fontSize: value,
                hasIntro: Db_fontWeight,
                lang: langue,
              });
            }
          );
        },
        null,
        null
      );
    }
  };
}

export function increaseFontSize() {
  return (dispatch) => {
    let value = 0;
    db.transaction((tx) => {
      tx.executeSql(
        "select * from parametres order by id desc limit 1",
        [],
        (tx, results) => {
          var len = results.rows.length;
          var rows = [];
          for (let i = 0; i < len; i++) {
            let row = results.rows.item(i);
            rows.push(row);
            value = row.fontSize;
            updateParametres(value, "INCREASE");
          }
          dispatch({
            type: SET_FONT_SIZE,
            fontSize: value,
          });
        }
      );
    });
  };
}

export function decreaseFontSize() {
  return (dispatch) => {
    let value = 0;
    db.transaction((tx) => {
      tx.executeSql(
        "select * from parametres order by id desc limit 1",
        [],
        (tx, results) => {
          var len = results.rows.length;
          var rows = [];
          for (let i = 0; i < len; i++) {
            let row = results.rows.item(i);
            rows.push(row);
            value = row.fontSize;
            updateParametres(value, "DECREASE");
          }
          dispatch({
            type: SET_FONT_SIZE,
            fontSize: value,
          });
        }
      );
    });
  };
}
export function changeFont(fontValue, fontWeight) {
  return (dispatch) => {
    var intro = fontWeight == null ? fontText.fontWeight : fontWeight;
    var fSize = fontValue;
    if (fontValue > 24) {
      fSize = 24;
    }
    if (fontValue < 12) {
      fSize = 12;
    }
    db.transaction(
      (tx) => {
        tx.executeSql(
          "update parametres set fontSize= ? ,FontWeight= ? ",
          [fSize, intro],
          () => {
            dispatch({
              type: SET_FONT_SIZE,
              fontSize: fontValue,
            });
          },
          () => null
        );
      },
      null,
      null
    );
  };
}

export function changeLanguage() {
  return (dispatch) => {
    let value = "";

    db.transaction((tx) => {
      tx.executeSql(
        "select * from parametres order by id desc limit 1",
        [],
        (tx, results) => {
          var len = results.rows.length;
          var rows = [];
          for (let i = 0; i < len; i++) {
            let row = results.rows.item(i);
            rows.push(row);
            value = row.lang;

            dispatch({
              type: CHANGE_LANG_SUCCESS,
              lang: updateLang(value),
            });
          }
        }
      );
    });
  };
}
export function editLanguageAr() {
  return (dispatch) => {
    let value = "ar";
    console.log("doneAR " + value);

    db.transaction((tx) => {
      tx.executeSql(
        "select * from parametres order by id desc limit 1",
        [],
        (tx, results) => {
          var len = results.rows.length;
          var rows = [];
          for (let i = 0; i < len; i++) {
            let row = results.rows.item(i);
            rows.push(row);
            value = "ar";

            console.log("testerrAr : " + value);

            dispatch({
              type: CHANGE_LANG_SUCCESS,
              lang: changeLang_fr_ar(value),
            });
          }
        }
      );
    });
  };
}
export function editLanguageFr() {
  return (dispatch) => {
    let value = "fr";

    console.log("doneFR " + value);

    db.transaction((tx) => {
      tx.executeSql(
        "select * from parametres order by id desc limit 1",
        [],
        (tx, results) => {
          var len = results.rows.length;
          var rows = [];
          for (let i = 0; i < len; i++) {
            let row = results.rows.item(i);
            rows.push(row);
            value = "fr";
            dispatch({
              type: CHANGE_LANG_SUCCESS,
              lang: changeLang_fr_ar(value),
            });
          }
        }
      );
    });
  };
}

updateLang = (rows) => {
  var lang = "fr";
  console.log(lang + " (((000");
  if (rows == "fr") {
    lang = "ar";
  } else {
    lang = "fr";
  }
  db.transaction(
    (tx) => {
      tx.executeSql(
        "update parametres set lang= ? ",
        [lang],
        () => null,
        (a, b) => null
      );
    },
    null,
    null
  );
  return lang;
};
changeLang_fr_ar = (rows) => {
  var lang = rows;

  console.log("$$$$$$", lang);

  db.transaction(
    (tx) => {
      tx.executeSql(
        "update parametres set lang= ? ",
        [lang],
        () => console.log("goood -- ", lang),
        (a, b) => null
      );
    },
    null,
    null
  );
  return lang;
};

const updateParametres = (rows, operation) => {
  var fontSize = rows == 0 ? fontText.fontSize : rows;
  if (rows.length == 0) {
    db.transaction(
      (tx) => {
        tx.executeSql(
          "insert into parametres (fontSize) values (?)",
          [fontSize],
          () => null,
          (a, b) => null
        );
      },
      null,
      null
    );
  } else {
    if (operation == "INCREASE") {
      fontSize = fontSize !== fontText.fontSizeMax ? fontSize + 2 : fontSize;
    } else {
      fontSize = fontSize !== fontText.fontSizeMax ? fontSize - 2 : fontSize;
    }
    db.transaction(
      (tx) => {
        tx.executeSql(
          "update parametres set fontSize= ? ",
          [fontSize],
          () => null,
          (a, b) => null
        );
      },
      null,
      null
    );
  }
};
