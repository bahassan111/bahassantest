<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Settings extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!isLoggedIn()) {
            callback_whenNotLoggedIn();
        }
    }

    public function index()
    {


    }

    public function users(){

        $data = [
            '_page' => 'users',
            '_action' => Pages::ACTION_READ,
        ];

        loadView('setting_users', $data);
    }
    public function groups(){

        $data = [
            '_page' => 'groups',
            '_action' => Pages::ACTION_READ,
        ];

        loadView('setting_groups', $data);
    }

    function get_users(){

        if(!hasPermission('users', Pages::ACTION_READ)) callback_whenNoPermission();

        $data = doTwtable("SELECT u.*, g.name as `group`, trim(concat_ws(' ', u.first_name, u.last_name)) name FROM users u LEFT JOIN `users_groups` ug ON ug.user_id = u.id LEFT JOIN `groups` g ON g.id = ug.group_id WHERE u.deleted = 0", function(&$row){
            $row->status = $row->active ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-danger">Inactive</span>';
            $row->ref = '#u' . str_pad($row->id, 4, 0, 0);
            $row->login = date('Y-m-d H:i', $row->last_login);
        });

        responseJSON($data);

    }

    function get_groups(){

        if(!hasPermission('groups', Pages::ACTION_READ)) callback_whenNoPermission();

        $data = doTwtable("SELECT * FROM `groups` WHERE deleted = 0 AND id > 1", function(&$row){
            $row->status = $row->status === '1' ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-danger">Inactive</span>';
            $row->ref = '#u' . str_pad($row->id, 4, 0, 0);
        });

        responseJSON($data);

    }

    function one_user($id = false){
        if($id){
            $user = $this->db->get_where('users', ['id' => $id])->row();
            if(!$user) callback_whenNotFound();
            $user->group = $this->db->query("SELECT * FROM users_groups WHERE user_id = $id")->row()->group_id;
        }

        $data = [
            '_page' => 'users',
            '_action' => Pages::ACTION_EDIT,
            'user' => isset($user) ? $user : null,
            'edit' => isset($user),
            'groups' => $this->db->get_where('groups')->result(),
        ];

        loadView('user_form', $data);

    }
    function one_group($id = false){
        if($id){
            $group = $this->db->get_where('groups', ['id' => $id])->row();
            if(!$group) callback_whenNotFound();
        }

        $data = [
            '_page' => 'groups',
            '_action' => Pages::ACTION_EDIT,
            'group' => isset($group) ? $group : null,
            'edit' => isset($group),
        ];

        loadView('groups_form', $data);

    }
    function group_permissions($id){
        if(!$id) callback_whenNotFound();
        $group = $this->db->get_where('groups', ['id' => $id])->row();
        if(!$group) callback_whenNotFound();

        $permissions = $this->db->get_where('__permissions', ['id_group' => $id])->result();
        $pages = $this->db->get_where('__pages', ['deleted' => 0])->result();

        $data = [
            '_page' => 'groups',
            '_action' => 'manage_permissions',
            'group' => $group,
            'permissions' => $permissions,
            'pages' => $pages,
        ];

        loadView('permissions', $data);

    }

    public function save_permissions(){
        if(!hasPermission('groups', 'manage_permissions')) callback_whenNoPermission();
        $data = (object) $this->input->post();
        $group = $data->id_group ?: 'x';

        $q = $this->db->delete('__permissions', ['id_group' => $group]);

        foreach ($data->permissions as $id_page => $permissions){
            foreach ($permissions as $permission){
                $q = $this->db->insert('__permissions', [
                    'id_group' => $group,
                    'id_page' => $id_page,
                    'action' => $permission,
                ]);
            }
        }

        responseJSON(['status' => 'OK']);


    }

    public function save_user($id = FALSE){
        if(!hasPermission('users', Pages::ACTION_EDIT)) callback_whenNoPermission();
        $data = (object) $this->input->post();
        $message = "Please fill all the required fields";
        $status = "EMPTY";

        if($this->alpha->email_exisits($data->email, $id)){
            $status = 'ERROR';
            $message = 'This email address already exists';

        }elseif($data->password && ($data->password != $data->password2)) {
            $status = 'ERROR';
            $message = 'Password confirmation is not identical';
        }else{

            $this->db->trans_begin();

            if($data->password) $data->password = $this->ion_auth_model->hash_password($data->password);


            $id_group = $data->group;
            unset($data->group);
            unset($data->password2);

            if(!$id){

                $data->created_on = time();
                $q = $this->db->insert('users', $data);

                if($q){
                    $status = 'OK';
                    $id = $this->db->insert_id();
                }else{
                    $status = 'ERROR';
                    $message = 'Unable to save this user';
                }



            }else{

                $q = $this->db->update('users', $data, ['id' => $id]);

                if($q){
                    $status = 'OK';
                }else{
                    $status = 'ERROR';
                    $message = 'Unable to update the user';
                }
            }

            if($id && $status === 'OK'){
                $g = $this->db->delete('users_groups', ['user_id' => $id]);

                if($q){
                    $r = $this->db->insert('users_groups', ['user_id' => $id, 'group_id' => $id_group]);
                }
            }

            if($q && $g && $r){
                $this->db->trans_commit();
            }else{
                $this->db->trans_rollback();
            }

        }





        responseJSON([
            'status' => $status,
            'message' => $message,
        ]);

    }
    public function save_group($id = FALSE){
        if(!hasPermission('groups', Pages::ACTION_EDIT)) callback_whenNoPermission();
        $data = (object) $this->input->post();
        $message = "Please fill all the required fields";
        $status = "EMPTY";

        if($this->alpha->group_exisits($data->name, $id)){
            $status = 'ERROR';
            $message = 'This group already exists';

        }else{

            $data->date_updated = time();
            $data->updated_by = userInfo()->id;



            if(!$id){

                $data->date_added = time();
                $data->id_user = userInfo()->id;

                $q = $this->db->insert('groups', $data);

                if($q){
                    $status = 'OK';
                    $id = $this->db->insert_id();
                }else{
                    $status = 'ERROR';
                    $message = 'Unable to save this group';
                }



            }else{

                $q = $this->db->update('groups', $data, ['id' => $id]);

                if($q){
                    $status = 'OK';
                }else{
                    $status = 'ERROR';
                    $message = 'Unable to update the group';
                }
            }


        }





        responseJSON([
            'status' => $status,
            'message' => $message,
        ]);

    }

    public function delete_user($id){
        if(!hasPermission('users', Pages::ACTION_DELETE)) callback_whenNoPermission();
        if(!$id) callback_whenNotFound();
        $q = $this->db->update('users', ['deleted' => 1], ['id' => $id]);

        responseJSON([
            'status' => $q ? 'OK' : 'ERROR',
            'message' => $q ? '' : 'Unable to deleted the selected user',
        ]);
    }
    public function delete_group($id){
        if(!hasPermission('groups', Pages::ACTION_DELETE)) callback_whenNoPermission();
        if(!$id) callback_whenNotFound();
        $q = $this->db->update('groups', ['deleted' => 1], ['id' => $id]);

        responseJSON([
            'status' => $q ? 'OK' : 'ERROR',
            'message' => $q ? '' : 'Unable to deleted the selected group',
        ]);
    }
}
