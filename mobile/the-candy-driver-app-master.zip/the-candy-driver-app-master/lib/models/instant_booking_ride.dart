class RideDetailModel {
  String id;
  String dispatchId;
  String userId;
  String driverId;
  String clientId;
  String managerId;
  String adminId;
  String countryId;
  int leftCharterTime;
  String flightnumber;
  String pickupaddress;
  String pickuplat;
  String pickuplong;
  String dropaddress;
  String droplat;
  String droplong;
  String dropotheraddress;
  String dropotherLat;
  String dropotherLong;
  String driverLat;
  String driverLong;
  String bookType;
  String carCategory;
  String vichleType;
  String carMake;
  String carModel;
  String carColor;
  String drivergender;
  String note;
  String bookDate;
  String bookDatetime;
  String pickupDate;
  String pickupTime;
  String dropDate;
  String startTime;
  String endTime;
  String driverArrivaltime;
  String waypoint;
  String leaveondate;
  String leaveontime;
  String returnondate;
  String returnontime;
  String distance;
  String duration;
  String fareid;
  String totalfare;
  String tolltaxamount;
  String clientfees;
  String dispatchfees;
  String adminfees;
  String gatewayFee;
  String supplierPartnerTax;
  String prebookingFee;
  String candytechmarkup;
  String driverfees;
  String candytechtax;
  String surge;
  String fullname;
  String mobile;
  String passport;
  String email;
  String paymentmode;
  String rideStatus;
  String preStatus;
  String reason;
  String cancelledBy;
  String driverEta;
  String refundamount;
  String cancelcharge;
  String cancelServiceFee;
  String passengerStatus;
  String blockStatus;
  String subuserId;
  String mailStatus;
  String reassignStatus;
  String waitingTimeCharge;
  String waitingTime;
  String paymentTokenId;
  String driverPaymentMode;
  String updatedDriverEarning;
  String agentBookerTax;
  String currency;
  String categoryCode;

  RideDetailModel(
      {this.id,
      this.dispatchId,
      this.userId,
      this.leftCharterTime,
      this.driverId,
      this.clientId,
      this.managerId,
      this.adminId,
      this.countryId,
      this.flightnumber,
      this.pickupaddress,
      this.pickuplat,
      this.pickuplong,
      this.dropaddress,
      this.droplat,
      this.droplong,
      this.dropotheraddress,
      this.dropotherLat,
      this.dropotherLong,
      this.driverLat,
      this.driverLong,
      this.bookType,
      this.carCategory,
      this.vichleType,
      this.carMake,
      this.carModel,
      this.carColor,
      this.drivergender,
      this.note,
      this.bookDate,
      this.bookDatetime,
      this.pickupDate,
      this.categoryCode,
      this.pickupTime,
      this.dropDate,
      this.startTime,
      this.endTime,
      this.driverArrivaltime,
      this.waypoint,
      this.leaveondate,
      this.leaveontime,
      this.returnondate,
      this.returnontime,
      this.distance,
      this.duration,
      this.fareid,
      this.totalfare,
      this.tolltaxamount,
      this.clientfees,
      this.dispatchfees,
      this.adminfees,
      this.gatewayFee,
      this.supplierPartnerTax,
      this.prebookingFee,
      this.candytechmarkup,
      this.driverfees,
      this.candytechtax,
      this.surge,
      this.fullname,
      this.mobile,
      this.passport,
      this.email,
      this.paymentmode,
      this.rideStatus,
      this.preStatus,
      this.reason,
      this.cancelledBy,
      this.driverEta,
      this.refundamount,
      this.cancelcharge,
      this.cancelServiceFee,
      this.passengerStatus,
      this.blockStatus,
      this.subuserId,
      this.mailStatus,
      this.reassignStatus,
      this.waitingTimeCharge,
      this.waitingTime,
      this.paymentTokenId,
      this.driverPaymentMode,
      this.updatedDriverEarning,
      this.agentBookerTax,
      this.currency});

  RideDetailModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dispatchId = json['dispatch_id'];
    userId = json['user_id'];
    driverId = json['driver_id'];
    clientId = json['client_id'];
    managerId = json['manager_id'];
    adminId = json['admin_id'];
    countryId = json['country_id'];
    flightnumber = json['flightnumber'];
    pickupaddress = json['pickupaddress'];
    pickuplat = json['pickuplat'];
    pickuplong = json['pickuplong'];
    dropaddress = json['dropaddress'];
    droplat = json['droplat'];
    droplong = json['droplong'];
    dropotheraddress = json['dropotheraddress'];
    dropotherLat = json['dropother_lat'] ?? "";
    dropotherLong = json['dropother_long'] ?? "";
    driverLat = json['driver_lat'];
    driverLong = json['driver_long'];
    bookType = json['book_type'];
    carCategory = json['car_category'];
    vichleType = json['vichle_type'];
    carMake = json['car_make'];
    carModel = json['car_model'];
    carColor = json['car_color'];
    drivergender = json['drivergender'];
    note = json['note'];
    bookDate = json['book_date'];
    bookDatetime = json['book_datetime'];
    pickupDate = json['pickup_date'];
    pickupTime = json['pickup_time'];
    dropDate = json['drop_date'];
    startTime = json['start_time'];
    endTime = json['end_time'];
    driverArrivaltime = json['driver_arrivaltime'];
    waypoint = json['waypoint'];
    leaveondate = json['leaveondate'];
    leaveontime = json['leaveontime'];
    returnondate = json['returnondate'];
    returnontime = json['returnontime'];
    distance = json['distance'];
    duration = json['duration'];
    fareid = json['fareid'];
    totalfare = json['totalfare'].toString();
    tolltaxamount = json['tolltaxamount'];
    clientfees = json['clientfees'];
    dispatchfees = json['dispatchfees'];
    adminfees = json['adminfees'];
    gatewayFee = json['gateway_fee'];
    supplierPartnerTax = json['supplier_partner_tax'];
    prebookingFee = json['prebooking_fee'];
    candytechmarkup = json['candytechmarkup'];
    driverfees = json['driverfees'];
    candytechtax = json['candytechtax'];
    surge = json['surge'];
    fullname = json['fullname'];
    mobile = json['mobile'];
    passport = json['passport'];
    email = json['email'];
    paymentmode = json['paymentmode'];
    rideStatus = json['ride_status'];
    preStatus = json['pre_status'];
    reason = json['reason'];
    cancelledBy = json['cancelled_by'];
    driverEta = json['driver_eta'];
    refundamount = json['refundamount'];
    cancelcharge = json['cancelcharge'];
    cancelServiceFee = json['cancel_service_fee'];
    passengerStatus = json['passenger_status'];
    blockStatus = json['block_status'];
    subuserId = json['subuser_id'];
    mailStatus = json['mail_status'];
    reassignStatus = json['reassign_status'];
    waitingTimeCharge = json['waiting_time_charge'];
    waitingTime = json['waiting_time'];
    paymentTokenId = json['payment_token_id'];
    driverPaymentMode = json['driver_payment_mode'];
    updatedDriverEarning = json['updated_driver_earning'];
    agentBookerTax = json['agent_booker_tax'];
    currency = json['currency'];
    categoryCode = json['category_code'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['dispatch_id'] = this.dispatchId;
    data['user_id'] = this.userId;
    data['driver_id'] = this.driverId;
    data['client_id'] = this.clientId;
    data['manager_id'] = this.managerId;
    data['admin_id'] = this.adminId;
    data['country_id'] = this.countryId;
    data['flightnumber'] = this.flightnumber;
    data['pickupaddress'] = this.pickupaddress;
    data['pickuplat'] = this.pickuplat;
    data['pickuplong'] = this.pickuplong;
    data['dropaddress'] = this.dropaddress;
    data['droplat'] = this.droplat;
    data['droplong'] = this.droplong;
    data['dropotheraddress'] = this.dropotheraddress;
    data['dropother_lat'] = this.dropotherLat;
    data['dropother_long'] = this.dropotherLong;
    data['driver_lat'] = this.driverLat;
    data['driver_long'] = this.driverLong;
    data['book_type'] = this.bookType;
    data['car_category'] = this.carCategory;
    data['vichle_type'] = this.vichleType;
    data['car_make'] = this.carMake;
    data['car_model'] = this.carModel;
    data['car_color'] = this.carColor;
    data['drivergender'] = this.drivergender;
    data['note'] = this.note;
    data['book_date'] = this.bookDate;
    data['book_datetime'] = this.bookDatetime;
    data['pickup_date'] = this.pickupDate;
    data['pickup_time'] = this.pickupTime;
    data['drop_date'] = this.dropDate;
    data['start_time'] = this.startTime;
    data['end_time'] = this.endTime;
    data['driver_arrivaltime'] = this.driverArrivaltime;
    data['waypoint'] = this.waypoint;
    data['leaveondate'] = this.leaveondate;
    data['leaveontime'] = this.leaveontime;
    data['returnondate'] = this.returnondate;
    data['returnontime'] = this.returnontime;
    data['distance'] = this.distance;
    data['duration'] = this.duration;
    data['fareid'] = this.fareid;
    data['totalfare'] = this.totalfare;
    data['tolltaxamount'] = this.tolltaxamount;
    data['clientfees'] = this.clientfees;
    data['dispatchfees'] = this.dispatchfees;
    data['adminfees'] = this.adminfees;
    data['gateway_fee'] = this.gatewayFee;
    data['supplier_partner_tax'] = this.supplierPartnerTax;
    data['prebooking_fee'] = this.prebookingFee;
    data['candytechmarkup'] = this.candytechmarkup;
    data['driverfees'] = this.driverfees;
    data['candytechtax'] = this.candytechtax;
    data['surge'] = this.surge;
    data['fullname'] = this.fullname;
    data['mobile'] = this.mobile;
    data['passport'] = this.passport;
    data['email'] = this.email;
    data['paymentmode'] = this.paymentmode;
    data['ride_status'] = this.rideStatus;
    data['pre_status'] = this.preStatus;
    data['reason'] = this.reason;
    data['cancelled_by'] = this.cancelledBy;
    data['driver_eta'] = this.driverEta;
    data['refundamount'] = this.refundamount;
    data['cancelcharge'] = this.cancelcharge;
    data['cancel_service_fee'] = this.cancelServiceFee;
    data['passenger_status'] = this.passengerStatus;
    data['block_status'] = this.blockStatus;
    data['subuser_id'] = this.subuserId;
    data['mail_status'] = this.mailStatus;
    data['reassign_status'] = this.reassignStatus;
    data['waiting_time_charge'] = this.waitingTimeCharge;
    data['waiting_time'] = this.waitingTime;
    data['payment_token_id'] = this.paymentTokenId;
    data['driver_payment_mode'] = this.driverPaymentMode;
    data['updated_driver_earning'] = this.updatedDriverEarning;
    data['agent_booker_tax'] = this.agentBookerTax;
    data['currency'] = this.currency;
    data['category_code'] = this.categoryCode;
    return data;
  }
}
