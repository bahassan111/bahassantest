﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Telerik.WinControls;
using Telerik.WinControls.UI;

namespace CCISFMMND
{

    public partial class MainNew : Form
    {

       

        public List<RIBClass> data;
        DB db;
        splash s;
        public MainNew()
        {

         

            InitializeComponent();

        




            db = new DB();

            data = db.getRIBS();
            ThemeResolutionService.ApplicationThemeName = "Office2013Light";


            
        }


        private void MainNew_Load(object sender, EventArgs e)
        {
            for (var i = 1; i <= 31; i++)
            {
                remise.Items.Add(i.ToString().PadLeft(4, '0'));
            }

            rib.Mask = "###-#####-##############-##";



            del_item.Click += del_item_Click;
            delall.Click += delall_click;
            itemedit.Click += itemedit_click;

            seg.Left = nom.Left;
            seg.Top = nom.Top + nom.Height;
            seg.Width = nom.Width;
            seg.Height = 130;
            date.Text = DateTime.Now.ToString("dd/MM/yyyy");

        }

        public decimal getAmount()
        {
            char a = Convert.ToChar(Thread.CurrentThread.CurrentCulture.NumberFormat.NumberDecimalSeparator);



            return decimal.Parse(amt.Value.ToString().Replace('.', a), NumberStyles.Float);
        }

        private void del_item_Click(object sender, EventArgs e)
        {
            if (list.SelectedItem != null)
            {
                if (MessageBox.Show("Voulez-vous vraiment supprimer cette ligne?", "Supprimer", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1) == System.Windows.Forms.DialogResult.Yes)
                {
                    RIBClass amt = (RIBClass)list.SelectedItem.Tag;

                    list.Items.RemoveAt(list.SelectedIndex);

                    recalc();

                    save.Enabled = list.Items.Count > 0;
                }
            }
        }
        private void delall_click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Voulez-vous vraiment effacer la liste?", "Supprimer", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1) == System.Windows.Forms.DialogResult.Yes)
            {
                list.Items.Clear();
                recalc();
            }
        }
        private void itemedit_click(object sender, EventArgs e)
        {
            if (list.SelectedItem != null)
            {
                RIBClass amt = (RIBClass)list.SelectedItem.Tag;

                list.Items.RemoveAt(list.SelectedIndex);

                recalc();

                save.Enabled = list.Items.Count > 0;

                nom.Text = amt.Nom;
                rib.Text = amt.RIB;
                this.amt.Text = amt.AMT;
                add.Enabled = true;
            }
        }

        private void nom_TextChanged(object sender, EventArgs e)
        {
            rib.Text = "";
            nom.Tag = null;
        }

        private void rib_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(rib.Text.Length.ToString());
        }

        private void rib_TextChanged(object sender, EventArgs e)
        {
            add.Enabled = !nom.Text.Trim().Equals("") && !this.rib.Text.Trim().Contains("_") && this.rib.Text.Trim().Length == 27;
            
        }

        void recalc()
        {
            decimal t = 0;
            foreach (var item in list.Items)
            {
                var row = (RIBClass)item.Tag;
                t += decimal.Parse(row.AMT, NumberStyles.Float);
            }

            total.Text = t.ToString() + " DH";
        }

        private void add_Click(object sender, EventArgs e)
        {
            var err_msg = "";

            if (remise.Text == "")
            {
                err_msg = "sélectionner le numéro de remise";
            }

            if (rib.Text.Trim().Contains("_") || rib.Text.Length < 27)
            {
                err_msg = "Le numéro de compte bancaire fourni n'est pas valide";
            }

            if (nom.Text.Trim().Equals(""))
            {
                err_msg = "Veuillez fournir un nom complet valide";
            }

            if (amt.Text == "" || getAmount() < 1)
            {
                err_msg = "Veuillez fournir un montant valide";
            }

            if (!err_msg.Equals(""))
            {
                MessageBox.Show(err_msg, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            RIBClass d = null;

            if (nom.Text != "" && nom.Tag == null)
            {
                db.addRIB(nom.Text, rib.Text, getAmount().ToString());
                var itm = new RadListDataItem(nom.Text);
                itm.Tag = rib.Text;
                d = new RIBClass(nom.Text, rib.Text, getAmount().ToString());

                data = db.getRIBS();
            }
            else
            {
                db.updateRIBamt(nom.Text, rib.Text, getAmount().ToString());
                d = (RIBClass)nom.Tag;
                d.AMT = getAmount().ToString();
            }

            var ne = new Telerik.WinControls.UI.ListViewDataItem(nom.Text, new string[] { nom.Text, rib.Text.Replace("-", ""), getAmount().ToString() });
            

            ne.Tag = d;
            list.Items.Add(ne);

            recalc();

            nom.Text = "";
            rib.Text = "________________________";
            amt.Text = "";
            
            seg.Hide();
            ramt.Visible = false;

            save.Enabled = true;

        }

        private void amt_Click(object sender, EventArgs e)
        {

        }

        private void nom_TextChanged_1(object sender, EventArgs e)
        {
            seg.Items.Clear();
            if (nom.Text.Trim().Equals(""))
            {
                seg.Hide();
                return;
            }

            foreach (var rib in data)
            {
                if (rib.Nom.ToLower().Contains(nom.Text.ToLower()))
                {
                    

                    var itm = new ListViewDataItem(rib.Nom, new string[] { rib.Nom, rib.RIB });
                    itm.Tag = rib;
                    seg.Items.Add(itm);
                    seg.SelectedIndex = 0;
                }
            }

            if (seg.Items.Count == 0) seg.Hide(); else seg.Show();

            add.Enabled = !nom.Text.Trim().Equals("") && !this.rib.Text.Trim().Contains("_") && this.rib.Text.Trim().Length == 27;
            
        }

        void fill(string nom, string rib)
        {
            this.nom.Text = nom;
            this.rib.Text = rib;
        }

        private void nom_Leave(object sender, EventArgs e)
        {
            if (!seg.Focused) seg.Hide();
        }

        private void seg_Leave(object sender, EventArgs e)
        {
            if (!nom.Focused) seg.Hide();
        }

        private void nom_KeyUp(object sender, KeyEventArgs e)
        {
            ramt.Visible = false;
            nom.Tag = null;
            if (e.KeyCode == Keys.Down || e.KeyCode == Keys.Up)
            {
                if(seg.Visible) seg.Focus();
            }

            if (e.KeyCode == Keys.Enter && seg.Visible && seg.SelectedItem != null)
            {
                seg_ItemMouseClick(sender, new ListViewItemEventArgs(seg.SelectedItem));
            }
        }

        private void seg_ItemMouseClick(object sender, ListViewItemEventArgs e)
        {
            var item = seg.SelectedItem;
            if(item == null) return;

            var row = (RIBClass)item.Tag;

            fill(row.Nom, row.RIB);

            ramt.Text = "Dernier montant : " + row.AMT + " DH";
            ramt.Tag = row.AMT;
            ramt.Visible = true;
           

            nom.Tag = row;

            seg.Hide();
            nom.Focus();
        }


        void selectfromSeg(ListViewDataItem item)
        {
            nom.Text = item.Value.ToString();
        }

        private void seg_SelectedItemChanged(object sender, EventArgs e)
        {

        }

        private void seg_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Space) seg_ItemMouseClick(sender, new ListViewItemEventArgs(seg.SelectedItem));
        }

        private void list_ItemEditing(object sender, ListViewItemEditingEventArgs e)
        {

        }

        private void list_ItemMouseClick(object sender, ListViewItemEventArgs e)
        {
            
        }

        private void list_ItemMouseDown(object sender, ListViewItemMouseEventArgs e)
        {
            if (e.OriginalEventArgs.Button == System.Windows.Forms.MouseButtons.Right)
            {
                itemm.Show(list, e.OriginalEventArgs.Location);
            }
        }

        private void ramt_Click(object sender, EventArgs e)
        {

        }

        private void ramt_DoubleClick(object sender, EventArgs e)
        {
            if (ramt.Tag != null)
            {
                amt.Text = ramt.Tag.ToString().Replace(',', '.');
            }
        }

        private void rib_KeyUp(object sender, KeyEventArgs e)
        {
            if (nom.Tag != null)
            {
                if (((RIBClass)nom.Tag).RIB != rib.Text.Replace("-", ""))
                {
                    nom.Tag = null;
                }
            }
        }

        private void radButton1_Click(object sender, EventArgs e)
        {
            
        }

        private void parametresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            param.Show();
            param.BringToFront();
            param.Dock = DockStyle.Fill;
        }

        private void radButton2_Click(object sender, EventArgs e)
        {
            param.Hide();
        }

        private void sauvgarderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            save_Click(sender, e);
        }

        private void save_Click(object sender, EventArgs e)
        {
            var output = "";
            var date = Convert.ToDateTime(this.date.Text);

            var filename = String.Format("bvov7310050000{0}{1}.unl", date.ToString("yyMMdd"), remise.Text);
            output += String.Format("@nom_fic:{0}", filename); ;
            output += System.Environment.NewLine + String.Format("@des_fic : OV,{0}", date.ToString("dd/MM/yyyy"));
            output += System.Environment.NewLine + String.Format("@dat_gen : {0}", date.ToString("dd/MM/yyyy"));
            output += System.Environment.NewLine + String.Format("@heur_gen : {0}", DateTime.Now.ToString("HH:mm:ss"));
            output += System.Environment.NewLine + String.Format("@cod_emet : {0}", p_address.Text);
            output += System.Environment.NewLine + String.Format("@cod_dest : {0}", p_code.Text);
            output += System.Environment.NewLine + String.Format("@N_remise : {0}", remise.Text);
            output += System.Environment.NewLine + String.Format("@nbr_enr : {0}", list.Items.Count);
            output += System.Environment.NewLine + String.Format("@taille (octets) : {0}", "");
            output += System.Environment.NewLine + String.Format("@utilisateur : {0}", p_user.Text);
            output += System.Environment.NewLine + String.Format("@Tel :{0}", p_tel.Text);

            int c = 0;
            foreach (var item in list.Items)
            {
                var row = (RIBClass)item.Tag;

                output += System.Environment.NewLine + String.Format("73|{0}|{1}|{2}|{3}|{4}|{5}|{6}|",
                    date.ToString("yyyy"),
                    date.ToString("MM"),
                    remise.Text,
                    100111 + c,
                    row.Nom,
                    row.RIB,
                    row.AMT.Replace(',', '.')
                    );

                c++;
            }


            using (var d = new FolderBrowserDialog())
            {
                if (d.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    File.WriteAllText(d.SelectedPath + @"\" + filename, output);
                    MessageBox.Show("Fichier enregistré avec succès", "OK", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    db.saveToHistory(output, date, remise.Text);
                    resetEverything();
                }
            }


            

        }

        public void resetEverything()
        {
            remise.Text = "";
            rib.Text = "________________________";
            nom.Text = "";
            list.Items.Clear();
            date.Text = DateTime.Now.ToString("dd/MM/yyyy");
            add.Enabled = save.Enabled = false;
            ramt.Visible = false;
            seg.Visible = false;
        }

        private void importerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            resetEverything();

            using (var d = new OpenFileDialog())
            {
                d.Filter = "Fichier OV (*.unl)|*.unl";

                if (d.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {

                    loadfile(d.FileName);

                }

            }

        }

        public void loadfile(String filename)
        {
            try
            {
                var data = File.ReadAllLines(filename);

                foreach (var line in data)
                {
                    if (line.StartsWith("@dat_gen"))
                    {
                        var p = line.Split(' ');
                        if (p.Length > 1) date.Text = p[p.Length - 1];

                    }
                    else if (line.StartsWith("@N_remise"))
                    {
                        var p = line.Split(' ');
                        if (p.Length > 1) remise.Text = p[p.Length - 1];

                    }
                    else if (!line.StartsWith("@"))
                    {
                        var p = line.Split('|');
                        if (p.Length < 8) return;

                        var n = p[5];
                        var r = p[6];
                        var a = p[7];

                        db.addRIB(n, r, a);


                        var ne = new ListViewDataItem(n, new string[] { n, r, a });


                        ne.Tag = new RIBClass(n, r, a);
                        list.Items.Add(ne);

                    }
                }

                save.Enabled = true;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void defaultToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ThemeResolutionService.ApplicationThemeName = "Office2013Light";
        }

        private void fluentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ThemeResolutionService.ApplicationThemeName = "Fluent";
        }

        private void crystalToolStripMenuItem_Click(object sender, EventArgs e)
        {

            ThemeResolutionService.ApplicationThemeName = "Crystal";
        }

        private void desertToolStripMenuItem_Click(object sender, EventArgs e)
        {

            ThemeResolutionService.ApplicationThemeName = "Desert";
        }

        private void noirToolStripMenuItem_Click(object sender, EventArgs e)
        {

            ThemeResolutionService.ApplicationThemeName = "Office2013Dark";
        }

        private void blackToolStripMenuItem_Click(object sender, EventArgs e)
        {

            ThemeResolutionService.ApplicationThemeName = "VisualStudio2012Dark";
        }

        private void quitterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void outilsToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void optionsToolStripMenuItem_Click(object sender, EventArgs e)
        {

            param.Show();
            param.BringToFront();
            param.Dock = DockStyle.Fill;
        }


        public static void SetAssociation(string Extension, string KeyName, string OpenWith, string FileDescription)
        {
            RegistryKey BaseKey;
            RegistryKey OpenMethod;
            RegistryKey Shell;
            RegistryKey CurrentUser;

            BaseKey = Registry.ClassesRoot.CreateSubKey(Extension);
            BaseKey.SetValue("", KeyName);

            OpenMethod = Registry.ClassesRoot.CreateSubKey(KeyName);
            OpenMethod.SetValue("", FileDescription);
            OpenMethod.CreateSubKey("DefaultIcon").SetValue("", "\"" + OpenWith + "\",0");
            Shell = OpenMethod.CreateSubKey("Shell");
            Shell.CreateSubKey("edit").CreateSubKey("command").SetValue("", "\"" + OpenWith + "\"" + " \"%1\"");
            Shell.CreateSubKey("open").CreateSubKey("command").SetValue("", "\"" + OpenWith + "\"" + " \"%1\"");
            BaseKey.Close();
            OpenMethod.Close();
            Shell.Close();

        }

        private void radButton1_Click_1(object sender, EventArgs e)
        {
            param.Hide();
        }

        private void MainNew_Shown(object sender, EventArgs e)
        {
            if (s != null)
            {
                s.Close();
            }
        }

        private void MainNew_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void baseDeDonnéeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var r = new DbExplore();
            var rd = r.ShowDialog();

            if (rd == System.Windows.Forms.DialogResult.OK)
            {
                var row = r.selected;
                if (row != null)
                {
                    fill(row.Nom, row.RIB);

                    ramt.Text = "Dernier montant : " + row.AMT + " DH";
                    ramt.Tag = row.AMT;
                    ramt.Visible = true;


                    nom.Tag = row;

                    seg.Hide();
                    nom.Focus();
                }
                
            }

            data = db.getRIBS();
        }

        private void historiqueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var d = new history())
            {
                if (d.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {

                    loadfile(d.selected);

                }
            }
        }
    }
}
