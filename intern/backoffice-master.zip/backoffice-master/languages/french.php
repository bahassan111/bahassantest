<?php

$language = [

    'loading' => 'Chargement en cours',
    'home' => 'Accueil',
    'chapters' => 'Les Chapitres',
    'chapter' => 'Chapitre',
    'about' => 'À propos de nous',
    'mobile_app' => 'Mobile APP',
    'android' => 'Android',
    'iphone' => 'iPhone',
    'search_chapters' => 'Rechercher les chapitres et les sous chapitres',
    'insert_keyword' => 'Tapez un mot clé',
    'or' => 'OU',
    'explore' => 'Explorer',
    'download_app' => "Téléchargez maintenant l'application mobile officielle pour votre appareil mobile",
    'search' => "Rechercher",
    'read_more' => "Lire la suite",
    'no_result_for' => "Aucun résultat trouvé pour le mot clé",
    'use_diffrent_word' => "Essayez de chercher en utilisant un autre mot clé",
    'share_friends' => "Partager avec vous amis",
    'more_chapter' => "Plus dans le même chapitre",
    'who' => "A Propos De Programme",
    'text_propo_nous' => "« <span class='color_propos'>M</span>on signe Ma voix » est le premier dictionnaire électoral en langue des signes en Tunisie. Il a été développé par la Fondation internationale pour les systèmes électoraux (IFES) avec le soutien de l'Agence américaine pour la coopération internationale (USAID) et en consultation avec des experts en langue des signes et les associations de personnes sourdes en Tunisie.
                        L'objectif principal de ce dictionnaire est de fournir des informations électorales aux personnes sourdes et malentendantes dans une langue des signes simplifiée, par le biais d’images et de vidéos, dans le but de renforcer la participation des personnes sourdes et malentendantes dans le processus électoral et de les sensibiliser à leurs droits politiques.
                        ",
    'text_propo_nous2' => "Ce dictionnaire comprend 193 termes électoraux répartis en 8 chapitres qui traitent de tous les aspects du processus électoral, à commencer par le cadre juridique des élections et les normes internationales, puis les étapes de l'inscription et de la candidature aux élections, puis le vote, le dépouillement et l’annonce des résultats, ainsi que les parties prenantes au processus électoral.Afin de rendre le dictionnaire plus accessible à tous les bénéficiaires, IFES a développé une application mobile appelée \"Mon signe ma voix \", qui contient tous les termes traduits en langue des signes avec des images et des vidéos en arabe et en français, pouvant être téléchargés via Play Store et Apple Store. Un CD-ROM accompagnant la version imprimée du dictionnaire a été développé.",
    'text_propo_nous3' => "Le développement du dictionnaire a commencé depuis octobre 2018 en définissant le contenu du dictionnaire en consultation avec un expert accrédité dans le domaine des élections. Ensuite, le contenu a été traduit en langue des signes à travers des images et des vidéos en collaboration avec un groupe de jeunes malentendants et sourdes et un interprète en langue des signes. Ces termes ont été présentés à un grand nombre de représentants d’associations œuvrant dans la défense des droits des personnes sourdes et malentendantes ainsi qu’à des associations de défense des droits des personnes handicapées, à des experts en langue des signes et à des représentants de l’Instance supérieure indépendante pour les élections lors d’un atelier de concertation. Des modifications ont été apportées au dictionnaire sur la base des suggestions formulées lors de l’atelier. Une première version du dictionnaire des termes électoraux en langue des signes tunisienne est maintenant prête et disponible.",
    'telecharger_doc' => "Télécharger Version Papier",
    'icharty_sawty' => "Icharty Sawty",
    'follow' => "Suivez-nous",
    'contact' => "contact",
    'copyright' => " Tous droits réservés ".date('Y')." | La Fondation Internationale des Systèmes Electoraux - IFES Tunisie ",

    'tous_droit' => "Tous droits réservés ".date('Y')." |",
    'fondation' => "Systèmes Electoraux - IFES Tunisie",
    'system_elec' => "Systèmes Electoraux - IFES Tunisie",
    'rue_capital' => "Rue de lac Mazurie Imm Le Capitole,",
    'block_m' => "bloc A 3eme étage appt4(0,001mi)",
    'text_contact' => "Tunis, Tunisia 1053",
    'tel_foot' => "Tel : ",
    'retour_back' => "Retour à l'accueil ",
    'country_region' => "Pays/Région",


];