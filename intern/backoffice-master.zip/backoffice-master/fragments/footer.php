<?php
defined('BASE') OR die('Direct access is not allowed');
?>
</div>

<footer>
    <div class='dropDown-tltp'>

        <button class="label"><?= lang('country_region') ?> : <?= information_country() ? '<img src="'.site_url('images/flags/'.information_country()->iso.'.png').'"/> '.information_country()->name : '' ?>  </button>
        <div class="content">
            <?php foreach ($front_countries as $front_country){ ?>
                <a href="javascript:void(0)" class="change_country <?= $front_country->id===current_country() ? ' selected' : '' ?>" data-country="<?= $front_country->id ?>"><?= $front_country->name ?></a>
            <?php } ?>
        </div>
    </div>
    <div class="all_f">



        <div class="oo">
            <div class="dv_f footer_logo">
                <img src="<?= site_url('images/log.png') ?>" alt="" width="90px" style="border-radius: 4px;">
            </div>
            <div class="dv_f" id="back_info">
                <a target="_blank" href="https://www.facebook.com/ichartisawti/">
                    <img src="<?= site_url('images/suivez.png') ?>" alt="" id="img_fb" width="75%">
                </a>
            </div>
        </div>

        <div class="dv_f" id="dv_f_contact">
            <div class="text-contact"><?= lang('contact') ?></div>
            <div>
                <div><?= lang('rue_capital') ?></div>
                <div><?= lang('block_m') ?></div>
                <div><?= lang('text_contact') ?></div>
                <div class="tel_foot" ><?= lang('tel_foot') ?> <div style="direction: ltr !important;">  +216 54044953 </div> </div>
                <div>
                    <a href="mailto:ichartisawti@gmail.com" id="mail_to">
                        ichartisawti@gmail.com
                    </a>
                </div>
            </div>
        </div>
        <div class="dv_f">
            <div class="text-copyright">
                <div>
                    <?= lang('tous_droit').'  '.date('Y')." |" ?>
                </div>
                <div>
                    <?= lang('fondation') ?>
                </div>
                <div>
                    <?= lang('system_elec') ?>
                </div>
            </div>
        </div>
    </div>

</footer>

<script src="<?= site_url('assets/js/vendor/modernizr-3.7.1.min.js'); ?>"></script>
<script src="<?= site_url('assets/js/vendor/jquery-3.4.1.min.js'); ?>"></script>
<script src="<?= site_url('assets/js/vendor/Tocca.min.js'); ?>"></script>
<script src="<?= site_url('assets/js/plugins.js'); ?>"></script>
<script src="<?= site_url('assets/js/app.js?v='.rand(0,99999)); ?>"></script>
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5db2c7c732071240"></script>
</body>

</html>
