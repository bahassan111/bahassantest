﻿using PCARD_CLIB_45;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebSocketsCmd.Meta;

namespace WebSocketsCmd
{
    public class Pay
    {
        PCARDAPI api;
        string DC1;
        string DC2;
        string DC3;
        int apiRep;

        public bool signedOn;
        public string SessionID;
        public string TerminalID;
        public string OutletID;
        public string STAN;
        public string EFT_STAN;

        public ParseResult last_pay_c2;
        public ParseResult last_pay_c3;

        private Func<string, int> ticket_callback;

        public Pay()
        {
            this.init();
        }
        public Pay(Func<string, int> ticket_cb)
        {
            this.ticket_callback = ticket_cb;
            this.init();
        }

        private void init()
        {
            api = new PCARDAPI(1);
            PCARDAPI.dDisplay = new PCARDAPI.dlgtOutPut(_displayCallback);
            PCARDAPI.dPrint = new PCARDAPI.dlgtOutPut(this.ticket_callback);
        }

        static int _displayCallback(string Msg)
        {
            Console.WriteLine("Message :  " + Msg);
            return 0;
        }
        static int _printCallback(string Tckt)
        {
            Console.WriteLine("Ticket :  " + Tckt);
            
            return 0;
        }


        public RepCode signOn(string ProtocolVersion, string FABID, string ECRNUM, string PASSWORD)
        {

            var tag1 = new TwTAG(TwConstants.TAG_SIGN_ON_REQUEST_DATA, -1, "", new[]
            {
                new TwTAG(TwConstants.TAG_PROTOCOL_VER, ProtocolVersion.Length, ProtocolVersion, null),
                new TwTAG(TwConstants.TAG_ECR_FAB_ID, FABID.Length, FABID, null),
                new TwTAG(TwConstants.TAG_ECR_NUM, ECRNUM.Length, ECRNUM, null),
                new TwTAG(TwConstants.TAG_PWD, PASSWORD.Length, PASSWORD, null),
                new TwTAG(TwConstants.TAG_ECR_INPUT_OPT, 2, "00", null),
            });

            var tag2 = new TwTAG(TwConstants.TAG_TIME_OUTS, 32, "", new[]
            {
                new TwTAG(TwConstants.TAG_TRANS_TIME_OUT, 2, "30", null),
                new TwTAG(TwConstants.TAG_OPER_TIME_OUT, 2, "05", null),
                new TwTAG(TwConstants.TAG_END_OF_DAY_TIME_OUT, 4, "0180", null),
            });


            DC1 = tag1.ToString() + tag2.ToString();

            this.apiRep = api.SignOn(DC1, ref DC2, ref DC3);


            var rep = TwParser.parseTLV(DC2);
            var rep2 = TwParser.parseTLV(DC3);

            var status_tag = rep.getTag(TwConstants.TAG_PROCESS_STATUS);
            var rep_tag = rep2.getTag(TwConstants.TAG_SIGN_ON_RESPONSE_DATA);

            var rep_code = Codes.getCode(status_tag.Val);

            if (rep_code.message == Codes.CODE_0000)
            {
                foreach (TwTAG sub in rep_tag.SubTags)
                {
                    if (sub.Type == TwConstants.TAG_TERMINAL_ID) this.TerminalID = sub.Val;
                    else if (sub.Type == TwConstants.TAG_OUTLET_ID) this.OutletID = sub.Val;
                }

                this.signedOn = true;

            }

            return rep_code;

        }


        public RepCode signOff()
        {


            Pay.log("Sign OFF ############################################");
            this.apiRep = api.SignOff(ref DC3);



            var rep = TwParser.parseTLV(DC3);


            var rep_tag = rep.getTag(TwConstants.TAG_RESULT);

            var rep_code = Codes.getCode(rep_tag.Val);

            if (rep_code.message == Codes.CODE_0000)
            {


                this.signedOn = false;

            }

            return rep_code;

        }


        public RepCode voidTx(TwTAG void_request_tag, string sess_id)
        {
            this.SessionID = sess_id;

            var sess_tag = new TwTAG(TwConstants.TAG_OPEN_SESSION_REQUEST_DATA, -1, "", new[] { 
                new TwTAG(TwConstants.TAG_SESSION_ID, this.SessionID.Length, this.SessionID) 
            });

            DC1 = sess_tag.ToString();

            Pay.log("OPEN_SESSION " + DC1);
            apiRep = api.OpenSession(DC1, ref DC2, ref DC3);

            var sess_status = TwParser.parseTLV(DC2).getTag(TwConstants.TAG_PROCESS_STATUS);
            var sess_result_DC3 = TwParser.parseTLV(DC3).getTag(TwConstants.TAG_RESULT);
            var sess_result_DC3_S = TwParser.parseTLV(DC3).getTag(TwConstants.TAG_SESSION_ID);

            bool sessionOpen = sess_status != null && sess_status.Val == "0000" && sess_result_DC3 != null && sess_result_DC3.Val == "0000";

            if (sessionOpen)
            {
                this.SessionID = sess_result_DC3_S.Val;
            }
            else
            {
                return Codes.getCode(sess_status.Val);
            }

            Pay.log("VOID  " + void_request_tag.ToString());
            this.apiRep = api.Void(void_request_tag.ToString(), ref this.DC2, ref this.DC3);



            var status = TwParser.parseTLV(DC2);
            var rep = TwParser.parseTLV(DC3);


            var rep_tag = status.getTag(TwConstants.TAG_PROCESS_STATUS);

            var rep_code = Codes.getCode(rep_tag.Val);


            RepCode closeRep = this.closeSession(this.SessionID);


            return rep_code;

        }


        public RepCode closeSession(String session_id)
        {



            var sessClose = (new TwTAG(TwConstants.TAG_CLOSE_SESSION_REQUEST_DATA, -1, "", new[] { 
                new TwTAG(TwConstants.TAG_SESSION_ID, -1, this.SessionID)
            }));

            DC1 = sessClose.ToString();

            Pay.log("CLOSE_SESSION " + DC1);
            apiRep = api.CloseSession(DC1, ref DC2, ref DC3);



            var status = TwParser.parseTLV(DC2);
            var rep = TwParser.parseTLV(DC3);


            var rep_tag = status.getTag(TwConstants.TAG_PROCESS_STATUS);

            var rep_code = Codes.getCode(rep_tag.Val);


            return rep_code;

        }

        public RepCode processPayement(int amount)
        {
           
            var centime = amount;
      
            var date = DateTime.Now.ToString("yMMddhhmmtt");
            this.SessionID = Pay.nextSessionID().ToString();

            var sess_tag = new TwTAG(TwConstants.TAG_OPEN_SESSION_REQUEST_DATA, -1, "", new[] { 
                new TwTAG(TwConstants.TAG_SESSION_ID, this.SessionID.Length, this.SessionID) 
            });

            DC1 = sess_tag.ToString();

            Pay.log("OPEN_SESSION " + DC1);
            apiRep = api.OpenSession(DC1, ref DC2, ref DC3);

            var sess_status = TwParser.parseTLV(DC2).getTag(TwConstants.TAG_PROCESS_STATUS);
            var sess_result_DC3 = TwParser.parseTLV(DC3).getTag(TwConstants.TAG_RESULT);
            var sess_result_DC3_S = TwParser.parseTLV(DC3).getTag(TwConstants.TAG_SESSION_ID);

            bool sessionOpen = sess_status != null && sess_status.Val == "0000" && sess_result_DC3 != null && sess_result_DC3.Val == "0000";

            if (sessionOpen)
            {
                this.SessionID = sess_result_DC3_S.Val;
            }
            else
            {
                return Codes.getCode(sess_status.Val);
            }

            var pay_tag = new TwTAG(TwConstants.TAG_PAYMENT_REQUEST_DATA, -1, "", new[]{
                
                new TwTAG(TwConstants.TAG_PAYMENT_REQUEST_STD_DATA, -1, "", new []{
                    
                    new TwTAG(TwConstants.TAG_AMOUNT, String.Format("{0}", centime).Length, String.Format("{0}", centime)),
                    new TwTAG(TwConstants.TAG_CURRENCY, 3, "504"),
                    new TwTAG(TwConstants.TAG_PAY_KIND, 1, "0"),
                    new TwTAG(TwConstants.TAG_SESSION_ID, this.SessionID.Length, this.SessionID)

                }),

                new TwTAG(TwConstants.TAG_PAYMENT_REQUEST_ADDITIONAL_DATA, -1, "", new[] { 
                    new TwTAG(TwConstants.TAG_ECR_STAN, 2, "99"),
                    new TwTAG(TwConstants.TAG_ECR_DATE_TIME, date.Length, date)
                })

            });


            Pay.log("PAY " + pay_tag.ToString());
            apiRep = api.Payment(pay_tag.ToString(), ref DC2, ref DC3);

            var pay_dc2 = TwParser.parseTLV(DC2);
            var pay_dc3 = TwParser.parseTLV(DC3);

            this.last_pay_c2 = pay_dc2;
            this.last_pay_c3 = pay_dc3;


            

            
            
            var payStatus = pay_dc2.getTag(TwConstants.TAG_PROCESS_STATUS);
            var payPayload = pay_dc3.getTag(TwConstants.TAG_RESULT);

            var payOK = payStatus != null && payStatus.Val == "0000";
            var poOK = payPayload != null && payPayload.Val == "0000";

            RepCode closeRep = this.closeSession(this.SessionID);

            if (payOK && poOK)
            {
                return Codes.getCode("0000");
            }
            else
            {
                return !poOK ? Codes.getCode(payStatus.Val) : Codes.getCode(payPayload.Val);
            }

        }

        public static void log(string content)
        {
            content = String.Format("{0} \t {1} \r\n", DateTime.Now.ToShortTimeString(), content);
            
            File.AppendAllText(Environment.CurrentDirectory + @"\log.log", content, UTF8Encoding.UTF8);
        }

        public static int nextSessionID()
        {
            var current_id = Properties.Settings.Default.session;
            if (current_id < 0 || current_id > 999)
            {
                current_id = 0;
            }

            var next_id = ++current_id;

            Properties.Settings.Default.session = next_id;
            Properties.Settings.Default.Save();

            return next_id;
        }
    }
}
