import 'package:rider_app/models/models.dart';

class Steps {
  Maneuver maneuver;
  List<Intersections> intersections;
  var weight;
  var duration;
  var distance;
  String name;
  String drivingSide;
  String mode;
  String geometry;
  String ref;

  Steps(
      {this.maneuver,
      this.intersections,
      this.weight,
      this.duration,
      this.distance,
      this.name,
      this.drivingSide,
      this.mode,
      this.geometry,
      this.ref});

  Steps.fromJson(Map<String, dynamic> json) {
    maneuver = json['maneuver'] != null
        ? new Maneuver.fromJson(json['maneuver'])
        : null;
    if (json['intersections'] != null) {
      intersections = [];
      json['intersections'].forEach((v) {
        intersections.add(new Intersections.fromJson(v));
      });
    }
    weight = json['weight'];
    duration = json['duration'];
    distance = json['distance'];
    name = json['name'];
    drivingSide = json['driving_side'];
    mode = json['mode'];
    geometry = json['geometry'];
    ref = json['ref'];
  }
}
