import React, { Component } from "react";
import {
  Dimensions,
  ImageBackground,
  StyleSheet,
  TouchableHighlight,
} from "react-native";
import { AsyncStorage } from "react-native";
import { NavigationActions, StackActions } from "react-navigation";
import { connect } from "react-redux";

import { View, Text, Image } from "react-native-ui-lib";

/*import * as Google from "expo-google-app-auth";*/
import * as GoogleSignIn from "expo-google-sign-in";
import * as Facebook from "expo-facebook";

import { Audio } from "expo-av";

import environment, {
  appId,
  androidClientId,
  iosClientId,
} from "../constants/envirenement";

import Config from "../constants/Config";
import Colors from "../constants/Colors";
import Icon from "../constants/Icons";
import { fetchBanners } from "../Redux/actions/BannersActions";
import {
  fetchFontSize,
  changeFont,
  changeLanguage,
  editLanguageFr,
  editLanguageAr,
} from "../Redux/actions/FontSizeActions";

import {
  fetchArticleDetails,
  saveInfo,
} from "../Redux/actions/ChapitresActions";

import * as Updates from 'expo-updates';

class IntroScreen extends Component {
  constructor(props) {
    super(props);
    this._isMounted = true;
  }
  static navigationOptions = ({ navigation }) => ({
    header: null,
  });

  state = {
    itemsCount: this.props.fontSizeValue.fontSize,
    shouldPlay: false,
    data: [],
    result: null,
    userID: "",
    userName: "",
    userEmail: "",
    userImage: "",
    fetchDataCountries: [],
    checkingUpdate:false,
    footer_message : 'checking updates ..',
  };

  componentWillMount() {
    AsyncStorage.multiGet([
      "id",
      "name",
      "email",
      "image",
      "lang",
      "id_country",
    ]).then((data) => {
      let id = data[0][1];
      let name = data[1][1];
      let email = data[2][1];
      let image = data[3][1];
      let lang = data[4][1];
      let id_country = data[5][1];

      if (id) {
        if (id_country) {
          console.log("hado country", id_country);
          this.redirect_Tolang();
        } else this.redirect_ToCountry();
      }
      this.setState({
        userID: id,
        userName: name,
        userEmail: email,
        userImage: image,
      });
      console.log(
        this.state.userID + " " + this.state.userEmail,
        "ha detailss"
      );
      Audio.setAudioModeAsync({
        allowsRecordingIOS: false,
        interruptionModeIOS: Audio.INTERRUPTION_MODE_IOS_DO_NOT_MIX,
        playsInSilentModeIOS: true,
        shouldDuckAndroid: true,
        interruptionModeAndroid: Audio.INTERRUPTION_MODE_ANDROID_DO_NOT_MIX,
        playThroughEarpieceAndroid: false,
      });
      this.props.fetchFontSize();
    });
  }

  componentDidUpdate(nextProps) {
    console.log("this.props.hasIntro", this.props.hasIntro);
    if (nextProps.hasIntro !== this.props.hasIntro) {
      if (this.props.hasIntro == 500) {
        // this.resetStack();
      }
    }
  }

  // _goHome = () => {
  //     // this.setState({
  //     //   shouldPlay: !shouldPlay
  //     // });
  //
  //     this.props.navigation.navigate("Home");
  // };

  resetStack = async () => {
    let user_id = this.state.userID;
    await fetch(Config.API_URL + "includes/encode/index.php", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        post: "save_langueUser",
        user_id: user_id,
        lang: "ar",
      }),
    })
      .then((res) => res.json())
      .then((responseJson) => {
        if (responseJson.lang) {
          AsyncStorage.multiSet([["lang", responseJson.lang]]);
        }
      })
      .catch((error) => {
        console.log("error save Save Lang ", error);
      });

    this.props.fetchArticleDetails("ar");
    this.props.fetchBanners();

    this.props.changeFont(this.props.fontSizeValue.fontSize, 500);
    this.props.navigation.dispatch(
      StackActions.reset({
        index: 0,
        key: null,
        actions: [
          NavigationActions.navigate({
            routeName: "Main",
          }),
        ],
      })
    );

    this.props.fetchFontSize("ar");
    this.props.editLanguageAr();
  };
  resetStackFr = async () => {
    let user_id = this.state.userID;
    await fetch(Config.API_URL + "includes/encode/index.php", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        post: "save_langueUser",
        user_id: user_id,
        lang: "fr",
      }),
    })
      .then((res) => res.json())
      .then((responseJson) => {
        if (responseJson.lang) {
          AsyncStorage.multiSet([["lang", responseJson.lang]]);
        }
      })
      .catch((error) => {
        console.log("error save Save Lang ", error);
      });

    this.props.fetchArticleDetails("fr");
    this.props.fetchBanners();

    this.props.changeFont(this.props.fontSizeValue.fontSize, 500);
    this.props.navigation.dispatch(
      StackActions.reset({
        index: 0,
        key: null,
        actions: [
          NavigationActions.navigate({
            routeName: "Main",
          }),
        ],
      })
    );

    this.props.fetchFontSize("fr");
    this.props.editLanguageFr();
  };

  componentDidMount() {
    this.initAsync();

    this.setState({checkingUpdate : true, footer_message : 'checking updates ..'});
    Updates.checkForUpdateAsync()
        .then((result) =>{
          if(result.isAvailable){
            this.setState({footer_message : ' Updating .. '});
            Updates.fetchUpdateAsync()
                .then(()=>{
                  Updates.reloadAsync()
                      .then(()=> this.setState({checkingUpdate : false, footer_message : 'Updated!'}))
                });
          }else{
            this.setState({checkingUpdate : false, footer_message : ' up to date'});
          }
        });
  }
  initAsync = async () => {
    await GoogleSignIn.initAsync({
      // You may ommit the clientId when the firebase `googleServicesFile` is configured
      clientId: '30760096106-o1hfh4amp9viisk6t3797ol4go2tt9d6.apps.googleusercontent.com',
    });
  };

  _syncUserWithStateAsync = async (user)=>{
    if(!user){
      user = await GoogleSignIn.signInSilentlyAsync();
    }

    if (user) {
      let id = user.uid;
      let name = user.name;
      let email = user.email;
      let image = user.photoURL;



      AsyncStorage.multiSet([
        ["id", id],
        ["name", name],
        ["email", email],
        ["image", image],
      ]);


      if (id) {
        this.props.saveInfo(id, name, email, image);
        this.setState({
          userID: id,
          userName: name,
          userEmail: email,
          userImage: image,
        });
      }

      await this.check_countryUser(id);
    }
  };

  async _handleGoogleLogin() {

    try {
      await GoogleSignIn.askForPlayServicesAsync();
      const { type, user, accessT } = await GoogleSignIn.signInAsync();
      if (type === 'success') {
        let result = {type : type, user : user};

        this._syncUserWithStateAsync(user);
      }else{

      }



    } catch ({ message }) {
      console.log('login: Error:' + message);
    }

  }


  async _handleGoogleLogin_old() {
    try {
      const result = await Google.logInAsync({
        androidClientId: '30760096106-mh6m0dlgipk326pnrkgvnrp7kpe2fl52.apps.googleusercontent.com',
        iosClientId: '30760096106-mh6m0dlgipk326pnrkgvnrp7kpe2fl52.apps.googleusercontent.com',
        iosStandaloneAppClientId : '30760096106-o1hfh4amp9viisk6t3797ol4go2tt9d6.apps.googleusercontent.com',
        androidStandaloneAppClientId : '30760096106-3860t5ed5l6nlejbjmao426lhh29cfd6.apps.googleusercontent.com',
        clientId : '30760096106-o1hfh4amp9viisk6t3797ol4go2tt9d6.apps.googleusercontent.com',
        behavior: 'system',
        scopes: ["profile", "email"],
      });
      if (result.type === "success") {
        if (result.user) {
          let id = result.user.id;
          let name = result.user.name;
          let email = result.user.email;
          let image = result.user.photoUrl;

          AsyncStorage.multiSet([
            ["id", id],
            ["name", name],
            ["email", email],
            ["image", image],
          ]);

          await this.check_countryUser(id);

          if (id) {
            this.props.saveInfo(id, name, email, image);
            this.setState({
              userID: id,
              userName: name,
              userEmail: email,
              userImage: image,
            });
          }

          return result.accessToken;
        }
      } else {
        console.log("Cancelled!", "Login was cancelled!");
        return { cancelled: true };
      }
    } catch (error) {
      console.log("Oops!", "Login failed!");
      console.error("google login error!", error);
      return { error: true };
    }
  }

  async logIn(options) {
    try {
      await Facebook.initializeAsync({
        appId: appId,
      });

      const {
        type,
        token,
        expires,
        permissions,
        declinedPermissions,
      } = await Facebook.logInWithReadPermissionsAsync({
        permissions: ["public_profile", "email"],
        behavior: "system",
      });

      if (type === "success") {
        // Get the user's name using Facebook's Graph API
        const response = await fetch(
          `https://graph.facebook.com/me?access_token=${token}&fields=id,name,email,picture.type(large)`
        );
        const userInfo = await response.json();

        let id = userInfo.id;
        let name = userInfo.name;
        let email = userInfo.email;
        var image = userInfo.picture.data.url;

        AsyncStorage.multiSet([
          ["id", id],
          ["name", name],
          ["email", email],
          ["image", image],
        ]);

        await this.check_countryUser(id);

        if (id) {
          this.props.saveInfo(id, name, email, image);
          this.setState({
            userID: id,
            userName: name,
            userEmail: email,
            userImage: image,
          });
        }

        console.log("goood__=> ", id, name);
        if (id) {
          console.log("after" + image);
          this.props.saveInfo(id, name, email, image);
          console.log("goood=> mzyan ", id, name);
        }

        console.log("Logged in!", `Hi ${(await response.json()).name}!`);
      } else {
        // type === 'cancel'
      }
    } catch ({ message }) {

      console.log(`Facebook Login Error: ${message}`);
    }
  }

  check_countryUser = async (user_id) => {
    await fetch(Config.API_URL + "includes/encode/index.php", {
      method: "post",
      body: JSON.stringify({
        post: "check_country",
        user_id: user_id,
      }),

      headers: {
        Accept: "application/json",
        "content-type": "multipart/form-data",
      },
    })
      .then((res) => res.json())
      .then((responseJson) => {
        console.log("lang iss", responseJson);
        AsyncStorage.multiSet([["id_country", responseJson.id_country]]);


        if (responseJson.id_country)
          this.chooseCountry(responseJson.id_country);
      })
      .catch((error) => {});
  };

  async chooseCountry(id_country) {
    fetch("http://ifes-esll.com/new/api/includes/encode/index.php", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        post: "addCountry",
        user_id: this.state.userID,
        id_country: id_country,
      }),
    })
      .then((res) => res.json())
      .then((responseJson) => {
        console.log("dataa");
        console.log(responseJson);

        AsyncStorage.setItem("id_country", id_country);
        AsyncStorage.setItem("id_lang", responseJson.id_lang);
        AsyncStorage.setItem("lang_index", responseJson.lang_index);
        AsyncStorage.setItem("rtl", responseJson.rtl);
        AsyncStorage.setItem("lang", responseJson.lang2);
        AsyncStorage.setItem("lang_index2", responseJson.lang_index2);
        AsyncStorage.setItem("rtl2", responseJson.rtl2);
        AsyncStorage.setItem("lang2", responseJson.lang);
        AsyncStorage.setItem("fields", JSON.stringify(responseJson.fields));
        AsyncStorage.setItem("see_more", responseJson.see_more);
        AsyncStorage.setItem("search", responseJson.search);
        AsyncStorage.setItem("see_less", responseJson.see_less);
        AsyncStorage.setItem("homeScreen", responseJson.homeScreen);
        AsyncStorage.setItem("settingScreen", responseJson.settingScreen);
        AsyncStorage.setItem("count_languages", responseJson.count_languages);
        AsyncStorage.setItem("countries", responseJson.countries);
        AsyncStorage.setItem("name_country", responseJson.name_country);
        AsyncStorage.setItem("iso_country", responseJson.iso_country);
        AsyncStorage.setItem("change_country", responseJson.change_country);
        this.redirect_Tolang();
      })
      .catch((error) => {
        console.log("error", error);
      });
  }

  redirect_Tolang = async () => {
    let id_country = await AsyncStorage.getItem("id_country");
    let id_lang = await AsyncStorage.getItem("id_lang");
    let lang_index = await AsyncStorage.getItem("lang_index");
    let lang_index2 = await AsyncStorage.getItem("lang_index2");
    let lang = await AsyncStorage.getItem("lang");
    let rtl = await AsyncStorage.getItem("rtl");

    this.props.fetchArticleDetails(id_country, lang_index);
    this.props.fetchBanners();
    this.props.changeFont(this.props.fontSizeValue.fontSize, 500);
    this.props.navigation.dispatch(
      StackActions.reset({
        index: 0,
        key: null,
        actions: [
          NavigationActions.navigate({
            routeName: "Main",
          }),
        ],
      })
    );
    // this.props.fetchFontSize(lang, id);

    console.log("ha rtl", rtl);

    if (rtl === 1) this.props.editLanguageAr();
    else this.props.editLanguageFr();
  };

  redirect_ToCountry = () => {
    this.props.navigation.navigate({
      routeName: "Countries",
    });
  };

  renderLogin() {
    if (!this.state.userID) {
      return (
        <View>
          <View style={styles.topbg}>
            <ImageBackground
              source={require("../assets/images/topbg.png")}
              style={{ width: "100%", height: "100%" }}
            ></ImageBackground>
          </View>
          <View style={styles.inner}>
            <Image
              style={styles.logo}
              source={require("../assets/images/logo_bg.jpg")}
            />
            <View style={styles.subtext}>
              <View style={styles.subtext_line} />
              <Text style={styles.subtext_txt}>Sign in</Text>
            </View>
            {(this.state.checkingUpdate ? <View style={styles.loading_text}>
              <Text text40>Synchronisation ..</Text>
            </View> : <View style={styles.login_buttons}>
              <TouchableHighlight
                  onPress={this.logIn.bind(this)}
                  style={styles.fbButton}
                  underlayColor="#042417"
              >
                <View style={styles.btnContainer}>
                  <Image
                      style={styles.btnIcon}
                      source={require("../assets/images/fb_round.png")}
                  />
                  <Text style={styles.btnText}>Facebook</Text>
                </View>
              </TouchableHighlight>
              <TouchableHighlight
                  onPress={this._handleGoogleLogin.bind(this)}
                  style={styles.googleButton}
                  underlayColor="#042417"
              >
                <View style={styles.btnContainer}>
                  <Image
                      style={styles.btnIcon}
                      source={require("../assets/images/google.png")}
                  />
                  <Text style={styles.btnTextg}>Google</Text>
                </View>
              </TouchableHighlight>
            </View>)}
          </View>
          <View style={styles.bottombg}>
            <ImageBackground
              source={require("../assets/images/bottombg.png")}
              style={{ width: "100%", height: "100%" }}
            >
              <Text style={styles.footer_txt}>
                ©{new Date().getFullYear()} IFES - {this.state.footer_message}
              </Text>
            </ImageBackground>
          </View>
        </View>
      );
    }
  }

  render() {
    const icon = (name, size = 36) => () => (
      <Icon
        name={name}
        iconSize={size}
        color={Colors.white}
        style={{ textAlign: "center" }}
      />
    );
    return <View style={styles.container}>{this.renderLogin()}</View>;
  }
}

const mapStateToProps = (state) => {
  const fontSizeValue = state.fontSize;
  const hasIntro = state.fontSize.hasIntro;
  const lang = state.fontSize.lang;

  const data = state.searchAll.data;
  const isLoadingData = state.searchAll.isLoadingData;

  return {
    lang,
    fontSizeValue,
    hasIntro,
    isLoadingData,
    data,
  };
};

const colors = {
  bg: "#f2f2f2",
  bg_darker: "#ececec",
  white: "#fff",
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f2f2f2",
    justifyContent: "center",
  },
  topbg: {
    height: "20%",
  },
  bottombg: {
    height: "20%",
  },
  inner: {
    height: "60%",
    alignItems: "center",
    justifyContent: "center",
  },
  logo: {
    borderRadius:
      Math.round(
        Dimensions.get("window").width + Dimensions.get("window").height
      ) / 2,
    width: Dimensions.get("window").width * 0.35,
    height: Dimensions.get("window").width * 0.35,
    shadowColor: "#000",
    shadowOffset: { width: 60, height: 20 },
    shadowOpacity: 1,
    shadowRadius: 80,
    borderColor: "#ececec",
    borderWidth: 2,
  },
  subtext: {
    marginTop: 22,
    padding: 12,
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
  },
  subtext_txt: {
    backgroundColor: colors.bg,
    padding: 12,
  },
  subtext_line: {
    height: 1,
    width: "90%",
    left: "10%",
    top: "80%",
    backgroundColor: "#000",
    position: "absolute",
  },
  login_fb: {
    backgroundColor: "red",
  },
  login_buttons: {
    height: "60%",
    width: "100%",
    alignItems: "center",
  },

  loading_text : {

  },

  fbButton: {
    flexDirection: "row",
    justifyContent: "center",
    backgroundColor: "#4e71a8",
    borderRadius: 20,
    padding: 5,
    marginTop: 5,
    marginBottom: 5,
    height: 42,
    width: "80%",
    maxWidth: 400,
  },
  googleButton: {
    flexDirection: "row",
    justifyContent: "center",
    backgroundColor: "#ffffff",
    borderRadius: 20,
    padding: 5,
    marginTop: 5,
    marginBottom: 5,
    height: 42,
    width: "80%",
    maxWidth: 400,
  },
  btnContainer: {
    flexDirection: "row",
    flex: 1,
    alignItems: "center",
  },
  btnIcon: {
    height: 25,
    width: 25,
    marginLeft: 16,
    borderWidth: 1,
    borderColor: "#fff",
    borderRadius:
      Math.round(
        Dimensions.get("window").width + Dimensions.get("window").height
      ) / 2,
  },
  btnText: {
    marginTop: -3,
    fontSize: 18,
    color: "#FAFAFA",
    flex: 1,
    paddingLeft: 64,
  },
  btnTextg: {
    marginTop: -3,
    fontSize: 18,
    color: "#1d1d1d",
    flex: 1,
    paddingLeft: 64,
  },
  footer_txt: {
    textAlign: "center",
    position: "absolute",
    bottom: 0,
    left: 0,
    width: "100%",
    paddingBottom: 12,
    color: colors.white,
  },
  inner_countries: {
    paddingLeft: 2,
    paddingRight: 10,
    paddingVertical: 12,
    flexDirection: "row",
    alignItems: "flex-start",
  },
  image_countries: {
    width: 20,
    height: 20,
    borderRadius: 20,
    marginLeft: 20,
  },
  contentHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 6,
    marginLeft: 10,
  },
  time: {
    fontSize: 11,
    color: "#808080",
    alignItems: "flex-end",
  },
  name: {
    fontSize: 12,
    fontWeight: "bold",
  },
  root: {
    marginTop: 10,
  },
  separator: {
    height: 1,
    backgroundColor: "#CCCCCC",
  },
});

export default connect(mapStateToProps, {
  fetchFontSize,
  changeLanguage,
  editLanguageAr,
  editLanguageFr,
  fetchBanners,
  changeFont,
  fetchArticleDetails,
  saveInfo,
})(IntroScreen);
