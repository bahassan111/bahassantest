import 'package:rider_app/models/models.dart';

class RouteDetailModel {
  List<Routes> routes;
  List<Waypoints> waypoints;
  String code;
  String uuid;

  RouteDetailModel({this.routes, this.waypoints, this.code, this.uuid});

  RouteDetailModel.fromJson(Map<String, dynamic> json) {
    if (json['routes'] != null) {
      routes = [];
      json['routes'].forEach((v) {
        routes.add(Routes.fromJson(v));
      });
    }
    if (json['waypoints'] != null) {
      waypoints = [];
      json['waypoints'].forEach((v) {
        waypoints.add(Waypoints.fromJson(v));
      });
    }
    code = json['code'];
    uuid = json['uuid'];
  }
}
