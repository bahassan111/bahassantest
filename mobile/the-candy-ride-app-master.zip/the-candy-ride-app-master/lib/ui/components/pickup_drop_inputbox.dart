import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rider_app/constants/app_themes.dart';
import 'package:rider_app/controllers/controllers.dart';
import 'package:rider_app/models/models.dart';

class PickUpDropInputBox extends StatefulWidget {
  static HomeController to = Get.find();

  PickUpDropInputBox({
    this.controller,
    this.labelText,
    this.keyboardType = TextInputType.text,
    this.obscureText = false,
    this.minLines,
    this.isReadOnly = false,
    this.iconSuffix,
    this.onChanged,
    this.focusNode,
    this.onSuggestionSelected,
    this.disableBorderColor,
  });

  final TextEditingController controller;
  final String labelText;
  final bool isReadOnly;
  final FocusNode focusNode;
  final TextInputType keyboardType;
  final bool obscureText;
  final int minLines;
  final Widget iconSuffix;
  final Color disableBorderColor;
  final Function(Features) onSuggestionSelected;
  final void Function(String) onChanged;

  @override
  _PickUpDropInputBoxState createState() => _PickUpDropInputBoxState();
}

class _PickUpDropInputBoxState extends State<PickUpDropInputBox> {
  SearchPlaceModel searchPlaceModel;
  TextEditingController controller = TextEditingController();
  @override
  void initState() {
    super.initState();
    print("widget.controller.text ${widget.controller.text}");
    controller.text = widget.controller.text;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        margin: EdgeInsets.all(20),
        padding: EdgeInsets.all(10),
        decoration: BoxDecoration(
            color: Colors.white, borderRadius: BorderRadius.circular(5)),
        child: Column(
          children: [
            Row(
              children: [
                IconButton(
                    icon: Icon(Icons.arrow_back),
                    onPressed: () {
                      Get.back();
                    }),
                Expanded(
                    child: Container(
                  height: 35,
                  child: TextFormField(
                    autofocus: true,
                    style: Theme.of(context).textTheme.headline2.copyWith(
                        fontSize: 18, fontWeight: FontWeight.w700, height: 1.2),
                    decoration: InputDecoration(
                      enabledBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                            color: AppThemes.lightinputBorderColor, width: 2.0),
                      ),
                      focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                            color: AppThemes.lightActiveInputBorder,
                            width: 2.0),
                      ),
                      contentPadding: EdgeInsets.only(bottom: 5),
                      suffixIcon: GestureDetector(
                        onTap: () {
                          setState(() {
                            controller.text = "";
                          });
                        },
                        child: Icon(Icons.close),
                      ),
                    ),
                    controller: controller,
                    onChanged: (String value) async {
                      searchPlaceModel = await PickUpDropInputBox.to
                          .getSuggestionLocations(value);
                      if (mounted) {
                        setState(() {});
                      }
                    },
                    keyboardType: widget.keyboardType,
                    obscureText: widget.obscureText,
                  ),
                )),
              ],
            ),
            Expanded(
              child: ListView.builder(
                itemCount: searchPlaceModel?.features?.length ?? 0,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () {
                      widget.onSuggestionSelected(
                          searchPlaceModel.features[index]);
                      Get.back();
                    },
                    child: ListTile(
                      title: Text(
                        searchPlaceModel.features[index].placeName,
                        style: Theme.of(context)
                            .textTheme
                            .bodyText2
                            .copyWith(fontSize: 15),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/**/
/*

TypeAheadField<Features>(
                    noItemsFoundBuilder: (context) => Container(),
                    textFieldConfiguration: TextFieldConfiguration(
                      controller: widget.controller,
                      onChanged: widget.onChanged,
                      keyboardType: widget.keyboardType,
                      obscureText: widget.obscureText,
                      focusNode: widget.focusNode,
                      style: Theme.of(context).textTheme.headline2.copyWith(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                          height: 1.2),
                      decoration: InputDecoration(
                        enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                              color: widget.disableBorderColor ??
                                  AppThemes.lightinputBorderColor,
                              width: 2.0),
                        ),
                        focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                              color: AppThemes.lightActiveInputBorder,
                              width: 2.0),
                        ),
                        contentPadding: EdgeInsets.only(bottom: 5),
                        suffixIcon: widget.iconSuffix,
                      ),
                    ),
                    suggestionsCallback: (pattern) async {
                      if (pattern == '') {
                        return [];
                      }
                      SearchPlaceModel searchPlaceModel =
                          await PickUpDropInputBox.to
                              .getSuggestionLocations(pattern);
                      print("features ${searchPlaceModel.features.length}");
                      return searchPlaceModel.features;
                    },
                    itemBuilder: (context, suggestion) {
                      return ListTile(
                        title: Text(
                          suggestion.placeName,
                          style: Theme.of(context)
                              .textTheme
                              .bodyText2
                              .copyWith(fontSize: 16),
                        ),
                      );
                    },
                    onSuggestionSelected: widget.onSuggestionSelected,
                  )
*/
