import 'package:driver/constants/constants.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ProfilePicture extends StatelessWidget {
  final double size;
  final String image;
  const ProfilePicture({this.size, @required this.image});
  static AuthController to = Get.find();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: size,
      width: size,
      decoration: BoxDecoration(
        border: Border.all(
            color: AppThemes.lightdeepPinkDropDownIconColor, width: 2),
        shape: BoxShape.circle,
      ),
      child: Container(
        margin: EdgeInsets.all(3),
        decoration: BoxDecoration(
          image: DecorationImage(
            image: image != null &&
                    image.trim() != Urls.imageBaseUrl &&
                    image.trim() != ''
                ? NetworkImage(
                    image,
                  )
                : AssetImage(
                    AllImages.adddp,
                  ),
          ),
          shape: BoxShape.circle,
        ),
      ),
    );
  }
}
