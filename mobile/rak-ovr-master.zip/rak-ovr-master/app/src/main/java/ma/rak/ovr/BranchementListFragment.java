package ma.rak.ovr;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.PopupMenu;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.HashMap;

import ma.rak.ovr.adapter.DemandesAdapter;
import ma.rak.ovr.storage.SharedPrefManager;
import ma.rak.ovr.ui.main.DemandViewModel;
import ma.rak.ovr.ui.main.MainActivity;

public class BranchementListFragment extends Fragment implements
        AdapterView.OnItemSelectedListener {

    public RecyclerView recyclerView;
    private SwipeRefreshLayout swipeContainer;
    private FrameLayout progressOverlay;
    private TabLayout tabLayout;
    private ArrayList<HashMap<String, String>> branchementsList = null;
    private ArrayList<HashMap<String, String>> abonnementList = null;

    String[] status = {"En instance", "Non Executee"};
    int archivePosition = 1;
    int spinnerPosition = 0;

    private TextView listTitle, notFoundMsg;
    private Spinner spinner;

    private DemandViewModel demandViewModel;
    TextView hamMenu;
    DemandesAdapter demandeAdapter = null;

    ArrayList<HashMap<String, String>> newBrResponse = null;
    ArrayList<HashMap<String, String>> newAbResponse = null;

    public static BranchementFragment newInstance() {
        return new BranchementFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_pending_list_list, container, false);
        listTitle = (TextView) rootView.findViewById(R.id.listTitle);
        tabLayout = (TabLayout) getActivity().findViewById(R.id.tab_layout);
        progressOverlay = rootView.findViewById(R.id.progress_overlay);
        progressOverlay.setVisibility(View.VISIBLE);
        spinner = (Spinner) rootView.findViewById(R.id.status_spinner);
        spinner.setOnItemSelectedListener(this);
        spinner.setVisibility(View.INVISIBLE);

        if(((MainActivity)getActivity()).showHisto){
            TabLayout.Tab tab = tabLayout.getTabAt(1);
            tab.select();
        }


        if (SharedPrefManager.getInstance(getActivity()).getMode() == 1) {

        } else {
            progressOverlay.setVisibility(View.VISIBLE);
        }

        recyclerView = rootView.findViewById(R.id.list);
        swipeContainer = rootView.findViewById(R.id.swipeContainer);
        swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                fetchData(archivePosition);
                swipeContainer.setRefreshing(false);
            }
        });
        swipeContainer.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light);

        ArrayAdapter aa = new ArrayAdapter(getActivity(), android.R.layout.simple_spinner_item, status);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        aa.notifyDataSetChanged();
        spinner.setAdapter(aa);

        return rootView;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        demandViewModel = ViewModelProviders.of(this).get(DemandViewModel.class);
        if (SharedPrefManager.getInstance(getActivity()).getMode() == 1) {
            demandViewModel.getBrachments(null, 1, getContext(), 0);
        } else {
            demandViewModel.getAbonnements(null, 0, getContext());
        }
        fetchData(archivePosition);
    }

    public void fetchData(int status) {
        progressOverlay.setVisibility(View.VISIBLE);
        demandeAdapter = new DemandesAdapter(getActivity(), branchementsList, abonnementList);

        if (SharedPrefManager.getInstance(getActivity()).getMode() == 1) {
            listTitle.setText(getString(R.string.listTitleBrIns));

            demandViewModel.getBrachments(null, 1, getActivity(), status);
            newBrResponse = new ArrayList<HashMap<String, String>>();
            demandViewModel.BrResponseMutableLiveData.observe(getActivity(), new Observer<ArrayList<HashMap<String, String>>>() {
                @Override
                public void onChanged(ArrayList<HashMap<String, String>> branchementResponse) {
                    newBrResponse = branchementResponse;
                    demandeAdapter.setList(branchementResponse, null);
                    tabLayout.getTabAt(0).setText("EN INSTANCE (" + branchementResponse.size() + ")");
                }

            });
            if (newBrResponse != null && newBrResponse != null) {
                tabLayout.getTabAt(0).setText("EN INSTANCE (" + newBrResponse.size() + ")");
            }


        } else {
            listTitle.setText(getString(R.string.listTitleAbIns));
            demandViewModel.getAbonnements(null, status, getContext());
            newAbResponse = new ArrayList<HashMap<String, String>>();
            demandViewModel.AbResponseMutableLiveData.observe(getActivity(), new Observer<ArrayList<HashMap<String, String>>>() {
                @Override
                public void onChanged(ArrayList<HashMap<String, String>> abonnementResponse) {
                    demandeAdapter.setList(null, abonnementResponse);
                    newAbResponse = abonnementResponse;
                    tabLayout.getTabAt(0).setText("EN INSTANCE (" + newAbResponse.size() + ")   ");
                }
            });
            if (newAbResponse != null && newAbResponse.size() > 0) {

                tabLayout.getTabAt(0).setText("EN INSTANCE (" + newAbResponse.size() + ")   ");
            }

        }
        progressOverlay.setVisibility(View.INVISIBLE);
        recyclerView.setAdapter(demandeAdapter);
    }

    //Performing action onItemSelected and onNothing selected
    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id) {

        spinnerPosition = position;
        if (position == 0) {
            archivePosition = 1;
        } else if (position == 1) {
            archivePosition = 4;
        }

        fetchData(archivePosition);
    }

    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }

}