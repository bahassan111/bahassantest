package ma.rak.ovr.models;

import io.realm.RealmObject;

public class Motif extends RealmObject {

    private int ID;
    private String label;
    private String codegera;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getLabel() {
        return label;
    }

    public String getCodegera() {
        return codegera;
    }

    public void setCodegera(String codegera) {
        this.codegera = codegera;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Motif(int ID, String label, String codegera) {
        this.ID = ID;
        this.label = label;
        this.codegera = codegera;
    }

    public Motif() {
    }

    @Override
    public String toString() {
        return "Motif{" +
                "ID=" + ID +
                ", label='" + label + '\'' +
                ", gerance='" + codegera + '\'' +
                '}';
    }
}
