import { UPDATE_DATA } from '../constants';

export function updateData(data) {
    return {
        type: UPDATE_DATA,
        payload: data
    }
}
