﻿using System;
using System.Collections.Generic;

namespace WebSocketsCmd.Meta
{
    public class TwTAG
    {
        
        
        
        
        
        public string Val;
        public int Length;
        public string Type;
        public Array SubTags;
        public string Name;

        public TwTAG(string type, int length, string val, Array childs)
        {
            this.Type = type;
            this.Val = val;
            this.SubTags = childs;
            this.Length = length;
            this.Name = TwParser.getTagName(type);


            if (this.Length < 0) this.Length = this.calcLength();
        }
        public TwTAG(string type, int length, string val)
        {
            this.Type = type;
            this.Val = val;
            this.SubTags = null;
            this.Length = length;

            this.Name = TwParser.getTagName(type);

            if (this.Length < 0) this.Length = this.calcLength();

        }



        private int calcLength()
        {
            var childs = "";
            if (this.SubTags != null && this.SubTags.Length > 0)
            {
                foreach (var child in this.SubTags)
                {
                    childs += child.ToString();
                }
            }


            return ( this.Val + childs).Length;
        }

        public override string ToString()
        {
            var childs = "";
            if (this.SubTags != null && this.SubTags.Length > 0)
            {
                foreach (var child in this.SubTags)
                {
                    childs += child.ToString();
                }
            }


            return this.Type + this.Length.ToString().PadLeft(4, '0') + this.Val + childs;
        }

        public string ToReadableString(string prepend)
        {
            var str = "TAG : " + this.Type +  "\r\n";

            str += prepend + "Name : " + this.Name + "\r\n";
            str += prepend + "Value : " + this.Val + "\r\n";

            if (this.SubTags != null && this.SubTags.Length > 0)
            {
                str += prepend + "Sub Tags : \r\n";

                foreach(TwTAG child in this.SubTags){
                    str += prepend + "\t\t" + child.ToReadableString(prepend + "\t\t");
                }
            }

           return str + prepend + "_______________________________________________" + "\r\n";
        }

        public string HumainReadable()
        {
            var childs = "";
            if (this.SubTags != null && this.SubTags.Length > 0)
            {
                foreach (TwTAG child in this.SubTags)
                {
                    childs += child.HumainReadable();
                } 
            }


            var str = String.Format("{0}  : ({1})`{2}` \r\n\t{3}", this.Name, (this.Length + " Octet"), this.Val, childs);

            
            
            return str;
        }
    }
    
    
}