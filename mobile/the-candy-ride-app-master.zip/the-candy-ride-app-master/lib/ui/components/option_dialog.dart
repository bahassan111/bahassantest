import 'package:flutter/material.dart';
import 'package:rider_app/ui/components/components.dart';
import 'package:get/get.dart';

class OptionDialog extends StatelessWidget {
  const OptionDialog(
      {Key key, this.message, this.title, this.onOkay, this.onCancel})
      : super(key: key);
  final String title;
  final String message;
  final Function onOkay;
  final Function onCancel;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(title,
          style: Theme.of(context).textTheme.headline2.copyWith(fontSize: 18)),
      content: Text(message,
          style: Theme.of(context).textTheme.headline2.copyWith(fontSize: 16)),
      actions: [
        Align(
          alignment: Alignment.center,
          child: Container(
            padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
            width: 100,
            child: RoundButton(
              onTap: onCancel,
              text: "cancel".tr,
            ),
          ),
        ),
        Align(
          alignment: Alignment.center,
          child: Container(
            padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
            width: 100,
            child: RoundButton(
              onTap: onOkay,
              text: "yes".tr,
            ),
          ),
        )
      ],
    );
  }
}
