import 'package:driver/controllers/controllers.dart';
import 'package:driver/ui/components/components.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class YourBankDetails extends StatefulWidget {
  @override
  _YourBankDetailsState createState() => _YourBankDetailsState();
}

class _YourBankDetailsState extends State<YourBankDetails> {
  final AuthController authController = AuthController.to;

  @override
  void initState() {
    super.initState();
    if (authController.userModel != null) {
      authController.bankNameController.text =
          authController.userModel.bankname;
      authController.accountNumberController.text =
          authController.userModel.accountno;
      authController.accoutNameController.text =
          authController.userModel.accountname;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 15),
      child: Column(
        children: [
          SizedBox(
            height: 30,
          ),
          Text(
            "your_bank_details".tr,
            style: Theme.of(context).textTheme.headline2.copyWith(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
          ),
          SizedBox(
            height: 10,
          ),
          FormInputField(
            labelText: "bank_name".tr,
            controller: authController.bankNameController,
          ),
          SizedBox(
            height: 10,
          ),
          FormInputField(
            labelText: "accout_name".tr,
            controller: authController.accoutNameController,
          ),
          SizedBox(
            height: 10,
          ),
          FormInputField(
            labelText: "account_number".tr,
            controller: authController.accountNumberController,
          ),
        ],
      ),
    );
  }
}
