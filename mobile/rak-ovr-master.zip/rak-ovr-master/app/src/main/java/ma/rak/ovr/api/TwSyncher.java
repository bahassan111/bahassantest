package ma.rak.ovr.api;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import ma.rak.ovr.bodyResponse.AgentsResponse;
import ma.rak.ovr.bodyResponse.ReclamationResponse;
import ma.rak.ovr.bodyResponse.SettingsResponse;
import ma.rak.ovr.models.Agent;
import ma.rak.ovr.models.Reclamation;
import ma.rak.ovr.models.Resultat;
import ma.rak.ovr.storage.SharedPrefManager;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TwSyncher {

    public static void init(Context ctx, Runnable onStep, Runnable onSuccess, Runnable onFailed, int index){

        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);
        SQLiteDatabase db = dbh.getWritableDatabase();



        if(index == 0){
            InitAgents(ctx, db, new Runnable() {
                @Override
                public void run() {
                    onStep.run();
                    init(ctx, onStep, onSuccess, onFailed, index+1);
                }
            }, new Runnable() {
                @Override
                public void run() {
                    onFailed.run();
                }
            });



        }else if(index == 1){
            InitSettings(ctx, db, new Runnable() {
                @Override
                public void run() {
                    onStep.run();
                    init(ctx, onStep, onSuccess, onFailed, index+1);
                }
            }, new Runnable() {
                @Override
                public void run() {
                    onFailed.run();
                }
            });
        }else if(index == 2){
            InitReclamations(ctx, db, new Runnable() {
                @Override
                public void run() {
                    onStep.run();
                    init(ctx, onStep, onSuccess, onFailed, index+1);
                }
            }, new Runnable() {
                @Override
                public void run() {
                    onFailed.run();
                }
            });
        }else{

            onSuccess.run();
        }





    }

    public static boolean isAgentsInit(Context ctx){
        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);
        return dbh.query(TwDatabase.ALLAgents.TABLE_NAME, null, null, null).size() > 0;
    }

    public static boolean isSettingsInit(Context ctx){
        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);
        return dbh.query(TwDatabase.Results.TABLE_NAME, null, null, null).size() > 0;
    }

    public static boolean isReclamationsInit(Context ctx){
        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);
        ArrayList array = dbh.query(TwDatabase.Demandes.TABLE_NAME, null, null, null);
        return array.size() > 1;
    }

    public static void InitAgents(Context ctx, SQLiteDatabase db, Runnable onSuccess, Runnable onFail){

        if(isAgentsInit(ctx)){
            onSuccess.run();
            return;
        }

        Log.e("xxxxxxxxxx", SharedPrefManager.getInstance(ctx).getToken());

        Call<AgentsResponse> call = RetrofitClient.getApi(SharedPrefManager.getInstance(ctx).getToken()).agents();

        call.enqueue(new Callback<AgentsResponse>() {
            @Override
            public void onResponse(Call<AgentsResponse> call, Response<AgentsResponse> response) {

                if(response.code() != 200){
                    onFail.run();
                    return;
                }

                for (Agent agent : response.body().getAgents()) {
                    ContentValues values = new ContentValues();
                    values.put(TwDatabase.ALLAgents.COL_KEY, agent.getCODEUTIL());
                    values.put(TwDatabase.ALLAgents.COL_LABEL, agent.getNOM_UTIL());
                    values.put(TwDatabase.ALLAgents.COL_TYPE, agent.getCODEPROF());
                    values.put(TwDatabase.ALLAgents.CODE_TSP, agent.getCODE_TSP());
                    values.put(TwDatabase.ALLAgents.COL_IMEI, agent.getIMEI());

                    long newRowId = db.insert(TwDatabase.ALLAgents.TABLE_NAME, null, values);
                    boolean inserted = newRowId > 0;
                }

                onSuccess.run();

            }

            @Override
            public void onFailure(Call<AgentsResponse> call, Throwable t) {
                onFail.run();
            }
        });

    }

    public static void InitSettings(Context ctx, SQLiteDatabase db, Runnable onSuccess, Runnable onFailed){

        if(isSettingsInit(ctx)){
            onSuccess.run();
            return;
        }

        Call<SettingsResponse> call = RetrofitClient.getApi(SharedPrefManager.getInstance(ctx).getToken()).settingsReclamation();

        call.enqueue(new Callback<SettingsResponse>() {
            @Override
            public void onResponse(Call<SettingsResponse> call, Response<SettingsResponse> response) {

                if(response.code() != 200){
                    onFailed.run();
                    return;
                }

                for (Resultat res : response.body().getResults()) {
                    ContentValues values = new ContentValues();
                    values.put(TwDatabase.Results.CODRESRE, res.getCODRESRE());
                    values.put(TwDatabase.Results.LIBRESRE, res.getLIBRESRE());
                    long newRowId = db.insert(TwDatabase.Results.TABLE_NAME, null, values);
                }



                onSuccess.run();

            }

            @Override
            public void onFailure(Call<SettingsResponse> call, Throwable t) {
                onFailed.run();
            }
        });

    }

    public static void InitReclamations(Context ctx, SQLiteDatabase db, Runnable onSuccess, Runnable onFailed){

        if(isReclamationsInit(ctx)){
            onSuccess.run();
            return;
        }

        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);

        Call<ReclamationResponse> call = RetrofitClient.getApi(SharedPrefManager.getInstance(ctx).getToken()).reclamations(1);

        call.enqueue(new Callback<ReclamationResponse>() {
            @Override
            public void onResponse(Call<ReclamationResponse> call, Response<ReclamationResponse> response) {

                if(response.code() != 200){
                    onFailed.run();
                    return;
                }

                for (Reclamation ab : response.body().getData()) {
                    dbh.insertReclamation(ab);
                }

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String currentDateandTime = sdf.format(new Date());
                SharedPrefManager.getInstance(ctx).setFetchTime(currentDateandTime);

                onSuccess.run();
            }

            @Override
            public void onFailure(Call<ReclamationResponse> call, Throwable t) {
                onFailed.run();
            }
        });
    }

    public static void getNewReclamation(Context ctx, SQLiteDatabase db, Runnable onSuccess, Runnable onFailed){

        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);

        String last_date = SharedPrefManager.getInstance(ctx).getFetchTime();
        if(last_date == null || last_date.equals("")){
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            last_date = sdf.format(new Date());
        }

        Call<ReclamationResponse> call = RetrofitClient.getApi(SharedPrefManager.getInstance(ctx).getToken()).new_reclamations(last_date);

        call.enqueue(new Callback<ReclamationResponse>() {
            @Override
            public void onResponse(Call<ReclamationResponse> call, Response<ReclamationResponse> response) {

                if(response.code() != 200){
                    onFailed.run();
                    return;
                }


                Toast.makeText(ctx, "Found new " + String.valueOf(response.body().getData().size()) + " new operations", Toast.LENGTH_LONG).show();

                for (Reclamation ab : response.body().getData()) {

                    boolean exists = dbh.query(TwDatabase.Demandes.TABLE_NAME, "NUMDOSRE = ?", new String[]{ab.getNUMDOSRE()}, null).size() > 0;

                    if(exists){
                        dbh.getWritableDatabase().delete(TwDatabase.Demandes.TABLE_NAME,"NUMDOSRE = ?", new String[]{ab.getNUMDOSRE()});
                    }

                    dbh.insertReclamation(ab);
                }

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String currentDateandTime = sdf.format(new Date());
                SharedPrefManager.getInstance(ctx).setFetchTime(currentDateandTime);

                onSuccess.run();
            }

            @Override
            public void onFailure(Call<ReclamationResponse> call, Throwable t) {
                onFailed.run();
            }
        });
    }

}
