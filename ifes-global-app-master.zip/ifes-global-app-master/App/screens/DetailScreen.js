import React, { Component } from "react";
import {
  View,
  Button,
  TouchableOpacity,
  Constants,
  AnimatableManager,
  Carousel,
  Modal,
  Text,
  TextInput,
} from "react-native-ui-lib";

import {
  StyleSheet,
  FlatList,
  ScrollView,
  ImageBackground,
  Share,
  Image,
  Platform,
  RefreshControl,
  Linking,
  AsyncStorage,
  Picker,
  Alert,
  Dimensions,
  PermissionsAndroid,
  ActivityIndicator,
} from "react-native";

import TextHelper from "../components/CustomText";

import * as Animatable from "react-native-animatable";

import { Google } from "expo-google-app-auth";
import { Audio, Video } from "expo-av";
import * as Camera from "expo-camera";

import Colors from "../constants/Colors";
import Icon from "../constants/Icons";
import environment, {
  appId,
  androidClientId,
  iosClientId,
} from "../constants/envirenement";

import { changeLanguage } from "../Redux/actions/FontSizeActions";
import {
  fetchGalleries,
  saveComment,
  fetchComment,
  deleteComment,
  getComment,
  postFile,
  saveInfo,
} from "../Redux/actions/ChapitresActions";

import { connect } from "react-redux";
import Config from "../constants/Config";
import I18n from "../commons/i18n";

import * as FileSystem from "expo-file-system";
import { ImagePicker } from "expo";

import ImageBrowser from "../../ImageBrowser";
import * as Facebook from "expo-facebook";
import * as Permissions from "expo-permissions";

import { SocialIcon } from "react-native-elements";

const { width: winWidth, height: winHeight } = Dimensions.get("window");
const images_ = {
  33: require("../assets/images/_33.png"),
  34: require("../assets/images/_1.png"),
  35: require("../assets/images/_2.png"),
  36: require("../assets/images/_2.png"),
  37: require("../assets/images/_1.png"),
  38: require("../assets/images/_33.png"),
  39: require("../assets/images/_2.png"),
  40: require("../assets/images/_1.png"),
};

class DetailScreen extends Component {
  camera = null;

  state = {
    dataSource: {},
    chapitre: {},
    isPortrait: true,
    toggle: false,
    imageuri: "",
    ModalVisibleStatus: false,
    currentPage: 0,
    label: I18n.t("Commons.see_more", { locale: this.props.lang }),
    info: "",
    userID: "",
    userName: "",
    userEmail: "",
    userImage: "",
    textComment: "",
    dataComments: [],
    actions: "",
    dataComment: [],
    commentId: "",
    dynamicIndex: 0,
    arr: "",
    scroll_x: "",
    scroll_y: "",

    hasCameraPermission: null,
    imageBrowserOpen: false,
    images: [],
    allPhotos: [],
    allPhotosImages: [],
    showCamera: false,
    images64: [],
    images64Gallerie: [],
    images64Camera: [],
    imagePath: [],

    dataFile64: [],
    imageCommentModal: "",
    modalVisibleComment: false,
    dataCommentImage: "",
    textCancelComment: "",
    isLoadingComment: false,
    rowsRecentComment_: 0,
    offsetNext: 0,
    dataCommentMore: [],
    viewCommentMore: [],
    fetchDataComments: [],
    isLoadingMoreComment: false,
    isLoadingTaperComment: false,

    //ACHRAF
    type: Camera.Constants.Type.front,
    recording: false,
    duration: 0,
    redirect: false,
    picVideo: "",
    videoRecord: "",
    videoGallery: "",
    showVideoModal: "",

    idVideo: "",
    videoPath: "",
    switchValue: false,
    showCameraVideo: false,
    ModalVisibleCameraVideo: false,
    ModalVisibleRecordingVideo: false,

    showCloseVideo: false,
    isStatusCamera: true,
    isStatusVideo: true,

    timer: 1,
    timerRecording: 0,
    see_more: "",
    see_less: "",
    rtl: "",
  };

  static navigationOptions = ({ navigation }) => {
    const { params = {} } = navigation.state;
    return {
      headerRight: (
        <TouchableOpacity onPress={() => navigation.navigate("Account")}>
          <Image
            borderRadius={50}
            style={{
              height: 30,
              width: 30,
              paddingHorizontal: 10,
              marginHorizontal: 10,
            }}
            source={{
              uri: params.showPicture ? params.showPicture : "",
            }}
          />
        </TouchableOpacity>
      ),
    };
  };

  async componentDidMount() {
    AsyncStorage.multiGet(["id", "name", "email", "image"]).then((data) => {
      let id = data[0][1];
      let name = data[1][1];
      let email = data[2][1];
      let image = data[3][1];

      const { showPicture } = this.state;
      // Assuming you have access to the navigation props
      this.props.navigation.setParams({
        showPicture: image,
      });
      this.setState({ showPicture: image });

      this.setState({
        userID: id,
        userName: name,
        userEmail: email,
        userImage: image,
      });

      console.log(this.state.userID + " " + this.state.userName, "ha detailss");
    });

    let see_more = await AsyncStorage.getItem("see_more");
    let see_less = await AsyncStorage.getItem("see_less");
    let rtl = await AsyncStorage.getItem("rtl");
    await this.setState({ see_more: see_more, see_less: see_less, rtl: rtl });

    const checkPermission = async () => {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE
      );

      if (granted === PermissionsAndroid.RESULTS.GRANTED) return true;
      return false;
    };

    await Permissions.askAsync(Permissions.CAMERA);
    const { status } = await Permissions.askAsync(Permissions.CAMERA_ROLL);
    this.setState({ hasCameraPermission: status === "granted" });

    //recording Video
    const { audioStatus } = await Permissions.askAsync(
      Permissions.AUDIO_RECORDING
    );

    var test = "";
    var that = this;
    const { navigation } = this.props;
    const chapitre = navigation.getParam("chapitre", {});
    console.log("detail chapitre", chapitre);
    that.setState({ chapitre });
    this.fetchData();
    let lang = await AsyncStorage.getItem("lang");
    let count_languages = await AsyncStorage.getItem("count_languages");
    navigation.setParams({
      changeLanguage: this._changeLanguage,
      lang: count_languages > 1 ? lang : "",
    });
    Audio.setAudioModeAsync({
      allowsRecordingIOS: false,
      interruptionModeIOS: Audio.INTERRUPTION_MODE_IOS_DO_NOT_MIX,
      playsInSilentModeIOS: true,
      shouldDuckAndroid: true,
      interruptionModeAndroid: Audio.INTERRUPTION_MODE_ANDROID_DO_NOT_MIX,
      playThroughEarpieceAndroid: false,
    });

    this.fetchComments_();
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.lang !== this.props.lang) {
      this.fetchData();
      this.props.navigation.setParams({
        changeLanguage: this._changeLanguage,
        lang: I18n.t("Commons.lang", { locale: this.props.lang }),
      });
    }
    if (prevProps.data !== this.props.data) {
      this.getData();
    }
  }

  fetchData() {
    const { navigation } = this.props;
    const chapitre = navigation.getParam("chapitre", {});
    this.props.fetchGalleries(chapitre.id);
    this.props.fetchComment(chapitre.id);
  }

  getData() {
    const { data } = this.props;
    this.setState({
      dataSource: data,
    });
  }

  _changeLanguage = async () => {
    let id_country = await AsyncStorage.getItem("id_country");
    let lang_index = await AsyncStorage.getItem("lang_index");
    let rtl = await AsyncStorage.getItem("rtl");
    let lang = await AsyncStorage.getItem("lang");
    let lang_index2 = await AsyncStorage.getItem("lang_index2");
    let rtl2 = await AsyncStorage.getItem("rtl2");
    let lang2 = await AsyncStorage.getItem("lang2");
    let lang_header = "";
    this.props.changeLanguage();
    const { navigation } = this.props;
    //navigation.navigate('SousChapitre');
    navigation.goBack(null);
    const chapitre = navigation.getParam("chapitre", {});

    this.changeFields(id_country, lang_index2);

    console.log("index_");
    console.log(lang_index);
    console.log(lang_index2);

    await AsyncStorage.setItem("lang_index", lang_index2);
    await AsyncStorage.setItem("rtl", rtl2);
    await AsyncStorage.setItem("lang", lang2);
    await AsyncStorage.setItem("lang_index2", lang_index);
    await AsyncStorage.setItem("rtl2", rtl);
    await AsyncStorage.setItem("lang2", lang);
    lang_header = lang2;

    this.props.navigation.setParams({
      changeLanguage: this._changeLanguage,
      lang: lang_header,
    });
    await this.setState({ rtl: rtl2 });

    this.props.fetchGalleries(chapitre.id);
  };

  changeFields(id_country, lang_index) {
    fetch("http://ifes-esll.com/new/api/includes/encode/index.php", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        post: "change_lang",
        id_country: id_country,
        lang_index: lang_index,
      }),
    })
      .then((res) => res.json())
      .then((responseJson) => {
        console.log("data fields");
        console.log(responseJson);
        AsyncStorage.setItem("fields", JSON.stringify(responseJson.fields));
        AsyncStorage.setItem("see_more", responseJson.see_more);
        AsyncStorage.setItem("search", responseJson.search);
        AsyncStorage.setItem("see_less", responseJson.see_less);
        AsyncStorage.setItem("homeScreen", responseJson.homeScreen);
        AsyncStorage.setItem("settingScreen", responseJson.settingScreen);
        AsyncStorage.setItem("countries", responseJson.countries);
        AsyncStorage.setItem("change_country", responseJson.change_country);

        this.setState({ see_more: responseJson.see_more });
        this.props.navigation.state.params.refresh();
      })
      .catch((error) => {
        console.log("error", error);
      });
  }

  _onRefresh = async () => {
    const { navigation } = this.props;
    const chapitre = navigation.getParam("chapitre", {});
    console.log("chapitre on refresh", chapitre);
    this.props.fetchGalleries(chapitre.id);
    this.props.fetchComment(chapitre.id);
  };

  keyExtractor = (item) => item.id;

  /*Login if Not*/
  _handleGoogleLogin = async () => {
    try {
      const result = await Google.logInAsync({
        androidClientId: androidClientId,
        iosClientId: iosClientId,
        scopes: ["profile", "email"],
      });
      if (result.type === "success") {
        if (result.user) {
          let id = result.user.id;
          let name = result.user.name;
          let email = result.user.email;
          let image = result.user.photoUrl;
          let type_login = "google";

          if (id) {
            this.props.saveInfo(id, name, email, image, type_login);

            AsyncStorage.multiSet([
              ["id", id],
              ["name", name],
              ["email", email],
              ["image", image],
            ]);

            this.setState({
              userID: id,
              userName: name,
              userEmail: email,
              userImage: image,
            });
          }

          return result.accessToken;
        }
      } else {
        console.log("Cancelled!", "Login was cancelled!");
        return { cancelled: true };
      }
    } catch (e) {
      console.log("Oops!", "Login failed!");
      return { error: true };
    }
  };

  async logIn() {
    try {
      const {
        type,
        token,
        expires,
        permissions,
        declinedPermissions,
      } = await Facebook.logInWithReadPermissionsAsync("454703512093640", {
        permissions: ["public_profile", "email"],
        behavior: "web",
      });
      if (type === "success") {
        // Get the user's name using Facebook's Graph API
        const response = await fetch(
          `https://graph.facebook.com/me?access_token=${token}&fields=id,name,email,picture.type(large)`
        );
        const userInfo = await response.json();
        this.setState({ userInfo });

        if (this.state.userInfo) {
          let id = this.state.userInfo.id;
          let name = this.state.userInfo.name;
          let email = this.state.userInfo.email;
          let image = this.state.userInfo.picture.data.url;
          let type_login = "fb";

          console.log("goood__=> ", id, name);
          if (id) {
            this.props.saveInfo(id, name, email, image, type_login);

            AsyncStorage.multiSet([
              ["id", id],
              ["name", name],
              ["email", email],
              ["image", image],
            ]);

            this.setState({
              userID: id,
              userName: name,
              userEmail: email,
              userImage: image,
            });

            console.log("goood=> mzyan ", id, name);
          }
        }
        console.log("Logged in!", `Hi ${(await response.json()).name}!`);
      } else {
        // type === 'cancel'
      }
    } catch ({ message }) {
      //alert(`Facebook Login Error: ${message}`);
      console.log(`Facebook Login Error: ${message}`);
    }
  }
  /*Login if Not*/

  imageComment(item, i) {
    const imageAnimationProps = AnimatableManager.getRandomDelay();
    const fileName = Config.API_IMAGE_COMMENT + item;

    return (
      <TouchableOpacity
        key={i}
        onPress={() => {
          this.ShowModalFunctionComment(true, fileName);
        }}
      >
        <Image
          key={i}
          style={styles.imageCss}
          source={{
            uri: fileName,
          }}
          {...imageAnimationProps}
        />
      </TouchableOpacity>
    );
  }

  videoComment(item) {
    const imageAnimationProps = AnimatableManager.getRandomDelay();
    const fileName = Config.API_VIDEO_COMMENT + item;

    console.log("item===", fileName);

    return (
      <TouchableOpacity
        onPress={() => {
          this.ShowModalRecordingVideo(true, fileName);
        }}
      >
        <Video
          source={{ uri: fileName }}
          rate={1.0}
          volume={1.0}
          isMuted={false}
          resizeMode="cover"
          style={styles.imageCss}
        />
      </TouchableOpacity>
    );
  }

  ShowModalFunction(visible, imageURL) {
    //handler to handle the click on image of Grid
    //and close button on modal
    console.log("teste", visible, imageURL);
    this.setState({
      ModalVisibleRecordingVideo: false,
      ModalVisibleComment: false,
      ModalVisibleCameraVideo: false,
      ModalVisibleStatus: visible,
      imageuri: imageURL,
    });
  }

  ShowModalFunctionComment(visible, imageURL) {
    console.log("testeComment", visible, imageURL);

    this.setState({ dataCommentImage: imageURL });

    console.log("__FFF__", this.state.dataCommentImage);

    this.setState({
      ModalVisibleRecordingVideo: false,
      ModalVisibleStatus: false,
      ModalVisibleCameraVideo: false,
      ModalVisibleComment: visible,
      imageuri: imageURL,
    });
  }

  ShowModalCameraVideo(visible) {
    this.setState({ processing: false, showCloseVideo: false });
    console.log("ShowModalCameraVideo", visible);

    this.setState({
      ModalVisibleRecordingVideo: false,
      ModalVisibleStatus: false,
      ModalVisibleComment: false,
      ModalVisibleCameraVideo: visible,
    });
  }

  ShowModalRecordingVideo(visible, filename) {
    this.setState({
      showVideoModal: filename,
      ModalVisibleStatus: false,
      ModalVisibleComment: false,
      ModalVisibleCameraVideo: false,
      ModalVisibleRecordingVideo: visible,
    });

    console.log("ShowModalRecordingVideo_==", this.state.showVideoModal);
  }

  closeScreen() {
    this.ShowModalFunction(!this.state.ModalVisibleStatus, "");
  }
  closeScreenComment() {
    // this.ShowModalFunction(!this.state.ModalVisibleComment, "");
    this.setState({ ModalVisibleComment: false });
    console.log("state ModalVisibleComment", this.state.ModalVisibleComment);
  }

  ShowHideText = () => {
    this.setState((state) => ({
      toggle: !state.toggle,
    }));
  };

  shareToTwitter() {
    const linkToShare =
      "http://ifes-esll.com/new/pages/?id=" + this.state.chapitre.id;
    const title =
      this.props.lang == "fr"
        ? this.state.chapitre.titre_fr
        : this.state.chapitre.titre_ar;
    Share.share(
      {
        ...Platform.select({
          ios: {
            message: title,
            url: linkToShare,
          },
          android: {
            message: title + " : \n" + linkToShare,
          },
        }),
        title: title,
      },
      {
        ...Platform.select({
          ios: {
            // iOS only:
            // excludedActivityTypes: ["com.apple.UIKit.activity.PostToTwitter"]
          },
          android: {
            // Android only:
            dialogTitle: "Share : " + title,
          },
        }),
      }
    );
  }

  shareToWhatsapp() {
    const linkToShare =
      "http://ifes-esll.com/new/pages/?id=" + this.state.chapitre.id;
    Linking.openURL(`whatsapp://send?text=${linkToShare}`);
  }

  onChangePage(index) {
    this.setState({ currentPage: index });
  }
  saveTodevice() {
    FileSystem.downloadAsync(
      "https://s3.amazonaws.com/dancebook-development/mov.mp4",
      FileSystem.documentDirectory + "TEST.mp4"
    )
      .then(({ uri }) => {
        console.log("uri is ::", uri);
        self.setState({ video: uri, showVideo: true });
        console.log("Finished downloading to ", uri);
      })
      .catch((error) => {
        console.error(error);
      });
  }

  async actionsComment(value, index) {
    let user_id = this.state.userID,
      chapitre_id = this.state.chapitre.id;

    if (value === "delete") {
      Alert.alert(
        I18n.t("Commons.title_delete", { locale: this.props.lang }),
        I18n.t("Commons.delete_comment", { locale: this.props.lang }),
        [
          {
            text: I18n.t("Commons.cancel", { locale: this.props.lang }),
            onPress: () => console.log("Cancel Pressed"),
            style: "cancel",
          },
          {
            text: I18n.t("Commons.ok", { locale: this.props.lang }),
            onPress: () => {
              this.deleteComment(user_id, index);
              //this.props.deleteComment(user_id,index);
              //this.props.fetchComment(chapitre_id);
            },
          },
        ],
        { cancelable: false }
      );
    }

    if (value == "edit") {
      this.scrollview_ref.scrollTo({
        x: this.state.scroll_x,
        y: this.state.scroll_y,
        animated: true,
      });

      this.setState({ videoPath: "" });
      this.setState({ textComment: "" });
      this.setState({ isLoadingTaperComment: true });
      this.setState({ imagePath: [] });
      this.setState({ allPhotos: [] });
      this.setState({ images: [] });
      this.setState({ images: [] });

      let rep = await fetch(
        Config.API_URL +
          "includes/encode/index.php/?get=getComment&user_id=" +
          user_id +
          "&comment_id=" +
          index
      );
      let data_rep = await rep.json();

      this.setState({ textComment: data_rep.comment });
      this.setState({ commentId: data_rep.id });
      this.setState({
        textCancelComment: I18n.t("Commons.CancelComment", {
          locale: this.props.lang,
        }),
      });

      console.log("data_rep", data_rep);
      console.log("reps", rep);

      data_rep.commentImage.map((item, i) =>
        this.setState({
          imagePath: [...this.state.imagePath, item],
        })
      );

      this.setState({ actionsSelect: "" });
      this.setState({
        videoPath: data_rep.commentVideo,
      });

      if (this.state.videoPath)
        this.setState({ isStatusCamera: false, isStatusVideo: true });
      else if (this.state.imagePath.length > 0)
        this.setState({ isStatusCamera: true, isStatusVideo: false });
      else this.setState({ isStatusCamera: true, isStatusVideo: true });

      this.setState({ isLoadingTaperComment: false });
    }
  }

  deleteComment(userId, index) {
    fetch(
      "http://ifes-esll.com/new/api/includes/encode/index.php/?get=deleteComment&user_id=" +
        userId +
        "&comment_id=" +
        index
    )
      .then((res) => res.json())
      .then((responseJson) => {
        this.fetchComments_(index);
        console.log("DeleteComment", responseJson);
      })
      .catch((error) => {
        console.log("error", error);
      });
  }

  startRecording_ = async () => {
    this.setState({ recording: true });

    /*setInterval(() =>
                this.setState({timerRecording : this.state.timerRecording  + 1})
            , 1000);

        console.log(this.state.timer ,'timer');

        if(this.state.timer >= 30){
            this.stopRecording_.bind(this)
        }*/

    // default to mp4 for android as codec is not set
    const { uri, codec = "mp4" } = await this.camera.recordAsync({
      ratio: "4:3",
      quality: 1,
      maxDuration: 30,
    });
    this.setState({ recording: false, processing: true });
    const type = `video/${codec}`;

    console.log("URIgoooop____", uri);
    console.log("URIgoooop____type", type);

    const data = new FormData();

    data.append("videos", {
      name: "video",
      type,
      uri,
    });

    this.setState({ videoRecord: uri });

    this.sendFile(data);
  };

  sendFile = async (data) => {
    //SI on edit clique pour add video video empty videoPath
    this.setState({ videoPath: "" });

    try {
      console.log("----goooop----");
      console.log(data);
      console.log("----goooop----");

      return await fetch(Config.API_URL + "includes/encode/index.php", {
        method: "post",
        body: data,
        headers: {
          Accept: "application/json",
          "content-type": "multipart/form-data",
        },
      })
        .then((res) => res.json())
        .then((responseJson) => {
          this.setState({ isStatusCamera: false, isStatusVideo: true });
          this.setState({ isLoadingTaperComment: false });
          this.setState({ processing: false });
          this.ShowModalCameraVideo(false);
          this.setState({ idVideo: responseJson.id_file });
          console.log("Good new ", responseJson);
        })
        .catch((error) => {
          console.log("error save recording ", error);
          console.log(error);
          console.log("error save recording ", error);

          this.setState({ videoRecord: "", isLoadingTaperComment: false });

          Alert.alert(
            I18n.t("Commons.error", { locale: this.props.lang }),
            I18n.t("Commons.error_after", { locale: this.props.lang }),
            [
              {
                text: I18n.t("Commons.daccord", { locale: this.props.lang }),
                onPress: () => console.log(error),
                style: "cancel",
              },
            ],
            { cancelable: false }
          );

          this.ShowModalCameraVideo(false);
          this.setState({ processing: false });
        });
    } catch (e) {
      console.error(e);
      console.log("error000");

      this.setState({ processing: false });
      this.ShowModalCameraVideo(false);
    }
  };

  stopRecording_() {
    this.camera.stopRecording();
    this.setState({ showCameraVideo: false, showCloseVideo: true });
    this.setState({ isLoadingTaperComment: true });
    this.ShowModalCameraVideo(false);

    console.log("stoooop");
  }

  /*Mounir*/
  fetchComments_() {
    var chapitre_id = this.state.chapitre.id;

    this.setState({ isLoadingComment: true });

    fetch(
      "http://ifes-esll.com/new/api/includes/encode/index.php/?get=fetchComments&chapitreId=" +
        chapitre_id
    )
      .then((res) => res.json())
      .then((responseJson) => {
        console.log("fetchComments_", responseJson);

        this.setState({
          fetchDataComments: responseJson.dataComments,
          rowsRecentComment_: responseJson.rowsRecentComment,
          offsetNext: responseJson.offsetNext,
        });

        this.setState({ isLoadingComment: false });
      })
      .catch((error) => {
        console.log("error", error);
      });
  }

  loadMoreComment = async () => {
    let chapitre_id = this.state.chapitre.id,
      offsetNext = this.state.offsetNext,
      dataFetchComment = "";

    this.setState({ rowsRecentComment_: 0, isLoadingMoreComment: true });

    await fetch(Config.API_URL + "includes/encode/index.php", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        post: "loadMoreComment",
        chapitre_id: chapitre_id,
        limit_comment: 5,
        offset_comment: offsetNext + 5,
      }),
    })
      .then((res) => res.json())
      .then((responseJson) => {
        this.setState({
          dataCommentMore: responseJson.dataComments,
          rowsRecentComment_: responseJson.rowsRecentComment,
          offsetNext: responseJson.offsetNext,
        });

        var newStateArray = this.state.viewCommentMore.slice();
        newStateArray.push(this.fetch_MoreComment());
        this.setState({ viewCommentMore: newStateArray });

        this.setState({ isLoadingMoreComment: false });
      })
      .catch((error) => {
        console.log("error save FileXXX ", error);
      });
  };

  fetch_MoreComment() {
    var items = this.state.dataCommentMore.map((item, index) => {
      return (
        <View>
          <View style={styles.separator} />
          <View style={styles.container}>
            <TouchableOpacity onPress={() => {}}>
              <Image style={styles.image} source={{ uri: item.photo }} />
            </TouchableOpacity>
            <View style={styles.content}>
              <View style={styles.contentHeader}>
                <Text style={styles.name}>{item.name}</Text>
                <Text style={styles.time}>{item.date}</Text>
              </View>
              <Text
                style={{ paddingRight: 10, marginRight: 10 }}
                rkType="primary3 mediumLine"
              >
                {item.comment}
              </Text>

              {item.commentImage ? (
                <View
                  style={{
                    display: "flex",
                    flexDirection: "row",
                    paddingTop: 5,
                  }}
                >
                  <ScrollView horizontal={true}>
                    {item.commentImage.map((item2, i) =>
                      this.imageComment(item2, i)
                    )}
                  </ScrollView>
                </View>
              ) : (
                <View />
              )}

              {item.user_id === this.state.userID ? (
                <Picker
                  selectedValue={this.state.actions}
                  style={{
                    height: 50,
                    width: 100,
                    position: "absolute",
                    right: 0,
                    top: 5,
                    alignSelf: "stretch",
                  }}
                  onValueChange={(value, index) =>
                    this.actionsComment(value, item.id)
                  }
                >
                  <Picker.Item label="" value="" />
                  <Picker.Item
                    label={I18n.t("Commons.edit", { locale: this.props.lang })}
                    value="edit"
                  />
                  <Picker.Item
                    label={I18n.t("Commons.delete", {
                      locale: this.props.lang,
                    })}
                    value="delete"
                  />
                </Picker>
              ) : (
                <View />
              )}
            </View>
          </View>
        </View>
      );
    });

    return items;
  }
  /*Mounir*/

  //Image Achraf

  _pickVideo = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Videos,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    console.log("zzzz", result);
    let max_duration = 30;
    let duration;
    if (!result.cancelled) {
      duration = result.duration;
      duration = duration / 1000;

      if (duration <= max_duration) {
        this.setState({ videoRecord: result.uri });

        if (this.state.videoRecord) {
          this.setState({ isStatusVideo: true, isStatusCamera: false });

          const data = new FormData();
          const uri = result.uri;
          const type =
            "video/" + result.uri.substr(result.uri.lastIndexOf(".") + 1);

          console.log("extension", type);

          data.append("videos", {
            name: "video",
            type,
            uri,
          });

          console.log("datas", data);

          this.setState({ isLoadingTaperComment: true });

          this.sendFile(data);
        }
      } else alert(I18n.t("Commons.maxDuration", { locale: this.props.lang }));
    }

    console.log("zzzz____", this.state.videoRecord);
  };

  _getPhotoLibrary = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      allowsEditing: true,
      aspect: [4, 3],
    });
    if (!result.cancelled) {
      this.setState({ image: result.uri });
    }
    if (result.uri) {
      //this.save_file(result.uri);

      console.log("_getPhotoLibrary", result.uri);
      console.log("_getPhotoLibraryrrrrrr", r);
    }
  };

  fun_takePicture = async () => {
    await Permissions.askAsync(Permissions.CAMERA);
    const { cancelled, uri } = await ImagePicker.launchCameraAsync({
      allowsEditing: false,
    });

    if (uri) {
      this.setState({
        images: [...this.state.images, uri],
        isStatusVideo: false,
        isStatusCamera: true,
      });

      const ext = uri.substr(uri.lastIndexOf(".") + 1);
      console.log("extension", ext);
      this.convertToBase64(uri, "camera");
    }
    console.log("takePicture_", this.state.images);
  };

  imageBrowserCallback = (callback) => {
    callback
      .then((photos) => {
        console.log("imageBrowserCallback=>", photos);
        this.setState({
          imageBrowserOpen: false,
          photos,
        });

        this.setState({ images64Gallerie: [] });
        this.setState({ allPhotos: [] });

        photos.map((item, i) =>
          this.setState({ allPhotos: [...this.state.allPhotos, item.file] })
        );

        if (this.state.allPhotos.length)
          this.setState({ isStatusVideo: false, isStatusCamera: true });

        console.log("lll", this.state.allPhotos.length);

        photos.map((item, i) => this.convertToBase64(item.file, "gallerie"));
      })
      .catch((e) => console.log(e));
  };

  convertToBase64 = async (Photo, type) => {
    const blob = await new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.onload = () => {
        resolve(xhr.response);
      };
      xhr.onerror = () => {
        reject(new TypeError("Network request failed"));
      };
      xhr.responseType = "blob";
      xhr.open("GET", Photo, true);
      xhr.send(null);
    });

    let base64 = "";
    const reader = new FileReader();
    reader.readAsDataURL(blob);
    reader.onloadend = () => {
      const toString = reader.result.toString();
      base64 = toString.substring(toString.indexOf(",") + 1);

      if (type == "camera")
        this.setState({
          images64Camera: [...this.state.images64Camera, base64],
        });
      else if (type == "gallerie")
        this.setState({
          images64Gallerie: [...this.state.images64Gallerie, base64],
        });

      this.pressComment();
    };
  };

  removeImage64 = (e) => {
    var array = [...this.state.allPhotos];
    var index = array.indexOf(e.target.value);

    console.log("index", index);
    console.log("e.target", e);
    console.log("e.target.value", e.target.value);

    if (index !== -1) {
      //this.state.images64.splice(index, 1);
      console.log("Goood 0000", this.state.allPhotos);
    }

    /*
        if (index !== -1) {
            this.state.images64.splice(index, 1);
            console.log('==this.state.images64',this.state.images64);

        }
        */
  };
  removeImageAfter = async (e) => {
    var array = this.state.allPhotos;
    var index = array.indexOf(e); // Hnaya error

    console.log("array", array);
    console.log("index", index);
    console.log("e.target", e);

    if (index !== -1) {
      console.log("Goood 0000", this.state.allPhotos);
    }

    /*
        if (index !== -1) {
            this.state.images64.splice(index, 1);
            console.log('==this.state.images64',this.state.images64);

        }
        */
  };

  deleteImageInEdit(fileName) {
    if (fileName) {
      Alert.alert(
        I18n.t("Commons.title_delete", { locale: this.props.lang }),
        I18n.t("Commons.delete_file_img", { locale: this.props.lang }),
        [
          {
            text: I18n.t("Commons.cancel", { locale: this.props.lang }),
            onPress: () => console.log("Cancel Pressed"),
            style: "cancel",
          },
          {
            text: I18n.t("Commons.ok", { locale: this.props.lang }),
            onPress: () => {
              fetch(Config.API_URL + "includes/encode/index.php", {
                method: "POST",
                headers: {
                  Accept: "application/json",
                  "Content-Type": "application/json",
                },
                body: JSON.stringify({
                  post: "deleteImageComment",
                  user_id: this.state.userID,
                  commentID: this.state.commentId,
                  chapitre_id: this.state.chapitre.id,
                  fileName: fileName,
                }),
              })
                .then((res) => res.json())
                .then((responseJson) => {
                  this.setState({ imagePath: [] });
                  responseJson.map((item) =>
                    this.setState({
                      imagePath: [...this.state.imagePath, item],
                    })
                  );

                  this.fetchComments_(this.state.chapitre.id);

                  console.log("Good delete & fetch new Pictures", responseJson);
                })
                .catch((error) => {
                  console.log("error delete Img ", error);
                });
            },
          },
        ],
        { cancelable: false }
      );
    }
  }
  deleteVideoInEdit(fileName) {
    if (fileName) {
      Alert.alert(
        I18n.t("Commons.title_delete", { locale: this.props.lang }),
        I18n.t("Commons.delete_file_video", { locale: this.props.lang }),
        [
          {
            text: I18n.t("Commons.cancel", { locale: this.props.lang }),
            onPress: () => console.log("Cancel Pressed"),
            style: "cancel",
          },
          {
            text: I18n.t("Commons.ok", { locale: this.props.lang }),
            onPress: () => {
              fetch(Config.API_URL + "includes/encode/index.php", {
                method: "POST",
                headers: {
                  Accept: "application/json",
                  "Content-Type": "application/json",
                },
                body: JSON.stringify({
                  post: "deleteVideoComment",
                  user_id: this.state.userID,
                  commentID: this.state.commentId,
                  chapitre_id: this.state.chapitre.id,
                  fileName: fileName,
                }),
              })
                .then((res) => res.json())
                .then((responseJson) => {
                  this.setState({ videoPath: "" });
                  this.fetchComments_(this.state.chapitre.id);

                  console.log("Good delete & fetch new Videos", responseJson);
                })
                .catch((error) => {
                  console.log("error delete Video ", error);
                });
            },
          },
        ],
        { cancelable: false }
      );
    }
  }

  fetchImageComment(fileName, i) {
    console.log("wwwwwww", fileName);

    const fullPath = Config.API_IMAGE_COMMENT + fileName;

    return (
      <View flex column>
        <TouchableOpacity
          onPress={() => {
            this.ShowModalFunctionComment(true, fullPath);
          }}
        >
          <Image
            style={styles.imageCssClose}
            source={{ uri: fullPath }}
            key={i}
          />
        </TouchableOpacity>

        <TouchableOpacity
          style={{ position: "absolute", top: 0, left: -2, zIndex: 0 }}
          onPress={() => this.deleteImageInEdit(fileName)}
        >
          <Image
            style={{ width: 15, height: 15 }}
            source={require("../assets/images/cancel.png")}
          />
        </TouchableOpacity>
      </View>
    );
  }

  fetchVideoComment(fileName) {
    const fullPath = Config.API_VIDEO_COMMENT + fileName;

    console.log("fetchVideoComment___", fullPath);

    return (
      <View flex column>
        <TouchableOpacity
          onPress={() => {
            this.ShowModalRecordingVideo(true, fullPath);
          }}
        >
          <Video
            source={{ uri: fullPath }}
            rate={1.0}
            volume={1.0}
            isMuted={false}
            resizeMode="cover"
            style={styles.imageCssClose}
          />
        </TouchableOpacity>

        <TouchableOpacity
          style={{ position: "absolute", top: 0, left: -2, zIndex: 0 }}
          onPress={() => this.deleteVideoInEdit(fileName)}
        >
          <Image
            style={{ width: 15, height: 15 }}
            source={require("../assets/images/cancel.png")}
          />
        </TouchableOpacity>
      </View>
    );
  }

  //Fin Image Achraf

  handleLayoutChange() {
    this.positionCommente.measure((fx, fy, width, height, px, py) => {
      this.setState({ scroll_x: px, scroll_y: py });
    });
  }

  pressComment = () => {
    this.scrollview_ref.scrollTo({
      x: this.state.scroll_x,
      y: this.state.scroll_y,
      animated: true,
    });
  };

  _saveComment = async () => {
    let textComment = this.state.textComment,
      userID = this.state.userID,
      chapitre_id = this.state.chapitre.id,
      commentID = this.state.commentId;

    if (textComment !== "") {
      let countGallerie = this.state.images64Gallerie.length;
      let countCamera = this.state.images64Camera.length;
      let sumCount = countGallerie * 1 + countCamera * 1;

      if (sumCount > 5) {
        this.setState({
          images64Gallerie: [],
          images64Camera: [],
          images64: [],
          imagePath: [],
          allPhotos: [],
          images: [],
        });

        Alert.alert(
          I18n.t("Commons.title_take_picture", { locale: this.props.lang }),
          I18n.t("Commons.max_upload", { locale: this.props.lang }),
          [
            {
              text: I18n.t("Commons.cancel", { locale: this.props.lang }),
              onPress: () => console.log("Cancel Pressed"),
              style: "cancel",
            },
          ],
          { cancelable: false }
        );
      } else {
        this.setState({ isLoadingTaperComment: true });

        await fetch(Config.API_URL + "includes/encode/index.php", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            post: "saveComment",
            user_id: userID,
            comment: textComment,
            chapitre_id: chapitre_id,
            commentID: commentID,
            images64Gallerie: this.state.images64Gallerie,
            images64Camera: this.state.images64Camera,
            idVideo: this.state.idVideo,
          }),
        })
          .then((res) => res.json())
          .then((responseJson) => {
            this.setState({ textComment: "" });
            this.setState({ imagePath: [] });
            this.setState({ images64: [] });
            this.setState({ images64Gallerie: [] });
            this.setState({ images64Camera: [] });
            this.setState({ allPhotos: [] });
            this.setState({ images: [] });
            this.setState({ commentId: "" });
            this.setState({ idVideo: "" });
            this.setState({ videoRecord: "" });
            this.setState({ videoPath: "" });
            this.setState({ textCancelComment: "" });
            this.fetchComments_(chapitre_id);

            this.setState({ isStatusCamera: true, isStatusVideo: true });

            this.setState({ isLoadingTaperComment: false });
          })
          .catch((error) => {
            this.setState({ isStatusCamera: true, isStatusVideo: true });

            Alert.alert(
              I18n.t("Commons.error", { locale: this.props.lang }),
              I18n.t("Commons.error_after", { locale: this.props.lang }),
              [
                {
                  text: I18n.t("Commons.daccord", { locale: this.props.lang }),
                  onPress: () => console.log(error),
                  style: "cancel",
                },
              ],
              { cancelable: false }
            );

            console.log("error save FileXXX ", error);
          });
      }
    } else {
      Alert.alert(
        I18n.t("Commons.title_take_picture", { locale: this.props.lang }),
        I18n.t("Commons.remplir_comment", { locale: this.props.lang }),
        [
          {
            text: I18n.t("Commons.cancel", { locale: this.props.lang }),
            onPress: () => console.log("Cancel Pressed"),
            style: "cancel",
          },
        ],
        { cancelable: false }
      );
    }
  };

  emptyComment() {
    this.setState({ textComment: "" });
    this.setState({ imagePath: [] });
    this.setState({ images64: [] });
    this.setState({ images64Gallerie: [] });
    this.setState({ images64Camera: [] });
    this.setState({ photos: [] });
    this.setState({ allPhotos: [] });
    this.setState({ images: [] });
    this.setState({ commentId: "" });
    this.setState({ videoPath: "" });
    this.setState({ textCancelComment: "" });

    this.setState({ isStatusCamera: true, isStatusVideo: true });
  }

  cancelComment = () => {
    this.emptyComment();
  };

  cameraChange = () => {
    this.setState({
      type:
        this.state.type === Camera.Constants.Type.back
          ? Camera.Constants.Type.front
          : Camera.Constants.Type.back,
    });
  };

  checkRecordingExsit() {
    console.log("exxx", this.state.videoRecord);

    return this.state.videoRecord ? (
      <TouchableOpacity
        onPress={() => {
          this.ShowModalRecordingVideo(true, this.state.videoRecord);
        }}
      >
        <Image
          style={styles.imageCss1}
          source={{ uri: this.state.videoRecord }}
        />
      </TouchableOpacity>
    ) : (
      <View />
    );
  }

  takePicture = async () => {
    Alert.alert(
      I18n.t("Commons.title_take_picture", { locale: this.props.lang }),
      I18n.t("Commons.upload_picture", { locale: this.props.lang }),
      [
        {
          text: I18n.t("Commons.cancel", { locale: this.props.lang }),
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel",
        },

        {
          text: I18n.t("Commons.camera", { locale: this.props.lang }),
          onPress: () => {
            this.fun_takePicture();
          },
        },
        {
          text: I18n.t("Commons.gallery", { locale: this.props.lang }),
          onPress: () => {
            this.setState({ imageBrowserOpen: true });
          },
        },
      ],
      { cancelable: false }
    );
  };

  galleryPicture = async () => {
    Alert.alert(
      I18n.t("Commons.title_take_picture", { locale: this.props.lang }),
      I18n.t("Commons.upload_videos", { locale: this.props.lang }),
      [
        {
          text: I18n.t("Commons.cancel", { locale: this.props.lang }),
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel",
        },
        {
          text: I18n.t("Commons.camera", { locale: this.props.lang }),
          onPress: () => {
            this.ShowModalCameraVideo(true);
          },
        },
        {
          text: I18n.t("Commons.gallery", { locale: this.props.lang }),
          onPress: () => {
            this._pickVideo();
          },
        },
      ],
      { cancelable: false }
    );
  };

  renderRow(row, id) {
    const animationProps = AnimatableManager.presets.fadeInRight;
    const imageAnimationProps = AnimatableManager.getRandomDelay();
    const imageSlider = Config.SOUS_CHAPITRE_IMAGE + row.slider;

    return (
      <Animatable.View {...animationProps}>
        <View column marginH-3 marginV-2>
          <TouchableOpacity
            onPress={() => {
              this.ShowModalFunction(!this.state.ModalVisibleStatus, "");
            }}
          >
            <ImageBackground
              style={styles.imageThumbnail}
              source={{
                uri: imageSlider,
              }}
              {...imageAnimationProps}
            />
          </TouchableOpacity>
        </View>
      </Animatable.View>
    );
  }

  renderImage(item, i) {
    console.log("renderImage", item, i);

    return (
      <View flex column>
        <TouchableOpacity
          onPress={() => {
            this.ShowModalFunctionComment(true, item);
          }}
        >
          <Image style={styles.imageCss1} source={{ uri: item }} key={i} />
        </TouchableOpacity>
      </View>
    );
  }

  renderImageCapture(item, i) {
    console.log("renderImageCapture", item, i);

    return (
      <View flex column>
        <TouchableOpacity
          onPress={() => {
            this.ShowModalFunctionComment(true, item);
          }}
        >
          <Image style={styles.imageCss1} source={{ uri: item }} key={i} />
        </TouchableOpacity>
      </View>
    );
  }

  render() {
    const { navigation } = this.props;

    const chapitreData = navigation.getParam("chapitre", {});
    const videoUrl =
      this.props.lang == "ar"
        ? Config.SOUS_CHAPITRE_VIDEO + chapitreData.videoUrlAr
        : Config.SOUS_CHAPITRE_VIDEO + chapitreData.videoUrl;

    const COLOR = "#FFF";
    const icon = (name, size = 36) => () => (
      <Icon
        name={name}
        iconSize={size}
        color={COLOR}
        style={{ textAlign: "center" }}
      />
    );

    //Debut Achraf Images
    const { hasCameraPermission } = this.state;

    if (this.state.imageBrowserOpen) {
      return <ImageBrowser max={5} callback={this.imageBrowserCallback} />;
    }
    //Fin Achraf Images

    // Start Recording Video
    const { recording, processing } = this.state;
    let button = (
      <View row center style={styles.viewCamera}>
        <Button
          label={I18n.t("Commons.record", { locale: this.props.lang })}
          onPress={this.startRecording_.bind(this)}
          avoidMinWidth
          avoidInnerPadding
          bg-green20
          borderRadius={10}
          color={Colors.tabBar}
          style={styles.btnCamera}
        />
      </View>
    );

    if (recording) {
      button = (
        <View row center style={styles.viewCamera}>
          <Button
            label={I18n.t("Commons.stop", { locale: this.props.lang })}
            onPress={this.stopRecording_.bind(this)}
            avoidMinWidth
            avoidInnerPadding
            bg-green20
            borderRadius={10}
            color={Colors.tabBar}
            style={styles.btnCamera}
          />
        </View>
      );
    }

    if (processing) {
      button = (
        <View style={styles.viewCamera}>
          <ActivityIndicator
            size="large"
            color="#223968"
            style={{ flex: 1, justifyContent: "center", alignItems: "center" }}
          />
        </View>
      );
    }
    // Fin Recording Video

    return (
      <View flex paddingT-0 bg-white>
        {this.state.ModalVisibleStatus && (
          <Modal
            transparent={true}
            animationType={"fade"}
            visible={this.state.ModalVisibleStatus}
            onRequestClose={() => {
              this.ShowModalFunction(!this.state.ModalVisibleStatus, "");
            }}
          >
            <View flex>
              <Carousel
                loop
                onChangePage={(index) => this.onChangePage(index)}
                initialPage={1}
              >
                {this.props.data.map((item, i) => (
                  <Page flex bg-white center key={i}>
                    <View
                      style={{
                        ...StyleSheet.absoluteFillObject,
                        top: 30,
                        right: 20,
                        padding: 10,
                      }}
                      right
                    >
                      <TouchableOpacity onPress={() => this.closeScreen()}>
                        <Icon
                          name={"ion-close-round"}
                          iconSize={30}
                          color={Colors.tabBar}
                        />
                      </TouchableOpacity>
                    </View>
                    <Image
                      source={{
                        uri: Config.SOUS_CHAPITRE_IMAGE + item.slider,
                      }}
                      style={{ width: Constants.screenWidth, height: 400 }}
                    />
                  </Page>
                ))}
              </Carousel>
            </View>
          </Modal>
        )}

        {this.state.ModalVisibleComment && (
          <Modal
            // transparent={true}
            animationType={"fade"}
            visible={this.state.ModalVisibleComment}
            onRequestClose={() => {
              this.ShowModalFunctionComment(!this.state.ModalVisibleComment);
            }}
          >
            <View flex useSafeArea>
              <Page flex bg-white center>
                <View
                  style={{
                    ...StyleSheet.absoluteFillObject,
                    top: 0,
                    right: 20,
                    padding: 10,
                  }}
                  right
                >
                  <TouchableOpacity
                    onPress={() =>
                      this.setState({ ModalVisibleComment: false })
                    }
                  >
                    <Icon
                      name={"ion-close-round"}
                      iconSize={30}
                      color={Colors.tabBar}
                    />
                  </TouchableOpacity>
                </View>
                <Image
                  source={{
                    uri: this.state.dataCommentImage,
                  }}
                  style={{
                    width: "100%",
                    height: winHeight - 90,
                    resizeMode: "contain",
                  }}
                />
              </Page>
            </View>
          </Modal>
        )}

        {this.state.ModalVisibleCameraVideo && (
          <Modal
            transparent={true}
            animationType={"fade"}
            visible={this.state.ModalVisibleCameraVideo}
            onRequestClose={() => {
              this.ShowModalCameraVideo(
                !this.state.ModalVisibleCameraVideo,
                ""
              );
            }}
          >
            <View flex>
              <Page flex bg-white center>
                <View
                  style={{
                    ...StyleSheet.absoluteFillObject,
                    backgroundColor: "#000",
                  }}
                >
                  <View
                    right
                    style={{ paddingTop: 6, marginTop: 6, right: 14 }}
                  >
                    {!this.state.showCloseVideo ? (
                      <TouchableOpacity
                        onPress={() => this.ShowModalCameraVideo(false)}
                      >
                        <Icon
                          name={"ion-close-round"}
                          iconSize={22}
                          color={Colors.gray}
                        />
                      </TouchableOpacity>
                    ) : (
                      <TouchableOpacity>
                        <Icon
                          name={"ion-close-round"}
                          iconSize={28}
                          color={Colors.black}
                        />
                      </TouchableOpacity>
                    )}
                  </View>

                  <View left style={{ top: -34, left: 5 }}>
                    {!this.state.showCloseVideo ? (
                      <TouchableOpacity onPress={() => this.cameraChange()}>
                        <Image
                          source={require("../assets/images/photo.png")}
                          style={{
                            width: 55,
                            height: 55,
                          }}
                        />
                      </TouchableOpacity>
                    ) : (
                      <View />
                    )}
                  </View>
                </View>

                <View row>
                  <Camera
                    ref={(ref) => {
                      this.camera = ref;
                    }}
                    style={{ width: Constants.screenWidth, height: 450 }}
                    type={this.state.type}
                    autofocus={Camera.Constants.AutoFocus.on}
                    flashMode={Camera.Constants.FlashMode.off}
                    permissionDialogTitle={"Permission to use camera"}
                    permissionDialogMessage={
                      "We need your permission to use your camera phone"
                    }
                  />
                </View>

                {button}
              </Page>
            </View>
          </Modal>
        )}

        {this.state.ModalVisibleRecordingVideo && (
          <Modal
            // transparent={true}
            animationType={"fade"}
            visible={this.state.ModalVisibleRecordingVideo}
            onRequestClose={() => {
              this.ShowModalRecordingVideo(
                !this.state.ModalVisibleRecordingVideo
              );
            }}
          >
            <View flex useSafeArea>
              <Page flex bg-red center>
                <View
                  style={{
                    ...StyleSheet.absoluteFillObject,
                    top: 0,
                    right: 20,
                    padding: 10,
                  }}
                  right
                >
                  <TouchableOpacity
                    onPress={() => this.ShowModalRecordingVideo(false, "")}
                  >
                    <Icon
                      name={"ion-close-round"}
                      iconSize={30}
                      color={Colors.tabBar}
                    />
                  </TouchableOpacity>
                </View>

                <View column bg-red10>
                  <Video
                    source={{
                      uri: this.state.showVideoModal,
                    }}
                    rate={1.0}
                    volume={1.0}
                    isMuted={false}
                    resizeMode="cover"
                    shouldPlay
                    isLooping
                    style={{ width: Constants.screenWidth, height: 300 }}
                  />
                </View>
              </Page>
            </View>
          </Modal>
        )}

        <View row style={{ backgroundColor: "transparent" }}>
          <ImageBackground
            style={{ flex: 1, width: "100%", zIndex: 2 }}
            source={images_[chapitreData.chapitreId]}
          >
            <View
              padding-10
              paddingT-10
              right={this.state.rtl === 1}
              style={{
                flexDirection: this.state.rtl === 1 ? "row-reverse" : "row",
              }}
            >
              <Text
                centerV
                style={{
                  fontWeight: "700",
                  fontSize: 20,
                  color: "#fff",
                }}
              >
                {chapitreData.titre}
              </Text>
            </View>
          </ImageBackground>
        </View>

        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={this.props.isLoadingData}
              onRefresh={this._onRefresh}
            />
          }
          ref={(ref) => {
            this.scrollview_ref = ref;
          }}
        >
          <View padding-5 centerH>
            <FlatList
              data={this.props.data}
              keyExtractor={this.keyExtractor}
              renderItem={({ item, index }) => this.renderRow(item, index)}
              numColumns={4}
              keyExtractor={(item, index) => index}
            />
          </View>
          <View flex marginV-10>
            {/* <Video
              videoProps={{
                shouldPlay: true,
                resizeMode: Video.RESIZE_MODE_COVER,
                source: { uri: videoUrl },
                isMuted: false,
              }}
              isPortrait={true}
              playFromPositionMillis={0}
              switchToLandscape={() => null}
              switchToPortrait={() =>
                ScreenOrientation.allowAsync(
                  ScreenOrientation.Orientation.PORTRAIT
                )
              }
            /> */}
            <Video
              source={{
                uri: videoUrl,
              }}
              rate={1.0}
              volume={1.0}
              isMuted={false}
              resizeMode="cover"
              shouldPlay
              isLooping
              style={{ width: Constants.screenWidth, height: 300 }}
            />
          </View>
          <View column centerH>
            <Button
              label={
                !this.state.toggle ? this.state.see_more : this.state.see_less
              }
              labelStyle={{
                fontWeight: "600",
                fontSize: 15,
                fontFamily:
                  this.props.lang == "ar"
                    ? "ge-thameen-book"
                    : "bw-seido-round",
              }}
              iconSource={require("../assets/images/info.png")}
              iconStyle={{ tintColor: Colors.white, width: 25, height: 25 }}
              iconOnRight={this.props.lang == "ar"}
              size="medium"
              white
              marginH-40
              borderRadius={50}
              style={{
                height: 35,
                width: Constants.screenWidth - 50,
                marginBottom: 5,
                backgroundColor: Colors.greenLight,
              }}
              onPress={() => this.ShowHideText()}
            />
            {this.state.toggle && (
              <Animatable.View ref={this.handleViewRef} animation="fadeInUpBig">
                <TextHelper
                  marginT-20
                  marginH-30
                  ellipsizeMode="tail"
                  style={{
                    textAlign: this.props.lang == "ar" ? "right" : "left",
                  }}
                >
                  {chapitreData.description}
                </TextHelper>
              </Animatable.View>
            )}

            <Image
              source={require("../assets/images/partage.png")}
              style={{
                width: "100%",
                height: 50,
              }}
              resizeMode={"contain"}
            />
            <View row flex paddingB-20>
              <TouchableOpacity onPress={() => this.shareToTwitter()}>
                <Image
                  source={require("../assets/images/twitter.png")}
                  style={{
                    width: 60,
                    height: 60,
                    margin: 5,
                  }}
                />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => this.shareToTwitter()}>
                <Image
                  source={require("../assets/images/facebook.png")}
                  style={{
                    width: 60,
                    height: 60,
                    margin: 5,
                  }}
                />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => this.shareToWhatsapp()}>
                <Image
                  source={require("../assets/images/whatsapp.png")}
                  style={{
                    width: 60,
                    height: 60,
                    margin: 5,
                  }}
                />
              </TouchableOpacity>
            </View>
          </View>

          {this.state.userID ? (
            <View style={styles.commentSection}>
              {/*refreshControl={
                                    <RefreshControl
                                        refreshing={this.props.isLoadingdataComments}
                                    />
                                }*/}
              <View
                column
                marginB-10
                style={styles.textAreaContainer}
                onLayout={(event) => {
                  this.handleLayoutChange(event);
                }}
                ref={(view) => {
                  this.positionCommente = view;
                }}
              >
                <View
                  style={{
                    display: "flex",
                    flexDirection:
                      this.props.lang == "ar" ? "row-reverse" : "row",
                  }}
                >
                  <TouchableOpacity
                    onPress={() => navigation.navigate("Account")}
                  >
                    <Image
                      column
                      style={{
                        height: 30,
                        width: 30,
                        borderRadius: 15,
                        marginTop: 8,
                      }}
                      source={{ uri: this.state.userImage }}
                      resizeMode="cover"
                    />
                  </TouchableOpacity>
                  <Text
                    column
                    style={{
                      marginVertical: 13,
                      marginHorizontal: 10,
                      fontSize: 16,
                      fontWeight: "500",
                    }}
                  >
                    {this.state.userName}
                  </Text>
                </View>

                <TextInput
                  style={{
                    height: 60,
                    color: "#000",
                    textAlign: this.props.lang == "ar" ? "right" : "left",
                  }}
                  underlineColorAndroid="transparent"
                  placeholder={I18n.t("Commons.tapez_comment", {
                    locale: this.props.lang,
                  })}
                  placeholderTextColor="grey"
                  numberOfLines={10}
                  multiline={true}
                  onChangeText={(textComment) => this.setState({ textComment })}
                  onTouchStart={this.pressComment}
                  value={this.state.textComment}
                />

                <View style={styles.container0}>
                  <ScrollView
                    style={{
                      marginRight: this.props.lang == "ar" ? 0 : 10,
                      marginLeft: this.props.lang == "ar" ? 10 : 0,
                      paddingBottom: 5,
                    }}
                    horizontal={true}
                  >
                    <View
                      style={{
                        display: "flex",
                        flexDirection: "row",
                        paddingHorizontal: 3,
                      }}
                    >
                      {this.state.imagePath.map((item, i) =>
                        this.fetchImageComment(item, i)
                      )}
                      {this.state.videoPath ? (
                        this.fetchVideoComment(this.state.videoPath)
                      ) : (
                        <View />
                      )}

                      {this.state.allPhotos.map((item, i) =>
                        this.renderImage(item, i)
                      )}
                      {this.state.images.map((item, i) =>
                        this.renderImageCapture(item, i)
                      )}

                      {this.checkRecordingExsit()}
                    </View>
                  </ScrollView>
                </View>

                {this.state.isLoadingTaperComment ? (
                  <ActivityIndicator
                    size="large"
                    color="#0000ff"
                    style={{
                      flex: 1,
                      justifyContent: "center",
                      alignItems: "center",
                      paddingVertical: 10,
                      paddingBottom: 10,
                    }}
                  />
                ) : (
                  <View row flex paddingB-10>
                    {hasCameraPermission === null ? (
                      <View center flex>
                        <Text>
                          {I18n.t("Commons.need_permission", {
                            locale: this.props.lang,
                          })}
                        </Text>
                      </View>
                    ) : (
                      <View />
                    )}
                    {hasCameraPermission === false ? (
                      <View center flex>
                        <Text>
                          {I18n.t("Commons.no_access_camera", {
                            locale: this.props.lang,
                          })}
                        </Text>
                      </View>
                    ) : (
                      <View />
                    )}
                    {hasCameraPermission === true ? (
                      <View flex row>
                        {this.state.isStatusCamera ? (
                          <TouchableOpacity onPress={this.takePicture}>
                            <Image
                              source={require("../assets/images/uploadPhoto.png")}
                              style={{
                                width: 30,
                                height: 30,
                                margin: 5,
                              }}
                            />
                          </TouchableOpacity>
                        ) : (
                          <View />
                        )}

                        {this.state.isStatusVideo ? (
                          <TouchableOpacity
                            onPress={() => this.galleryPicture()}
                          >
                            <Image
                              source={require("../assets/images/uploadVideo.png")}
                              style={{
                                width: 30,
                                height: 30,
                                margin: 5,
                              }}
                            />
                          </TouchableOpacity>
                        ) : (
                          <View />
                        )}
                      </View>
                    ) : (
                      <View />
                    )}

                    <View flex row style={{ position: "absolute", right: 0 }}>
                      <Text
                        style={{ fontSize: 16, marginTop: 8 }}
                        onPress={this.cancelComment}
                      >
                        {this.state.textCancelComment}
                      </Text>
                      <TouchableOpacity onPress={this._saveComment}>
                        <Image
                          source={require("../assets/images/icon_save1.png")}
                          style={{
                            width: 20,
                            height: 20,
                            margin: 10,
                          }}
                        />
                      </TouchableOpacity>
                    </View>
                  </View>
                )}
              </View>

              <View style={styles.separator} />

              {this.state.isLoadingComment ? (
                <ActivityIndicator
                  size="large"
                  color="#0000ff"
                  style={{
                    flex: 1,
                    justifyContent: "center",
                    alignItems: "center",
                    paddingVertical: 20,
                  }}
                />
              ) : null}

              <FlatList
                style={styles.root}
                data={this.state.fetchDataComments}
                extraData={this.state}
                ItemSeparatorComponent={() => {
                  return <View style={styles.separator} />;
                }}
                keyExtractor={(item) => {
                  return item.id;
                }}
                renderItem={(item) => {
                  const comment = item.item;

                  return (
                    <View style={styles.container}>
                      <Image
                        style={styles.image}
                        source={{ uri: comment.photo }}
                      />
                      <View style={styles.content}>
                        <View style={styles.contentHeader}>
                          <Text style={styles.name}>{comment.name}</Text>
                          <Text style={styles.time}>{comment.date}</Text>
                        </View>
                        <Text rkType="primary3 mediumLine">
                          {comment.comment}
                        </Text>

                        {comment.commentImage ? (
                          <View
                            style={{
                              display: "flex",
                              flexDirection: "row",
                              paddingTop: 5,
                            }}
                          >
                            <ScrollView horizontal={true}>
                              {comment.commentImage.map((item, i) =>
                                this.imageComment(item, i)
                              )}
                            </ScrollView>
                          </View>
                        ) : (
                          <View />
                        )}

                        {comment.commentVideo ? (
                          <View
                            style={{
                              display: "flex",
                              flexDirection: "row",
                              paddingTop: 5,
                            }}
                          >
                            <ScrollView horizontal={true}>
                              <TouchableOpacity
                                onPress={() => {
                                  this.ShowModalRecordingVideo(
                                    true,
                                    Config.API_VIDEO_COMMENT +
                                      comment.commentVideo
                                  );
                                }}
                              >
                                <Video
                                  source={{
                                    uri:
                                      Config.API_VIDEO_COMMENT +
                                      comment.commentVideo,
                                  }}
                                  rate={1.0}
                                  volume={1.0}
                                  isMuted={false}
                                  resizeMode="cover"
                                  style={styles.imageCss}
                                />
                              </TouchableOpacity>
                            </ScrollView>
                          </View>
                        ) : (
                          <View />
                        )}

                        {comment.user_id === this.state.userID ? (
                          <Picker
                            mode="dialog"
                            selectedValue={this.state.actions}
                            style={{
                              height: 50,
                              width: 100,
                              position: "absolute",
                              right: 1,
                              top: 10,
                              alignSelf: "stretch",
                            }}
                            onValueChange={(value, index) =>
                              this.actionsComment(value, comment.id)
                            }
                          >
                            <Picker.Item label="" value="" />
                            <Picker.Item
                              label={I18n.t("Commons.edit", {
                                locale: this.props.lang,
                              })}
                              value="edit"
                            />
                            <Picker.Item
                              label={I18n.t("Commons.delete", {
                                locale: this.props.lang,
                              })}
                              value="delete"
                            />
                          </Picker>
                        ) : (
                          <View />
                        )}
                      </View>
                    </View>
                  );
                }}
              />

              {this.state.viewCommentMore ? this.state.viewCommentMore : null}

              {this.state.isLoadingMoreComment ? (
                <ActivityIndicator
                  size="large"
                  color="#0000ff"
                  style={{
                    flex: 1,
                    justifyContent: "center",
                    alignItems: "center",
                    marginBottom: 10,
                  }}
                />
              ) : null}

              <View>
                {this.state.rowsRecentComment_ > 0 ? (
                  <View
                    style={{
                      flex: 1,
                      paddingBottom: 5,
                      flexDirection: "column",
                      justifyContent: "center",
                      alignItems: "center",
                    }}
                  >
                    <Text
                      center
                      rkType="primary3 mediumLine"
                      onPress={this.loadMoreComment}
                      style={{
                        width: "100%",
                        borderTopWidth: 1,
                        borderTopColor: "#CCCCCC",
                        color: "#2196f3",
                        paddingVertical: 20,
                      }}
                    >
                      {I18n.t("Commons.load_more_comment", {
                        locale: this.props.lang,
                      })}
                      ( {this.state.rowsRecentComment_} )
                    </Text>
                  </View>
                ) : null}
              </View>
            </View>
          ) : (
            <View>
              <View flex>
                <Text text60 dark40 center>
                  {" "}
                  {I18n.t("Commons.se_connecter", { locale: "fr" })}{" "}
                </Text>
                <Text marginV-1></Text>
                <Text text60 dark40 center>
                  {I18n.t("Commons.se_connecter", { locale: "ar" })}
                </Text>
              </View>
              <View
                flex
                style={{
                  flex: 1,
                  flexDirection: "row",
                  justifyContent: "space-evenly",
                }}
              >
                <View
                  marginV-5
                  style={{
                    flexDirection: "column",
                  }}
                >
                  {!this.state.userID ? (
                    <SocialIcon
                      style={{ padding: 10, width: 60 }}
                      button
                      type="facebook"
                      onPress={this.logIn.bind(this)}
                    />
                  ) : null}
                </View>
                <View marginV-5 style={{ flexDirection: "column" }}>
                  {!this.state.userID ? (
                    <SocialIcon
                      style={{ padding: 10, width: 60 }}
                      button
                      type="google"
                      onPress={this._handleGoogleLogin}
                    />
                  ) : null}
                </View>
              </View>
            </View>
          )}
        </ScrollView>
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  const fontSizeValue = state.fontSize.fontSize;
  const lang = state.fontSize.lang;
  const data = state.galleries.data;
  const dataSousChapitre = state.sousChapitre.data;
  const dataComments = state.fetchComments.data.dataComments;
  const rowsCommentsAll = state.fetchComments.data.rowsCommentsAll;
  const rowsCommentResult = state.fetchComments.data.rowsCommentResult;
  const rowsRecentComment = state.fetchComments.data.rowsRecentComment;
  const offsetNext = state.fetchComments.data.offsetNext;
  const isLoadingdataComments = state.fetchComments.isLoadingData;
  const isLoadingdatasaveComment = state.saveComments.isLoadingData;
  const dataComment = state.getComments.data;

  const dataFile64 = state.postFiles.data;
  const loadingDataFile64 = state.postFiles.isLoadingData;

  console.log("isLoadingdataComments", isLoadingdataComments);

  return {
    fontSizeValue,
    lang,
    data,
    dataSousChapitre,
    dataComments,
    rowsCommentsAll,
    rowsCommentResult,
    rowsRecentComment,
    offsetNext,
    isLoadingdataComments,
    isLoadingdatasaveComment,
    dataComment,
    dataFile64,
    loadingDataFile64,
  };
};

export default connect(mapStateToProps, {
  changeLanguage,
  fetchGalleries,
  saveComment,
  postFile,
  fetchComment,
  deleteComment,
  getComment,
})(DetailScreen);

const Page = ({ children, ...others }) => {
  return (
    <View {...others} style={styles.page}>
      {children}
    </View>
  );
};

const styles = StyleSheet.create({
  MainContainer: {
    justifyContent: "center",
    flex: 1,
    paddingTop: 30,
  },
  commentSection: {
    marginLeft: 10,
    paddingRight: 10,
  },
  inputReplyBox: {
    width: 300,
  },

  root: {
    marginTop: 10,
  },
  container: {
    paddingLeft: 2,
    paddingRight: 10,
    paddingVertical: 12,
    flexDirection: "row",
    alignItems: "flex-start",
  },
  container0: {
    paddingLeft: 2,
    paddingRight: 10,
    //paddingVertical: 12,
    flexDirection: "row",
    alignItems: "flex-start",
  },
  content: {
    marginLeft: 10,
    flex: 1,
  },
  contentHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 6,
  },
  separator: {
    height: 1,
    backgroundColor: "#CCCCCC",
  },
  image: {
    width: 38,
    height: 38,
    borderRadius: 20,
    marginLeft: 20,
  },
  time: {
    fontSize: 11,
    color: "#808080",
  },
  name: {
    fontSize: 16,
    fontWeight: "bold",
  },
  imageThumbnail: {
    width: 80,
    height: 80,
  },
  page: {
    width: Constants.screenWidth,
  },
  textAreaContainer: {
    borderColor: "#F5F5F5",
    borderRadius: 2,
    borderWidth: 1,
    paddingHorizontal: 10,
    marginHorizontal: 5,
    shadowRadius: 3,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    elevation: 1,
  },
  textArea: {
    height: 60,
    color: "#000",
    textAlign: "left",
  },

  text: {
    fontSize: 21,
  },
  row: { flexDirection: "row" },
  image2: { width: 300, height: 300, backgroundColor: "gray" },
  button: {
    padding: 13,
    margin: 15,
    backgroundColor: "#dddddd",
  },
  container2: {
    flex: 1,
    backgroundColor: "#ffffff",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 10,
    marginHorizontal: 10,
  },
  activeImageContainer: {
    flex: 1,
    maxWidth: Dimensions.get("window").width,
    maxHeight: Dimensions.get("window").height / 2,
    backgroundColor: "#eee",
    borderBottomWidth: 0.5,
    borderColor: "#fff",
  },
  imageCss: {
    height: 50,
    width: 50,
    marginHorizontal: 2,
    flexDirection: "column",
  },
  imageCss1: {
    height: 50,
    width: 50,
    marginHorizontal: 2,
    flexDirection: "column",
    marginTop: 5,
  },
  imageCssClose: {
    height: 50,
    width: 50,
    marginHorizontal: 5,
    marginTop: 5,
    zIndex: 1,
    flexDirection: "column",
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: "bold",
    textAlign: "center",
    color: "#34495e",
  },
  scrollView: {},

  topActions: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  flipCamera: {
    margin: 10,
  },
  chronometer: {
    margin: 10,
  },
  bottonActions: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-around",
    marginBottom: 10,
  },
  containerCenter: {
    flex: 1,
    flexDirection: "column",
    justifyContent: "center",
  },
  containerCamera: {
    flex: 1,
    flexDirection: "column",
    justifyContent: "space-between",
  },
  viewCamera: {
    position: "absolute",
    bottom: 12,
    backgroundColor: "#000",
  },
  btnCamera: {
    padding: 10,
    fontSize: 15,
    width: 100,
    backgroundColor: "#dcdde1",
  },
});
