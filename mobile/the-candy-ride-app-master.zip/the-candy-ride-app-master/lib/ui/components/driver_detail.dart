import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:rider_app/constants/constants.dart';
import 'package:rider_app/controllers/controllers.dart';
import 'package:intl/intl.dart';
import 'package:rider_app/helpers/formaters.dart';
import 'package:url_launcher/url_launcher.dart';

class DriverDetail extends StatelessWidget {
  static TripAcceptController to = AuthController.tripTo;
  static HomeController homeTo = HomeController.to;

  final numberFormating = NumberFormat("##0.00", "en_US");

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Column(
        children: [
          SizedBox(height: 5),
          Row(
            children: [
              SizedBox(width: 10),
              Expanded(
                child: Text(
                  "bookingDate".tr +
                      ": " +
                      (datedayddMMMyyyyhhMMssWithSpace(to?.ride?.bookDate) ??
                          ""),
                  style: Theme.of(context)
                      .textTheme
                      .subtitle2
                      .copyWith(fontSize: 12, fontWeight: FontWeight.w600),
                ),
              ),
              Text(
                'tripId'.tr + ": ",
                style: Theme.of(context)
                    .textTheme
                    .subtitle2
                    .copyWith(fontSize: 14, fontWeight: FontWeight.w600),
              ),
              Text(
                homeTo.tripId(
                  id: to?.ride?.id ?? "",
                  bookingType: to?.ride?.bookType ?? "",
                  type: to?.carType ?? "",
                ),
                style: Theme.of(context)
                    .textTheme
                    .subtitle2
                    .copyWith(fontSize: 14, fontWeight: FontWeight.w600),
              ),
              SizedBox(width: 10),
            ],
          ),
          Divider(
            color: AppThemes.lightAthensGrayBorderColor,
            thickness: 2,
          ),
          Row(
            children: [
              Expanded(
                child: Row(
                  children: [
                    SizedBox(width: 10),
                    Container(
                      height: 45,
                      width: 45,
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: AppThemes.lightAthensGrayBorderColor,
                        ),
                        image: DecorationImage(
                          image: to.driverImage != Urls.baseDriverImageUrl &&
                                  to.driverImage != null
                              ? NetworkImage(to.driverImage)
                              : AssetImage(AllImages.adddp),
                          fit: BoxFit.cover,
                        ),
                        shape: BoxShape.circle,
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          (to?.ride?.fname ?? "") +
                              " " +
                              (to?.ride?.lname ?? ""),
                          style: Theme.of(context).textTheme.subtitle2.copyWith(
                              fontSize: 14, fontWeight: FontWeight.w600),
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Row(
                          children: [
                            Container(
                              padding: EdgeInsets.all(5),
                              decoration: BoxDecoration(
                                color: AppThemes.lightPinkBackGroundColor,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Center(
                                child: Text(
                                  numberFormating.format(
                                      double.parse(to?.driverRating ?? "0.0")),
                                  style: Theme.of(context)
                                      .textTheme
                                      .subtitle1
                                      .copyWith(
                                        fontSize: 12,
                                      ),
                                ),
                              ),
                            ),
                            SizedBox(width: 7),
                            RatingBar(
                              initialRating:
                                  double.parse(to?.driverRating ?? "0.0"),
                              direction: Axis.horizontal,
                              allowHalfRating: true,
                              ignoreGestures: true,
                              itemCount: 5,
                              itemSize: 13,
                              ratingWidget: RatingWidget(
                                full: Icon(
                                  Icons.star,
                                  color: AppThemes.lightPinkBackGroundColor,
                                ),
                                half: Icon(
                                  Icons.star_half,
                                  color: AppThemes.lightPinkBackGroundColor,
                                ),
                                empty: Icon(
                                  Icons.star_border,
                                  color: AppThemes.lightStarColor,
                                ),
                              ),
                              glow: false,
                              itemPadding:
                                  EdgeInsets.symmetric(horizontal: 0.0),
                              onRatingUpdate: (rating) {},
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(
                width: 10,
              ),

              TextButton.icon(
                style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.resolveWith(
                        (states) => AppThemes.lightPinkBackGroundColor)),
                icon: Icon(
                  Icons.call,
                  color: Colors.white,
                ),
                onPressed: () async {
                  final url = "tel:${to?.ride?.driverMobile}";
                  if (await canLaunch(url)) {
                    await launch(url);
                  }
                },
                label: Text("${to?.ride?.driverMobile}",
                    style: Theme.of(context).textTheme.subtitle2.copyWith(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: Colors.white)),
              ),
              //   child: TextButton.icon(onPressed: onPressed, icon: icon, label: label)(
              //     children: [
              //       Icon(
              //         Icons.call,
              //       ),
              //       SizedBox(width: 10),
              //       Text(
              //         ": ${to?.ride?.driverMobile}",

              //       ),
              //     ],
              //   ),
              // ),
              SizedBox(
                width: 10,
              ),
            ],
          ),
          Divider(
            color: AppThemes.lightAthensGrayBorderColor,
            thickness: 2,
          ),
        ],
      ),
    );
  }
}
