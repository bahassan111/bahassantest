package ma.rak.ovr.ui.main;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProviders;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import io.realm.Realm;
import ma.rak.ovr.R;
import ma.rak.ovr.api.TwDatabase;
import ma.rak.ovr.api.TwHelper;
import ma.rak.ovr.bodyResponse.OperationResponse;
import ma.rak.ovr.bodyResponse.SettingsResponse;
import ma.rak.ovr.models.Dossier;
import ma.rak.ovr.models.Resultat;
import ma.rak.ovr.storage.SharedPrefManager;
import ma.rak.ovr.utils.ImageUtils;

public class ExecutionFragment extends FragmentActivity implements AdapterView.OnItemSelectedListener {

    String token = SharedPrefManager.getInstance(this).getToken();
    ImageView ivImage;
    Integer REQUEST_CAMERA = 1, SELECT_FILE = 0;
    Realm realm;
    SettingsResponse newSettingsResponse = null;
    ProgressButton progressButton;
    OperationResponse operationResponse = null;
    ArrayList<Dossier> dossierArrayList;
    HashMap<String ,String> naturesIDS = new HashMap<String,String>();
    HashMap<String ,String> catsIDS = new HashMap<String,String>();
    HashMap<String ,String> empIDS = new HashMap<String,String>();
    private DropDownAlert downAlertImage;
    private DropDownAlert downAlertNoImage;
    private int devis = 0;
    private Spinner nature_installation, categorie_Abonnement, dossier_resiler, emplacement;
    private Button cancelButton;
    private View saveButton;
    private TextView typeAction, client;
    private EditText nature_lot, obs, repcli;
    private RadioGroup adevis;
    private DemandViewModel demandViewModel;
    private String base64Image, adreloca, doss_annee, doss_numm, num_operation, gerance, etage, nature_install, observation = "", date, natureValue, categoryValue, dossierValue, emplacementValue, lotValue, status = "3";
    public boolean isBR = false;
    LinearLayout for_ab;
    HashMap<String, String> row = new HashMap<>();

    public static ExecutionFragment newInstance() {
        return new ExecutionFragment();
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_fragment);
        progressButton = new ProgressButton(ExecutionFragment.this, R.string.enregistrer, "Enregistrer");

        isBR = getIntent().getExtras().getBoolean("br");

        realm = Realm.getDefaultInstance();


        row = (HashMap<String, String>)getIntent().getExtras().getSerializable("ITEM");

        demandViewModel = ViewModelProviders.of(this).get(DemandViewModel.class);
        demandViewModel.getSettings(token, this, row.get("CODEGERA"));
        obs = findViewById(R.id.observation);
        repcli = findViewById(R.id.repcli);


        nature_installation = (Spinner) findViewById(R.id.resultat);



        cancelButton = (Button) findViewById(R.id.cancel_button);
        saveButton = findViewById(R.id.save_button);
        client = (TextView) findViewById(R.id.adrelocaClient);
        typeAction = (TextView) findViewById(R.id.typeAction);



        downAlertImage = new DropDownAlert(this, this.getWindow().getContext(), true);
        downAlertNoImage = new DropDownAlert(this, this.getWindow().getContext(), false);

        ivImage = (ImageView) findViewById(R.id.ivImage);

        ivImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SelectImage();
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ExecutionFragment.super.onBackPressed();
            }
        });

        if(getIntent().getExtras().getBoolean("CONSULT")){
            saveButton.setVisibility(View.INVISIBLE);
            nature_installation.setEnabled(false);
            categorie_Abonnement.setEnabled(false);
            dossier_resiler.setEnabled(false);
            emplacement.setEnabled(false);
            nature_lot.setEnabled(false);
            //adevis.setEnabled(false);

            cancelButton.setText(R.string.goback);
        }

//        if(!isBR){ // ABONNEMEN?T
//            nature_lot.setText(row.get("NATU_LOT"));
//            for_ab.setVisibility(View.VISIBLE);
//            obs.setText(row.get(TwDatabase.Demandes.OBJECT_VERIF));
//        }else{ // BRANCHEMENT
//            emplacement.setVisibility(View.INVISIBLE);
//            for_ab.setVisibility(View.GONE);
//            obs.setText(row.get(TwDatabase.Demandes.OBJECT_VERIF));
//        }

        View.OnClickListener save = save = new View.OnClickListener() {

            @Override
            public void onClick(View v) {


                progressButton.buttonActivated();


                if (natureValue == null || natureValue.equals("")) {
                    downAlertNoImage.setTitle(getString(R.string.dropdown_error));
                    downAlertNoImage.setContent(getString(R.string.required_form_data));
                    downAlertNoImage.show();
                    progressButton.buttonCancled(R.string.enregistrer);
                    return;
                }

                SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                Date d = new Date();
                String date = formatter.format(d);

                TwDatabase.TwDatabaseHelper.Executer(
                        getApplicationContext(),
                        false,
                        "2",
                        date,
                        SharedPrefManager.getInstance(getApplicationContext()).getPos().get("lat").toString(),
                        SharedPrefManager.getInstance(getApplicationContext()).getPos().get("lng").toString(),
                        row.get("NUMDOSRE"),
                        repcli.getText().toString(),
                        natureValue,
                        obs.getText().toString(),
                        "",
                        new Runnable() { // SUCCESS
                            @Override
                            public void run() {

                                downAlertNoImage.setTitle(getString(R.string.dropdown_info));
                                downAlertNoImage.setContent("Toutes les données ont été bien enregistrées");
                                downAlertNoImage.show();
                                progressButton.buttonFinished();
                                Handler handler1 = new Handler();
                                handler1.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        ExecutionFragment.super.onBackPressed();
                                    }
                                }, 1000);

                            }
                        },
                        new Runnable() { // OFFLINE
                            @Override
                            public void run() {



                            }
                        },
                        new Runnable() { // SUCCESS
                            @Override
                            public void run() {

                                downAlertNoImage.setTitle(getString(R.string.dropdown_error));
                                downAlertNoImage.setContent("Erreur lors de l'enregistrement des données");
                                downAlertNoImage.show();
                                progressButton.buttonCancled(R.string.enregistrer);
                                Handler handler1 = new Handler();
                                handler1.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        //ExecutionFragment.super.onBackPressed();
                                    }
                                }, 1000);

                            }
                        }
                );


            }
        };

        saveButton.setOnClickListener(save);

        ArrayList<String> naturee = new ArrayList<>();
        ArrayAdapter nature = new ArrayAdapter(this, android.R.layout.simple_spinner_item, naturee);
        nature.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        newSettingsResponse = new SettingsResponse();
        demandViewModel.SettingsMutableLiveData.observe(this, settingsResponse -> {
            newSettingsResponse = settingsResponse;


            if(newSettingsResponse != null){
                naturee.clear();
                naturesIDS.clear();
                naturee.add("<VIDE>");

                for (Resultat label : newSettingsResponse.getResults()) {
                    naturee.add(label.getLIBRESRE());
                    naturesIDS.put(label.getLIBRESRE(), String.valueOf(label.getCODRESRE()));
                }
                nature.notifyDataSetChanged();
                nature_installation.setAdapter(nature);

                String nv = TwHelper.getKeyOf(naturesIDS, natureValue == null ? row.get("CODRESRE") : natureValue, "");
                int p = nature.getPosition(nv);
                nature_installation.setSelection(p);
            }

        });

        nature_installation.setAdapter(nature);
        nature_installation.setOnItemSelectedListener(this);




        Intent intent = getIntent();
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            if (bundle.getString("date") != null && !isBR) {
                this.doss_annee = bundle.getString("doss_annee");
                this.gerance = bundle.getString("gerance");
                this.doss_numm = bundle.getString("doss_numm");
                this.date = bundle.getString("date");
                this.num_operation = bundle.getString("num_operation");
                this.status = bundle.getString("status");
                this.date = bundle.getString("date");
                this.adreloca = bundle.getString("adreloca");
                this.nature_install = bundle.getString("nature_install");
                this.etage = bundle.getString("etage");
                client.setText(bundle.getString("adreloca"));
                typeAction.setText(typeAction.getText() + " Exécutions");
                this.dossierArrayList = intent.getParcelableArrayListExtra("dossier");

            }
        }

    }



    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Spinner spinner = (Spinner) parent;

        if (spinner.getId() == R.id.resultat) {

            String nv = spinner.getItemAtPosition(position).toString();
            natureValue = naturesIDS.get(nv);

        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    private void SelectImage() {

        final CharSequence[] items = {"Camera", "Gallery", "Cancel"};

        AlertDialog.Builder builder = new AlertDialog.Builder(ExecutionFragment.this);
        builder.setTitle("Add Image");

        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {
                if (items[i].equals("Camera")) {

                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(intent, REQUEST_CAMERA);

                } else if (items[i].equals("Gallery")) {

                    Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    intent.setType("image/*");
                    //startActivityForResult(intent.createChooser(intent, "Select File"), SELECT_FILE);
                    startActivityForResult(intent, SELECT_FILE);

                } else if (items[i].equals("Cancel")) {
                    dialog.dismiss();
                }
            }

        });
        builder.show();

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {

            if (requestCode == REQUEST_CAMERA) {

                Bundle bundle = data.getExtras();
                final Bitmap bitmap = (Bitmap) bundle.get("data");
                ivImage.setImageBitmap(bitmap);
                base64Image = ImageUtils.getBase64Image(bitmap);

                Log.i("Camera-base64", base64Image);

            } else if (requestCode == SELECT_FILE) {

                Uri selectedImageUri = data.getData();
                Bitmap bitmap = null;
                if (selectedImageUri != null) {
                    try {
                        bitmap = ImageUtils.getBitmapFormUri(this, selectedImageUri);
                        base64Image = ImageUtils.getBase64Image(bitmap);
                        ivImage.setImageURI(selectedImageUri);
                        Log.i("File-base64", base64Image);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }


                }

            }

        }
    }

}