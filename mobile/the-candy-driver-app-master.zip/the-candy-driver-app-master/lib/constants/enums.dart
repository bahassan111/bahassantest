enum HomeScreenStatus {
  None,
  TripDetail,
  Procced,
  IhaveArrived,
  StartTrip,
  FinishTrip
}
List<String> rideStatus = [
  "Waiting",
  "Accepted",
  "Canceled",
  "Proceed",
  "Completed"
];
