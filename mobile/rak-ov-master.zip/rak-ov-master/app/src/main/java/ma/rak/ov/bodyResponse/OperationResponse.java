package ma.rak.ov.bodyResponse;

import com.google.gson.annotations.SerializedName;

import io.realm.RealmObject;

public class OperationResponse extends RealmObject {

    @SerializedName("status")
    private String status;

    @SerializedName("error")
    private boolean err;

    @SerializedName("message")
    private String msg;

    public OperationResponse(String status, boolean err, String msg) {
        this.status = status;
        this.err = err;
        this.msg = msg;
    }

    public OperationResponse() {
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean isErr() {
        return err;
    }

    public void setErr(boolean err) {
        this.err = err;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    @Override
    public String toString() {
        return "OperationResponse{" +
                "status='" + status + '\'' +
                ", err=" + err +
                ", msg='" + msg + '\'' +
                '}';
    }
}
