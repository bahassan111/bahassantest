class OnlineDrivesModel {
  String name;
  String onlineStatus;
  double lat;
  String id;
  double lng;
  String countryId;
  int angle;
  String fleetId;

  OnlineDrivesModel(
      {this.name,
      this.onlineStatus,
      this.lat,
      this.id,
      this.lng,
      this.countryId,
      this.angle,
      this.fleetId});

  OnlineDrivesModel.fromJson(Map<dynamic, dynamic> json) {
    name = json['name'];
    onlineStatus = json['online_status'];
    lat = json['lat'];
    id = json['id'];
    lng = json['lng'];
    countryId = json['country_id'];
    angle = json['angle'];
    fleetId = json['fleet_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['online_status'] = this.onlineStatus;
    data['lat'] = this.lat;
    data['id'] = this.id;
    data['lng'] = this.lng;
    data['country_id'] = this.countryId;
    data['angle'] = this.angle;
    data['fleet_id'] = this.fleetId;
    return data;
  }
}
