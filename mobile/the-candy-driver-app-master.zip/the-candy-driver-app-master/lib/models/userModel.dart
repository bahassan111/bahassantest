class UserModel {
  String id;
  String firstname;
  String lastname;
  String fleetid;
  String address;
  String postcode;
  String state;
  String country;
  String mobile;
  String email;
  String plateNo;
  String carcategory;
  String vehicletype;
  String yearofreg;
  String bankname;
  String accountno;
  String emergencypserson;
  String emergencycontact;
  String profilephoto;
  String licensephoto;
  String insurancephoto;
  String vocationallicense;
  String vcexpiry;
  String vinsuranceexpiry;
  String vehiclepermitexpiry;
  String drivinglicense;
  String vehiclepermit;
  String activestatus;
  String alternateEmgNum;
  String accountname;
  String currency;
  String vehiclemodel;
  String vehiclecolor;
  UserModel({
    this.id,
    this.firstname,
    this.lastname,
    this.fleetid,
    this.address,
    this.postcode,
    this.state,
    this.accountname,
    this.country,
    this.mobile,
    this.email,
    this.plateNo,
    this.carcategory,
    this.vehicletype,
    this.yearofreg,
    this.bankname,
    this.accountno,
    this.emergencypserson,
    this.emergencycontact,
    this.profilephoto,
    this.licensephoto,
    this.insurancephoto,
    this.vocationallicense,
    this.vcexpiry,
    this.vinsuranceexpiry,
    this.vehiclepermitexpiry,
    this.drivinglicense,
    this.vehiclepermit,
    this.activestatus,
    this.alternateEmgNum,
    this.currency,
    this.vehiclecolor,
    this.vehiclemodel,
  });

  UserModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    firstname = json['firstname'];
    lastname = json['lastname'];
    fleetid = json['fleetid'];
    address = json['address'];
    postcode = json['postcode'];
    accountname = json['accountname'];
    state = json['state'];
    country = json['country'];
    mobile = json['mobile'];
    email = json['email'];
    plateNo = json['plate_no'];
    carcategory = json['carcategory'];
    vehicletype = json['vehicletype'];
    yearofreg = json['yearofreg'];
    bankname = json['bankname'];
    accountno = json['accountno'];
    emergencypserson = json['emergencypserson'];
    emergencycontact = json['emergencycontact'];
    profilephoto = json['profilephoto'];
    licensephoto = json['licensephoto'];
    insurancephoto = json['insurancephoto'];
    vocationallicense = json['vocationallicense'];
    vcexpiry = json['vcexpiry'];
    vinsuranceexpiry = json['vinsuranceexpiry'];
    vehiclepermitexpiry = json['vehiclepermitexpiry'];
    drivinglicense = json['drivinglicense'];
    vehiclepermit = json['vehiclepermit'];
    activestatus = json['activestatus'];
    currency = json['currency'];
    alternateEmgNum = json['alternate_emg_num'];
    vehiclemodel = json['vehiclemodel'];
    vehiclecolor = json['vehiclecolor'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['firstname'] = this.firstname;
    data['lastname'] = this.lastname;
    data['fleetid'] = this.fleetid;
    data['address'] = this.address;
    data['postcode'] = this.postcode;
    data['state'] = this.state;
    data['country'] = this.country;
    data['mobile'] = this.mobile;
    data['email'] = this.email;
    data['plate_no'] = this.plateNo;
    data['carcategory'] = this.carcategory;
    data['vehicletype'] = this.vehicletype;
    data['yearofreg'] = this.yearofreg;
    data['bankname'] = this.bankname;
    data['accountno'] = this.accountno;
    data['emergencypserson'] = this.emergencypserson;
    data['emergencycontact'] = this.emergencycontact;
    data['profilephoto'] = this.profilephoto;
    data['licensephoto'] = this.licensephoto;
    data['insurancephoto'] = this.insurancephoto;
    data['vocationallicense'] = this.vocationallicense;
    data['vcexpiry'] = this.vcexpiry;
    data['vinsuranceexpiry'] = this.vinsuranceexpiry;
    data['vehiclepermitexpiry'] = this.vehiclepermitexpiry;
    data['drivinglicense'] = this.drivinglicense;
    data['vehiclepermit'] = this.vehiclepermit;
    data['activestatus'] = this.activestatus;
    data['currency'] = this.currency;
    data['alternate_emg_num'] = this.alternateEmgNum;
    data['accountname'] = this.accountname;
    data['vehiclecolor'] = this.vehiclecolor;
    data['vehiclemodel'] = this.vehiclemodel;
    return data;
  }
}
