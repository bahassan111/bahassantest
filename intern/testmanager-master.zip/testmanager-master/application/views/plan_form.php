<?php
?>

<div class="" id="plan_form">


    <div id="group_select" class="form-group">
        <label for="id_group" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Group</label>
        <select title="Select a Group" name="id_group" id="id_group" class="selectpicker form-control form-control-sm">
            <?php foreach($groups as $group){ ?>
                <option <?= $edit && $plan->id_group === $group->id ? 'selected' : ''; ?> value="<?= $group->id; ?>"><?= $group->name; ?></option>
            <?php } ?>

            <option value="new_group">Create New Group</option>
        </select>
    </div>
    <div id="groupe_input" class="form-group" style="display: none">
        <label for="group" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Group Name</label>
        <input id="group" type="text" class="form-control form-control-sm" placeholder="Enter a a group title ..">
    </div>
    <div class="form-group">
        <label for="title" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Plan Name</label>
        <input id="title" value="<?= $edit ? $plan->title : ''; ?>" type="text" class="form-control form-control-sm" placeholder="Enter a descriptive title ..">
    </div>
    <div class="form-group">
        <label for="desc" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Description (optional)</label>
        <textarea class="form-control form-control-sm" id="desc" name="desc"><?= $edit ? $plan->desc : ''; ?></textarea>
    </div>


    <div class="form-group">
        <label for="type" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Test Environments</label>
        <select name="type" id="type" class="selectpicker form-control form-control-sm">
            <option <?= $edit && $plan->type === 'auto' ? 'selected' : ''; ?> value="auto">Auto (Runs in the PM)</option>
            <option <?= $edit && $plan->type === 'manual' ? 'selected' : ($edit ? '' : 'selected'); ?> value="manual">Manual</option>
            <option <?= $edit && $plan->type === 'unit' ? 'selected' : ''; ?> value="unit">Unit Test</option>
        </select>
    </div>
    <div class="form-group" data-shownby="#type:auto">
        <label for="url" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Default URL</label>
        <input id="url" name="url" value="<?= $edit ? $plan->url : ($project->url ?: ''); ?>" type="text" class="form-control form-control-sm" placeholder="Enter a descriptive title ..">
    </div>


</div>

