export default {
  API_URL: "http://ifes-esll.com/new/api/",
  API_INTRO_URL: "http://ifes-esll.com/new/intro/intro.mp4/",
  BANNERS_IMAGE: "http://ifes-esll.com/new/",
  CHAPITRE_IMAGE: "http://ifes-esll.com/new/",
  IMAGE: "http://ifes-esll.com/new/",
  SOUS_CHAPITRE_IMAGE: "http://ifes-esll.com/new/",
  SOUS_CHAPITRE_VIDEO: "http://ifes-esll.com/new/",
  API_IMAGE_COMMENT: "http://ifes-esll.com/new/api/img/",
  API_VIDEO_COMMENT: "http://ifes-esll.com/new/api/video/",
};
