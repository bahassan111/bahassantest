import React from "react";
import { Image, Button } from "react-native";
import { createDrawerNavigator } from "react-navigation";
import Colors from "../constants/Colors";
import Icon from "../constants/Icons";

import HomeScreen from "../screens/HomeScreen";
import SettingsScreen from "../screens/SettingsScreen";

class MyDrawer extends React.Component {
  static navigationOptions = {
    drawerLabel: "Notifications",
    drawerIcon: ({ tintColor }) => (
      <Icon name="menu" iconSize={50} color={Colors.green} />
    )
  };

  render() {
    return (
      <Button
        onPress={() => this.props.navigation.goBack()}
        title="Go back home"
      />
    );
  }
}

const MyApp = createDrawerNavigator({
  HomeScreen,
  SettingsScreen,
  Notifications: {
    screen: MyDrawer
  }
});

export default MyApp;
