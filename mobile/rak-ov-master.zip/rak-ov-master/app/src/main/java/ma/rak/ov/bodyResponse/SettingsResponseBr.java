package ma.rak.ov.bodyResponse;

import com.google.gson.annotations.SerializedName;

import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;
import ma.rak.ov.models.Categorie;
import ma.rak.ov.models.CategorieBr;
import ma.rak.ov.models.Emplacement;
import ma.rak.ov.models.Motif;
import ma.rak.ov.models.MotifBr;
import ma.rak.ov.models.Nature;
import ma.rak.ov.models.NatureBr;

public class SettingsResponseBr extends RealmObject {


    @SerializedName("nature")
    private RealmList<NatureBr> nature;

    @SerializedName("categorie")
    private RealmList<CategorieBr> categorie;

    @SerializedName("motif")
    private RealmList<MotifBr> motif;

    public SettingsResponseBr() {

    }

    public SettingsResponseBr(RealmList<NatureBr> nature, RealmList<CategorieBr> categorie, RealmList<MotifBr> motif) {

        this.nature = nature;
        this.categorie = categorie;
        this.motif = motif;
    }


    public RealmList<NatureBr> getNature() {
        return nature;
    }

    public void setNature(RealmList<NatureBr> nature) {
        this.nature = nature;
    }

    public RealmList<CategorieBr> getCategorie() {
        return categorie;
    }

    public void setCategorie(RealmList<CategorieBr> categorie) {
        this.categorie = categorie;
    }

    public RealmList<MotifBr> getMotif() {
        return motif;
    }

    public void setMotif(RealmList<MotifBr> motif) {
        this.motif = motif;
    }

    @Override
    public String toString() {
        return "SettingsResponseBr{" +
                "nature=" + nature +
                ", categorie=" + categorie +
                ", motif=" + motif +
                '}';
    }
}
