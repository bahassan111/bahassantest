const URL = 'https://dibnews.ma/wp-json/wp/v2/';
const URL2 = 'https://dibnews.ma/wp-json/wp/v2/';


async function Query(path, params, useURL2){

    let addUrl = "";

    for(let i in params){
        addUrl += (addUrl ? '&' : '?') + `${i}=${params[i]}`;
    }


    let fullURL = (useURL2 ? URL2 : URL) + path + addUrl;

    console.log('querying', fullURL);

    return new Promise(((resolve, reject) => {
        fetch(fullURL, {
            method: 'GET',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
        })
            .then((rep)=>{
                rep.json().then(resolve).catch(reject);
            })
            .catch(()=>{
                reject();
            })
    }));


}
async function POST(path, params, useURL2){

    let addUrl = "";

    let fullURL = (useURL2 ? URL2 : URL) + path + addUrl;

    console.log('POST querying', fullURL);

    let rep = await fetch(fullURL, {
        method: 'POST',
        headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
            data : JSON.stringify(params),
        },
    });



    return rep.json();

}
const API = {Query,POST};

export default API;
