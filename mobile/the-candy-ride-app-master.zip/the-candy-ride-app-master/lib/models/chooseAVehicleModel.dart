class ChooseAVehicleModel {
  String id;
  String name;
  String icon;

  ChooseAVehicleModel({this.id, this.name, this.icon});

  ChooseAVehicleModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    icon = json['icon'];
  }
}
