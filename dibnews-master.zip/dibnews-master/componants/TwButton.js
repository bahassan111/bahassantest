import React, { Component } from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    ImageBackground,
    ActivityIndicator,
    Button,
    TouchableOpacity
} from "react-native";

import { AntDesign } from '@expo/vector-icons';
import {updateData} from "../redux/actions/dataAction";
import {connect} from "react-redux";
import {bindActionCreators} from "redux";
import {colors, sizes} from "../global/GlobalStyle";

class TwButton extends Component {

    state = {
      pressed : false,
        fsize : 18,
    };

    UNSAFE_componentWillMount() {
        if(('style' in this.props) && ('fontSize' in this.props.style))
            this.setState({fsize:this.props.style.fontSize})
    }






    render() {

        let isFull = ('full' in this.props) ? this.props.full : true;
        let flip = ('flip' in this.props) ? this.props.flip : false;
        let small = ('small' in this.props) ? this.props.small : false;
        let white = ('white' in this.props) ? this.props.white : false;



        if(!this.props.white && this.props.data.theme === 'dark'){
            white = true;
        }

        return (

            <View style={[this.props.style || {}, styles.holder, isFull ? (white ? styles.holder_white : styles.holder_full) : {}]}>
                <TouchableOpacity onPress={this.props.onPress} style={[styles.btn, (small) ? styles.btn_small : {}, (this.props.language === 'ar' || flip) ? styles.btn_rtl : {}, (isFull) ? (white ? styles.btn_full_white : styles.btn_full) : {}]}>

                    <Text numberOfLines={1} style={[styles.btn_txt,((this.props.language === 'ar') ? styles.rtl_txt : {}) , (isFull) ? (white ? styles.text_btn_full_white : styles.text_btn_full) : {}, (small) ? styles.text_btn_small : {}]}>{this.props.title}</Text>
                    <AntDesign style={[styles.ic, (isFull) ? (white ? styles.icon_btn_full_white : styles.icon_btn_full) : {}, (small) ? styles.icon_btn_small : {}]} name={this.props.icon || ((this.props.language === 'ar') ? 'leftcircleo' : 'rightcircleo')} size={22} color="#273272" />

                </TouchableOpacity>
            </View>

        );
    }

}


const styles = StyleSheet.create({
    holder:{
        //backgroundColor: colors.back,
    },
    holder_full:{
        backgroundColor: colors.back,
    },
    holder_white:{
        backgroundColor: '#dedede',
    },
    rtl_txt:{

    },
    ic:{
        margin:16,
        marginBottom:6,
        marginTop:6,
        color:colors.back,
    },
    icon_btn_small: {
        margin: 10,
        marginVertical: 2,
        fontSize: 14,
    },
    text_btn_small : {
        fontWeight: 'normal',
        margin: 10,
        marginVertical: 3,
        fontSize: 12,
    },
    btn_txt: {
        flex:1,
        fontWeight: 'bold',
        margin:16,
        marginBottom:6,
        marginTop:6,
        fontSize: 18,
    },
    btn_rtl:{
        flexDirection: 'row-reverse',
    },
    btn_full: {
        backgroundColor: colors.back,
        color: colors.front,
        borderWidth: 3,
        borderColor: colors.back,
    },
    btn_full_white: {
        backgroundColor: '#dedede',
        color: '#000',
        borderWidth: 3,
        borderColor: '#bcbcbc',
    },
    btn_small : {
        borderWidth: 2,
    },
    btn: {
        backgroundColor : 'transparent',
        color : colors.back,
        borderWidth: 3,
        borderColor: colors.back,
        borderRadius: 4,
        flexDirection:'row',
        alignItems: 'center',
    },
    text_btn_full:{
        color:'#fff'
    },
    text_btn_full_white:{
        color:'#393939'
    },
    icon_btn_full:{
        color:'#fff'
    },
    icon_btn_full_white:{
        color:'#3e3e3e'
    },
});


const mapDispatchToProps = dispatch => (
    bindActionCreators({
        updateData: updateData,
    }, dispatch)
);
const mapStateToProps = (state) => {
    const {data} = state;
    return {data}
};

export default connect(mapStateToProps, mapDispatchToProps)(TwButton);
