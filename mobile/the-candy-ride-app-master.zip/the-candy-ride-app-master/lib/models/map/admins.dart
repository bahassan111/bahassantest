class Admins {
  String iso31661Alpha3;
  String iso31661;

  Admins({this.iso31661Alpha3, this.iso31661});

  Admins.fromJson(Map<String, dynamic> json) {
    iso31661Alpha3 = json['iso_3166_1_alpha3'];
    iso31661 = json['iso_3166_1'];
  }
}
