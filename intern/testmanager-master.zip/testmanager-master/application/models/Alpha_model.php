<?php

class Alpha_model extends CI_Model
{
    public function get_run_overview($id_run)
    {

        $cases = $this->db
            ->select('c.id_run, c.status')
            ->join('runs_executions e', 'c.id = e.id_runcase', 'left')
            ->get_where('runs_cases c', ['c.id_run' => $id_run, 'c.deleted' => 0])->result();
        $total = $this->db->get_where('runs_cases', ['id_run' => $id_run, 'deleted' => 0])->num_rows();
        $data = [];
        $t = 0;
        foreach ($cases as $case) {
            $k = $case->status;
            if (!array_key_exists($k, $data)) $data[$k] = 0;
            $data[$k] += 1;

        }
        $statuses = [];
        foreach ($data as $st => $item) {
            $s = $this->db->get_where('_status', ['id' => $st, 'deleted' => 0])->row();
            $statuses[] = (object)[
                'status' => $s->name ?: '',
                'total' => $item,
                'percent' => round($item * 100 / count($cases)),
                'color' => $s->color ?: '',
            ];
        }
        return (object)[
            'total' => $total,
            'data' => $statuses,
        ];

    }

    public function get_status($id = FALSE)
    {
        if ($id) return $this->db->query("SELECT * FROM `_status` WHERE id = {$id} AND deleted = 0")->row();
        return $this->db->query("SELECT * FROM `_status` WHERE deleted = 0")->result();
    }

    public function set_step_run_status($id_runcase, $id_step, $status)
    {
        $exists = $this->db->query("SELECT * FROM runs_executions WHERE id_runcase = $id_runcase AND `key` = 'step' AND key_id = $id_step")->row();
        if ($exists) {
            $q = $this->db->update('runs_executions', [
                'date' => time(),
                'id_user' => userInfo()->id,
                'status' => $status,
            ], ['id' => $exists->id]);

        } else {
            $q = $this->db->insert('runs_executions', [
                'id_runcase' => $id_runcase,
                'date' => time(),
                'result' => '',
                'status' => $status,
                'id_user' => userInfo()->id,
                'data' => '',
                'key' => 'step',
                'key_id' => $id_step,
            ]);
        }
        $this->update_run_case_status($id_runcase);
        return $q ? ($exists ? $exists->id : $this->db->insert_id()) : null;
    }

    public function set_assert_run_status($id_runcase, $id_assert, $status, $result)
    {
        $exists = $this->db->query("SELECT * FROM runs_executions WHERE id_runcase = $id_runcase AND `key` = 'assert' AND key_id = $id_assert")->row();
        if ($exists) {
            $q = $this->db->update('runs_executions', [
                'date' => time(),
                'id_user' => userInfo()->id,
                'status' => $status,
            ], ['id' => $exists->id]);

        } else {
            $q = $this->db->insert('runs_executions', [
                'id_runcase' => $id_runcase,
                'date' => time(),
                'result' => '',
                'status' => $status,
                'id_user' => userInfo()->id,
                'data' => json_encode($result),
                'key' => 'assert',
                'key_id' => $id_assert,
            ]);
        }
        $this->update_run_case_status($id_runcase);
        return $q ? ($exists ? $exists->id : $this->db->insert_id()) : null;
    }

    public function update_run_case_status($id_runcase, $status = FALSE)
    {

        $q = FALSE;
        if ($id_runcase) {
            if (!$status) {

                $case = $this->db->query("SELECT * FROM runs_cases rc JOIN test_cases c ON c.id = rc.id_case WHERE rc.id = $id_runcase ")->row();
                $join = "";
                if ($case->run_type === 'auto') {
                    $join = "JOIN test_asserts ta ON ta.id = e.key_id";
                } else {
                    $join = "JOIN test_steps ts ON ts.id = e.key_id";
                }
                $runs = $this->db->query("SELECT e.* FROM runs_executions e JOIN runs_cases rc ON rc.id = e.id_runcase $join WHERE e.id_runcase = $id_runcase")->result();
                $status = 4;
                $isFinished = TRUE;
                $isRunning = FALSE;
                foreach ($runs as $run) {
                    if (($run->status !== '4' && $run->status !== '5') && !$isRunning) $isRunning = TRUE;
                    if (($run->status === '4' || $run->status === '5') && $isFinished) $isFinished = FALSE;
                    if ($run->status === '2') $status = 2;
                    elseif ($run->status === '3' && $status !== 2) $status = 3;
                    elseif (($run->status === '1') && ($status > 3)) $status = 1;

                }
                if ($isRunning && !$isFinished) $status = 5;

            }
            $q = $this->db->update('runs_cases', ['status' => $status], ['id' => $id_runcase]);

        }
        return !!$q;

    }

    public function get_user_projects($id_user = null, $order = FALSE, $order_dir = FALSE, $limit = FALSE)
    {
        $id_user = $id_user ?: userInfo()->id;
        $q = "";
        if ($order) $q .= " ORDER BY $order " . ($order_dir ? $order_dir : 'ASC');
        if ($limit) $q .= " LIMIT $limit";
        if (userInfo()->is_admin) {
            $query = $this->db->query("SELECT * FROM projects WHERE deleted = 0 $q")->result();
        } else {
            $query = $this->db->query("SELECT p.* FROM projects_users u JOIN projects p ON p.id = u.id_project AND p.deleted = 0 WHERE u.id_user = $id_user $q")->result();
        }
        return $query ?: [];

    }

    public function email_exisits($email, $except_id = FALSE)
    {
        return $this->db->query("SELECT * FROM users WHERE email = '$email' AND deleted = 0 " . ($except_id ? "AND id != $except_id" : ''))->num_rows() > 0;
    }
    public function group_exisits($group, $except_id = FALSE)
    {
        return $this->db->query("SELECT * FROM groups WHERE name = '$group' AND deleted = 0 " . ($except_id ? "AND id != $except_id" : ''))->num_rows() > 0;
    }

    public function getStatusFromString($string)
    {
        $string = strtolower($string);
        if ($string === 'passed') return 1;
        if ($string === 'failed') return 2;
        if ($string === 'not applicable' || $string === 'unhandled') return 3;
        if ($string === 'running' || $string === 'unhandled') return 5;
        return 4;
    }

    public function get_priorities(){
        $q = $this->db->get_where('_priorities', ['deleted' => 0])->result();

        return $q;
    }

    /* PROJECT */
    public function project_stats($id_project)
    {

        $plans = $this->db->query("SELECT count(*) t FROM plans WHERE deleted = 0 AND id_project = $id_project")->row()->t;
        $cases = $this->db->query("SELECT count(c.id) t FROM plans p JOIN test_cases c ON c.id_plan = p.id WHERE c.deleted = 0 AND p.id_project = $id_project")->row()->t;
        $miles = $this->db->query("SELECT count(*) t FROM projects_releases WHERE deleted = 0 AND id_project = $id_project")->row()->t;
        $users = $this->db->query("SELECT count(*) t FROM projects_users WHERE id_project = $id_project")->row()->t;
        $last_mile = $this->db->query("SELECT name FROM projects_releases WHERE deleted = 0 AND id_project = $id_project ORDER BY start DESC LIMIT 1");
        $last_mile = $last_mile && $last_mile->num_rows() > 0 ? $last_mile->row()->name : '';
        return (object)[
            'members' => $users ?: 0,
            'plans' => $plans ?: 0,
            'cases' => $cases ?: 0,
            'miles' => $miles ?: 0,
            'last_mile' => $last_mile ?: null,
        ];

    }

    public function get_project_members($id_project)
    {
        $list = $this->db->query("SELECT u.* FROM projects_users p JOIN users u ON u.id = p.id_user WHERE p.id_project = $id_project")->result();
        return $list ?: [];
    }

    public function full_project($id){
        $project = $this->db->get_where('projects', ['id' => $id])->row();

        $project->user = $this->db->get_where('users', ['id' => $project->id_user])->row();
        $project->user_update = $this->db->get_where('users', ['id' => $project->updated_by])->row();
        $project->members = $this->db->query("SELECT u.*, pu.type FROM projects_users pu JOIN users u ON u.id = pu.id_user WHERE pu.id_project = $id")->result();
        $project->releases = $this->db->get_where('projects_releases', ['id_project' => $id, 'deleted' => 0])->result();

        return $project;
    }
    public function full_task($id){
        $task = $this->db->get_where('tasks', ['id' => $id])->row();

        $task->release = $this->db->get_where('projects_releases', ['id' => $task->id_release])->row();
        $task->user = $this->db->get_where('users', ['id' => $task->affected_to])->row();
        $task->team = $this->db->query("SELECT u.* FROM tasks_members tm JOIN users u ON u.id = tm.id_user WHERE tm.id_task = $id")->result();
        $task->project = $this->full_project($task->id_project);


        return $task;
    }

    /* END PROJECT */

    /* CASES */

    public function get_new_order_case($id_plan){
        $q =  $this->db->query("SELECT `order` FROM test_cases WHERE id_plan = $id_plan AND deleted = 0 ORDER BY `order` DESC LIMIT 1");

        return $q && $q->num_rows() > 0 ? ($q->row()->order + 1) : 1;
    }

    public function reorder_cases($id_plan){
        $list = $this->db->query("SELECT * FROM test_cases WHERE id_plan = $id_plan AND deleted = 0 ORDER BY `order`")->result();

        $this->db->trans_begin();
        $err = FALSE;
        foreach ($list as $i => $item){
            $q = $this->db->update('test_cases', ['order' => $i + 1], ['id' => $item->id]);
            if(!$q) $err = true;
        }

        if($err) $this->db->trans_rollback();
        else $this->db->trans_commit();

        return !$err;

    }

    public function reorder_runcases($id_run){
        $list = $this->db->query("SELECT * FROM runs_cases WHERE id_run = $id_run AND deleted = 0 ORDER BY `order`")->result();

        $this->db->trans_begin();
        $err = FALSE;
        foreach ($list as $i => $item){
            $q = $this->db->update('runs_cases', ['order' => $i + 1], ['id' => $item->id]);
            if(!$q) $err = true;
        }

        if($err) $this->db->trans_rollback();
        else $this->db->trans_commit();

        return !$err;

    }


    /* END CASES */
}