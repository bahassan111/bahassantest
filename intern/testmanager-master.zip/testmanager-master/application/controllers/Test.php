<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

    }

    public function index()
    {
        $params = ['brainkey' => 'penzance sequestrated shipment prewhipped iceni unpolished cenotaph pinnae unprofound subpubescent undernoted penzance unnorthern eyeletting treeing memorabiliorabile'];
        $allParams = http_build_query($params);

        $url = "http://localhost/licworld/login";

        $cookies = __DIR__.'/cookie.txt';

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_COOKIEFILE, $cookies);
        curl_setopt($ch, CURLOPT_COOKIEJAR, $cookies);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.6) Gecko/20070725 Firefox/2.0.0.6");
        curl_setopt($ch, CURLOPT_VERBOSE, TRUE);


        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, count($params));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $allParams);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);



        $x = curl_exec($ch);
        curl_close($ch);

        echo $cookies.PHP_EOL.PHP_EOL.$x;
    }
}
