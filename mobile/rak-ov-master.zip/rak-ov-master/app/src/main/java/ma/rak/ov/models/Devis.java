package ma.rak.ov.models;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class Devis extends RealmObject {
    @PrimaryKey
    private String TYPE_ABN;
    private String DATE_ABN;
    private String LOGIUSER;
    private String ANNDEMDE;
    private String NUMDEMDE;
    private String CODEGERA;
    private String LIBEGERA;
    private String LIBSTAAB;
    private String STATUT;
    private String ADRESDEVI;
    private String MONDEVHT;
    private String MONDEVTT;
    private String REGLEMENT;

    public Devis() {
    }

    public Devis(String TYPE_ABN, String DATE_ABN, String LOGIUSER, String ANNDEMDE, String NUMDEMDE, String CODEGERA, String LIBEGERA, String LIBSTAAB, String STATUT, String ADRESDEVI, String MONDEVHT, String MONDEVTT, String REGLEMENT) {
        this.TYPE_ABN = TYPE_ABN;
        this.DATE_ABN = DATE_ABN;
        this.LOGIUSER = LOGIUSER;
        this.ANNDEMDE = ANNDEMDE;
        this.NUMDEMDE = NUMDEMDE;
        this.CODEGERA = CODEGERA;
        this.LIBEGERA = LIBEGERA;
        this.LIBSTAAB = LIBSTAAB;
        this.STATUT = STATUT;
        this.ADRESDEVI = ADRESDEVI;
        this.MONDEVHT = MONDEVHT;
        this.MONDEVTT = MONDEVTT;
        this.REGLEMENT = REGLEMENT;
    }

    public String getTYPE_ABN() {
        return TYPE_ABN;
    }

    public String getDATE_ABN() {
        return DATE_ABN;
    }

    public String getLOGIUSER() {
        return LOGIUSER;
    }

    public String getANNDEMDE() {
        return ANNDEMDE;
    }

    public String getNUMDEMDE() {
        return NUMDEMDE;
    }

    public String getCODEGERA() {
        return CODEGERA;
    }

    public String getLIBEGERA() {
        return LIBEGERA;
    }

    public String getLIBSTAAB() {
        return LIBSTAAB;
    }

    public String getSTATUT() {
        return STATUT;
    }

    public String getADRESDEVI() {
        return ADRESDEVI;
    }

    public String getMONDEVHT() {
        return MONDEVHT;
    }

    public String getMONDEVTT() {
        return MONDEVTT;
    }

    public String getREGLEMENT() {
        return REGLEMENT;
    }

    public void setTYPE_ABN(String TYPE_ABN) {
        this.TYPE_ABN = TYPE_ABN;
    }

    public void setDATE_ABN(String DATE_ABN) {
        this.DATE_ABN = DATE_ABN;
    }

    public void setLOGIUSER(String LOGIUSER) {
        this.LOGIUSER = LOGIUSER;
    }

    public void setANNDEMDE(String ANNDEMDE) {
        this.ANNDEMDE = ANNDEMDE;
    }

    public void setNUMDEMDE(String NUMDEMDE) {
        this.NUMDEMDE = NUMDEMDE;
    }

    public void setCODEGERA(String CODEGERA) {
        this.CODEGERA = CODEGERA;
    }

    public void setLIBEGERA(String LIBEGERA) {
        this.LIBEGERA = LIBEGERA;
    }

    public void setLIBSTAAB(String LIBSTAAB) {
        this.LIBSTAAB = LIBSTAAB;
    }

    public void setSTATUT(String STATUT) {
        this.STATUT = STATUT;
    }

    public void setADRESDEVI(String ADRESDEVI) {
        this.ADRESDEVI = ADRESDEVI;
    }

    public void setMONDEVHT(String MONDEVHT) {
        this.MONDEVHT = MONDEVHT;
    }

    public void setMONDEVTT(String MONDEVTT) {
        this.MONDEVTT = MONDEVTT;
    }

    public void setREGLEMENT(String REGLEMENT) {
        this.REGLEMENT = REGLEMENT;
    }

    @Override
    public String toString() {
        return "Devis{" +
                "TYPE_ABN='" + TYPE_ABN + '\'' +
                ", DATE_ABN='" + DATE_ABN + '\'' +
                ", LOGIUSER='" + LOGIUSER + '\'' +
                ", ANNDEMDE='" + ANNDEMDE + '\'' +
                ", NUMDEMDE='" + NUMDEMDE + '\'' +
                ", CODEGERA='" + CODEGERA + '\'' +
                ", LIBEGERA='" + LIBEGERA + '\'' +
                ", LIBSTAAB='" + LIBSTAAB + '\'' +
                ", STATUT='" + STATUT + '\'' +
                ", ADRESDEVI='" + ADRESDEVI + '\'' +
                ", MONDEVHT='" + MONDEVHT + '\'' +
                ", MONDEVTT='" + MONDEVTT + '\'' +
                ", REGLEMENT='" + REGLEMENT + '\'' +
                '}';
    }
}
