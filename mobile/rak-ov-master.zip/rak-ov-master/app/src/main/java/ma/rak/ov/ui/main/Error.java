package ma.rak.ov.ui.main;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import ma.rak.ov.LoginActivity;
import ma.rak.ov.R;
import ma.rak.ov.api.RetrofitClient;
import ma.rak.ov.storage.SharedPrefManager;

public class Error extends AppCompatActivity {

    Button relogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_error);

        relogin = findViewById(R.id.relogin);

        relogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logout();
            }
        });

    }

    public void logout(){
        String host = SharedPrefManager.getInstance(this).getBaseUrl();
        SharedPrefManager.getInstance(this).clear();
        RetrofitClient.resetInstance();
        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        SharedPrefManager.getInstance(this).saveBaseUrl(host);


        startActivity(intent);
    }
}