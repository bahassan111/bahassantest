<?php ?>
<div class="project_menu">
    <ul class="pmenu">
        <li class="<?= $active == 'dashboard' ? 'active' : ''; ?>">
            <a href="<?= getProjectUrl($project); ?>">
                <span class="i"><i class="fas fa-globe"></i></span>
                <span class="t">Project Dashboard</span>
            </a>
        </li>
        <?php if(hasPermission('releases', Pages::ACTION_ANY)){?>
            <li class="<?= $active == 'releases' ? 'active' : ''; ?>">
                <a href="<?= getProjectUrl($project, 'releases'); ?>">
                    <span class="i"><i class="fas fa-code-branch"></i></span>
                    <span class="t">Releases</span>
                </a>
            </li>
        <?php } ?>
        <?php if(hasPermission('tasks', 'any')){?>
            <li class="<?= $active == 'tasks' ? 'active' : ''; ?>">
                <a href="<?= getProjectUrl($project, 'tasks'); ?>">
                    <span class="i"><i class="fas fa-tasks"></i></span>
                    <span class="t">Tasks</span>
                </a>
            </li>
            <li class="<?= $active == 'tasks_kanban' ? 'active' : ''; ?>">
                <a href="<?= getProjectUrl($project, 'kanban'); ?>">
                    <span class="i"><i class="fab fa-buromobelexperte"></i></span>
                    <span class="t">Kanban</span>
                </a>
            </li>
        <?php } ?>
        <?php if(hasPermission('plans', 'any')){?>
            <li class="<?= $active == 'test_plans' ? 'active' : ''; ?>">
                <a href="<?= getProjectUrl($project, 'tests'); ?>">
                    <span class="i"><i class="fas fa-sitemap"></i></span>
                    <span class="t">Test Plans</span>
                </a>
            </li>
        <?php } ?>
       <?php if(hasPermission('runs', 'any')){?>
           <li class="<?= $active == 'test_runs' ? 'active' : ''; ?>">
               <a href="<?= getProjectUrl($project, 'runs'); ?>">
                   <span class="i"><i class="fas fa-cogs"></i></span>
                   <span class="t">Test Runs</span>
               </a>
           </li>
       <?php } ?>

        <?php if(hasPermission('files', 'any')){?>
            <li class="<?= $active == 'files' ? 'active' : ''; ?>">
                <a href="<?= getProjectUrl($project, 'files'); ?>">
                    <span class="i"><i class="far fa-hdd"></i></span>
                    <span class="t">Files</span>
                </a>
            </li>
        <?php } ?>
        <?php if(hasPermission('chats', 'any')){?>
            <li class="<?= $active == 'discussion' ? 'active' : ''; ?>">
                <a href="<?= getProjectUrl($project, 'chat'); ?>">
                    <span class="i"><i class="far fa-comment-alt"></i></span>
                    <span class="t">Discussion</span>
                </a>
            </li>
        <?php } ?>
    </ul>
</div>