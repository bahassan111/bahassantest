import 'dart:async';
import 'dart:typed_data';

import 'package:audioplayers/audio_cache.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:bot_toast/bot_toast.dart';
import 'package:driver/constants/constants.dart';
import 'package:driver/constants/helpers/helpers.dart';
import 'package:driver/models/models.dart';
import 'package:driver/ui/components/booking_notification.dart';
import 'package:driver/ui/components/error_dialog.dart';
import 'package:driver/ui/upcoming_jobs/upcoming_item.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'controllers.dart';
import 'package:dio/dio.dart' as dio;
import 'dart:convert';

import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:driver/constants/helpers/time_zone.dart';

class PreBookingController extends GetxController {
  static PreBookingController to = Get.find();
  static AuthController authTo = Get.find();
  static HomeController home = Get.find();
  bool procededPreBooking = false;
  final store = GetStorage();
  PreBookingModel selectedPreBooking;
  NetWorkCall netWorkCall = NetWorkCall();
  List<PreBookingModel> preBookingJobs;
  List<RideDetailModel> upComingRides;
  int id;
  var timeBeforPrebook;
  var timer;
  NotificationDetails platform;
  @override
  void onReady() {
    super.onReady();
    intializeNotification();
  }

  intializeNotification() async {
    var android = new AndroidNotificationDetails(
      'Channel ID',
      'Channel Name',
      'channelDescription',
      playSound: true,
      onlyAlertOnce: false,
      icon: '@mipmap/launcher_icon',
      priority: Priority.high,
      importance: Importance.max,
      largeIcon: DrawableResourceAndroidBitmap('@mipmap/launcher_icon'),
      sound: RawResourceAndroidNotificationSound('tone'),
    );
    var iOS = new IOSNotificationDetails();
    platform = new NotificationDetails(android: android, iOS: iOS);
  }

  setLocalNotification({
    int id,
    DateTime prebookingTime,
  }) async {
    List<dynamic> ids = [];
    print("prebboking id $id");
    print("prebookingTime $prebookingTime");
    tz.initializeTimeZones();
    DateTime yourTime;
    VoidCallback yourAction;

    // Timer(DateTime.now().difference(prebookingTime), () {
    //   home.canReceiveNotif = true;
    //   print("Receive notif is true now ");
    //   update();
    // });
    final timeZone = TimeZone();

    // The device's timezone.
    String timeZoneName = await timeZone.getTimeZoneName();

    // Find the 'current location'
    final location = await timeZone.getLocation(timeZoneName);

    print("DATEEEEE" + prebookingTime.toString());
    var first = tz.TZDateTime.from(
        prebookingTime.subtract(Duration(minutes: 30)), location);
    var second = tz.TZDateTime.from(
        prebookingTime.subtract(Duration(minutes: 20)), location);
    var third = tz.TZDateTime.from(
        prebookingTime.subtract(Duration(minutes: 10)), location);
    var fourth = tz.TZDateTime.from(
        prebookingTime.subtract(Duration(minutes: 40)), location);
    // var currentDateTime =
    //    tz.TZDateTime.now(tz.local).subtract(Duration(minutes: 30));
    // var currentDateTime =
    //   tz.TZDateTime.now(tz.local).add(Duration(seconds: 10));
    print(
        "currentDateTime $first  $second $third ${first.runtimeType} PB$id${authTo.userModel.carcategory}");

    //(PB$id${authTo.userModel.carcategory} )
    flutterLocalNotificationsPlugin.zonedSchedule(
      id * 300,
      "Your Prebooking",
      "Your prebooking is in 30 min ",
      first,
      platform,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      androidAllowWhileIdle: true,
    );
    flutterLocalNotificationsPlugin.zonedSchedule(
      id * 200,
      "Your Prebooking",
      "Your prebooking is in 20 min",
      second,
      platform,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      androidAllowWhileIdle: true,
    );
    flutterLocalNotificationsPlugin.zonedSchedule(
      id * 100,
      "Your Prebooking",
      "Your prebooking is in 10 min",
      third,
      platform,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      androidAllowWhileIdle: true,
    );
    flutterLocalNotificationsPlugin.zonedSchedule(
      id,
      "Your Prebooking",
      "Your prebooking is in 40 min",
      fourth,
      platform,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      androidAllowWhileIdle: true,
    );
    final store = GetStorage();
    if (store.hasData("all_notification")) {
      ids = store.read("all_notification");
    }
    ids.add(id);
    store.write("all_notification", ids);
  }

  cancelLocalNotification(int id) {
    List<dynamic> ids = [];
    int indexOfCurrentId;
    if (store.hasData("all_notification")) {
      ids = store.read("all_notification");
    }
    for (int i = 0; i < ids.length; i++) {
      if (id == ids[i]) {
        indexOfCurrentId = i;
      }
    }
    if (indexOfCurrentId != null) {
      flutterLocalNotificationsPlugin.cancel(id);
      flutterLocalNotificationsPlugin.cancel(id * 200);
      flutterLocalNotificationsPlugin.cancel(id * 300);
      flutterLocalNotificationsPlugin.cancel(id * 100);

      ids.removeAt(indexOfCurrentId);
      store.write("all_notification", ids);
    }
  }

  cancelAll(int id) async {
    await this.cancelLocalNotification(id);
    this.procededPreBooking = true;
  }

  getPrebookings() async {
    preBookingJobs = [];

    final result = await netWorkCall.postRequestWithResponse(
        url: Urls.prebookingJobs,
        json: {
          Params.id: authTo.userModel.id,
          Params.fleetId: authTo.userModel.fleetid
        });
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return [];
    }, (_response) {
      print("_response.data ${_response.data}");
      if (_response != null &&
          _response.data['prebookingdata'].runtimeType != String) {
        final data = _response.data;
        List<PreBookingModel> preJobs = [];
        data['prebookingdata'].forEach((e) {
          if ((strinToDateTime((PreBookingModel.fromJson(e)).newprebookingdate))
                  .difference(DateTime.now())
                  .inMinutes >
              0) preJobs.add(PreBookingModel.fromJson(e));
        });
        preBookingJobs = preJobs;
      }
      return preBookingJobs;
    });
  }

  selectPreBooking({@required PreBookingModel preBookingModel}) async {
    final result = await netWorkCall
        .postRequestWithResponse(url: Urls.driverPrebookingstatusTrip, json: {
      Params.rideId: preBookingModel.bookingid,
      Params.fleetId: authTo.userModel.fleetid,
      Params.fareId: preBookingModel.fareid,
      Params.driverId: authTo.userModel.id,
      Params.totalfare: preBookingModel.totalfare,
      Params.agentfees: preBookingModel.agentfees,
      Params.fleetfees: preBookingModel.fleetfees,
      Params.adminfees: preBookingModel.adminfees,
      Params.prebookingFee: preBookingModel.prebookingfees,
      Params.gatewayFee: preBookingModel.gatewayfees,
      Params.driverfees: preBookingModel.driverfees,
      Params.preStatus: 1
    });
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
    }, (r) {
      procededPreBooking = false;
      showNotif();
      // selectedPreBooking = preBookingModel;
      // selectedPreBooking.prebookingdate =
      //     stringToDateTime2(preBookingModel.prebookingdate).toString();
      return true;
    });
  }

  getUpbookings() async {
    print(
        "authTo.userModel.id ${authTo.userModel.id} authTo.userModel.fleetid ${authTo.userModel.fleetid}");
    final result = await netWorkCall.postRequestWithResponse(
        url: Urls.driverUpcomingbooking,
        json: {
          Params.driverId: authTo.userModel.id,
          Params.fleetId: authTo.userModel.fleetid
        });
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return [];
    }, (_response) {
      print("_response ${_response.data['prebook']}");
      if (_response?.statusCode == 200) {
        final data = _response.data;
        upComingRides = [];
        data['prebook'].forEach((e) {
          upComingRides.add(RideDetailModel.fromJson(e));
        });
      }
      // to.showNotif();
      return upComingRides;
    });
  }

  showNotif() async {
    if (procededPreBooking) {
      timer?.cancel();
      return;
    }
    var prebook = await preTo.getUpbookings();

    if (prebook.length > 0 && prebook[0] is RideDetailModel) {
      timeBeforPrebook =
          ((strinToDateTime((prebook[0] as RideDetailModel).bookDate))
              .difference(DateTime.now())
              .inSeconds);
      if (timeBeforPrebook <= 0) return;
      if (timeBeforPrebook < 2400 && !procededPreBooking)
        BotToast.showWidget(
          toastBuilder: (ctx) {
            return Toast(
              title:
                  "Your Booking  in ${(timeBeforPrebook ~/ 60).toString()} min",
            );
          },
        );
    
      print(timeBeforPrebook);
      if (timeBeforPrebook > 2400) {
        print("aaa");
        print(timeBeforPrebook);
        timer?.cancel();
        timer = Timer(Duration(seconds: timeBeforPrebook - 2400), () {
          if (!procededPreBooking)
            BotToast.showWidget(
              toastBuilder: (ctx) {
                return Toast(
                  title: "Your Booking  in 40 min",
                );
              },
            );
        });
      } else if (timeBeforPrebook <= 2400 && timeBeforPrebook > 1800) {
        print("aaa");
        timer?.cancel();
        timer = Timer(Duration(seconds: timeBeforPrebook - 1800), () {
          if (!procededPreBooking)
            BotToast.showWidget(
              toastBuilder: (ctx) {
                return Toast(
                  title: "Your Booking  in 30 min",
                );
              },
            );
        });
      } else if (timeBeforPrebook <= 1800 && timeBeforPrebook > 1200) {
        print("aaa");
        timer?.cancel();
        timer = Timer(Duration(seconds: timeBeforPrebook - 1200), () {
          if (!procededPreBooking)
            BotToast.showWidget(
              toastBuilder: (ctx) {
                return Toast(
                  title: "Your Booking  in 20 min",
                );
              },
            );
          print("YOur booking iin 20 min ");
        });
      } else if (timeBeforPrebook <= 1200 && timeBeforPrebook > 600) {
        if (!procededPreBooking) print("aaa");
        timer?.cancel();
        timer = Timer(Duration(seconds: timeBeforPrebook - 600), () {
          BotToast.showWidget(
            toastBuilder: (ctx) {
              return Toast(
                title: "Your Booking  in 10 min",
              );
            },
          );
          print("YOur booking iin 10 min ");
        });
      }
    }
  }

  cancelPreBooking({@required RideDetailModel rideDetailModel}) async {
    final result = await netWorkCall.postRequestWithResponse(
        url: Urls.driverPrebookingstatusCancel,
        json: {Params.rideId: rideDetailModel.id, Params.preStatus: 0});
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return false;
    }, (r) {
      return true;
    });
  }

  checkPreBooking() async {
    BotToast.showLoading();

    final result = await netWorkCall
        .postRequestWithResponse(url: Urls.driverPrebookCheck, json: {
      Params.driverId: int.tryParse(authTo.userModel.id),
    });
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return false;
    }, (response) {
      Map valueMap = json.decode(response.toString());
      print("driver iD = " + authTo.userModel.id);
      print(
          "respone code from check is  " + valueMap["responsecode"].toString());
      if (valueMap["responsecode"].toString() == "0") return false;

      return true;
    });
  }

  driverPrebookingstatusChange(
      {@required RideDetailModel rideDetailModel}) async {
    final result = await netWorkCall.postRequestWithResponse(
        url: Urls.driverPrebookingstatusChange,
        json: {Params.rideId: rideDetailModel.id, Params.preStatus: 1});
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return false;
    }, (r) {
      return true;
    });
  }
}

class Toast extends StatefulWidget {
  final String title;
  const Toast({
    Key key,
    @required this.title,
  }) : super(key: key);

  @override
  _ToastState createState() => _ToastState();
}

class _ToastState extends State<Toast> {
  AudioCache cache = AudioCache();
  AudioPlayer player;
  var timer;

  @override
  void dispose() {
    timer?.cancel();
    player?.stop();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    startTone();
  }

  startTone() async {
    print(" Tones.instantBookingTone ${Tones.preBookingTone}");
    player =
        await cache.play(Tones.preBookingTone).onError((error, stackTrace) {
      print("loop error $error");
      return null;
    }).whenComplete(() {
      print("loop complete");
    });

    timer = Timer(Duration(seconds: 10), () {
      player.stop();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.transparent,
        body: preTo.upComingRides != null
            ? Center(
                child: Container(
                  height: Get.height * 0.8,
                  child: SingleChildScrollView(
                    child: UpcomingItem(
                      isNotif: true,
                      title: widget.title,
                      rideDetailModel: preTo?.upComingRides[0],
                    ),
                  ),
                ),
              )
            : SizedBox());
  }
}
