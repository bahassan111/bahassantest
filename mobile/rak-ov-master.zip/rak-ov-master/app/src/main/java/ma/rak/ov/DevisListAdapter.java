package ma.rak.ov;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import io.realm.RealmList;
import ma.rak.ov.models.Devis;

public class DevisListAdapter extends ArrayAdapter<Devis> {
    private final Activity context;
    private final RealmList<Devis> devis;

    public DevisListAdapter(Activity context, RealmList<Devis> devis) {
        super(context, R.layout.devislist, devis);
        // TODO Auto-generated constructor stub

        this.context=context;
        this.devis = devis;

    }

    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.devislist, null,true);

        Devis oneDevis = devis.get(position);

        TextView titleText = (TextView) rowView.findViewById(R.id.title);
        TextView statusText = (TextView) rowView.findViewById(R.id.status);
        TextView dateText = (TextView) rowView.findViewById(R.id.date);
        TextView tsText = (TextView) rowView.findViewById(R.id.tstatus);
        TextView psText = (TextView) rowView.findViewById(R.id.pstatus);
        TextView priceText = (TextView) rowView.findViewById(R.id.price);

        titleText.setText(oneDevis.getANNDEMDE() + "/" + oneDevis.getNUMDEMDE() + "  -  " + oneDevis.getLIBEGERA());
        dateText.setText(oneDevis.getDATE_ABN() + " - " + oneDevis.getADRESDEVI());
        statusText.setText(oneDevis.getLIBSTAAB() + " - ");
        tsText.setText(oneDevis.getSTATUT());
        psText.setText(oneDevis.getREGLEMENT() == "OUI" ? " - Réglé" : " - Non Réglé");
        priceText.setText(oneDevis.getMONDEVTT() + "DH");

        return rowView;

    };
}
