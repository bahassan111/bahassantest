const searchAnimation = "./lottie/search_ask_loop.json";
export { searchAnimation };
