package ma.rak.ov;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import ma.rak.ov.storage.SharedPrefManager;

public class ListeDemandeAdapter extends FragmentStatePagerAdapter {
    private Context context;
    int totalTabs;

    public final BranchementListFragment branchementListFragment = new BranchementListFragment();

    public final ArchivedListFragment archivedListFragment = new ArchivedListFragment();

    private Integer mode = SharedPrefManager.getInstance(context).getMode();

    public ListeDemandeAdapter(FragmentManager fm, Context context, int totalTabs) {
        super(fm);
        this.context = context;
        this.totalTabs = totalTabs;

    }

    @NonNull
    @Override
    public Fragment getItem(int position) {

        switch (position) {
            case 0:
                return branchementListFragment;
            case 1:
                return archivedListFragment;
            default:
                throw new IllegalStateException("Unexpected value: " + position);
        }
    }

    @Override
    public int getCount() {
        return this.totalTabs;
    }
}
