package ma.rak.ovr.api;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Handler;
import android.provider.BaseColumns;
import android.util.Base64;
import android.util.Log;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import ma.rak.ovr.bodyResponse.LoginResponse;
import ma.rak.ovr.bodyResponse.OperationResponse;
import ma.rak.ovr.bodyResponse.StatistiqueResponse;
import ma.rak.ovr.models.Reclamation;
import ma.rak.ovr.storage.SharedPrefManager;
import ma.rak.ovr.ui.main.Error;
import ma.rak.ovr.utils.NetworkUtility;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public final class TwDatabase {
    // To prevent someone from accidentally instantiating the contract class,
    // make the constructor private.
    private TwDatabase() {
    }

    public static class MetaTable implements BaseColumns {
        public static final String TABLE_NAME = "meta";
        public static final String COL_KEY = "key";
        public static final String COL_VALUE = "value";
    }


    public static class ALLAgents implements BaseColumns {
        public static final String TABLE_NAME = "all_agents";
        public static final String COL_KEY = "CODEUTIL";
        public static final String COL_LABEL = "NOM_UTIL";
        public static final String COL_TYPE = "CODEPROF";
        public static final String COL_IMEI = "IMEI";
        public static final String CODE_TSP = "CODE_TSP";
    }

    public static class Natures implements BaseColumns {
        public static final String TABLE_NAME = "natures";
        public static final String CODNATRE = "CODNATRE";
        public static final String DESNATRE = "DESNATRE";
        public static final String TARIFRAU = "TARIFRAU";
        public static final String DELTHERE = "DELTHERE";
        public static final String PRIODOSS = "PRIODOSS";
        public static final String TAUTVARE = "TAUTVARE";
        public static final String USERSAIS = "USERSAIS";
        public static final String CODTYPFA = "CODTYPFA";
        public static final String CODESTRU = "CODESTRU";
        public static final String CODEENTI = "CODEENTI";
        public static final String CODNATRE_SIGID = "CODNATRE_SIGID";
        public static final String CODEGERA = "CODEGERA";
        public static final String STANATRE = "STANATRE";
        public static final String CODCATRE = "CODCATRE";
        public static final String DELAESTI = "DELAESTI";
        public static final String FERMAUTO = "FERMAUTO";
        public static final String SYSTTRAI = "SYSTTRAI";
        public static final String ENTITRAI = "ENTITRAI";
        public static final String CODNATRE_ = "CODNATRE_";
    }

    public static class Status implements BaseColumns {
        public static final String TABLE_NAME = "status";
        public static final String CODSTARE = "CODSTARE";
        public static final String LIBSTAAB = "LIBSTAAB";
    }

    public static class Stades implements BaseColumns {
        public static final String TABLE_NAME = "stades";
        public static final String STATDOSS = "STATDOSS";
        public static final String LIBSTADO = "LIBSTADO";
    }

    public static class Results implements BaseColumns {
        public static final String TABLE_NAME = "results";
        public static final String CODRESRE = "CODRESRE";
        public static final String LIBRESRE = "LIBRESRE";
    }

    public static class Emetteurs implements BaseColumns {
        public static final String TABLE_NAME = "emetteurs";
        public static final String CODEMERE = "CODEMERE";
        public static final String LIBEMERE = "LIBEMERE";
    }

    public static class Origins implements BaseColumns {
        public static final String TABLE_NAME = "origins";
        public static final String CODORIRE = "CODORIRE";
        public static final String LIBORIRE = "LIBORIRE";
        public static final String ABREVIAT = "ABREVIAT";
        public static final String ORDRAFFI = "ORDRAFFI";
    }

    public static class Demandes implements BaseColumns {
        public static final String TABLE_NAME = "demandes";
        public static final String CATEGORIE = "CATEGORIE";
        public static final String CODEGERA = "CODEGERA";
        public static final String LIBEGERA = "LIBEGERA";
        public static final String CODEAGEN = "CODEAGEN";
        public static final String CODELOCA = "CODELOCA";
        public static final String CODESECT = "CODESECT";
        public static final String LIBEAGEN = "LIBEAGEN";
        public static final String DESNATRE = "DESNATRE";
        public static final String CODNATRE = "CODNATRE";
        public static final String PRIODOSS = "PRIODOSS";
        public static final String NUMDOSRE = "NUMDOSRE";
        public static final String DESCRECL = "DESCRECL";
        public static final String DATCREDO = "DATCREDO";
        public static final String NOMPRECL = "NOMPRECL";
        public static final String TELERECL = "TELERECL";
        public static final String CIN_CLIE = "CIN_CLIE";
        public static final String ADRECLIE = "ADRECLIE";
        public static final String ADRERECL = "ADRERECL";
        public static final String USERSAIS = "USERSAIS";
        public static final String NUMEDOSS = "NUMEDOSS";
        public static final String ANNEDOSS = "ANNEDOSS";
        public static final String NUMOPRAB = "NUMOPRAB";
        public static final String REFECOMP = "REFECOMP";
        public static final String CODSTRDE = "CODSTRDE";
        public static final String CODEMERE = "CODEMERE";
        public static final String LIBEEMET = "LIBEEMET";
        public static final String CODCATRE = "CODCATRE";
        public static final String CODENTTR = "CODENTTR";
        public static final String USERAFF = "USERAFF";
        public static final String LONGITUDE = "LONGITUDE";
        public static final String LATITUDE = "LATITUDE";
        public static final String DATE_OPERATION = "DATE_OPERATION";
        public static final String OBJECT_VERIF = "OBJECT_VERIF";
        public static final String STATUS = "STATUS";
    }

    public static class Available implements BaseColumns {
        public static final String TABLE_NAME = "available";
        public static final String CATEGORIE = "CATEGORIE";
        public static final String NUMERO_RECLAMATION = "NUMERO_RECLAMATION";
        public static final String GERANCE = "GERANCE";
        public static final String CODE_GERANC = "CODE_GERANC";
        public static final String AGENCE = "AGENCE";
        public static final String NATURE_VERIFICATION = "NATURE_VERIFICATION";
        public static final String DESCRIPTION = "DESCRIPTION";
        public static final String ANNEE_DOSSIER = "ANNEE_DOSSIER";
        public static final String NUMERO_DOSSIER = "NUMERO_DOSSIER";
        public static final String NOM_CLIENT = "NOM_CLIENT";
        public static final String ADRESSE_RECLAMATION = "ADRESSE_RECLAMATION";
        public static final String ADRESSE_CLIENT = "ADRESSE_CLIENT";
        public static final String TELECLIENT = "TELECLIENT";
        public static final String CIN_CLIEN = "CIN_CLIEN";
        public static final String REFERENCE = "REFERENCE";
        public static final String COMPTEUR = "COMPTEUR";
        public static final String EMMETTEUR_RECLAMATION = "EMMETTEUR_RECLAMATION";
        public static final String DATE_CREATION_RECLAMATION = "DATE_CREATION_RECLAMATION";
    }

    /*
    * ", DATTRAOP text\n" +
                    ", LONGITUDE text\n" +
                    ", LATITUDE text\n" +
                    ", NUMDOSRE text\n" +
                    ", NULDECRE text\n" +
                    ", REPECLIE text\n" +
                    ", RESU_FIN text\n" +
                    ", base64Image text);");*/
    public static class Pending implements BaseColumns {
        public static final String TABLE_NAME = "_pending";
        public static final String STATOPER = "STATOPER";
        public static final String DATTRAOP = "DATTRAOP";
        public static final String LONGITUDE = "LONGITUDE";
        public static final String LATITUDE = "LATITUDE";
        public static final String NUMDOSRE = "NUMDOSRE";
        public static final String REPECLIE = "REPECLIE";
        public static final String RESU_FIN = "RESU_FIN";
        public static final String base64Image = "base64Image";
        public static final String REASON = "REASON";
    }

    public static class Motifs implements BaseColumns {
        public static final String TABLE_NAME = "br_motifs";
        public static final String COL_KEY = "key";
        public static final String COL_LABEL = "label";
        public static final String COL_GERANCE = "codegera";
        public static final String CODSTAOP = "CODSTAOP";
    }

    public static class BRMotifs implements BaseColumns {
        public static final String TABLE_NAME = "br_motifs";
        public static final String COL_KEY = "key";
        public static final String COL_LABEL = "label";
        public static final String COL_GERANCE = "codegera";
        public static final String CODSTAOP = "CODSTAOP";
    }

    public static class BRNatures implements BaseColumns {
        public static final String TABLE_NAME = "br_natures";
        public static final String COL_KEY = "key";
        public static final String COL_LABEL = "label";
        public static final String CODCATAB = "CODCATAB";
        public static final String CODNATIN = "CODNATIN";
        public static final String CALICOMP = "CALICOMP";
        public static final String NOMBFILS = "NOMBFILS";
        public static final String INTENSIT = "INTENSIT";
        public static final String TENSELEC = "TENSELEC";
        public static final String PUISSANC = "PUISSANC";
    }

    public static class BRCats implements BaseColumns {
        public static final String TABLE_NAME = "br_cats";
        public static final String COL_KEY = "key";
        public static final String COL_LABEL = "label";
        public static final String COL_GERANCE = "codegera";
    }

    public static class ABNatures implements BaseColumns {
        public static final String TABLE_NAME = "ab_natures";
        public static final String COL_KEY = "key";
        public static final String COL_LABEL = "label";
        public static final String COL_GERANCE = "codegera";
        public static final String CODCATAB = "CODCATAB";
    }

    public static class ABMotifs implements BaseColumns {
        public static final String TABLE_NAME = "br_motifs";
        public static final String COL_KEY = "key";
        public static final String COL_LABEL = "label";
        public static final String COL_GERANCE = "codegera";
    }

    public static class ABCats implements BaseColumns {
        public static final String TABLE_NAME = "ab_cats";
        public static final String COL_KEY = "key";
        public static final String COL_LABEL = "label";
        public static final String COL_GERANCE = "codegera";
    }

    public static class ABEmplacements implements BaseColumns {
        public static final String TABLE_NAME = "ab_emplacements";
        public static final String COL_KEY = "key";
        public static final String COL_LABEL = "label";
    }


    public static class TwDatabaseHelper extends SQLiteOpenHelper {
        public static final int DATABASE_VERSION = 26;
        //public static final String DATABASE_NAME = "RAKOV.db";

        public TwDatabaseHelper(Context context) {
            super(context, "RAKOVR_" + SharedPrefManager.getInstance(context).getUserID() + ".db", null, DATABASE_VERSION);
        }

        public TwDatabaseHelper(Context context, String dbname) {
            super(context, dbname, null, DATABASE_VERSION);
        }

        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS " + ALLAgents.TABLE_NAME + ";");
            db.execSQL("DROP TABLE IF EXISTS " + Natures.TABLE_NAME + ";");
            db.execSQL("DROP TABLE IF EXISTS " + Status.TABLE_NAME + ";");
            db.execSQL("DROP TABLE IF EXISTS " + Stades.TABLE_NAME + ";");
            db.execSQL("DROP TABLE IF EXISTS " + Results.TABLE_NAME + ";");
            db.execSQL("DROP TABLE IF EXISTS " + Emetteurs.TABLE_NAME + ";");
            db.execSQL("DROP TABLE IF EXISTS " + Origins.TABLE_NAME + ";");
            db.execSQL("DROP TABLE IF EXISTS " + Demandes.TABLE_NAME + ";");
            db.execSQL("DROP TABLE IF EXISTS " + Available.TABLE_NAME + ";");
            db.execSQL("DROP TABLE IF EXISTS " + Pending.TABLE_NAME + ";");
            onCreate(db);
        }

        public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            onUpgrade(db, oldVersion, newVersion);
        }

        @Override
        public void onCreate(SQLiteDatabase sqLiteDatabase) {

            sqLiteDatabase.execSQL("create table all_agents ( \"_id\" INTEGER PRIMARY KEY, CODEUTIL text, CODE_TSP text, IMEI text, NOM_UTIL text, CODEPROF text );");
            sqLiteDatabase.execSQL("create table natures ( \"_id\" INTEGER PRIMARY KEY, CODNATRE text\n" +
                    ", DESNATRE text\n" +
                    ", TARIFRAU text\n" +
                    ", DELTHERE text\n" +
                    ", PRIODOSS text\n" +
                    ", TAUTVARE text\n" +
                    ", USERSAIS text\n" +
                    ", CODTYPFA text\n" +
                    ", CODESTRU text\n" +
                    ", CODEENTI text\n" +
                    ", CODNATRE_SIGID text\n" +
                    ", CODEGERA text\n" +
                    ", STANATRE text\n" +
                    ", CODCATRE text\n" +
                    ", DELAESTI text\n" +
                    ", FERMAUTO text\n" +
                    ", SYSTTRAI text\n" +
                    ", ENTITRAI text\n" +
                    ", CODNATRE_ text);");


            sqLiteDatabase.execSQL("create table status ( \"_id\" INTEGER PRIMARY KEY, CODSTARE text\n" +
                    ", LIBSTAAB text);");

            sqLiteDatabase.execSQL("create table stades ( \"_id\" INTEGER PRIMARY KEY, STATDOSS text\n" +
                    ", LIBSTADO text);");

            sqLiteDatabase.execSQL("create table results ( \"_id\" INTEGER PRIMARY KEY, CODRESRE text\n" +
                    ", LIBRESRE text);");

            sqLiteDatabase.execSQL("create table emetteurs ( \"_id\" INTEGER PRIMARY KEY, CODEMERE text\n" +
                    ", LIBEMERE text);");

            sqLiteDatabase.execSQL("create table origins ( \"_id\" INTEGER PRIMARY KEY, CODORIRE text\n" +
                    ", LIBORIRE text\n" +
                    ", ABREVIAT text\n" +
                    ", ORDRAFFI text);");

            sqLiteDatabase.execSQL("create table demandes ( \"_id\" INTEGER PRIMARY KEY, CATEGORIE text\n" +
                    ", CODEGERA text\n" +
                    ", LIBEGERA text\n" +
                    ", CODEAGEN text\n" +
                    ", CODELOCA text\n" +
                    ", CODESECT text\n" +
                    ", LIBEAGEN text\n" +
                    ", DESNATRE text\n" +
                    ", CODNATRE text\n" +
                    ", PRIODOSS text\n" +
                    ", NUMDOSRE text\n" +
                    ", DESCRECL text\n" +
                    ", DATCREDO text\n" +
                    ", NOMPRECL text\n" +
                    ", TELERECL text\n" +
                    ", CIN_CLIE text\n" +
                    ", ADRECLIE text\n" +
                    ", ADRERECL text\n" +
                    ", USERSAIS text\n" +
                    ", NUMEDOSS text\n" +
                    ", ANNEDOSS text\n" +
                    ", NUMOPRAB text\n" +
                    ", REFECOMP text\n" +
                    ", CODSTRDE text\n" +
                    ", CODEMERE text\n" +
                    ", LIBEEMET text\n" +
                    ", CODCATRE text\n" +
                    ", CODENTTR text\n" +
                    ", USERAFF text\n" +
                    ", LONGITUDE text\n" +
                    ", LATITUDE text\n" +
                    ", DATE_OPERATION text\n" +
                    ", OBJECT_VERIF text\n" +
                    ", STATUS text);");


            sqLiteDatabase.execSQL("create table available ( \"_id\" INTEGER PRIMARY KEY, CATEGORIE text\n" +
                    ", NUMERO_RECLAMATION text\n" +
                    ", GERANCE text\n" +
                    ", CODE_GERANC text\n" +
                    ", AGENCE text\n" +
                    ", NATURE_VERIFICATION text\n" +
                    ", DESCRIPTION text\n" +
                    ", ANNEE_DOSSIER text\n" +
                    ", NUMERO_DOSSIER text\n" +
                    ", NOM_CLIENT text\n" +
                    ", ADRESSE_RECLAMATION text\n" +
                    ", ADRESSE_CLIENT text\n" +
                    ", TELECLIENT text\n" +
                    ", CIN_CLIEN text\n" +
                    ", REFERENCE text\n" +
                    ", COMPTEUR text\n" +
                    ", EMMETTEUR_RECLAMATION text\n" +
                    ", DATE_CREATION_RECLAMATION text);");


            sqLiteDatabase.execSQL("create table _pending ( \"_id\" INTEGER PRIMARY KEY, STATOPER text\n" +
                    ", DATTRAOP text\n" +
                    ", LONGITUDE text\n" +
                    ", LATITUDE text\n" +
                    ", NUMDOSRE text\n" +
                    ", REPECLIE text\n" +
                    ", RESU_FIN text\n" +
                    ", base64Image text\n" +
                    ", REASON text);");


        }


        public long insert(String table, HashMap<String, String> set) {

            ContentValues values = new ContentValues();


            for (Map.Entry mapElement : set.entrySet()) {
                values.put(mapElement.getKey().toString(), mapElement.getValue().toString());
            }

            return this.getWritableDatabase().insert(table, null, values);

        }


        public ArrayList query(String table, String Where, String[] params, String order) {
            SQLiteDatabase db = this.getReadableDatabase();
            ArrayList<HashMap<String, String>> result = new ArrayList<>();
            Cursor cursor = db.query(table, null, Where, params, null, null, order);
            String[] columnNames = cursor.getColumnNames();
            while (cursor.moveToNext()) {
                HashMap<String, String> row = new HashMap<>();
                for (String col : columnNames) {
                    row.put(col, cursor.getString(cursor.getColumnIndex(col)));
                }
                result.add(row);
            }
            cursor.close();
            return result;
        }


        public StatistiqueResponse getStats() {
            SQLiteDatabase db = this.getReadableDatabase();
            Cursor cursor;
            cursor = db.query(Demandes.TABLE_NAME, new String[]{"STATUS", "COUNT(STATUS) total"}, null, null, "STATUS", null, null);
            StatistiqueResponse result = new StatistiqueResponse();
            int total = 0;

            result.setRejetees("0");
            result.setTotal("0");
            result.setExecutees("0");
            result.setEn_cours("0");
            while (cursor.moveToNext()) {
                String st = cursor.getString(0);
                String vl = cursor.getString(1);
                vl = vl == null || vl.equals("") ? "0" : vl;

                total += Integer.valueOf(vl);

                if (st == null || st.equals("1")) {
                    result.setEn_cours(vl);
                } else if (st.equals("2")) {
                    result.setExecutees(vl);
                } else if (st.equals("3")) {
                    result.setRejetees(vl);
                } else if (st.equals("4")) {
                    result.setAnnulees(vl);
                }


            }

            result.setTotal(String.valueOf(total));
            cursor.close();

            return result;
        }


        public boolean insertReclamation(Reclamation demande) {

            ContentValues values = new ContentValues();

            values.put(Demandes.CATEGORIE, demande.getCATEGORIE());
            values.put(Demandes.CODEGERA, demande.getCODEGERA());
            values.put(Demandes.LIBEGERA, demande.getLIBEGERA());
            values.put(Demandes.CODELOCA, demande.getCODELOCA());
            values.put(Demandes.CODESECT, demande.getCODESECT());
            values.put(Demandes.LIBEAGEN, demande.getLIBEAGEN());
            values.put(Demandes.DESNATRE, demande.getDESNATRE());
            values.put(Demandes.CODNATRE, demande.getCODNATRE());
            values.put(Demandes.PRIODOSS, demande.getPRIODOSS());
            values.put(Demandes.NUMDOSRE, demande.getNUMDOSRE());
            values.put(Demandes.DESCRECL, demande.getDESCRECL());
            values.put(Demandes.DATCREDO, demande.getDATCREDO());
            values.put(Demandes.NOMPRECL, demande.getNOMPRECL());
            values.put(Demandes.TELERECL, demande.getTELERECL());
            values.put(Demandes.CIN_CLIE, demande.getCIN_CLIE());
            values.put(Demandes.ADRECLIE, demande.getADRECLIE());
            values.put(Demandes.ADRERECL, demande.getADRERECL());
            values.put(Demandes.USERSAIS, demande.getUSERSAIS());
            values.put(Demandes.NUMEDOSS, demande.getNUMEDOSS());
            values.put(Demandes.ANNEDOSS, demande.getANNEDOSS());
            values.put(Demandes.NUMOPRAB, demande.getNUMOPRAB());
            values.put(Demandes.REFECOMP, demande.getREFECOMP());
            values.put(Demandes.CODSTRDE, demande.getCODSTRDE());
            values.put(Demandes.CODEMERE, demande.getCODEMERE());
            values.put(Demandes.LIBEEMET, demande.getLIBEEMET());
            values.put(Demandes.CODCATRE, demande.getCODCATRE());
            values.put(Demandes.USERAFF, demande.getUSERAFF());
            values.put(Demandes.LONGITUDE, demande.getLONGITUDE());
            values.put(Demandes.LATITUDE, demande.getLATITUDE());
            values.put(Demandes.DATE_OPERATION, demande.getDATE_OPERATION());
            values.put(Demandes.OBJECT_VERIF, demande.getOBJECT_VERIF());
            values.put(Demandes.STATUS, demande.getSTATUS() == null ? "1" : demande.getSTATUS());


            SQLiteDatabase db = this.getWritableDatabase();

            long newRowId = db.insert(TwDatabase.Demandes.TABLE_NAME, null, values);

            db.close();

            return newRowId > 0;
        }


        public static String getToken(Context ctx) {
            TwDatabaseHelper dbh = new TwDatabaseHelper(ctx);
            ArrayList res = dbh.query(MetaTable.TABLE_NAME, MetaTable.COL_KEY + " = 'token'", null, null);

            if (res.size() > 0) {
                return ((HashMap<String, String>) res.get(0)).get("value");
            } else {
                return null;
            }
        }


        public static boolean setToken(Context ctx, String token) {
            TwDatabaseHelper dbh = new TwDatabaseHelper(ctx);
            return dbh.insert(MetaTable.TABLE_NAME, new HashMap<String, String>() {{
                put("key", "token");
                put("value", token);
            }}) > 0;
        }


        public static void Executer(Context ctx, boolean fromSync, String STATOPER, String DATTRAOP, String LONGITUDE, String LATITUDE, String NUMDOSRE, String REPECLIE, String RESU_FIN, String OBS, String base64Image, Runnable onSuccess, Runnable onOffline, Runnable onFailed) {

            int status = 2;
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            Date d = new Date();
            String date = formatter.format(d);
            String token = SharedPrefManager.getInstance(ctx).getToken();
            TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);
            SQLiteDatabase db = dbh.getReadableDatabase();


            ContentValues local = new ContentValues();

            local.put("STATOPER", STATOPER);
            local.put("DATTRAOP", DATTRAOP);
            local.put("LONGITUDE", LONGITUDE);
            local.put("LATITUDE", LATITUDE);
            local.put("NUMDOSRE", NUMDOSRE);
            local.put("REPECLIE", REPECLIE);
            local.put("RESU_FIN", RESU_FIN);
            local.put("REASON", OBS);
            local.put("base64Image", base64Image);


            if (!fromSync) {
                ContentValues p = new ContentValues();
                p.put("STATUS", STATOPER);

                int lstatus = db.update(TwDatabase.Demandes.TABLE_NAME, p, "NUMDOSRE = ?", new String[]{NUMDOSRE});


                if (lstatus > 0) {
                    onSuccess.run();
                } else {
                    onFailed.run();
                    return;
                }
            }


            Call<OperationResponse> call = RetrofitClient.getApi(token)
                    .executerReclamation(
                            "XDEBUG_SESSION=XDEBUG_ECLIPSE",
                            STATOPER,
                            DATTRAOP,
                            LONGITUDE,
                            LATITUDE,
                            NUMDOSRE,
                            REPECLIE,
                            RESU_FIN,
                            base64Image, OBS);


            local.put("REASON", "");


            long pid = !fromSync ? db.insert(Pending.TABLE_NAME, null, local) : 0;

            call.enqueue(new Callback<OperationResponse>() {
                @Override
                public void onResponse(Call<OperationResponse> call, Response<OperationResponse> response) {
                    OperationResponse operationResponse = response.body();
                    if (response.body() != null && response.code() == 200 && response.body().getStatus().equals("SUCCESS")) {

                        SharedPrefManager.getInstance(ctx).setSyncTime(date);
                        if (!fromSync) {
                            int r = db.delete(Pending.TABLE_NAME, Pending._ID + " = ?", new String[]{String.valueOf(pid)});
                            boolean deleted = r > 0;
                        } else {
                            onSuccess.run();
                        }

                    } else {

                        if (!fromSync) {
                            ContentValues upd = new ContentValues();
                            upd.put("REASON", response.body().getMsg());

                            db.update(Pending.TABLE_NAME, upd, Pending._ID + " = ?", new String[]{String.valueOf(pid)});
                        }


                        onFailed.run();
                    }

                }

                @Override
                public void onFailure(Call<OperationResponse> call, Throwable t) {

                    if (!fromSync) {
                        ContentValues upd = new ContentValues();
                        upd.put("REASON", t.getMessage());

                        db.update(Pending.TABLE_NAME, upd, Pending._ID + " = ?", new String[]{String.valueOf(pid)});
                    }

                    onOffline.run();

                }
            });

        }

        public static void synchroniz(Context ctx, Runnable onStep, Runnable onSuccess, Runnable onFail) {

            TwDatabaseHelper dbh = new TwDatabaseHelper(ctx);
            SQLiteDatabase db = dbh.getReadableDatabase();

            boolean finished = true;

            ArrayList<HashMap<String, String>> pendings = dbh.query(Pending.TABLE_NAME, null, null, null);

            Log.e("#################", "Entred sync" + String.valueOf(pendings.size()));

            for (HashMap<String, String> pending : pendings) {

                finished = false;
                if (pending.get("STATOPER") == null) {

                } else {
                    Log.e("#################", "sent run");
                    TwDatabaseHelper.Executer(ctx, true,
                            pending.get("STATOPER"),
                            pending.get("DATTRAOP"),
                            pending.get("LONGITUDE"),
                            pending.get("LATITUDE"),
                            pending.get("NUMDOSRE"),
                            pending.get("REPECLIE"),
                            pending.get("RESU_FIN"),
                            pending.get("OBS"),
                            pending.get("base64Image"),
                            new Runnable() {
                                @Override
                                public void run() {

                                    Log.e("#################", "sit success");

                                    db.delete(Pending.TABLE_NAME, Pending._ID + " = ?", new String[]{pending.get(Pending._ID)});

                                    onStep.run();
                                    synchroniz(ctx, onStep, onSuccess, onFail);
                                }
                            },
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got offline");
                                    //db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});
                                    onFail.run();
                                }
                            },
                            new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("#################", "got error");
                                    //db.delete(ABPending.TABLE_NAME, ABPending._ID + " = ?", new String[]{pending.get(ABPending._ID)});
                                    onFail.run();
                                }
                            }
                    );
                }


            }


            Log.e("#################", "end s " + (finished ? "will success" : "will return"));

            if (!finished) return;

            TwSyncher.getNewReclamation(ctx, db, new Runnable() {
                @Override
                public void run() {
                    db.close();
                    onSuccess.run();
                }
            }, new Runnable() {
                @Override
                public void run() {
                    db.close();
                    onSuccess.run();
                }
            });


        }


        public static void handleRefreshToken(Context ctx) {

            int ctime = (int) System.currentTimeMillis() / 1000;
            int ltime = SharedPrefManager.getInstance(ctx).getLoginTime();

            if ((ctime - ltime) < 3500) {
                return;
            }

            SharedPrefManager pref = SharedPrefManager.getInstance(ctx);

            String username = pref.getUserID();
            String pass = pref.getUserPassword();

            String auth = Base64.encodeToString((username + ":" + pass).trim().getBytes(), Base64.NO_WRAP | Base64.URL_SAFE);
            String imei = NetworkUtility.getIMEI(ctx);

            try {
                Call<LoginResponse> call = RetrofitClient
                        .getApiNoHeaders()
                        .auth("Basic " + auth, "work_access", imei);

                call.enqueue(new Callback<LoginResponse>() {
                    @Override
                    public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                        LoginResponse s = null;
                        if (response.code() == 200) {
                            s = response.body();
                            pref.saveUser(username, s.getData().token, s.getData().expires.toString(), s.getData().scoop, s.getData().fullname, username, pass);

                            Handler handler1 = new Handler();
                            handler1.postDelayed(new Runnable() {
                                @Override
                                public void run() {

                                    Toast.makeText(ctx, "Token est actualisé avec succès", Toast.LENGTH_LONG).show();

                                }
                            }, 500);


                        } else {

                            TwDatabaseHelper.showError(ctx);

                        }
                    }

                    @Override
                    public void onFailure(Call<LoginResponse> call, Throwable t) {
                        TwDatabaseHelper.showError(ctx);
                    }


                });
            } catch (Exception e) {
                TwDatabaseHelper.showError(ctx);
            }

        }


        public static void showError(Context ctx) {
            Intent intent = new Intent(ctx, Error.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            ctx.startActivity(intent);
        }

        public static void RejeterAbonnement(Context ctx, boolean fromSync, String ANNEDOSS, String NUMEDOSS, String NUMOPRAB, String CODEGERA, String observation, String motif, String base64Image, Runnable onSuccess, Runnable onOffline, Runnable onFailed) {

            int status = 3;
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            Date d = new Date();
            String date = formatter.format(d);
            String token = SharedPrefManager.getInstance(ctx).getToken();
            TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);
            SQLiteDatabase db = dbh.getReadableDatabase();


            ContentValues local = new ContentValues();

            local.put("STATOPER", String.valueOf(status));
            local.put("RESTRAOP", observation);
            local.put("DATTRAOP", date);
            local.put("DATESAIS", date);
            local.put("CODUTIMA", SharedPrefManager.getInstance(ctx).getUserID());
            local.put("COMOSTOP", motif);


            if (!fromSync) {
                int lstatus = db.update(TwDatabase.Demandes.TABLE_NAME, local, "ANNEDOSS = ? AND NUMEDOSS = ? AND NUMOPRAB = ?", new String[]{ANNEDOSS, NUMEDOSS, NUMOPRAB});


                if (lstatus > 0) {
                    onSuccess.run();
                } else {
                    onFailed.run();
                    return;
                }
            }

            Call<OperationResponse> call = RetrofitClient.getApi(token)
                    .executerReclamation(
                            "XDEBUG_SESSION=XDEBUG_ECLIPSE",
                            String.valueOf(status),
                            date,
                            null,
                            null,
                            NUMEDOSS,
                            "REPECLIE",
                            "RESU_FIN",
                            base64Image,
                            observation);


            local.put("NUMOPRAB", NUMOPRAB);
            local.put("ANNEDOSS", ANNEDOSS);
            local.put("NUMEDOSS", NUMEDOSS);
            local.put("CODEGERA", CODEGERA);
            local.put("REASON", "");

            long pid = fromSync ? 0 : db.insert(Pending.TABLE_NAME, null, local);

            call.enqueue(new Callback<OperationResponse>() {
                @Override
                public void onResponse(Call<OperationResponse> call, Response<OperationResponse> response) {
                    OperationResponse operationResponse = response.body();
                    if (response.body() != null && response.code() == 200 && response.body().getStatus().equals("SUCCESS")) {
                        SharedPrefManager.getInstance(ctx).setSyncTime(date);
                        if (!fromSync) {
                            int r = db.delete(Pending.TABLE_NAME, Pending._ID + " = ?", new String[]{String.valueOf(pid)});
                            boolean deleted = r > 0;
                        } else {
                            onSuccess.run();
                        }

                    } else {

                        if (!fromSync) {
                            ContentValues upd = new ContentValues();
                            upd.put("REASON", response.body().getMsg());

                            db.update(Pending.TABLE_NAME, upd, Pending._ID + " = ?", new String[]{String.valueOf(pid)});
                        }

                        onFailed.run();
                        db.close();
                    }

                }

                @Override
                public void onFailure(Call<OperationResponse> call, Throwable t) {

                    if (!fromSync) {
                        ContentValues upd = new ContentValues();
                        upd.put("REASON", t.getMessage());
                        db.update(Pending.TABLE_NAME, upd, Pending._ID + " = ?", new String[]{String.valueOf(pid)});
                    }

                    onOffline.run();

                    db.close();

                }

                ;
            });

        }

    }

}
