package ma.rak.ov.ui.main;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProviders;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

import io.realm.Realm;
import ma.rak.ov.R;
import ma.rak.ov.api.TwDatabase;
import ma.rak.ov.bodyResponse.OperationResponse;
import ma.rak.ov.storage.SharedPrefManager;

public class AffecterFragment extends FragmentActivity implements AdapterView.OnItemSelectedListener {

    private Spinner agentSpinner, currentAgentSpinner;
    private Button saveButton, cancelButton;

    private Timer timer;

    private ArrayList<HashMap<String, String>> newAgentsResponse;
    private DemandViewModel demandViewModel;
    private OperationResponse operationResponse = null;

    private DropDownAlert downAlertNoImage;

    private String currentAgent, newAgent;
    private String date, gerance;

    private String token = SharedPrefManager.getInstance(this).getToken();
    HashMap<String, String> vagent = new HashMap<String, String>();
    HashMap<String, String> ivagent = new HashMap<String, String>();

    String ANNEDOSS, NUMOPRAB, NUMEDOSS, CODEGERA;
    private Realm realm;

    public AffecterFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_affecter);

        realm = Realm.getDefaultInstance();

        timer = new Timer();

        currentAgentSpinner = (Spinner) findViewById(R.id.currentAgentSpinner);
        agentSpinner = (Spinner) findViewById(R.id.agentSpinner);

        currentAgentSpinner.setEnabled(false);

        cancelButton = (Button) findViewById(R.id.cancel_button);
        saveButton = (Button) findViewById(R.id.save_button);
        downAlertNoImage = new DropDownAlert(this, this.getWindow().getContext(), false);

        cancelButton.setOnClickListener(v -> AffecterFragment.super.onBackPressed());

        demandViewModel = ViewModelProviders.of(this).get(DemandViewModel.class);

        demandViewModel.getAgents(this);


        ArrayList<String> agentArr = new ArrayList<>();
        ArrayAdapter agents = new ArrayAdapter(this, android.R.layout.simple_spinner_item, agentArr);
        agents.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        newAgentsResponse = new ArrayList<HashMap<String, String>>();

        vagent.put("<AUCUN>", null);
        ivagent.put(null, "<AUCUN>");
        agents.add("<AUCUN>");

        demandViewModel.AgentsMutableLiveData.observe(this, agentsResponse -> {
            newAgentsResponse = agentsResponse;
            if (newAgentsResponse != null) {
                for (HashMap<String, String> agent : newAgentsResponse) {
                    agents.add(agent.get(TwDatabase.ALLAgents.COL_KEY) + " - " + agent.get(TwDatabase.ALLAgents.COL_LABEL));
                    vagent.put(agent.get(TwDatabase.ALLAgents.COL_KEY) + " - " + agent.get(TwDatabase.ALLAgents.COL_LABEL), agent.get(TwDatabase.ALLAgents.COL_KEY));
                    ivagent.put(agent.get(TwDatabase.ALLAgents.COL_KEY), agent.get(TwDatabase.ALLAgents.COL_KEY) + " - " + agent.get(TwDatabase.ALLAgents.COL_LABEL));


                }
                agents.notifyDataSetChanged();
                agentSpinner.setAdapter(agents);
                currentAgentSpinner.setAdapter(agents);

                String cagent = getIntent().getExtras().getString("AGENT");

                String k = ivagent.get(cagent);

                if (k != null) {
                    int ai = agents.getPosition(k);
                    currentAgentSpinner.setSelection(ai);
                }
            }
        });

        agentSpinner.setOnItemSelectedListener(this);
        currentAgentSpinner.setOnItemSelectedListener(this);
        this.ANNEDOSS = getIntent().getExtras().getString("doss_annee");
        this.NUMEDOSS = getIntent().getExtras().getString("doss_numm");
        this.NUMOPRAB = getIntent().getExtras().getString("num_operation");
        this.CODEGERA = getIntent().getExtras().getString("gerance");

        saveButton.setOnClickListener(v -> {

            TwDatabase.TwDatabaseHelper.ReaffecterAbonnement(this, false, this.ANNEDOSS, this.NUMEDOSS, this.NUMOPRAB, this.CODEGERA, newAgent,
                    new Runnable() {
                        @Override
                        public void run() {

                            downAlertNoImage.setTitle(getString(R.string.dropdown_info));
                            downAlertNoImage.setContent("Réaffectation terminé");
                            downAlertNoImage.show();
                            timer.schedule(new dismissTimerTask(), 3500);

                        }
                    },
                    new Runnable() {
                        @Override
                        public void run() {
                            downAlertNoImage.setTitle(getString(R.string.dropdown_error));
                            downAlertNoImage.setContent("Impossible de réaffecter l'operation");
                            downAlertNoImage.show();
                        }
                    },
                    new Runnable() {
                        @Override
                        public void run() {
                            downAlertNoImage.setTitle(getString(R.string.dropdown_error));
                            downAlertNoImage.setContent("Impossible de réaffecter l'operation");
                            downAlertNoImage.show();
                        }
                    });

        });

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            if (bundle.getString("num_operation") != null) {
                this.gerance = bundle.getString("gerance");
                this.date = bundle.getString("date");

            }
        }

    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_affecter, container, false);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Spinner spinner = (Spinner) parent;

        if (spinner.getId() == R.id.currentAgentSpinner) {
            currentAgent = spinner.getItemAtPosition(position).toString();
        }

        if (spinner.getId() == R.id.agentSpinner) {
            String nak = spinner.getItemAtPosition(position).toString();
            newAgent = vagent.get(nak);
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    class dismissTimerTask extends TimerTask {
        public void run() {

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    AffecterFragment.super.onBackPressed();

                }
            });
        }
    }
}