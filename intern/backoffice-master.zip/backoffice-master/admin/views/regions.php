<?php
?>

<div id="regions_view">

    <div class="dt_section">

        <div class="dt_head">
            <div class="t">
                <h3>Toutes les régions</h3>
            </div>
            <div class="a">
                <button class="button default" data-table="regions_tbl" id="reload_table"><i class="fas fa-sync-alt"></i> </button>
                <button class="button primary" id="add_region">Ajouter région <i class="fas fa-plus"></i> </button>
            </div>
        </div>

        <div class="dt_inner">
            <?= datatable('regions_tbl', 6); ?>
        </div>

    </div>

</div>
