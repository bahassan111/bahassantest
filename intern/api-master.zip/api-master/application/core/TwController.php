<?php

class TwController extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();



    }

    protected function getEmptyResponse(){
        return (object)['status' => 'EMPTY', 'message' => '', 'data' => new stdClass()];
    }
}