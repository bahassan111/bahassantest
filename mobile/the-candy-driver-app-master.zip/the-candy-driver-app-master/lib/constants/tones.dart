class Tones {
  static String toneBaseUrl = "audios/";
  static String bookingCancel = toneBaseUrl + "booking_cancel_tone.mp3";
  static String driverOnlineTone = toneBaseUrl + "driver_online_tone.mp3";
  static String instantBookingTone = toneBaseUrl + "instant_booking_tone.mp3";
  static String preBookingTone = toneBaseUrl + "pre_booking_tone.mp3";
}
