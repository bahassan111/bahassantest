package ma.rak.ovr.bodyResponse;

import com.google.gson.annotations.SerializedName;

import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;
import ma.rak.ovr.models.Abonnement;
import ma.rak.ovr.models.Reclamation;

public class ReclamationResponse extends RealmObject {

    @SerializedName("data")
    private RealmList<Reclamation> data;

    public ReclamationResponse() {
    }

    ;

    public ReclamationResponse(RealmList<Reclamation> data) {

        this.data = data;
    }


    public RealmList<Reclamation> getData() {
        return data;
    }

    public void setData(RealmList<Reclamation> data) {
        this.data = data;
    }
}
