import { StatusBar } from 'expo-status-bar';
import React, {useState, useRef, useEffect} from 'react';
import { StyleSheet, Text, View, Linking } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { Provider } from 'react-redux';
import { createStore } from 'redux';
import dataReducer from './redux/reducers/dataReducer';
import * as Localization from 'expo-localization';
import fr from "./languages/fr";
import i18n from 'i18n-js';
import StackNav from "./nav/StackNav";
import DrawerNav from "./nav/DrawerNav";
import en from "./languages/en";
import ar from "./languages/ar";
import Constants from 'expo-constants';
import * as Notifications from 'expo-notifications';
import storage from "./storage/TwStorage";
import * as Updates from 'expo-updates';
i18n.translations = {
    fr: fr,
    en: en,
    ar: ar,
};
// Set the locale once at the beginning of your app.
i18n.locale = "fr";

Notifications.setNotificationHandler({
    handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: true,
        shouldSetBadge: false,
    }),
});


export default class App extends React.Component{

    state = {
        notification: {},
        notif_id : null
    };

    store = createStore(dataReducer);
    uid = Constants.installationId;
    //`http://192.168.1.5/twAPI/Test?token=${token}&uid=${uid}`

    componentDidMount() {
        i18n.locale = "fr";
        this.registerForPushNotificationsAsync();

        Notifications.addNotificationReceivedListener(this._handleNotification);

        Notifications.addNotificationResponseReceivedListener(this._handleNotificationResponse);
        console.log('started');
    }

    _handleNotification = notification => {

        this.setState({ notification: notification });
    };

    _handleNotificationResponse = response => {


        let id = response.notification.request.content.data.id;

        console.log('iddddd', id);
        if(id){
            id = `${id}`;
            storage.setStorage('notif_id', id);
            Updates.reloadAsync();


        }

    };

    registerForPushNotificationsAsync = async () => {
        console.log('registring ..');
        if (Constants.isDevice || true) {
            const { status: existingStatus } = await Notifications.getPermissionsAsync();
            let finalStatus = existingStatus;
            if (existingStatus !== 'granted') {
                const { status } = await Notifications.requestPermissionsAsync();
                finalStatus = status;
                console.log('no grant');
            }
            if (finalStatus !== 'granted') {
                //alert('Failed to get push token for push notification!');
                return;
            }
            const token = (await Notifications.getExpoPushTokenAsync()).data;

            fetch(`https://dibnews.ma/MOBILE_API/Root?token=${token}&uid=${this.uid}`);
            this.setState({ expoPushToken: token });
            console.log('token', token);
        } else {
            alert('Must use physical device for Push Notifications');
        }

        if (Platform.OS === 'android') {
            Notifications.setNotificationChannelAsync('default', {
                name: 'default',
                importance: Notifications.AndroidImportance.MAX,
                vibrationPattern: [0, 250, 250, 250],
                lightColor: '#FF231F7C',
            });
        }
    };




    render() {
        console.log('store',);
        return (
            <Provider store={this.store}>
                <NavigationContainer>
                    {StackNav(this.state.notif_id)}
                </NavigationContainer>
            </Provider>

        );
    }




}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
