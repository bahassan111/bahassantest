<?php

addJS([
    'assets/js/views/projects.js',
]);

?>



   <div id="projects_view">
       <div class="view_header">
           <div class="page_title">
               <div class="bread_crumb">
                   <span><a href="<?= site_url(); ?>">Dashboard</a></span>
                   <span>Projects list</span>
               </div>
               <h3>Projects</h3>
               <p>Here a description of the page if you can</p>
           </div>

           <div class="page_actions">
               <?php if(hasPermission('project', Pages::ACTION_ADD)){?>
                   <button class="btn btn-outline-primary btn-sm create_project"><i class="fas fa-plus"></i> Create Project</button>
               <?php } ?>
           </div>

       </div>


       <div class="container-fluid pd-x-0 pd-lg-x-10 pd-xl-x-0">
           <div class="row mb-3">
               <div class="col-lg-9 border-right">
                   <ul class="nav nav-line nav-line-profile mg-b-30">
                       <li class="nav-item">
                           <a data-lprojects="active" href="javascript:void(0);" class="nav-link d-flex align-items-center active">Active <span data-pcount="active" class="badge ml-2">340</span></a>
                       </li>
                       <li class="nav-item">
                           <a data-lprojects="closed" href="javascript:void(0);" class="nav-link">Closed <span data-pcount="closed" class="badge ml-2">6</span></a>
                       </li>
                       <li class="nav-item d-none d-sm-block">
                           <a data-lprojects="others" href="javascript:void(0);" class="nav-link">Others  <span data-pcount="others" class="badge ml-2">6</span></a>
                       </li>
                   </ul>

                   <div class="row row-xs mb-5" id="projects_holder">

                   </div><!-- row -->

                   <div class="prj_lm">
                       <button class="btn btn-block btn-sm btn-white" data-page="2">Load more</button>
                   </div>
               </div><!-- col -->
               <div class="col-lg-3 mg-t-40 mg-lg-t-0">
                   <h6 class="tx-uppercase tx-semibold mg-t-50 mg-b-15">Discover By Tags</h6>

                   <nav class="nav nav-classic tx-13" id="tags_list">

                   </nav>




                   <div class="d-flex align-items-center justify-content-between mg-t-20 mg-b-20">
                       <h6 class="tx-uppercase tx-semibold mg-b-0">Members involved</h6>
                   </div>
                   <ul class="list-unstyled media-list mg-b-15">
                       <li class="media align-items-center">
                           <a href=""><div class="avatar"><img src="https://via.placeholder.com/500" class="rounded-circle" alt=""></div></a>
                           <div class="media-body pd-l-15">
                               <h6 class="mg-b-2"><a href="" class="link-01">Allan Ray Palban</a></h6>
                               <span class="tx-13 tx-color-03">Senior Business Analyst</span>
                           </div>
                       </li>
                       <li class="media align-items-center mg-t-15">
                           <a href=""><div class="avatar"><img src="https://via.placeholder.com/500" class="rounded-circle" alt=""></div></a>
                           <div class="media-body pd-l-15">
                               <h6 class="mg-b-2"><a href="" class="link-01">Rhea Castanares</a></h6>
                               <span class="tx-13 tx-color-03">Product Designer</span>
                           </div>
                       </li>
                       <li class="media align-items-center mg-t-15">
                           <a href=""><div class="avatar"><img src="https://via.placeholder.com/500" class="rounded-circle" alt=""></div></a>
                           <div class="media-body pd-l-15">
                               <h6 class="mg-b-2"><a href="" class="link-01">Philip Cesar Galban</a></h6>
                               <span class="tx-13 tx-color-03">Executive Assistant</span>
                           </div>
                       </li>
                       <li class="media align-items-center mg-t-15">
                           <a href=""><div class="avatar"><img src="https://via.placeholder.com/500" class="rounded-circle" alt=""></div></a>
                           <div class="media-body pd-l-15">
                               <h6 class="mg-b-2"><a href="" class="link-01">Randy Macapala</a></h6>
                               <span class="tx-13 tx-color-03">Business Entrepreneur</span>
                           </div>
                       </li>
                       <li class="media align-items-center mg-t-15">
                           <a href=""><div class="avatar"><img src="https://via.placeholder.com/500" class="rounded-circle" alt=""></div></a>
                           <div class="media-body pd-l-15">
                               <h6 class="mg-b-2"><a href="" class="link-01">Abigail Johnson</a></h6>
                               <span class="d-block tx-13 tx-color-03">System Administrator</span>
                           </div>
                       </li>
                   </ul>




               </div><!-- col -->
           </div><!-- row -->
   </div>
