<?php

class TwClient
{
    public const POST = 'POST';
    public const GET = 'GET';
    public const PUT = 'PUT';
    public const DELETE = 'DELETE';
    protected $use_cookies = FALSE;

    public function __construct()
    {

    }

    public function request($method, $url, $data, $headers, $useCookies = FALSE, $uniqueCookieID = FALSE)
    {

        $postvars = http_build_query($data);

        if($method === self::GET){
            $url .= (strpos($url, '?') === FALSE ? '?' : '&') . $postvars;
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_URL, $url);
        if($method === self::GET){

        }else{
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
            curl_setopt($ch, CURLOPT_POST, count($data));
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postvars);
        }
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        if($useCookies){
            curl_setopt($ch, CURLOPT_COOKIESESSION, TRUE);
            curl_setopt($ch, CURLOPT_COOKIEJAR, $this->getCookieFile($uniqueCookieID));
            curl_setopt($ch, CURLOPT_COOKIEFILE, $this->getCookieFile($uniqueCookieID));
        }

        //curl_setopt($ch, CURLOPT_VERBOSE, 1);
        curl_setopt($ch, CURLOPT_HEADER, 1);


        return new TwResponse($ch, TRUE);



    }

    protected function getCookieFile($unique = FALSE){
        $folder = FCPATH . '_cookies/'.($unique ? "$unique/" : '');
        $file = 'cookies.txt';

        if(!file_exists($folder)) mkdir($folder);


        return $folder.$file;
    }


}

class TwResponse
{
    public $headers, $body, $content_type, $code, $infos;
    protected $handle, $header_str;

    public function __construct(&$curl_handle, $closeIT = FALSE)
    {
        $result = $result = curl_exec($curl_handle);

        $header_size = curl_getinfo($curl_handle, CURLINFO_HEADER_SIZE);
        $this->header_str = substr($result, 0, $header_size);
        $this->body = substr($result, $header_size);
        $this->headers = (object)$this->parseHeader($this->header_str);
        $this->infos = curl_getinfo($curl_handle);
        $this->code = $this->headers->HTTP_CODE;


        if($closeIT){
            curl_close($curl_handle);
        }
    }



    protected function parseHeader($header)
    {
        $obj = [];
        $str = $segments = preg_split('/([;]+|[\r\n]+)/', $header);
        foreach ($str as $part) {
            $i = strpos($part, ':');
            $y = strpos($part, '=');
            if ($i > 0) {
                $key = trim(substr($part, 0, $i));
                $val = trim(substr($part, $i + 1));
                $obj[$key] = $val;
            } else {
                if ($y > 0) {
                    $key = trim(substr($part, 0, $y));
                    $val = trim(substr($part, $y + 1));
                    $obj[$key] = $val;
                } elseif (strtoupper(substr($part, 0, 4)) === 'HTTP') {
                    $obj['HTTP'] = $part;
                    $obj['HTTP_CODE'] = $this->getHTTPCode($part);
                } else {
                    $obj[$part] = '';
                }

            }
        }
        $headers = [];
        foreach ($obj as $k => $v) {
            $k = trim($k);
            $v = trim($v);
            if ($k || $v) {
                $vv = (int)$v;
                if ("$vv" === $v) $v = $vv;
                $headers[$k] = $v;
            }
        }
        return (object)$headers;
    }

    protected function parseParams($params)
    {
        $params = $params ?: [];
        $str = "";
        foreach ($params as $key => $value) {
            $str .= ($str ? '&' : '?') . "$key=$value";
        }
        return $str;
    }

    protected function getHTTPCode($line)
    {
        $s = explode(' ', $line);
        foreach ($s as $value) {
            $x = (int)trim($value);
            if ("$x" === trim($value)) return $x;
        }
        return null;
    }
}