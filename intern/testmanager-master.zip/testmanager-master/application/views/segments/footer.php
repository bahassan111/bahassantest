
</div>
<footer class="footer">
    <div>
        <span>&copy; <?= date('Y'); ?> Twins Test Manager v0.0.0b </span>
        <span>Created by <a href="http://twinsmaroc.com">Twins</a></span>
    </div>
    <div>
        <nav class="nav">
            <a href="#" class="nav-link">Licenses</a>
            <a href="#" class="nav-link">Change Log</a>
            <a href="#" class="nav-link">Get Help</a>
        </nav>
    </div>
</footer>


<?= getJS(); ?>
</body>
</html>


