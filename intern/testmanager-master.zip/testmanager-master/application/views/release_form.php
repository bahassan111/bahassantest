<?php
?>

<div class="" id="release_form">


    <form method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="name" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Release Name</label>
            <input required id="name" name="name" value="<?= $edit ? $release->name : ''; ?>" type="text" class="form-control form-control-sm" placeholder="Enter a descriptive title ..">
        </div>
        <input type="hidden" name="id_project" value="<?= $id_project; ?>">

        <div class="form-group">
            <label for="note" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Note</label>
            <textarea id="note" name="note" class="form-control form-control-sm"><?= $edit ? $release->note : ''; ?></textarea>
        </div>

        <div class="form-group">
            <label for="start" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">Start Date</label>
            <input required id="start" name="start" value="<?= $edit ? date('Y-m-d', $release->start) : date('Y-m-d'); ?>" type="text" class="form-control form-control-sm datepicker" placeholder="Enter a descriptive title ..">
        </div>
        <div class="form-group">
            <label for="deadline" class="tx-10 tx-uppercase tx-medium tx-spacing-1 mg-b-5 tx-color-03">End Date</label>
            <input required id="deadline" name="deadline" value="<?= $edit ? date('Y-m-d', $release->deadline) : ''; ?>" type="text" class="form-control form-control-sm datepicker" placeholder="Enter a descriptive title ..">
        </div>
    </form>


</div>
