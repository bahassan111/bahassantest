import 'package:driver/constants/constants.dart';
import 'package:driver/constants/helpers/helpers.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'history_item.dart';

class TripHistoryUI extends StatefulWidget {
  @override
  _TripHistoryUIState createState() => _TripHistoryUIState();
}

class _TripHistoryUIState extends State<TripHistoryUI> {
  double height, width;

  final HistoryController to = Get.find();
  static AuthController authTo = Get.find();

  bool isLoading = true;
  @override
  void initState() {
    super.initState();
    to.getDriverHistory().then((value) {
      setState(() {
        isLoading = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: AppThemes.lightdeepPinkDropDownIconColor,
      body: SafeArea(
        child: Container(
          child: Column(
            children: [
              appbar(context),
              isLoading ? Container() : generalHistory(context),
              isLoading
                  ? Container()
                  : Expanded(
                      child: ListView.builder(
                      itemCount: to.filteredRides.length,
                      itemBuilder: (context, index) {
                        return HistoryItem(
                          // ride: to.filteredRides[index],
                          rideDetailModel: to.filteredRides[index],
                        );
                      },
                    ))
            ],
          ),
        ),
      ),
    );
  }

  appbar(context) => Container(
        width: width,
        margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        color: AppThemes.lightdeepPinkDropDownIconColor,
        child: Stack(
          children: [
            Center(
                child: Text(
              "tripHistory".tr,
              style: Theme.of(context).textTheme.headline6.copyWith(
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                  ),
            )),
            GestureDetector(
              onTap: () => Get.back(),
              child: Image.asset(
                AllImages.backIcon,
                height: 25,
                width: 25,
                color: Colors.white,
              ),
            ),
          ],
        ),
      );

  generalHistory(context) => Container(
        padding: EdgeInsets.only(left: 30),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Text(
                  "totalEarningFromTrips".tr + ': ',
                  style: Theme.of(context)
                      .textTheme
                      .headline6
                      .copyWith(fontSize: 18, fontFamily: "NunitoSans"),
                ),
                Text(
                  '${authTo.userModel.currency} ${to.totalwalletsum}',
                  style: Theme.of(context).textTheme.headline6.copyWith(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      fontFamily: "NunitoSans"),
                ),
              ],
            ),
            SizedBox(height: 5),
            Row(
              children: [
                Text(
                  "totalTripsMade".tr + ': ',
                  style: Theme.of(context)
                      .textTheme
                      .headline6
                      .copyWith(fontSize: 18, fontFamily: "NunitoSans"),
                ),
                Text(
                  '${to.rideDetails.length}',
                  style: Theme.of(context).textTheme.headline6.copyWith(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      fontFamily: "NunitoSans"),
                ),
              ],
            ),
            SizedBox(height: 5),
            GestureDetector(
              onTap: () async {
                final date =
                    await selectAllDate(context, selectedDate: to.selectedDate);
                if (date != null) {
                  setState(() {
                    to.selectedDate = date;
                    to.onDateChange();
                  });
                }
              },
              child: Row(
                children: [
                  Text(
                    "selectDate".tr + ': ',
                    style: Theme.of(context)
                        .textTheme
                        .headline6
                        .copyWith(fontSize: 18, fontFamily: "NunitoSans"),
                  ),
                  Text(
                    '${dateddMMMyyyy(to.selectedDate)}', //${dateddMMMyyyy(to.selectedDate)
                    style: Theme.of(context).textTheme.headline6.copyWith(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        fontFamily: "NunitoSans"),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
}
