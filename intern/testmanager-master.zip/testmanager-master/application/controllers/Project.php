<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Project extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!isLoggedIn()) {
            callback_whenNotLoggedIn();
        }

    }

    public function index()
    {

    }

    public function show($id)
    {
        if (!$id) callback_whenNotFound();
        $query = $this->db->get_where('projects', ['id' => $id, 'deleted' => 0]);
        $project = $query ? $query->row() : null;
        if (!$project) callback_whenNotFound();
        $plans = $this->db->get_where('plans', ['id_project' => $id, 'deleted' => 0])->result();
        $data = [
            '_page' => 'project',
            '_action' => Pages::ACTION_READ,
            '_title' => 'Project ' . $project->name,
            'project' => $project,
            'plans' => $plans,
            'stats' => $this->alpha->project_stats($id),
        ];
        loadView('project', $data);
    }





    public function tests($project_id)
    {
        if (!$project_id) callback_whenNotFound();
        $query = $this->db->get_where('projects', ['id' => $project_id, 'deleted' => 0]);
        $project = $query ? $query->row() : null;
        if (!$project) callback_whenNotFound();
        $data = [
            '_page' => 'plans',
            '_action' => Pages::ACTION_READ,
            '_title' => 'Test plans | ' . $project->name,
            'project' => $project,
        ];
        loadView('plans', $data);
    }

    function get_plans($id_project)
    {
        if(!hasPermission('plans', Pages::ACTION_READ)) callback_whenNoPermission();
        if (!$id_project) callback_whenNotFound();
        $list = (object)['empty' => (object)['items' => [], 'title' => '(Uncategorized)']];
        $query = $this->db->get_where('plans', ['id_project' => $id_project, 'deleted' => 0, 'id_group' => null]);
        $list->empty->items = $query ? $query->result() : [];
        $groups = $this->db->query("SELECT g.id, g.name FROM plans p LEFT JOIN plans_groups g ON g.id = id_group WHERE p.id_project = $id_project AND p.deleted = 0 and p.id_group is not null GROUP BY p.id_group")->result();
        foreach ($groups as $group) {
            $items = $this->db->get_where('plans', ['id_project' => $id_project, 'deleted' => 0, 'id_group' => $group->id])->result();
            $list->{$group->name} = (object)['title' => $group->name, 'items' => $items];
        }
        foreach ($list as $index => $g) {
            if (count($g->items) === 0) {
                unset($list->{$index});
            }
            foreach ($g->items as $row) {
                $row->date = 'Last update ' . fromNow($row->date_modified);
                $row->date_modified = date('Y-m-d H:i:s', $row->date_modified);
                $row->tasks = $this->db->query("SELECT count(*) v FROM test_cases WHERE deleted = 0 AND id_plan = '{$row->id}'")->row()->v ?: 0;
            }
        }
        responseJSON([
            'data' => $list,
        ]);

    }

    public function plan($id)
    {
        if (!$id) callback_whenNotFound();
        $plan = $this->db->get_where('plans', ['id' => $id, 'deleted' => 0])->row();
        if (!$plan) callback_whenNotFound();
        $cases = $this->db
                ->get_where('test_cases', ['id_plan' => $id, 'deleted' => 0])->result() || [];
        $data = [
            '_page' => 'plans',
            '_action' => Pages::ACTION_READ,
            'plan' => $plan,
            'cases' => $cases,
        ];
        loadView('plan', $data, FALSE);
    }

    public function one_plan($id = FALSE)
    {
        $plan = null;
        $id_project = $this->input->post('id_project');
        if (!$id && !$id_project) callback_whenNotFound();
        if ($id) {
            $query = $this->db->get_where('plans', ['id' => $id]);
            $plan = $query && $query->num_rows() > 0 ? $query->row() : null;
        }
        if ($plan) $id_project = $plan->id_project;

        $project = $this->db->get_where('projects', ['id' => $id_project])->row();
        $groups = $this->db->query("SELECT g.id, g.name FROM plans p LEFT JOIN plans_groups g ON g.id = id_group WHERE p.id_project = $id_project AND p.deleted = 0 and p.id_group is not null GROUP BY p.id_group")->result();

        $data = [
            'edit' => $plan ? TRUE : FALSE,
            'plan' => $plan,
            '_page' => 'plans',
            '_action' => Pages::ACTION_EDIT,
            'groups' => $groups,
            'project' => $project,
        ];
        loadView('plan_form', $data, FALSE);
    }

    public function save_plan($id_project = FALSE)
    {

        $rep = "ERROR";
        $name = $this->input->post('title');
        $id = $this->input->post('id');
        $desc = $this->input->post('desc');
        $type = $this->input->post('type') ?: 'auto';
        $id_group = $this->input->post('id_group');
        $group = $this->input->post('group');

        if(!hasPermission('plans', $id ? Pages::ACTION_EDIT : Pages::ACTION_ADD)) callback_whenNoPermission();

        if($id_group == 'new_group' && $group){
            $q = $this->db->insert('plans_groups', ['name' => $group]);
            $id_group = $q ? $this->db->insert_id() : null;
        }


        if($name && ($id || $id_project)){

            if ($id) {

                $query = $this->db->update('plans', [
                    'title' => $name,
                    'desc' => $desc,
                    'type' => $type,
                    'id_group' => $id_group,
                    'url' => $this->input->post('url'),
                    'date_modified' => time()], ['id' => $id]);
                if ($query) {
                    $id_project = $this->db->get_where('plans', ['id' => $id])->row()->id_project;
                    log_action($id_project, utils::METHOD_EDIT, 'Updated the plan ' . $name, 'plans', $id);
                }

            } else {
                $query = $this->db->insert('plans', [
                    'title' => $name,
                    'desc' => $desc,
                    'type' => $type,
                    'id_group' => $id_group,
                    'id_project' => $id_project,
                    'url' => $this->input->post('url'),
                    'date_added' => time(),
                    'date_modified' => time(),
                ]);
                if ($query) {
                    log_action($id_project, utils::METHOD_ADD, "Added a new plan ($name)", 'plans', $this->db->insert_id());
                }
            }
            if ($query) {
                $rep = "OK";
            }
        }
        responseJSON(['status' => $rep]);

    }

    public function delete_plan($id = FALSE)
    {
        if(!hasPermission('plans', Pages::ACTION_DELETE)) callback_whenNoPermission();
        $rep = "ERROR";
        if ($id) {
            $query = $this->db->update('plans', ['deleted' => 1], ['id' => $id]);
            if ($query) $rep = "OK";
        }
        responseJSON(['status' => $rep]);

    }

    public function get_members($id)
    {
        if(!hasPermission('project', Pages::ACTION_ANY)) callback_whenNoPermission();
        $result = doTwtable("SELECT u.username, p.id, p.type FROM projects_users p JOIN users u ON u.id = p.id_user WHERE p.id_project = $id", function (&$row) {
            $row->type = strtoupper($row->type);
        });

        $result->permissions = Pages::get_permissions('project');
        responseJSON($result);
    }

    public function add_member($id_project)
    {
        $users = $this->db->query("SELECT concat_ws(' ', u.first_name, u.last_name) name, u.username, u.id, p.id pid from users u LEFT JOIN projects_users p ON p.id_user = u.id AND p.id_project = $id_project WHERE p.id is null AND u.deleted = 0")->result();
        $data = [
            '_page' => 'project',
            '_action' => 'manage_members',
            'users' => $users,
            'project' => $this->db->get_where('projects', ['id' => $id_project])->row(),
        ];
        loadView('members_form', $data, FALSE);
    }

    public function save_member()
    {
        if(!hasPermission('project', 'manage_members')) callback_whenNoPermission();
        $data = (object)$this->input->post();
        $q = $this->db->insert('projects_users', $data);
        responseJSON(['status' => $q ? 'OK' : 'ERROR']);
    }

    public function delete_member($id = FALSE)
    {
        if(!hasPermission('project', 'manage_members')) callback_whenNoPermission();
        $rep = "ERROR";
        if ($id) {
            $query = $this->db->delete('projects_users', ['id' => $id]);
            if ($query) $rep = "OK";
        }
        responseJSON(['status' => $rep]);

    }

    public function get_cases($plan_id)
    {
        if(!hasPermission('cases', Pages::ACTION_READ)) callback_whenNoPermission();
        if (!$plan_id) callback_whenNotFound();
        $list = doTwtable(
            "SELECT c.*, t.name type_name, rc.status last_run FROM test_cases c LEFT JOIN runs_cases rc ON rc.id_case = c.id AND rc.deleted = 0 " .
            "LEFT JOIN `_case_types` t ON t.id = c.type " .
            "WHERE c.id_plan = $plan_id AND c.deleted = 0"
            , function (&$item) {

            $item->ref = '#' . str_pad($item->id, 4, '0', STR_PAD_LEFT);
            $item->desc = substr($item->desc, 0, 30);
            $item->time = fromNow($item->date_modified);
            $item->auto = (bool)$item->isauto;
            $item->last_run = $this->ui->status_badge($item->last_run ?: 4);

        });
        $list->permissions = Pages::get_permissions('cases');
        responseJSON($list);
    }

    public function one_case($id = FALSE)
    {
        $case = null;
        $id_plan = $this->input->post('id_plan');
        if (!$id_plan && !$id) callback_whenNotFound();
        $types = $this->db->get_where('_case_types', ['disabled' => 0, 'deleted' => 0])->result();
        $priorities = $this->db->get_where('_priorities', ['deleted' => 0])->result();

        if ($id) {
            $query = $this->db->get_where('test_cases', ['id' => $id]);
            $case = $query && $query->num_rows() > 0 ? $query->row() : null;
            $case->assert_values = json_decode($case->assert_values);
            $plan = $this->db->get_where('plans', ['id' => $case->id_plan])->row();
            if (!$plan) callback_whenNotFound();
            $case->steps = $this->db->order_by('order', 'asc')->get_where('test_steps', ['id_case' => $id])->result();
            $case->asserts = $this->db
                ->get_where('test_asserts', ['id_case' => $id])
                ->result();
        } else {
            $plan = $this->db->get_where('plans', ['id' => $id_plan])->row();
            if (!$plan) callback_whenNotFound();
        }


        $data = [
            '_page' => 'cases',
            '_action' => Pages::ACTION_EDIT,
            'edit' => $case ? TRUE : FALSE,
            'case' => $case,
            'plan' => $plan,
            'types' => $types,
            'priorities' => $priorities,
        ];


        loadView('case_form', $data, FALSE);
    }

    public function show_case_old($id)
    {
        if (!$id) callback_whenNotFound();
        $case = $this->db
            ->query("select u.username, uu.username username2, c.* FROM test_cases c left join users u ON u.id = c.id_user left join users uu ON uu.id = c.updated_by WHERE c.id = $id")
            ->row();
        if (!$case) callback_whenNotFound();
        $case->steps = $this->db->order_by('order', 'asc')->get_where('test_steps', ['id_case' => $id])->result();
        $case->asserts = $this->db
            ->get_where('test_asserts', ['id_case' => $id])
            ->result();
        $case->plan = $this->db->get_where('plans', ['id' => $case->id_plan])->row();
        $case->type = $this->db->get_where('_case_types', ['id' => $case->type])->row();
        $data = [
            '_page' => 'show_case',
            'case' => $case,
        ];
        loadView('case', $data, FALSE);
    }

    public function show_case($id)
    {
        if (!$id) callback_whenNotFound();
        $case = $this->db->query("SELECT c.* FROM test_cases c WHERE c.id = $id")->row();
        if (!$case) callback_whenNotFound();
        $case->plan = $this->db->get_where('plans', ['id' => $case->id_plan])->row();
        $case->project = $this->db->get_where('projects', ['id' => $case->plan->id_project])->row();
        $case->priority = $this->db->get_where('_priorities', ['id' => $case->priority])->row();
        $case->type = $this->db->get_where('_case_types', ['id' => $case->type])->row();
        $case->user = $this->db->get_where('users', ['id' => $case->id_user])->row();
        $case->maj_user = $this->db->get_where('users', ['id' => $case->updated_by])->row();
        $runs = $this->db->query("SELECT r.title, u.username, s.name, s.color, s.color2, s.icon FROM runs_cases c " .
            "JOIN runs r ON r.id = c.id_run " .
            "LEFT JOIN runs_executions e ON e.id_runcase = c.id " .
            "LEFT JOIN _status s ON e.status = s.id " .
            "LEFT JOIN users u ON u.id = e.id_user " .
            "WHERE c.id_case = $id AND c.deleted = 0")->result();
        $assets = $this->db->query("SELECT * FROM test_asserts WHERE id_case = $id")->result();
        $case->runs = $runs;
        $case->asserts = $assets;
        $case->steps = $this->db->order_by('order', 'ASC')->get_where('test_steps', ['id_case' => $id])->result();
        $data = [
            '_page' => 'cases',
            '_action' => Pages::ACTION_READ,
            'case' => $case,
        ];
        loadView('case_show', $data, FALSE);
    }

    public function save_case($plan_id)
    {
        if(!hasPermission('cases', Pages::ACTION_EDIT)) callback_whenNoPermission();
        if (!$plan_id) callback_whenNotFound();
        $plan = $this->db->get_where('plans', ['id' => $plan_id])->row();
        if (!$plan) callback_whenNotFound();
        $data = (object)$this->input->post();
        $rep = "";
        $steps = $this->input->post('steps') ?: [];
        $id = isset($data->id) ? $data->id : FALSE;
        $data->params = isset($data->params) ? json_encode($data->params) : '';
        $data->clear_cookies = $data->cookies === 'clear' ? 1 : 0;
        $data->use_cookies = $data->cookies === 'no' ? 0 : 1;
        unset($data->cookies);
        $data->headers = isset($data->headers) ? json_encode($data->headers) : '';
        $asserts = isset($data->asserts) ? $data->asserts : [];
        $data->date_modified = time();
        $data->updated_by = userInfo()->id;
        if ($id) {
            $query = $this->db->update('test_cases', $data, ['id' => $id]);
            if ($query) {
                $rep = 'OK';
            }

        } else {

            $data->order = $this->alpha->get_new_order_case($plan_id);
            $data->date_added = time();
            $data->id_plan = $plan_id;
            $data->id_user = userInfo()->id;
            $data->run_type = $plan->type;
            $query = $this->db->insert('test_cases', $data);
            $id = $query ? $this->db->insert_id() : null;
            if ($query) {
                $rep = 'OK';
            }

        }
        if ($query && $id) {
            $q = $this->db->delete('test_steps', ['id_case' => $id]);
            foreach ($steps as $step) {
                $step = (object)$step;
                $step->id_case = $id;
                $this->db->insert('test_steps', $step);
            }
            $q = $this->db->delete('test_asserts', ['id_case' => $id]);
            foreach ($asserts as $assert) {
                $assert = (object)$assert;
                $assert->id_case = $id;
                $this->db->insert('test_asserts', $assert);
            }

        }
        responseJSON(['status' => $rep]);

    }

    public function delete_case($id = FALSE)
    {
        if(!hasPermission('cases', Pages::ACTION_DELETE)) callback_whenNoPermission();
        $rep = "ERROR";
        if ($id) {
            $case = $this->db->get_where('test_cases', ['id' => $id])->row();
            $query = $this->db->update('test_cases', ['deleted' => 1], ['id' => $id]);
            if ($query) {
                $rep = "OK";
                $this->alpha->reorder_cases($case->id_plan);
            }
        }

        responseJSON(['status' => $rep]);

    }

    public function copy_case($id, $id_plan = FALSE)
    {
        if(!hasPermission('cases', Pages::ACTION_ADD)) callback_whenNoPermission();
        if (!$id) callback_whenNotFound();
        $rep = FALSE;
        $new_id = null;
        $case = $this->db->get_where('test_cases', ['id' => $id])->row();
        if (!$case) callback_whenNotFound();
        $steps = $this->db->get_where('test_steps', ['id_case' => $id])->result();
        $asserts = $this->db->get_where('test_asserts', ['id_case' => $id])->result();
        $case->id = null;
        $case->title .= ' (COPY)';
        $case->id_user = userInfo()->id;
        $case->updated_by = userInfo()->id;
        $case->date_added = time();
        $case->date_modified = time();
        $case->date_modified = time();
        $case->status = 0;
        if ($id_plan) $case->id_plan = $id_plan; else $id_plan = $case->id_plan;
        $case->order = $this->alpha->get_new_order_case($id_plan);
        $this->db->trans_begin();
        $q = $this->db->insert('test_cases', $case);
        $err = 0;
        if ($q) {
            $rep = TRUE;
            $new_id = $this->db->insert_id();
            foreach ($steps as $step) {
                $step->id_case = $new_id;
                $step->id = null;
                $q = $this->db->insert('test_steps', $step);
                if (!$q) $err++;

            }
            foreach ($asserts as $assert) {
                $assert->id_case = $new_id;
                $assert->id = null;
                $q = $this->db->insert('test_asserts', $assert);
                if (!$q) $err++;
            }
            if ($err > 0) {
                $rep = FALSE;
                $this->db->trans_rollback();
            }else{
                $this->alpha->reorder_cases($id_plan);
                $this->db->trans_commit();
            }
        } else {
            $this->db->trans_rollback();
        }



        responseJSON([
            'status' => $rep ? 'OK' : 'ERROR',
            'id' => $new_id,
        ]);
    }

    public function export_case($id)
    {
        if(!hasPermission('cases', 'export')) callback_whenNoPermission();
        if (!$id) callback_whenNotFound();
        $rep = FALSE;
        $new_id = null;
        $case = $this->db->get_where('test_cases', ['id' => $id])->row();
        if (!$case) callback_whenNotFound();
        $case->steps = $this->db->get_where('test_steps', ['id_case' => $id])->result();
        $case->asserts = $this->db->get_where('test_asserts', ['id_case' => $id])->result();
        unset($case->id);
        unset($case->deleted);
        foreach ($case->steps as $step) {
            unset($step->id);
            unset($step->id_case);
        }
        foreach ($case->asserts as $assert) {
            unset($assert->id);
            unset($assert->id_case);
            if ($assert->value2 === null) unset($assert->value2);
            if ($assert->value3 === null) unset($assert->value3);
            if ($assert->value4 === null) unset($assert->value4);
        }
        responseJSON($case);
    }

    public function existing_case($id_plan)
    {
        if (!$id_plan) callback_whenNotFound();
        $plan = $this->db->get_where('plans', ['id' => $id_plan])->row();
        if (!$plan) callback_whenNotFound();
        $cases = $this->db
            ->query("SELECT c.*, u.username, p.title plan, r.name project, t.name type_name  FROM test_cases c JOIN plans p ON p.id = c.id_plan JOIN users u ON u.id = c.id_user JOIN projects r ON r.id = p.id_project left join `_case_types` t ON t.id = c.type WHERE p.id != $id_plan AND c.deleted = 0 AND p.type = '{$plan->type}' ORDER BY c.date_modified DESC ")
            ->result();
        $data = [
            '_page' => 'cases',
            '_action' => Pages::ACTION_ADD,
            'id_project' => $plan->id_project,
            'cases' => $cases,
        ];
        loadView('existing_case', $data, FALSE);
    }

    public function runs($id_project)
    {
        if (!$id_project) callback_whenNotFound();
        $project = $this->db->get_where('projects', ['id' => $id_project])->row();
        if (!$project) callback_whenNotFound();
        $data = [
            '_page' => 'runs',
            '_action' => Pages::ACTION_READ,
            '_title' => 'Test Runs | ' . $project->name,
            'project' => $project,
        ];
        loadView('runs', $data);
    }

    public function one_run($id_project = FALSE, $id = FALSE)
    {
        $run = null;
        if (!$id && !$id_project) callback_whenNotFound();
        if ($id) {
            $query = $this->db->get_where('runs', ['id' => $id]);
            $run = $query && $query->num_rows() > 0 ? $query->row() : null;
        }
        if ($run) $id_project = $run->id_project;
        $releases = $this->db->get_where('projects_releases', ['deleted' => 0, 'id_project' => $id_project])->result();
        $users = $this->db->get_where('users', ['deleted' => 0])->result();
        $data = [
            '_page' => 'runs',
            '_action' => $id ? Pages::ACTION_EDIT : 'add',
            'edit' => $run ? TRUE : FALSE,
            'run' => $run,
            'releases' => $releases,
            'users' => $users,
            'id_project' => $id_project,
        ];
        loadView('run_form', $data, FALSE);
    }

    public function dt_runs()
    {
        if(!hasPermission('runs', Pages::ACTION_READ)) callback_whenNoPermission();
        $data = doDatatable("SELECT r.*, u.username, r.date_added date FROM runs r LEFT JOIN users u ON u.id = r.assigned_to");
        $data->permissions = Pages::get_permissions('runs');
        responseJSON($data);
    }

    public function get_runs($id_project)
    {
        if(!hasPermission('runs', Pages::ACTION_READ)) callback_whenNoPermission();
        if (!$id_project) callback_whenNotFound();
        $data = doTwtable(
            "SELECT r.*, u.username added_by, a.username assigned, re.name as `release` FROM runs r " .
            "LEFT JOIN users a ON a.id = r.assigned_to " .
            "LEFT JOIN users u ON u.id = r.id_user " .
            "LEFT JOIN projects_releases re ON re.id = r.id_release " .
            "WHERE r.id_project = $id_project AND r.deleted = 0 ",
            function (&$row) {
                $row->date = $row->date ?: '(unset)';
                $row->ref = '#' . str_pad($row->id, 4, '0', 0);
                $ov = $this->alpha->get_run_overview($row->id);
                $row->title = "<b>{$row->title}</b>";
                $row->cases = '<b>' . $ov->total . '</b>';
                $row->stat = "<div class='tiny_progress'>";
                foreach ($ov->data as $status) {
                    $row->stat .= '<span style="width: ' . $status->percent . '%; background : ' . $status->color . ';"></span>';
                }
                $row->stat .= '</div>';
                $st = '<span class="badge badge-secondary">PENDING</span>';
                if ($row->status === '1') {
                    $st = '<span class="badge badge-primary">OPEN</span>';
                } elseif ($row->status === '2') {
                    $st = '<span class="badge badge-success">FINISHED</span>';
                } elseif ($row->status === '3') {
                    $st = '<span class="badge badge-dark">CLOSED</span>';
                }
                $row->st = $st;

            });
        $data->permissions = Pages::get_permissions('runs');
        responseJSON($data);
    }

    public function save_run($id = FALSE)
    {
        if(!hasPermission('runs', $id ? Pages::ACTION_EDIT : Pages::ACTION_ADD)) callback_whenNoPermission();
        $data = (object)$this->input->post();
        $rep = "";
        $msg = "";
        $data->date_modified = time();
        $data->updated_by = userInfo()->id;
        if ($id) {

            $query = $this->db->update('runs', $data, ['id' => $id]);

        } else {

            $data->id_user = userInfo()->id;
            $data->date_added = time();
            $query = $this->db->insert('runs', $data);
            $id = $query ? $this->db->insert_id() : null;

        }
        if ($query) {
            $rep = 'OK';
        } else {
            $rep = "NO";
            $msg = "Error while saving the Test run :( ";
        }
        responseJSON(['status' => $rep, 'message' => $msg]);

    }

    public function delete_run($id = FALSE)
    {
        if(!hasPermission('runs', Pages::ACTION_DELETE)) callback_whenNoPermission();
        $rep = "ERROR";
        if ($id) {
            $query = $this->db->update('runs', ['deleted' => 1], ['id' => $id]);
            if ($query) $rep = "OK";
        }
        responseJSON(['status' => $rep]);

    }

    public function change_run_status()
    {
        if(!hasPermission('runs', Pages::ACTION_EDIT)) callback_whenNoPermission();
        $rep = "ERROR";
        $id = $this->input->post('id');
        $status = $this->input->post('status');
        if ($id && $status !== null) {
            $query = $this->db->update('runs', ['status' => intval($status)], ['id' => $id]);
            if ($query) $rep = "OK";
        }
        responseJSON(['status' => $rep]);

    }

    public function cases($id_run)
    {
        if (!$id_run) callback_whenNotFound();
        $run = $this->db->get_where('runs', ['id' => $id_run])->row();
        if (!$run) callback_whenNotFound();
        $project = $this->db->get_where('projects', ['id' => $run->id_project])->row();
        $data = [
            '_page' => 'runs',
            '_action' => 'manage_cases',
            '_title' => 'Test Run : ' . $run->title,
            'run' => $run,
            'project' => $project,
        ];
        loadView('run', $data);
    }

    public function get_runcases($id_run)
    {
        if(!hasPermission('runs', Pages::ACTION_READ)) callback_whenNoPermission();
        if (!$id_run) callback_whenNotFound();
        $statuses = $this->db->get_where('_status', ['deleted' => 0])->result();
        $data = doTwtable(
            "SELECT r.*, c.title, c.priority, c.type, c.run_type, tt.name type_name, ppr.name priority_name, ppr.icon picon, ppr.color pc, ppr.color2 pc2 FROM runs_cases r " .
            "JOIN test_cases c ON c.id = r.id_case " .
            "LEFT JOIN `_case_types` tt ON tt.id = c.type " .
            "LEFT JOIN `_priorities` ppr ON ppr.id = c.priority " .
            "WHERE r.deleted = 0 AND r.id_run = {$id_run} ",
            function (&$row) use ($statuses) {
                $row->ref = '#' . str_pad($row->id, 4, 0, 0);
                $runs = $this->db->get_where('runs_executions', ['id_runcase' => $row->id])->result();
                $row->iterations = count($runs);
                $row->stat = '<select style="display: none;" title="Set Result">';
                $s = null;
                foreach ($statuses as $status) {
                    if ($status->id === $row->status) $s = $status;
                    $row->stat .= '<option ' . ($status->id === $row->status ? 'selected' : '') . ' value="' . $status->id . '">' . $status->name . '</option>';
                }
                $row->stat .= '</select>';
                $row->priority_name = '<span style="color: ' . $row->pc2 . '; background-color: ' . $row->pc . '" class="priority"><i class="' . $row->picon . '"></i> ' . $row->priority_name . '</span>';
                $row->stat .= '<span class="run_status" style="background-color: ' . ($s ? $s->color : '#ccc') . ';color: ' . ($s ? $s->color2 : '#000') . ';">' . ($s ? ('<i class="' . $s->icon . '"></i>' . $s->name) : 'Pending ..') . '</span>';
                $row->rtype = '<span class="case_type ' . $row->run_type . '">' . strtoupper($row->run_type) . '</span>';

            });
        $data->permissions = Pages::get_permissions('run');
        responseJSON($data);
    }

    public function add_cases($id_run)
    {
        if (!$id_run) callback_whenNotFound();
        $run = $this->db->get_where('runs', ['id' => $id_run])->row();
        if (!$run) callback_whenNotFound();
        $plans = $this->db
            ->query("SELECT DISTINCT p.* FROM plans p JOIN test_cases c ON c.id_plan = p.id WHERE p.type = '{$run->type}' AND c.deleted = 0 AND p.deleted = 0 AND id_project = {$run->id_project}")
            ->result();
        $envs = $this->db->get_where('_environments', ['deleted' => 0])->result();
        $data = [
            '_page' => 'cases',
            '_action' => Pages::ACTION_EDIT,
            '_title' => 'Test Run plans : ',
            'run' => $run,
            'plans' => $plans,
            'envs' => $envs,
        ];
        loadView('add_cases', $data);
    }

    public function save_runcases($id_run)
    {
        if(!hasPermission('runs', Pages::ACTION_EDIT)) callback_whenNoPermission();
        if (!$id_run) callback_whenNotFound();
        $data = (object)$this->input->post();
        $errors = FALSE;
        $status = 'EMPTY';
        $q = $this->db->trans_begin();
        $last_order = $this->db->query("SELECT MAX(`order`) v FROM runs_cases WHERE id_run = $id_run AND deleted = 0");
        $last_order = $last_order->num_rows() > 0 ? ($last_order->row()->v ?: 0) : 0;
        $last_order += 1;

        foreach ($data->cases as $case) {


            $q = $this->db->insert('runs_cases', [
                'id_case' => $case,
                'id_run' => $id_run,
                'status' => 4,
                'order' => $last_order++,
            ]);
            if (!$q) $errors = FALSE;
        }
        if ($errors) {
            $status = 'ERROR';
            $this->db->trans_rollback();
        } else {
            $status = $this->db->trans_commit() ? 'OK' : 'ERROR';

        }
        responseJSON(['status' => $status]);

    }

    public function delete_runcase($id = FALSE)
    {
        if(!hasPermission('runs', Pages::ACTION_DELETE)) callback_whenNoPermission();
        $rep = "ERROR";
        if ($id) {
            $case = $this->db->get_where('runs_cases', ['id' => $id])->row();
            if($case){
                $query = $this->db->update('runs_cases', ['deleted' => 1], ['id' => $id]);
                if ($query) $rep = "OK";
                $this->alpha->reorder_runcases($case->id_run);
            }

        }

        responseJSON(['status' => $rep]);

    }

    public function run_testcase()
    {
        if(!hasPermission('runs', 'run')) callback_whenNoPermission();
        $id_runcase = $this->input->post('id');
        $runcase = $this->db->query("SELECT * FROM runs_cases WHERE id = $id_runcase")->row();
        if (!$runcase) callback_whenNotFound();
        $case = $this->db->query("SELECT * FROM test_cases WHERE id = {$runcase->id_case}")->row();
        $case->asserts = $this->db->query("SELECT * FROM test_asserts WHERE id_case = {$case->id}")->result();
        $case->params = json_decode($case->params) ?: [];
        $case->headers = json_decode($case->headers) ?: [];
        $result = $this->tester->run($case);
        foreach ($result->asserts as $assert) {

            $q = $this->alpha->set_assert_run_status($id_runcase, $assert->id, $this->alpha->getStatusFromString($assert->result), $assert);

        }
        $this->alpha->update_run_case_status($id_runcase);
        responseJSON($result);

    }

    public function releases($project_id)
    {
        if (!$project_id) callback_whenNotFound();
        $query = $this->db->get_where('projects', ['id' => $project_id, 'deleted' => 0]);
        $project = $query ? $query->row() : null;
        if (!$project) callback_whenNotFound();
        $data = [
            '_page' => 'releases',
            '_action' => Pages::ACTION_READ,
            '_title' => 'Releases | ' . $project->name,
            'project' => $project,
        ];
        loadView('releases', $data);
    }

    public function get_releases($project_id)
    {
        if(!hasPermission('releases', Pages::ACTION_READ)) callback_whenNoPermission();
        $data = doTwtable("SELECT r.*, u.username FROM projects_releases r LEFT JOIN users u ON u.id = r.updated_by WHERE r.id_project = $project_id AND r.deleted = 0", function (&$row) {
            $row->deadline = date('Y-m-d', $row->deadline);
            $row->start = date('Y-m-d', $row->start);
            $row->date_added = date('Y-m-d', $row->date_added);
            $row->date_modified = date('Y-m-d H:i', $row->date_modified);
            $row->ref = '#v' . str_pad($row->id, 4, 0, 0);
        });
        $data->permissions = Pages::get_permissions('releases');
        responseJSON($data);
    }

    public function one_release($id_project = FALSE, $id = FALSE)
    {
        $release = null;
        if (!$id && !$id_project) callback_whenNotFound();
        if ($id) {
            $query = $this->db->get_where('projects_releases', ['id' => $id]);
            $release = $query && $query->num_rows() > 0 ? $query->row() : null;
        }
        if ($release) $id_project = $release->id_project;
        $data = [
            '_page' => 'releases',
            '_action' => $id ? Pages::ACTION_EDIT : Pages::ACTION_ADD,
            'edit' => $release ? TRUE : FALSE,
            'release' => $release,
            'id_project' => $id_project,
        ];
        loadView('release_form', $data, FALSE);
    }

    public function save_release($id = FALSE)
    {
        if(!hasPermission('releases', $id ? Pages::ACTION_EDIT : Pages::ACTION_ADD)) callback_whenNoPermission();
        $data = (object)$this->input->post();
        $rep = "";
        $msg = "";
        $data->date_modified = time();
        $data->updated_by = userInfo()->id;
        $data->start = strtotime($data->start);
        $data->deadline = strtotime($data->deadline);
        if ($id) {

            $query = $this->db->update('projects_releases', $data, ['id' => $id]);

        } else {

            $data->id_user = userInfo()->id;
            $data->date_added = time();
            $query = $this->db->insert('projects_releases', $data);
            $id = $query ? $this->db->insert_id() : null;

        }
        if ($query) {
            $rep = 'OK';
        } else {
            $rep = "NO";
            $msg = "Error while saving the Test run :( ";
        }
        responseJSON(['status' => $rep, 'message' => $msg]);

    }

    public function delete_release($id = FALSE)
    {
        if(!hasPermission('releases', Pages::ACTION_DELETE)) callback_whenNoPermission();
        $rep = "ERROR";
        if ($id) {
            $query = $this->db->update('projects_releases', ['deleted' => 1], ['id' => $id]);
            if ($query) $rep = "OK";
        }
        responseJSON(['status' => $rep]);

    }

    public function run_test($id_run)
    {

        if (!$id_run) callback_whenNotFound();
        $run = $this->db->get_where('runs', ['id' => $id_run, 'deleted' => 0])->row();
        if (!$run) callback_whenNotFound();
        $project = $this->db->get_where('projects', ['id' => $run->id_project])->row();
        $cases = $this->db->query("SELECT c.*, r.status rstatus, r.id id_runcase FROM runs_cases r " .
            "JOIN test_cases c ON c.id = r.id_case " .
            "WHERE r.id_run = {$run->id} AND r.deleted = 0 ORDER BY c.order, c.id_plan")
            ->result();
        foreach ($cases as $case) {
            $case->steps = $this->db->query("SELECT ts.*, e.status last_run FROM test_steps ts LEFT JOIN runs_executions e ON e.`key` = 'step' AND e.key_id = ts.id WHERE ts.id_case = {$case->id} ORDER BY ts.`order`")->result();
            $case->asserts = $this->db->query("SELECT ts.*, e.status last_run FROM test_asserts ts LEFT JOIN runs_executions e ON e.`key` = 'assert' AND e.key_id = ts.id WHERE id_case = {$case->id}")->result();
            $case->stat = $this->db->query("SELECT * FROM `_status` WHERE id = {$case->rstatus}")->row();
            $q = $this->db->query("SELECT e.date FROM runs_executions e JOIN runs_cases r ON r.id = e.id_runcase WHERE r.id_run = $id_run AND r.id_case = {$case->id} ORDER BY e.date DESC LIMIT 1");
            $q = $q && $q->num_rows() > 0 ? $q->row()->date : '';
            $case->last_text = $q ? fromNow($q) : '';
            $case->last = $q ? date('Y-m-d H:i', $q) : '';
            foreach ($case->steps as $step) {
                if ($step->last_run === null) {
                    $this->alpha->set_step_run_status($case->id_runcase, $step->id, 4);
                    $step->last_run = '4';
                }
            }
            foreach ($case->asserts as $assert) {
                if ($assert->last_run === null) {
                    $this->alpha->set_assert_run_status($case->id_runcase, $assert->id, 4, []);
                    $assert->last_run = '4';
                }
            }
        }
        $data = [
            '_page' => 'runs',
            '_action' => 'run',
            '_title' => 'Running TEST | ' . $run->title,
            'project' => $project,
            'run' => $run,
            'cases' => $cases,
            'stats' => $this->alpha->get_status(),
        ];
        loadView('run_test', $data);
    }

    public function test_a_case($id_case)
    {
        $case = $this->db->get_where('test_cases', ['id' => $id_case ?: 0])->row();
        if (!$case) callback_whenNotFound();
        $data = [
            '_action' => 'test',
            '_page' => 'cases',
            'case' => $case,
        ];
        loadView('test_a_case', $data, FALSE);

    }

    public function do_test($id){
        if(!hasPermission('cases', 'test')) callback_whenNoPermission();
        $case = $this->db->get_where('test_cases', ['id' => $id ?: 0])->row();
        $case->asserts = $this->db->query("SELECT * FROM test_asserts WHERE id_case = $id")->result();
        $q = $this->tester->run($case);

        $q->status_id = $this->alpha->getStatusFromString($q->result);
        $q->status = $this->ui->status_badge($q->status_id);

        foreach ($q->asserts as $assert){
            $assert->status_id = $this->alpha->getStatusFromString($assert->result);
            $assert->status = $this->ui->status_badge($assert->status_id);
        }

        responseJSON($q);
    }


    public function order_case($id_case, $order){
        $order = strtoupper($order);
        if(!$id_case || !$order) callback_whenNotFound();
        $case = $this->db->query("SELECT * FROM test_cases WHERE id = $id_case AND deleted = 0")->row();
        if(!$case) callback_whenNotFound();

        $cases = $this->db->query("SELECT * FROM test_cases WHERE id_plan = {$case->id_plan} AND deleted = 0")->result();

        $q = $q2 = TRUE;

        if(($order === 'UP' && $case->order > 1) || ($order === 'DOWN' && $case->order < (count($cases)))){
            $order_num = $case->order += ($order == 'UP' ? -1 : 1);

            $q = $this->db->query("UPDATE test_cases SET `order` = `order` ".(($order == 'UP' ? '+' : '-'))." 1 WHERE `order` = {$case->order} AND id_plan = {$case->id_plan}");
            $q2 = $this->db->query("UPDATE test_cases SET `order` = $order_num WHERE id = {$case->id}");
        }


        responseJSON(['status' => $q && $q2 ? 'OK' : 'NO']);

    }

    public function order_runcase($id_rcase, $order){
        $order = strtoupper($order);
        if(!$id_rcase || !$order) callback_whenNotFound();
        $case = $this->db->query("SELECT * FROM runs_cases WHERE id = $id_rcase AND deleted = 0")->row();
        if(!$case) callback_whenNotFound();

        $cases = $this->db->query("SELECT * FROM runs_cases WHERE id_run = {$case->id_run} AND deleted = 0")->result();

        $q = $q2 = TRUE;

        if(($order === 'UP' && $case->order > 1) || ($order === 'DOWN' && $case->order < (count($cases)))){
            $order_num = $case->order += ($order == 'UP' ? -1 : 1);

            $q = $this->db->query("UPDATE runs_cases SET `order` = `order` ".(($order == 'UP' ? '+' : '-'))." 1 WHERE `order` = {$case->order} AND id_run = {$case->id_run}");
            $q2 = $this->db->query("UPDATE runs_cases SET `order` = $order_num WHERE id = {$case->id}");
        }


        responseJSON(['status' => $q && $q2 ? 'OK' : 'NO']);

    }
    public function reorder_runcases($id_run){
        $result = TRUE;

        $q = $this->db->query("SELECT * FROM runs_cases WHERE id_run = $id_run ORDER BY `order`")->result();

        $order = 1;
        foreach ($q as $row){
            $qq = $this->db->update('runs_cases', ['order' => $order++], ['id' => $row->id]);
            if(!$qq) $result = FALSE;
        }



        responseJSON(['status' => $result ? 'OK' : 'NO']);

    }

    public function update_run_step()
    {
        $id_step = $this->input->post('id_step');
        $id_runcase = $this->input->post('id_runcase');
        $id_status = $this->input->post('id_status');
        $q = FALSE;
        if ($id_runcase && $id_status && $id_step) {
            $q = $this->alpha->set_step_run_status($id_runcase, $id_step, $id_status);
        }
        responseJSON([
            'status' => $q ? 'OK' : 'ERROR',
        ]);

    }

    public function get_runcase_status($id)
    {
        $rep = null;
        if ($id) {
            $rep = $this->db->query("SELECT s.* FROM runs_cases c JOIN `_status` s ON s.id = c.status WHERE c.id = $id")->row();
        }
        responseJSON(['data' => $rep]);

    }

    public function get_plan_cases($id_plan, $id_run = FALSE)
    {
        $data = [];
        if ($id_plan) {
            if ($id_run) {
                $q = $this->db->query("SELECT id_case id FROM runs_cases WHERE id_run = $id_run AND deleted = 0")->result();
                $ids = "0";
                foreach ($q as $row) $ids .= ($ids ? ', ' : '') . $row->id;
                $this->db->where("id not in ($ids)");
            }
            $data = $this->db->get_where('test_cases', ['id_plan' => $id_plan, 'deleted' => 0])->result();
        }
        responseJSON([
            'status' => 'OK',
            'data' => $data,
        ]);
    }

    public function run_test_old($id)
    {
        if (!$id) callback_whenNotFound();
        $case = $this->db
            ->query("select u.username, uu.username username2, c.* FROM test_cases c left join users u ON u.id = c.id_user left join users uu ON uu.id = c.updated_by WHERE c.id = $id")
            ->row();
        if (!$case) callback_whenNotFound();
        $data = [
            '_page' => 'show_case',
            'case' => $case,
        ];
        loadView('run_test', $data, FALSE);

    }

    public function run()
    {
        $id_case = $this->input->post('id');
        $type = $this->input->post('type');
        if (!$id_case) callback_whenNotFound();
        $case = $this->db->get_where('test_cases', ['id' => $id_case])->row();
        if (!$case) callback_whenNotFound();
        $query = $this->tester->run($case);
        responseJSON($query);
    }

    public function get_run_stats($id_run){
        $cases = $this->db->query("SELECT s.id, s.name, s.icon, s.color, s.color2, rc.total FROM `_status` s LEFT JOIN (SELECT status, count(status) total FROM runs_cases WHERE id_run = $id_run AND deleted = 0 GROUP BY status) rc ON rc.status = s.id WHERE s.deleted = 0 ORDER BY s.type DESC");
        $cases = $cases ? $cases->result() : [];

        $message = "This Test Run has never been executed, Click on Start Running to execute the Run ..";
        $btn = "<button type='button' class='btn btn-sm btn-secondary'>Start <i class='fas fa-forward'></i></button>";

        $finished = TRUE;
        $running = FALSE;


        foreach ($cases as $case) {
            if($case->id === '4' && $case->total > 0) $finished = FALSE;
            if(($case->id !== '4' && $case->total > 0) && !$running) $running = TRUE;

        }

        if($running) $message = "Continue the execution by clicking on the Button below";
        if($finished) $message = "It seems that the Test Run was finished, Try to mark it as closed, or Start another Execution round.";

        $data = [
            '_page' => 'runs',
            '_action' => 'run',
            '_title' => 'Test Run Status',
            'stats' => $cases,
            'message' => $message,
            'button' => $btn,
            'finished' => $finished,
            'running' => $running,
        ];

        loadView('run_inline_stats', $data, FALSE);

    }
}
