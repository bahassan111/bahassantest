<?php
addJS([
    'assets/js/views/task_form.js',
]);
?>

<div class="" id="task_form">


    <form method="post" enctype="multipart/form-data" action="<?= site_url('tasks/save_task/'.($edit ? $task->id : '')); ?>">
        <input type="hidden" name="id_project" value="<?= $project->id; ?>">

        <div class="form-group">
            <label for="title">Title</label>
            <input required value="<?= $edit ? $task->title : ''; ?>" name="title" id="title" type="text" class="form-control form-control-sm">
        </div>
        <div class="form-group">
            <label for="details">Details</label>
            <textarea required class="form-control form-control-sm" name="details" id="details"><?= $edit ? $task->title : ''; ?></textarea>
        </div>
        <div class="form-group">
            <label for="id_release">Release</label>
            <select required title="Select a release" name="id_release" id="id_release" class="selectpicker">
                <?php foreach($project->releases as $release){ ?>
                    <option <?= $edit && $release->id === $task->id_release ? 'selected' : ''; ?> value="<?= $release->id; ?>"><?= $release->name; ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="form-group">
            <label for="priority">Priority</label>
            <select title="Select a priority" name="priority" id="priority" class="selectpicker">
                <?php foreach($priorities as $priority){ ?>
                    <option <?= $edit && $priority->id === $task->priority ? 'selected' : (!$edit && $priority->id === '2' ? 'selected' : ''); ?> value="<?= $priority->id; ?>"><?= $priority->name; ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="form-group">
            <label for="affected_to">Affected To</label>
            <select title="Select a member" name="affected_to" id="affected_to" class="selectpicker">
                <?php foreach($project->members as $member){ ?>
                    <option <?= $edit && $member->id === $task->affected_to ? 'selected' : ''; ?> value="<?= $member->id; ?>"><?= $member->username; ?></option>
                <?php } ?>
            </select>
        </div>
        <div class="form-group">
            <label for="team">Collaborators</label>
            <select multiple title="Select a member" name="team[]" id="team" class="selectpicker">

                <?php foreach($project->members as $member){
                    $selected = '';
                    if($edit){
                        foreach ($task->team as $item) if($item->id === $member->id) $selected = 'selected';
                    }
                    ?>
                    <option <?= $selected; ?> value="<?= $member->id; ?>"><?= $member->username; ?></option>
                <?php } ?>

            </select>
        </div>
        <div class="form-group">
            <label for="date">Start Date</label>
            <input required value="<?= $edit ? $task->date : date('Y-m-d'); ?>" name="date" id="date" type="text" class="form-control form-control-sm datepicker">
        </div>
        <div class="form-group">
            <label for="time">Estimated time (in minutes)</label>
            <input value="<?= $edit ? $task->time : '60'; ?>" name="time" id="time" type="number" class="form-control form-control-sm">
            <div class="times_list_f">
                <span data-tmm="15">15min</span>
                <span data-tmm="30">30min</span>
                <span data-tmm="45">45min</span>
                <span data-tmm="60">1h</span>
                <span data-tmm="120">2h</span>
                <span data-tmm="180">3h</span>
                <span data-tmm="240">4h</span>
                <span data-tmm="480">8h</span>
                <span data-tmm="960">2d</span>
                <span data-tmm="1440">3d</span>
                <span data-tmm="1920">4d</span>
            </div>
        </div>
        <div class="form-group">
            <label for="deadline">Deadline</label>
            <input value="<?= $edit ? $task->deadline : date('Y-m-d'); ?>" name="deadline" id="deadline" type="text" class="form-control form-control-sm datepicker">
        </div>
        <div class="form-group">
            <label for="tags">Tags</label>
            <input value="<?= $edit ? $task->tags : ''; ?>" name="tags" id="tags" type="text" class="form-control form-control-sm">
        </div>
    </form>


</div>
