import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:logger/logger.dart';
import 'package:rider_app/constants/constants.dart';
import 'package:rider_app/controllers/controllers.dart';
import "package:latlong/latlong.dart";
import 'package:dio/dio.dart' as dio;
import 'package:rider_app/helpers/helpers.dart';
import 'package:rider_app/models/models.dart';
import 'package:rider_app/models/ride.dart';
import 'package:rider_app/ui/components/components.dart';

class TripAcceptController extends GetxController {
  static AuthController authTo = Get.find();

  Ride ride;
  NetWorkCall networkCall = NetWorkCall();
  String vehicleType;
  ValueNotifier<String> rideStatus = ValueNotifier(RideStatus.notBokked);
  LatLng currentLocation;
  MapMatchingModel mapMatchingModel;
  RouteDetailModel routeDetail;
  int tripId;
  String driverImage;
  String driverRating;
  String carType;
  Future isAnyRideBooked() async {
    print("authTo.userModel.riderid ${authTo.userModel.riderid}");

    final result = await networkCall.postRequestWithResponse(
      url: Urls.riderCurrentride,
      json: {
        Params.riderId: authTo.userModel.riderid,
      },
    );

    return result.fold((l) {
      return null;
    }, (response) {
      print("response ----- > " + response.toString());
      try {
        if (response.data['response'] != "Fail!") {
          ride = Ride.fromJson(response.data['ridedetail']);
          return ride.id;
        }
      } catch (e) {
        return null;
      }
    });
  }

  Future<bool> isAnyRide() async {
    final result = await networkCall.postRequestWithResponse(
      url: Urls.rideRetrieveRide,
      json: {
        Params.riderId: authTo.userModel.riderid,
      },
    );

    return result.fold((l) {
      // BotToast.showWidget(
      //   toastBuilder: (_) => ErrorDialog(
      //     title: "".tr,
      //     message: l,
      //   ),
      // );
      return false;
    }, (response) {
      if (response != null) {
        print(response.data['response'] + " --!Fail!");
        if (response.data['response'] != "Fail!") {
          return true;
        } else {
          return false;
        }
      }
      return false;
    });
  }

  Future getVehicleCategory() async {
    BotToast.showLoading();
    final result = await networkCall.postRequest(
      url: Urls.vehicleSubtype,
      json: {
        Params.id: ride.carCategory,
      },
    );

    return result.fold((l) {
      // BotToast.showWidget(
      //   toastBuilder: (_) => ErrorDialog(
      //     title: "".tr,
      //     message: l,
      //   ),
      // );
      BotToast.closeAllLoading();
    }, (response) {
      if (response.responsecode == 1) {
        List<RiderVehicleSubTypeModel> subtypeOfVehicles = [];
        response.response.forEach((vehicle) {
          subtypeOfVehicles.add(RiderVehicleSubTypeModel.fromJson(vehicle));
          if (subtypeOfVehicles.last.id == ride.vichleType) {
            vehicleType = subtypeOfVehicles.last.categoryName;
          }
        });
      }

      BotToast.closeAllLoading();
    });
  }

  // following function will call basic route for path
  Future getRouteBetweenPath() async {
    String pickAndDropPins =
        '${double.parse(ride.pickuplong)},${double.parse(ride.pickuplat)};${double.parse(ride.droplong)},${double.parse(ride.droplat)}';
    String directionUrl = Urls.getNavigationUrl(pickAndDropPins);
    final result = await networkCall.getRequest(
      url: directionUrl,
    );

    return result.fold((l) {
      // BotToast.showWidget(
      //   toastBuilder: (_) => ErrorDialog(
      //     title: "".tr,
      //     message: l,
      //   ),
      // );
    }, (response) async {
      if (response?.statusCode == 200) {
        routeDetail = RouteDetailModel.fromJson(response.data);
        if (routeDetail.code == "Ok") {
          await getMapMatchingPoints();
        }
      }
    });
  }

  // this method will get detail points of path
  Future getMapMatchingPoints() async {
    String points = '';
    // it 100 is limit to pass points, so to make api will not break set to 90
    int i = 0;
    points +=
        '${double.parse(ride.pickuplong)},${double.parse(ride.pickuplat)};';

    routeDetail.routes.first.legs.forEach((leg) {
      leg.steps.forEach((step) {
        step.intersections.forEach((inter) {
          if (i < 90) {
            points += '${inter.location.first},${inter.location.last};';
          }
          i++;
        });
      });
    });

    points += '${double.parse(ride.droplong)},${double.parse(ride.droplat)}';
    String mapMatchingUrl = Urls.getMapMatchingUrl(points);
    final result = await networkCall.getRequest(
      url: mapMatchingUrl,
    );
    return result.fold((l) {
      // BotToast.showWidget(
      //   toastBuilder: (_) => ErrorDialog(
      //     title: "".tr,
      //     message: l,
      //   ),
      // );
    }, (response) {
      if (response?.statusCode == 200) {
        if (routeDetail.code == "Ok") {
          mapMatchingModel = MapMatchingModel.fromJson(response.data);
        }
      }
    });
  }

  Future getRideDetail(
      {bool isShowLoadingIndicator = false, bool shoDialog = true}) async {
    Map<String, dynamic> data;

    if (isShowLoadingIndicator) {
      BotToast.showLoading();
    }
    if (tripId == null) {
      final result = await networkCall.postRequestWithResponse(
        url: Urls.rideRetrieveRide,
        json: {
          Params.riderId: authTo.userModel.riderid,
        },
      );

      result.fold((l) {}, (response) {
        if (response.data['response'] != "Fail!") {
          data = response.data['getridedetails'];
          driverImage = response.data['imagedetails'];
          driverRating = response.data['ratings'];
          carType = response.data['car_category'];
        }
      });
    } else {
      final result = await networkCall.postRequestWithResponse(
        url: Urls.rideDetail,
        json: {
          Params.riderId: authTo.userModel.riderid,
          Params.rideId: tripId,
        },
      );

      result.fold((l) {}, (response) {
        print("response type " + response.data.runtimeType.toString());
        try {
          data = response.data['myridedetails'];
          if (response.data['myridedetails'] != null) {
            driverImage = "https://dms.thecandytech.com/uploads/driver/" +
                response.data['myridedetails']["profile_photo"];
          }
          driverRating = response.data['driverrating'];
        } catch (e) {
          data = null;
        }
      });
    }
    if (data == null) {
      if (shoDialog) {
        BotToast.showWidget(
          toastBuilder: (_) => SuccessDialog(
            title: "noRide".tr,
            message: "noRideAvailableAtTheMoment".tr,
            ontap: () {
              BotToast.cleanAll();
              Get.back();
            },
          ),
        );
      }
    } else {
      ride = Ride.fromJson(data);
      rideStatus.value = ride.rideStatus;
      tripId = int.parse(ride.id);
      if (isShowLoadingIndicator) {
        await getRouteBetweenPath();
        await getVehicleCategory();
      }
    }

    if (isShowLoadingIndicator) {
      BotToast.closeAllLoading();
    }
  }

  // Future getRideDetail(
  //     {bool isShowLoadingIndicator = false, bool shoDialog = true}) async {
  //   Map<String, dynamic> data;
  //   try {
  //     if (isShowLoadingIndicator) {
  //       BotToast.showLoading();
  //     }
  //     if (tripId == null) {
  //       final result = await networkCall.postRequestWithResponse(
  //         url: Urls.rideRetrieveRide,
  //         json: {
  //           Params.riderId: authTo.userModel.riderid,
  //         },
  //       );

  //       return result.fold((l) {
  //         BotToast.showWidget(
  //           toastBuilder: (_) => SuccessDialog(
  //             title: "error",
  //             message: l,
  //           ),
  //         );
  //       }, (response) async {
  //         if (response.data['response'] != "Fail!") {
  //           data = response.data['getridedetails'];
  //           driverImage = response.data['imagedetails'];
  //           driverRating = response.data['ratings'];
  //           carType = response.data['car_category'];
  //         } else {
  //           final result2 = await networkCall.postRequestWithResponse(
  //             url: Urls.rideDetail,
  //             json: {
  //               Params.riderId: authTo.userModel.riderid,
  //               Params.rideId: tripId,
  //             },
  //           );

  //           return result2.fold((l) {
  //             BotToast.showWidget(
  //               toastBuilder: (_) => SuccessDialog(
  //                 title: "error",
  //                 message: l,
  //               ),
  //             );
  //           }, (response2) async {
  //             data = response2.data['myridedetails'];
  //             if (response2.data['myridedetails'] != null) {
  //               driverImage = "https://dms.thecandytech.com/uploads/driver/" +
  //                   response.data['myridedetails']["profile_photo"];
  //             }
  //             driverRating = response2.data['driverrating'];

  //             if (data == null) {
  //               if (shoDialog) {
  //                 BotToast.showWidget(
  //                   toastBuilder: (_) => SuccessDialog(
  //                     title: "noRide".tr,
  //                     message: "noRideAvailableAtTheMoment".tr,
  //                     ontap: () {
  //                       BotToast.cleanAll();
  //                       Get.back();
  //                     },
  //                   ),
  //                 );
  //               }
  //             } else {
  //               ride = ride.fromJson(data);
  //               tripId = int.parse(ride.id);
  //               if (isShowLoadingIndicator) {
  //                 await getRouteBetweenPath();
  //                 await getVehicleCategory();
  //               }
  //             }
  //             ;

  //             BotToast.closeAllLoading();
  //           });
  //         }
  //       });
  //     }
  //     BotToast.closeAllLoading();
  //   } catch (e) {
  //     Logger().wtf(e);
  //   }
  // }

  Future cancelTrip() async {
    BotToast.showLoading();
    final result = await networkCall.postRequestWithResponse(
      url: Urls.cancelride,
      json: {
        Params.rideId: tripId,
        Params.reason: "",
        Params.statusType: 2,
        Params.cancelDateTime: DateTime.now().toString(),
        Params.bookType: int.parse(ride.bookType)
      },
    );
    return result.fold((l) {
      BotToast.showWidget(
        toastBuilder: (_) => ErrorDialog(
          title: "".tr,
          message: l,
        ),
      );
    }, (r) {
      BotToast.closeAllLoading();
    });
  }
}
