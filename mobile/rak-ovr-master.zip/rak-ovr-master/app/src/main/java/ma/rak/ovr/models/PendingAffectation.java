package ma.rak.ovr.models;


import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class PendingAffectation extends RealmObject {

    @PrimaryKey
    private String currentAgent;
    private String newAgent;
    private String gerance;
    private String date;

    public PendingAffectation() {
    }

    public PendingAffectation(String currentAgent, String newAgent, String gerance, String date) {
        this.currentAgent = currentAgent;
        this.newAgent = newAgent;
        this.gerance = gerance;
        this.date = date;
    }

    public String getCurrentAgent() {
        return currentAgent;
    }

    public void setCurrentAgent(String currentAgent) {
        this.currentAgent = currentAgent;
    }

    public String getNewAgent() {
        return newAgent;
    }

    public void setNewAgent(String newAgent) {
        this.newAgent = newAgent;
    }

    public String getGerance() {
        return gerance;
    }

    public void setGerance(String gerance) {
        this.gerance = gerance;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "PendingAffectation{" +
                "currentAgent='" + currentAgent + '\'' +
                ", newAgent='" + newAgent + '\'' +
                ", gerance='" + gerance + '\'' +
                ", date='" + date + '\'' +
                '}';
    }
}

