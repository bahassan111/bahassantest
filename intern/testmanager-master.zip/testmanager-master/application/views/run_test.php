<?php
addJS([
    'assets/js/views/run_test.js',
]);

viewHeader(
    'Running '.$run->title,
    '',
    [
        (object) ['name' => 'Dashboard', 'url' => site_url()],
        (object) ['name' => 'Projects', 'url' => site_url('projects')],
        (object) ['name' => $project->name, 'url' => getProjectUrl($project)],
        (object) ['name' => 'Test Runs', 'url' => getProjectUrl($project, 'runs')],
        (object) ['name' => 'Running Test', 'url' => ''],
    ], true);

projectMenu('test_runs', $project);
?>


<div class="test_running n_menu" id="run_test_view">

    <?php if($run->type === 'auto'){?>
        <div id="autotrun_stats" class="loading">
            <div class="autorun_overview">
                <div class="autr_right">
                    <div class="autr_stats">
                        <div class="total">
                            <b>-</b>
                            <span>Test Cases</span>
                        </div>
                        <div style="color:#1971d0;" class="srunning">
                            <b>-</b>
                            <span>RUNNING</span>
                        </div>
                        <div style="color:#f7f7f7;" class="spending">
                            <b>-</b>
                            <span>PENDING</span>
                        </div>
                        <div style="color:#39e8b9;" class="spassed">
                            <b>-</b>
                            <span>PASSED</span>
                        </div>
                        <div style="color:#ff717d;" class="sfailed">
                            <b>-</b>
                            <span>FAILED</span>
                        </div>
                        <div style="color:#ffc61f;" class="snotapplicable">
                            <b>-</b>
                            <span>NOTAPPLICABLE</span>
                        </div>
                    </div>
                    <div class="autr_actions">
                        <p>Error while loading the Data</p>
                        <button type="button" class="btn btn-sm btn-secondary">Start <i class="fas fa-forward"></i></button>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>

    <?php foreach($cases as $i => $case){ ?>

        <div class="rtest_case <?= $case->run_type !== 'auto' ? 'open' : '' ?>" data-runcaseid="<?= $case->id_runcase; ?>">
            <div class="h">
                <span class="r"><i class="fas fa-angle-right"></i></span>
                <?php if($case->run_type !== 'auto'){?>
                    <span class="n"><?= $i+1; ?></span>
                <?php }else{?>
                    <span class="n">
                    <button data-autocase="<?= $case->id_runcase ?>" class="btnx btn-sm btn btn-outline-info">Run <i class="fas fa-play"></i></button>
                    <button data-title="Run tests from here inwards" data-rautocase="<?= $case->id_runcase ?>" class="btnx btn-sm btn btn-outline-secondary"> <i class="fas fa-forward"></i></button>
                </span>
                <?php } ?>

                <span class="t"><?= $case->title; ?></span>
                <?php if($case->run_type === 'auto'){?>
                    <span class="s"><small class="rlast_run" data-title="<?= $case->last; ?>"><?= $case->last_text; ?></small></span>
                <?php } ?>
                <span class="s">
                    <span style="color: <?= $case->stat->color2 ?>; background-color: <?= $case->stat->color ?>" class="run_status">
                        <i class="<?= $case->stat->icon ?>"></i> <?= $case->stat->name ?>
                    </span>
                </span>
            </div>
            <div class="b" style="display: <?= $case->run_type !== 'auto' ? 'block' : 'none' ?>">
                <?php if($case->run_type !== 'auto'){
                    foreach($case->steps as $step){?>

                        <div class="rtest_step step_wstatus_<?= $step->last_run ?>" data-stepid="<?= $step->id; ?>">
                            <div class="h">
                                <div class="n"><b><?= $step->order; ?></b></div>
                                <div class="t"><p><?= $step->todo; ?></p></div>
                            </div>
                            <div class="b">
                                <label>Expected Result</label>
                                <div class="e"><p><?= $step->expect; ?></p></div>
                            </div>
                            <div class="a">
                                <label>Mark</label>

                                <div>
                                    <ul class="run_stat_list">
                                        <?php foreach($stats as $stat){ ?>
                                            <li data-statid="<?= $stat->id; ?>" class="<?= $stat->id === $step->last_run ? 'selected' : ''; ?>">
                                                <span style="color: <?= $stat->color2 ?>; background-color: <?= $stat->color ?>" class="run_status">
                                                    <i class="<?= $stat->icon ?>"></i> <?= $stat->name ?>
                                                </span>
                                            </li>
                                        <?php } ?>
                                    </ul>
                                </div>
                            </div>

                        </div>

                    <?php }
                }else{
                    ?>


                    <div class="rtest_request">
                        <div class="rtestr_inner">
                            <label>Request</label>
                            <div class="rtestr_inner_list">

                                <div><span>Method</span><b><span class="label_method <?= strtolower($case->method) ?>"><?= $case->method; ?></span></b></div>
                                <div><span>Url</span><b><?= $case->url; ?></b></div>
                                <div><small>Header</small></div>
                                <?php foreach((json_decode($case->headers) ?: []) as $header => $v){ ?>
                                    <div><span><?= $header; ?></span><b><?= $v; ?></b></div>
                                <?php } ?>
                                <div><small>Parametres</small></div>
                                <?php foreach((json_decode($case->params) ?: []) as $k => $v){ ?>
                                    <div><span><?= $k; ?></span><b><?= $v; ?></b></div>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="rtestr_inner">
                            <label>Expected result rules</label>
                            <div class="rtestr_inner_list">
                                <?php foreach($case->asserts as $x => $assert){ $assr = asserts($assert->id_assert); ?>
                                    <?php if(count($assr->values) > 1){?>
                                        <div><small><?= $assr->title; ?></small></div>
                                        <?php foreach($assr->values as $i => $value){$x = $i+1; ?>
                                            <div><span><?= $value->title; ?></span><b><?= $assert->{'value' . $x}; ?></b></div>
                                        <?php } ?>
                                    <?php }else{?>
                                        <div><small>Condition <?= $x +1 ?></small></div>
                                        <?php foreach($assr->values as $i => $value){$x = $i+1; ?>
                                            <div><span><?= $assr->title; ?></span><b><?= $assert->{'value' . $x}; ?></b></div>
                                        <?php } ?>
                                <?php } ?>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="rtestr_inner">
                            <label>Result</label>
                            <div class="rtestr_inner_list">
                                <?php foreach($case->asserts as $x => $assert){ $assr = asserts($assert->id_assert); ?>
                                    <?php if(count($assr->values) > 1){?>
                                        <div><small><?= $assr->title; ?></small></div>
                                        <?php foreach($assr->values as $i => $value){$x = $i+1; ?>
                                            <div><span>Result</span><b><?= $assert->last_run ?></b></div>
                                        <?php } ?>
                                    <?php }else{?>
                                        <div><small>Condition <?= $x +1 ?></small></div>
                                        <?php foreach($assr->values as $i => $value){$x = $i+1; ?>
                                            <div><span>Result</span><b><?= $assert->last_run ?></b></div>
                                        <?php } ?>
                                    <?php } ?>
                                <?php } ?>
                            </div>
                        </div>


                    </div>



                    <?php
                } ?>
            </div>
        </div>


    <?php } ?>
</div>





<script>
    var project_id = <?= $project->id ?: 0; ?>;
    var run_id = <?= $run->id ?: 0; ?>;
</script>
