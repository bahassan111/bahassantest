import 'package:flutter/material.dart';
import 'package:rider_app/constants/app_themes.dart';
import 'package:rider_app/constants/images.dart';
import 'package:get/get.dart';
import 'package:rider_app/controllers/controllers.dart';

class CustomeAppBar extends StatelessWidget {
  final Function updateMenuPosition;
  final bool isMenuShow;
  final String title;
  static AuthController authTo = Get.find();

  const CustomeAppBar(
      {Key key, this.updateMenuPosition, this.isMenuShow, this.title})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        height: 80,
        padding: EdgeInsets.only(left: 20),
        child: Row(
          children: [
            GestureDetector(
              onTap: () {
                updateMenuPosition();
              },
              child: Container(
                height: 40,
                width: 40,
                decoration: BoxDecoration(
                  color: isMenuShow
                      ? AppThemes.lightBlackbackGroundColor
                      : AppThemes.lightWhitebackGroundColor,
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: AppThemes.lightMenuIconBorder,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: isMenuShow
                          ? AppThemes.lightBlackbackGroundColor.withOpacity(0.3)
                          : AppThemes.lightMenuIconShadow.withOpacity(0.5),
                      blurRadius: 20,
                      spreadRadius: 20,
                      offset: Offset(0, 15),
                    )
                  ],
                ),
                child: Center(
                  child: Image.asset(AllImages.menu,
                      height: 15,
                      width: 15,
                      color: isMenuShow
                          ? AppThemes.lightWhitebackGroundColor
                          : AppThemes.lightBlackbackGroundColor),
                ),
              ),
            ),
            SizedBox(
              width: 20,
            ),
            Center(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  RichText(
                    text: TextSpan(
                      text: "hello".tr + ', ',
                      style: Theme.of(context)
                          .textTheme
                          .headline2
                          .copyWith(fontSize: 16),
                      children: [
                        TextSpan(
                          text: authTo.userModel.fullname,
                          style: Theme.of(context).textTheme.headline5.copyWith(
                              fontSize: 16, fontWeight: FontWeight.w700),
                        )
                      ],
                    ),
                  ),
                  Text(
                    title,
                    style: Theme.of(context).textTheme.headline2.copyWith(
                        fontSize: 18, fontWeight: FontWeight.w700, height: 1.1),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
