﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CCISFMMND
{
    public partial class history : Form
    {
        public DB db;
        public String selected;
        public history()
        {
            InitializeComponent();
            db = new DB();
        }


        void fixC()
        {
            list.Columns[0].Width = list.Width / 3;
            list.Columns[1].Width = list.Width / 3;
            list.Columns[2].Width = list.Width / 3;
        }
        private void DbExplore_Load(object sender, EventArgs e)
        {

            init();
            fixC();
        }

        public void init()
        {
            list.Items.Clear();
            var history = db.getHistory();

            foreach (var file in history)
            {
                var parts = file.Name.Replace(".unl", "").Split('_');
                var date = parts.Length > 0 ? parts[0] : "";
                var remise = parts.Length > 1 ? parts[1] : "";

                var ne = new Telerik.WinControls.UI.ListViewDataItem(date, new string[] { date, remise, file.LastWriteTime.ToString("yyyy-MM-dd HH:mm")});


                ne.Tag = file.FullName;
                list.Items.Add(ne);

            }
        }

        private void DbExplore_Resize(object sender, EventArgs e)
        {
            fixC();
        }

        

        private void list_SelectedItemChanged(object sender, EventArgs e)
        {
            if (list.SelectedItem != null) del.Enabled = true;
        }

        private void del_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Voulez vous vraiment supprimer le fichier selectionné?", "Supprimer", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
            {
                var s = list.SelectedItem;
                var lasti = list.SelectedIndex;

                if (s != null)
                {
                    var r = (String)s.Tag;
                    try
                    {
                        File.Delete(r);
                        init();
                    }
                    catch (Exception ee)
                    {
                        MessageBox.Show("Impossible de supprimer le fichier selectionné");
                    }
                }
            }
        }

        private void list_ItemMouseClick(object sender, Telerik.WinControls.UI.ListViewItemEventArgs e)
        {
            
        }

        private void list_ItemMouseDoubleClick(object sender, Telerik.WinControls.UI.ListViewItemEventArgs e)
        {
            var s = (string)list.SelectedItem.Tag;
            this.selected = s;
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }
    }
}
