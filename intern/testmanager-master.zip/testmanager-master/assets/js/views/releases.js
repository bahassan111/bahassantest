(function () {
    var view = $('#releases_view');
    if (!view.length) return;

    var table = $('.releases_list');

    $(view)


        .on('click', '.add_run', function () {
            ajaxSideModal('project/one_run/' + project_id, 'Create a Test Run', 'far fa-paper-plane', {
                close_text : 'Cancel',
                size : 'lg',
                confirm_text : 'Save Test Run',
                whenLoaded : function(modal, data){
                    log('?');
                    modal.on('change', '#id_group', function () {

                    })
                },
                whenConfirm : function(modal, data){

                },
                whenError : function(modal, error){},
                whenClosed : function(modal){},

            });
        })
        .ready(function () {

            table.twTable({

                url     : site_url + 'project/get_releases/' + project_id,
                key     : 'id',

                dblclick : function(id, tr){
                    addRelease(id);
                },

                columns : [
                    {name : 'id', data : 'ref', title : 'ID', orderable : true, searchable : false},
                    {name : 'name', data : 'name', title : 'name', orderable : true, searchable : false},
                    {name : 'start', data : 'start', title : 'Starts', orderable : true, searchable : true},
                    {name : 'deadline', data : 'deadline', title : 'Deadline', orderable : true, searchable : true},
                    {name : 'deadline', data : 'deadline', title : 'Deadline', orderable : true, searchable : true},
                    {name : 'date_modified', data : 'date_modified', title : 'Last Update', orderable : true, searchable : true},
                    {name : 'username', data : 'username', title : 'By', orderable : true, searchable : true},
                ],

                buttons : [
                    {
                        text : 'Add',
                        icon : 'fas fa-plus',
                        color : 'primary',
                        global : true,
                        remote : 'add',
                        action : function(){
                            addRelease();
                        },
                    },
                    {
                        separator : true,
                    },


                    {
                        icon : 'fas fa-pencil-alt',
                        global : false,
                        remote : 'edit',
                        action : function(id){
                            addRelease(id);

                        },
                    },
                    {separator : true},
                    {
                        icon : 'fas fa-times',
                        global : false,
                        remote : 'delete',
                        action : function(id){
                            deleteRelease(id)
                        },
                    },

                ],

            });



        })
    ;


    function addRelease(id) {

        ajaxSideModal('project/one_release/' + project_id + (id ? ('/' + id) : '') ,'Create a Release', 'far fa-paper-plane', {
            close_text : 'Cancel',
            confirm_text : 'Save',
            size: 'md',
            whenLoaded : function(modal, data){
                handleInits(modal);

                modal.find('form')
                    .validate();
                modal
                    .on('submit', 'form', function (e) {
                        e.preventDefault();
                        var btn = modal.find('.confirm').prop('disabled', true);

                        var form = $(this);

                        if(form.valid()){
                            post('project/save_release/' +(id || ''), form.serialize(), function (rep) {
                                if(rep.status === 'OK'){
                                    toastr_('The release was successfully added', 'success', 'success', 6000);
                                    modal.sideModal('hide');
                                    table.twTable('refresh');
                                }else{
                                    toastr_(rep.message || 'Error while saving the data', 'error', 'danger', 9000);
                                }
                            })
                        }



                    })
            },
            whenConfirm : function(modal, data){
                modal.find('form').submit();
            },
            whenError : function(modal, error){},
            whenClosed : function(modal){},

        });
    }
    function deleteRelease(id) {
        ask('Are you sure?', 'Do you really want to delete this Release from the list?, this action will clear all the reports.', function (yes) {

            if(yes){

                post('project/delete_release/' + id, {}, function (rep) {
                    if(rep.status === 'OK'){
                        toastr_('The Release was successfully deleted from this Run!', 'success', 'success');
                        table.twTable('refresh');
                    }else{
                        toastr_("We couldn't remove the selected release", 'error', 'danger');
                    }
                })

            }else{

            }

        }, 'Yes', 'Cancel', true);
    }



})();