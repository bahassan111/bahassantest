package ma.rak.ov.bodyResponse;

import java.util.ArrayList;
import java.util.HashMap;

public class RootResponse {

    String status;
    String message;
    HashMap<String, String> data;

    public RootResponse() {
    }

    public RootResponse(String status, String message, HashMap<String, String> data) {
        this.status = status;
        this.message = message;
        this.data = data;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public HashMap<String, String> getData() {
        return data;
    }

    public void setData(HashMap<String, String> data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "RootResponse{" +
                "status='" + status + '\'' +
                ", message='" + message + '\'' +
                ", data=" + data +
                '}';
    }
}
