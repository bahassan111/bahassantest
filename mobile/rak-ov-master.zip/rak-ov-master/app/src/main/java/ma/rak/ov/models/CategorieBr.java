package ma.rak.ov.models;

import io.realm.RealmObject;

public class CategorieBr extends RealmObject {
    private int ID;
    private String label;
    private String CODEGERA;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public CategorieBr() {
    }

    public CategorieBr(int ID, String label, String codegera) {
        this.ID = ID;
        this.label = label;
        CODEGERA = codegera;
    }


    public String getCODEGERA() {
        return CODEGERA;
    }

    public void setCODEGERA(String CODEGERA) {
        this.CODEGERA = CODEGERA;
    }

    @Override
    public String toString() {
        return "CategorieBr{" +
                "ID=" + ID +
                ", label='" + label + '\'' +
                ", CODEGERA='" + CODEGERA + '\'' +
                '}';
    }
}
