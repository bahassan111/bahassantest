import React, { Component } from "react";
import { connect } from "react-redux";
import { Text } from "react-native-ui-lib";

class CustomText extends Component {
  render() {
    const renderText = () => {
      if (this.props.small) {
        return (
          <Text
            {...this.props}
            style={{
              fontFamily:
                this.props.lang == "ar" ? "ge-thameen-book" : "bw-seido-round",
              textAlign: this.props.lang == "ar" ? "right" : "left"
            }}
          >
            {this.props.children}
          </Text>
        );
      } else {
        return (
          <Text
            {...this.props}
            style={{
              fontFamily:
                this.props.lang == "ar" ? "ge-thameen-book" : "bw-seido-round",
              fontSize: this.props.fontSize,
              textAlign: this.props.lang == "ar" ? "right" : "left"
            }}
          >
            {this.props.children}
          </Text>
        );
      }
    };
    return renderText();
  }
}

const mapStateToProps = state => {
  return {
    fontSize: state.fontSize.fontSize,
    lang: state.fontSize.lang
  };
};

export default connect(mapStateToProps)(CustomText);
