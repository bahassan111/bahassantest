package ma.rak.ovr.models;

import io.realm.RealmObject;

public class Categorie extends RealmObject {
    private int ID;
    private String label;
    private String codegera;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Categorie() {
    }

    public Categorie(int ID, String label, String codegera) {
        this.ID = ID;
        this.label = label;
        this.codegera = codegera;
    }

    @Override
    public String toString() {
        return "Categorie{" +
                "ID=" + ID +
                ", label='" + label + '\'' +
                ", gerance='" + codegera + '\'' +
                '}';
    }

    public String getCodegera() {
        return codegera;
    }

    public void setCodegera(String codegera) {
        this.codegera = codegera;
    }
}
