import 'package:rider_app/models/models.dart';

class Legs {
  List<Steps> steps;
  List<Admins> admins;
  var duration;
  var distance;
  var weight;
  String summary;

  Legs(
      {this.steps,
      this.admins,
      this.duration,
      this.distance,
      this.weight,
      this.summary});

  Legs.fromJson(Map<String, dynamic> json) {
    if (json['steps'] != null) {
      steps = [];
      json['steps'].forEach((v) {
        steps.add(new Steps.fromJson(v));
      });
    }
    if (json['admins'] != null) {
      admins = [];
      json['admins'].forEach((v) {
        admins.add(new Admins.fromJson(v));
      });
    }
    duration = json['duration'];
    distance = json['distance'];
    weight = json['weight'];
    summary = json['summary'];
  }
}
