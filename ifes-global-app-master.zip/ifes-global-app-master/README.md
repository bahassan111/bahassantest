# README

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for?

- Quick summary
- Version
- [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### Android keystore && alias

keystore password : ifes2019
Key alias : ifes
Key password : ifes2019

### build android

expo build:android

### build ios

expo build:ios

### How do I get set up?

TestFlight to test app for iOS
Add new app in iTunes connect
Open xCode —> dev tools —> application loader —> select & upload IPA —> Wait 15 minutes.
It can now be added to iTunes connect. In the meantime, descriptions can be filled in, and screenshots etc. can be uploaded.

### Remove Alpha from Icon

"mogrify -alpha off _/_.png;" replace "\_" width \*

### Contribution guidelines

- Writing tests
- Code review
- Other guidelines

### Installation?

- type in terminal : yarn

### Dev?

- Create an account in expo.io;

- open Terminal to login with expo created: expo login;

- Lanch project : watchman watch-del-all; expo start --no-dev --lan ;

### Build IOS/Android?

- Lanch Terminal and Type: expo build:ios or expo buid:android;

### Who do I talk to?

- Info credentials for publishing the app

expo fetch:android:keystore

Keystore password: 6c558a711eda497a80f502164985f8c1
Key alias: QG1ubTg0L0lGRVMtTU9CSUxF
Key password: 05c86f53a1e144e296706d7008e87458

java -jar pepk.jar --keystore=IFES-MOBILE.jks --alias=QG1ubTg0L0lGRVMtTU9CSUxF --output=encrypted_private_key_path --encryptionkey=eb10fe8f7c7c9df715022017b00c6471f8ba8170b13049a11e6c09ffe3056a104a3bbe4ac5a955f4ba4fe93fc8cef27558a3eb9d2a529a2092761fb833b656cd48b9de6a

MD5: 0B:46:B7:BD:00:9E:F4:25:3F:3F:5F:31:D6:CC:96:14

SHA1: 4B:D2:5A:AB:FD:8D:89:7A:D5:02:B5:2D:04:C3:DB:15:4F:71:32:37

SHA256: 60:46:14:6B:68:8E:12:99:A1:50:CC:17:36:94:8D:75:9F:A7:60:F8:83:28:7D:10:EA:16:FC:67:A0:FE:E4:8F
