import React, { Component } from "react";
import { StyleSheet, ScrollView, TouchableOpacity } from "react-native";
import { ExpoLinksView } from "@expo/samples";

import Colors from "../constants/Colors";
import Icon from "../constants/Icons";
import { DrawerActions } from "react-navigation";

import { View, Text } from "react-native-ui-lib"; //eslint-disable-line

export default class LinksScreen extends Component {
  static navigationOptions = ({ navigation }) => ({
    title: "Links" + navigation.getParam("chapitreId", "NO-ID"),
    headerTitle: (
      <View row flex paddingH-10 centerV>
        <View flex>
          <TouchableOpacity
            onPress={() => navigation.dispatch(DrawerActions.openDrawer())}
          >
            <Icon name="menu" iconSize={50} color={Colors.green} />
          </TouchableOpacity>
        </View>
        <View row flex center paddingH-8>
          <Text text50>Links</Text>
        </View>
        <View flex />
      </View>
    )
  });

  render() {
    console.log("params", this.props.navigation);
    return (
      <ScrollView style={styles.container}>
        {/* Go ahead and delete ExpoLinksView and replace it with your
         * content, we just wanted to provide you with some helpful links */}
        <ExpoLinksView />
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 15,
    backgroundColor: "#fff"
  }
});
