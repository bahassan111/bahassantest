import 'package:flutter/material.dart';
import 'package:rider_app/constants/constants.dart';
import 'package:rider_app/controllers/controllers.dart';
import 'package:rider_app/ui/components/components.dart';
import 'package:get/get.dart';

class SignInUI extends StatefulWidget {
  @override
  _SignInUIState createState() => _SignInUIState();
}

class _SignInUIState extends State<SignInUI> {
  double height, width;
  static AuthController to = Get.find();
  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  bool isPasswordReadOnly = true;
  FocusNode passwordFocusNode = FocusNode();

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Container(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              CustomeBackButton(),
              SizedBox(
                height: 10,
              ),
              Image.asset(
                AllImages.theCandy,
                width: (3 * width) / 4,
              ),
              Image.asset(
                AllImages.undrawTravelers,
                height: width / 2,
                fit: BoxFit.cover,
              ),
              getInputFields(context),
              SizedBox(
                height: 30,
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 35),
                child: singInButton(),
              ),
              SizedBox(
                height: 20,
              ),
              GestureDetector(
                onTap: () => Get.toNamed("/ForgotPasswordUI"),
                child: Text(
                  "forgotPassword".tr.toUpperCase(),
                  style: Theme.of(context)
                      .textTheme
                      .headline5
                      .copyWith(fontSize: 15, fontWeight: FontWeight.bold),
                ),
              ),
              SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
      ),
    );
  }

  singInButton() {
    return GestureDetector(
      onTap: () {
        to.signIn(email: email.text.trim(), password: password.text.trim());
      },
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 5),
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          color: AppThemes.lightPinkBackGroundColor,
        ),
        child: Center(
          child: Text(
            "signIn".tr.toUpperCase(),
            style: Theme.of(context)
                .textTheme
                .subtitle1
                .copyWith(fontSize: 20, fontWeight: FontWeight.w700),
          ),
        ),
      ),
    );
  }

  getInputFields(context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 35),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "email".tr,
            style: Theme.of(context).textTheme.headline2.copyWith(fontSize: 15),
          ),
          FormInputField(
            controller: email,
            keyboardType: TextInputType.emailAddress,
          ),
          SizedBox(
            height: 20,
          ),
          Text(
            "password".tr,
            style: Theme.of(context).textTheme.headline2.copyWith(fontSize: 15),
          ),
          FormInputField(
            controller: password,
            obscureText: isPasswordReadOnly,
            focusNode: passwordFocusNode,
            iconSuffix: GestureDetector(
              onTap: () {
                if (!passwordFocusNode.hasFocus) {
                  passwordFocusNode.unfocus();
                  passwordFocusNode.canRequestFocus = false;
                }
                setState(() {
                  isPasswordReadOnly = !isPasswordReadOnly;
                });
              },
              child: Image.asset(
                AllImages.showPassword,
                height: 10,
                width: 10,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
