export default {
	appname : 'DIB NEWS',
	loading_news : "Chargement des actualités ...",
	checking_updates : "Vérification des mises à jour ..",
	sys_msg : "Démarrage ..",


	start_btn : 'Personaliser ',
	welcome_title : 'Bienvenue sur DIB News',
	welcome_text : 'Commencez par personnaliser votre application, appuyez sur le bouton de personnalisation ci-dessous pour commencer..',
	select_your_language : 'Choisissez votre langue',
	select_layout : 'Votre mise en page préférée',
	layouts_description : 'Personnalisez votre écran de flux',
	themes_description : 'Personnalisez votre écran de flux',
	modern_mode : 'Mode moderne',
	stack_mode : 'Mode Classic',
	select_theme : 'Votre thème préféré',
	theme_light : "Claire",
	theme_dark : "Foncé",
	setup_final_message : "Enjoy ..",
	go_back : "Retour",
	save_language : "Enregistrer la langue",
	save_layout : "Enregistrer la mise en page",
	finish_btn : "Terminer!",

	save : 'Enregistrer',
	settings : 'Réglages',
	home: 'Accueil',

	reset : 'réinitialiser',
}
