﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Net.Sockets;
using WebSockets.Server.WebSocket;
using WebSockets.Common;
using System.IO;
using WebSocketsCmd.Meta;

namespace WebSocketsCmd.Server
{
    internal class APIWebSocketService : WebSocketService
    {
        private readonly IWebSocketLogger _logger;
        Pay pay;
        string token = "12345678";

        public APIWebSocketService(Stream stream, TcpClient tcpClient, string header, IWebSocketLogger logger)
            : base(stream, tcpClient, header, true, logger)
        {
            _logger = logger;
            pay = new Pay(print_ticket);
            Pay.log("Starting #######################");
        }

        public int print_ticket(string data)
        {
            var pdata = TwParser.parseTLV(data);

            var print_tag = pdata.getTag(TwConstants.TAG_PRINT_MSG);

            if (print_tag != null)
            {

                if (print_tag.Val.ToLower().Contains("copie commerçant")) return 0;
                if (print_tag.Val.ToLower().Contains("copie commercant")) return 0;
                if (print_tag.Val.ToLower().Contains("copie commer")) return 0;

                base.Send("print|" + print_tag.Val);
            }

            

            return 0;
        }

        protected override void OnTextFrame(string text)
        {
            string response = "ServerABC?: " + text;
            Pay.log(text);
            //base.Send(response);

            // limit the log message size
            //string logMessage = response.Length > 100 ? response.Substring(0, 100) + "..." : response;
            //_logger.Information(this.GetType(), logMessage);

            var parts = text.Split('|');
            if (parts.Length < 2)
            {
                base.Send("error|ERROR : UNKNOWN METHOD");
                return;
            }

            var cmd = parts[0];
            var user_token = parts[1];

            if (user_token != this.token)
            {
                base.Send("error|ERROR : UNKNOWN TOKEN?");
                return;
            }

            switch (cmd)
            {
                case "hello":
                    base.Send("hello|HELLO BACK");
                    break;

                case "login":
                    if (parts.Length < 6)
                    {
                        base.Send("error|ERROR : UNKNOWN METHOD");
                        return;
                    }

                    var pv = parts[2];
                    var mid = parts[3];
                    var id = parts[4];
                    var pwd = parts[5];

                    this.Send("login|" + this.signOn(pv, mid, id, pwd));
                    break;

                case "get_terminal_id":
                    this.Send("get_terminal_id|" + pay.TerminalID);
                    break;

                case "get_stan":
                    this.Send("get_stan|" + pay.STAN);
                    break;

                case "close_session":

                    if (parts.Length < 3)
                    {
                        base.Send("error|ERROR : UNKNOWN METHOD");
                        return;
                    }

                    string close_sess_id = parts[2];

                    RepCode closeRep = pay.closeSession(close_sess_id);
                    pay.signOff();
                    this.Send("close_session|" + closeRep.code + "|" + closeRep.message);
                    break;

                case "rollback":

                    if (parts.Length < 4)
                    {
                        base.Send("error|ERROR : UNKNOWN METHOD");
                        return;
                    }


                    string stan = parts[2];
                    string cardnum = parts[3];
                    string pay_mode = parts[4];
                    string session = parts[5];
                    string stantpe = parts[6];

                    var sess = Pay.nextSessionID().ToString();

                    TwTAG void_data = new TwTAG(TwConstants.TAG_VOID_REQUEST_DATA, -1, "", new[]{
                    
                            new TwTAG(TwConstants.TAG_VOID_REQUEST_STD_DATA, -1, "", new[]{
                                new TwTAG(TwConstants.TAG_EFT_STAN, -1, stantpe),
                                new TwTAG("0032", -1, pay_mode),
                                new TwTAG(TwConstants.TAG_SESSION_ID, -1, sess),
                            }),

                            new TwTAG(TwConstants.TAG_VOID_REQUEST_ADDITIONNAL_DATA, -1, "", new[]{
                                new TwTAG(TwConstants.TAG_ECR_STAN, -1, stan),
                                new TwTAG(TwConstants.TAG_VOID_KIND, -1, "5"),
                                new TwTAG(TwConstants.TAG_CARD_LAST_DIGITS_NEW, -1, cardnum),
                            }),

                        });


                    RepCode void_rep = pay.voidTx(void_data, sess);



                    this.Send("rollback|" + void_rep.code + "|" + void_rep.message);
                    break;

                case "pay":
                    

                    if (parts.Length < 3)
                    {
                        base.Send("error|ERROR : UNKNOWN METHOD");
                        return;
                    }

                    var amount = int.Parse(parts[2]);

                  

                    var rep = pay.processPayement(amount);


                 

                  
                    

                    Pay.log("Payed with : " + rep.ToString());

                    if (rep.code == "0000")
                    {
                        var stan_tpe = pay.last_pay_c3.getTag("0029");
                        var card_type = pay.last_pay_c3.getTag("006A");
                        var amt = pay.last_pay_c3.getTag("000C");
                        var card = pay.last_pay_c3.getTag(TwConstants.TAG_CARD_LAST_DIGITS_NEW);
                        var sessid = pay.last_pay_c3.getTag(TwConstants.TAG_SESSION_ID);
                        var stan_sys = pay.last_pay_c3.getTag(TwConstants.TAG_ECR_STAN);
                        var paymode = pay.last_pay_c3.getTag("0032");


                        base.Send(String.Format("pay|OK|{0}|{1}|{2}|{3}|{4}|{5}|{6}", 
                            amt!=null ? amt.Val : "",
                            stan_sys != null ? stan_sys.Val : "", 
                            card_type !=null ? card_type.Val : "",
                            card != null ? card.Val.Substring(card.Val.Length - 4) : "",
                            sessid != null ? sessid.Val : "",
                            paymode != null ? paymode.Val : "",
                            stan_tpe != null ? stan_tpe.Val : ""
                            ));

                        base.Send("pay_ok|" + (pay.last_pay_c3.ToString()));
                        base.Send("pay_ok_2|" + (pay.last_pay_c2.ToString()));
                        base.Send("pay_ok_extra|" + pay.last_pay_c3.ToReadableString());
                    }
                    else
                    {
                        base.Send("pay|" + rep.code + '|' + rep.message);
                    }

                   

                    
                    break;

                
            }
        }


        public string signOn(string pv, string mid, string id, string pwd)
        {
            var rep = pay.signOn(pv, mid, id, pwd);
           

            if (rep.code != "0000")
            {
                return  rep.code + '|' + rep.message;
            }
            else
            {
                return "OK";                
            }

            
        }
    }
}
