(function () {
    var view = $('#case_form_view');
    if (!view.length) return;

    $(view)
        .on('click', '.case_params > .l > div', function () {
            $(this).addClass('selected').parent().find('.selected').not(this).removeClass('selected');

        })
        .on('click', '.case_params > .t .r', function () {
            $(this).closest('.case_params').find('.l > .selected').slideUp(removeMe);
        })
        .on('click', '.case_params > .t .a', function () {
            $(this).closest('.case_params').find('.l').append('<div><span contenteditable="true">key</span><span contenteditable="true">val</span></div>')
        })
        .on('change', '#assert', function () {
            var val = $(this).val(), parent = $('.asserts_values');

            if(val){
                parent.find('>div').hide().removeClass('v');
                parent.find('.fg_' + val).addClass('v').fadeIn();
            }
        })
        .on('click', '.add_casestep', function () {


            var steps = $('.case_steps');
            var num = steps.find('.case_step').length;

            steps.find('.case_step').last().after(`<div class="case_step">
                                <span data-number="${num+1}">${num+1}</span>
                                <div class="cstep_actions">
                                    <a href="javascript:void(0);" class="r"><i class="fas fa-times"></i></a>
                                    <a href="javascript:void(0);" class="u"><i class="fas fa-angle-up"></i></a>
                                    <a href="javascript:void(0);" class="d"><i class="fas fa-angle-down"></i></a>
                                </div>
                                <div class="cstep_todo">
                                    <label>Todo :</label>
                                    <textarea></textarea>
                                </div>
                                <div class="cstep_assert">
                                    <label>Expected Result :</label>
                                    <textarea></textarea>
                                </div>
                            </div>`);

            steps.closest('.smodal_body').scrollTop(9999999);
        })
        .on('click', '.cstep_actions > a.u', function () {
            var step = $(this).closest('.case_step');
            if(step.index() > 0) step.prev().before(step);
            numerateSteps();
        })
        .on('click', '.cstep_actions > a.d', function () {
            var step = $(this).closest('.case_step'),
                next = step.next();

            if(next.is('.case_step')) step.next().after(step);
            numerateSteps();
        })
        .on('click', '.cstep_actions > a.r', function () {
            var step = $(this).closest('.case_step');

            if(step.parent().find('.case_step').length === 1){
                step.find('textarea').val('');
            }else{
                step.remove();
                numerateSteps();
            }
        })

        .on('click', '.add_case_expect', function () {
            var btn = $(this),
                div = $('.case_assert'),
                holder = $('.expect_results_holder')
            ;

            holder.addClass('inedit');

            div.find('input').val('').end().find('#assert').val(0).trigger('change');

            div.data('edit', false).slideDown();
        })
        .on('click', '.cancelassert', function () {
            $('.expect_results_holder').removeClass('inedit');
            $('.case_assert').slideUp();
        })
        .on('click', '.saveassert', function () {
            var div = $('.case_assert'),
                holder = $('.expect_results_holder'),
                assert = $('#assert'),
                val = $('.asserts_values > div:visible')
            ;

            var data = {
                assert : assert.val(),
                value : []
            };

            val.find('input, select').each(function () {
                data.value.push({
                    id : this.id,
                    val : $(this).val(),
                })
            });

            var item = $('<div class="case_expect_item"><span></span>' +
                '<a href="javascript:void(0);" class="e"><i class="fas fa-pencil-alt"></i></a>' +
                '<a href="javascript:void(0);" class="r"><i class="fas fa-times"></i></a></div>');

            if(div.data('edit')){
                item = $(div.data('edit'));
            }else{
                item.appendTo('.case_expect_list');
            }

            item.data('data', data);

            item.find('>span').html(assert.find('option[value="'+data.assert+'"]').html());

            div.data('edit', false).slideUp();
            holder.removeClass('inedit');


        })
        .on('click', '.case_expect_item > a.r', function () {
            $(this).parent().slideUp(removeMe);
        })
        .on('click', '.case_expect_item > a.e', function () {
            var btn = $(this),
                div = $('.case_assert'),
                assert = $('#assert'),
                holder = $('.expect_results_holder'),
                item = $(this).parent()
            ;

            holder.addClass('inedit');


            var data = item.data('data');

            assert.val(data.assert).trigger('change');

            $.each(data.value, function () {
                $('.fg_' + data.assert).find('#' + this.id).val(this.val);
            });


            div.data('edit', item).slideDown();
        })

        .on('submit', 'form', function (e) {
            e.preventDefault();
            var form = $(this);

            log(form);
            //form.find('input, textarea, select, button').prop('disabled', true);

            var data = {};


            form.find('[name]').each(function () {
                data[this.name] = $(this).val();
            });


            data.params = {};
            $('.case_params.p > .l > div').each(function () {
                var key = $(this).find('span').first().html();
                data.params[key] = $(this).find('span').last().html();
            });
            data.headers = {};
            $('.case_params.h > .l > div').each(function () {
                var key = $(this).find('span').first().html();
                data.headers[key] = $(this).find('span').last().html();
            });

            data.asserts = [];

            $('.case_expect_item').each(function () {
               var dt = $(this).data('data');

               var assert = {id_assert : dt.assert };

               $.each(dt.value, function (i) {
                   assert['value' + (i+1)] = this.val;
               });

                data.asserts.push(assert);
            });


            data.steps = [];
            $('.case_step').each(function (i, item) {
                data.steps.push({
                    order : $(item).find('> span').data('number'),
                    todo : $(item).find('.cstep_todo > textarea').val(),
                    expect : $(item).find('.cstep_assert textarea').val(),
                });
            });

            log(data);

            post('project/save_case/' + plan_id, data, function (rep) {

                if(rep.status === 'OK'){
                    toastr_('The test case was added successfully', 'success', 'success');
                    view.closest('.side_modal').sideModal('hide');
                    log('finished');
                    view.closest('.side_modal').trigger('submit_finished');

                }else{
                    toastr_('Error while saving the test case', 'error', 'danger');
                }

            }, function () {
                form.find('input, textarea, select, button').prop('disabled', false);
            })


        })


        .ready(function () {
            log('yep');
        })
    ;


    function numerateSteps() {
        var steps = $('.case_steps > .case_step');

        steps.each(function (i, item) {
            $(item).find('> span').html(i+1).data('number', i+1);
        })
    }

})();