package ma.rak.ov.models;

import io.realm.RealmObject;

public class NatureBr extends RealmObject {
    private int ID;
    private String label;
    private String CODCATAB;
    private String CODNATIN;
    private String CALICOMP;
    private String NOMBFILS;
    private String INTENSIT;
    private String TENSELEC;
    private String PUISSANC;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public NatureBr() {
    }

    public NatureBr(int ID, String label, String codcatab, String codnatin, String calicomp, String nombfils, String intensit, String tenselec, String puissanc) {
        this.ID = ID;
        this.label = label;
        CODCATAB = codcatab;
        CODNATIN = codnatin;
        CALICOMP = calicomp;
        NOMBFILS = nombfils;
        INTENSIT = intensit;
        TENSELEC = tenselec;
        PUISSANC = puissanc;
    }

    public String getCODCATAB() {
        return CODCATAB;
    }

    public void setCODCATAB(String CODCATAB) {
        this.CODCATAB = CODCATAB;
    }

    public String getCODNATIN() {
        return CODNATIN;
    }

    public void setCODNATIN(String CODNATIN) {
        this.CODNATIN = CODNATIN;
    }

    public String getCALICOMP() {
        return CALICOMP;
    }

    public void setCALICOMP(String CALICOMP) {
        this.CALICOMP = CALICOMP;
    }

    public String getNOMBFILS() {
        return NOMBFILS;
    }

    public void setNOMBFILS(String NOMBFILS) {
        this.NOMBFILS = NOMBFILS;
    }

    public String getINTENSIT() {
        return INTENSIT;
    }

    public void setINTENSIT(String INTENSIT) {
        this.INTENSIT = INTENSIT;
    }

    public String getTENSELEC() {
        return TENSELEC;
    }

    public void setTENSELEC(String TENSELEC) {
        this.TENSELEC = TENSELEC;
    }

    public String getPUISSANC() {
        return PUISSANC;
    }

    public void setPUISSANC(String PUISSANC) {
        this.PUISSANC = PUISSANC;
    }

    @Override
    public String toString() {
        return "NatureBr{" +
                "ID=" + ID +
                ", label='" + label + '\'' +
                ", CODCATAB='" + CODCATAB + '\'' +
                ", CODNATIN='" + CODNATIN + '\'' +
                ", CALICOMP='" + CALICOMP + '\'' +
                ", NOMBFILS='" + NOMBFILS + '\'' +
                ", INTENSIT='" + INTENSIT + '\'' +
                ", TENSELEC='" + TENSELEC + '\'' +
                ", PUISSANC='" + PUISSANC + '\'' +
                '}';
    }
}

