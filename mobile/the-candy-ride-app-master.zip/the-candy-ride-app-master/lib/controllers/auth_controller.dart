import 'dart:io';
import 'package:bot_toast/bot_toast.dart';
import 'package:device_info/device_info.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:rider_app/constants/constants.dart';
import 'package:rider_app/helpers/helpers.dart';
import 'package:rider_app/models/countryModel.dart';
import 'package:rider_app/models/models.dart';
import 'package:rider_app/ui/components/components.dart';
import 'package:location_permissions/location_permissions.dart';
import 'package:dio/dio.dart' as dio;

import 'controllers.dart';

class AuthController extends GetxController {
  /*
  Following is default fleet id for rider

  */

  int fleetId = 1;
  static AuthController to = Get.find();
  static TripAcceptController tripTo = Get.find();

  UserModel userModel;
  String currency;
  NetWorkCall networkCall = NetWorkCall();
  Validator validator = Validator();
  final store = GetStorage();
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging();
  static final DeviceInfoPlugin deviceInfoPlugin = DeviceInfoPlugin();
  List<CountryModel> countries = [];
  String deviceId;
  int deviceType;
  String tokenId;

  @override
  void onReady() {
    getUserFromLocalStore();
    initPlatformState();
    notificationInit();
    getCountries();
    super.onReady();
  }

  getLocationOfUser() async {
    PermissionStatus permission =
        await LocationPermissions().requestPermissions();
  }

  getUserFromLocalStore() {
    Future.delayed(Duration(seconds: 3), () async {
      if (store.hasData('user')) {
        userModel = UserModel.fromJson(await store.read('user'));
        print(userModel.riderid);
        currency = await store.read('currency');
        String newBookRideID = await tripTo.isAnyRideBooked();
        print("newBookRideID $newBookRideID");
        if (newBookRideID != null) {
          Get.offAndToNamed('/HomeUI');
          BotToast.showWidget(
            toastBuilder: (_) => RideBookSuccessDialog(
              rideId: int.parse(newBookRideID),
            ),
          );
        } else {
          bool isAnyRide = await tripTo.isAnyRide();
          Get.offAndToNamed('/HomeUI');
          if (isAnyRide) {
            Get.toNamed('/TripAceeptUI');
          }
        }
      } else {
        Get.offAndToNamed('/LanguageUI');
      }
    });
  }

  signIn({String email, String password}) async {
    //var locationOfUser = getLocationOfUser();
    BotToast.showLoading();
    print("deviceId $deviceId");
    print("tokenId $tokenId");

    final result = await networkCall.postRequest(
      url: Urls.login,
      json: {
        Params.email: email,
        Params.password: password,
        Params.deviceId: deviceId,
        Params.deviceType: deviceType,
        Params.tokenId: tokenId,
      },
    );

    return result.fold((l) {
      // BotToast.showWidget(
      //     toastBuilder: (_) => ErrorDialog(
      //           title: "Error".tr,
      //           message: "Unexcpected Error Occured",
      //         ));
      BotToast.closeAllLoading();
    }, (response) async {
      if (response.responsecode == 0 ||
          response.response.runtimeType == String) {
        if (response.response ==
            "You have been already logged in other device") {
          BotToast.showWidget(
            toastBuilder: (_) => CustomeAlertDoaligWithTwoOption(
              title: "alert".tr,
              message: "logout_all_other_device".tr,
              email: email,
              password: password,
            ),
          );
        } else {
          BotToast.showWidget(
            toastBuilder: (_) => ErrorDialog(
              title: "error".tr,
              message: response.response,
            ),
          );
        }
      } else {
        userModel = UserModel.fromJson(response.response);
        await store.write('user', userModel.toJson());
        getCurrency(int.parse(userModel.country));
        Get.offAllNamed('/HomeUI');
        BotToast.closeAllLoading();
      }
    });
  }

  Future logoutFromOtherDevices({String email, String password}) async {
    BotToast.showLoading();
    final result = await networkCall.postRequestWithResponse(
      url: Urls.riderUninstallapp,
      json: {
        Params.email: email,
        Params.password: password,
      },
    );

    return result.fold((l) {
      // BotToast.showWidget(
      //     toastBuilder: (_) => ErrorDialog(
      //           title: "Error".tr,
      //           message: "Unexcpected error during Logout From other Devices",
      //         ));
      BotToast.closeAllLoading();
      return;
    }, (r) {
      if (r.data['responsecode'] != 1) {
        BotToast.showWidget(
          toastBuilder: (_) => CustomeAlertDoaligWithTwoOption(
            title: "alert".tr,
            message: "fail_logout_all_other_device".tr,
          ),
        );
        return false;
      }
      BotToast.closeAllLoading();
      return true;
    });
  }

  getCurrency(int countryId) async {
    final result = await networkCall.postRequestWithResponse(
      url: Urls.currency,
      json: {
        Params.countryId: countryId,
      },
    );

    return result.fold((l) {
      // BotToast.showWidget(
      //     toastBuilder: (_) => ErrorDialog(
      //           title: "Error".tr,
      //           message: "Unexcpected error during get Currency ",
      //         ));
      return;
    }, (response) async {
      await store.write('currency', response.data['currency']);
      currency = response.data['currency'];
    });
  }

  singUp(
      {String fullName,
      int mobileNo,
      int countryId,
      String email,
      String password,
      String base64Image}) async {
    //var locationOfUser = getLocationOfUser();
    BotToast.showLoading();

    final result = await networkCall.postRequest(
      url: Urls.signUp,
      json: {
        Params.name: fullName,
        Params.mobile: mobileNo,
        Params.countryId: countryId,
        Params.email: email,
        Params.password: password,
        Params.userImage: base64Image,
        Params.fleetId: fleetId,
      },
    );
    BotToast.closeAllLoading();

    return result.fold((l) {
      // BotToast.showWidget(
      //     toastBuilder: (_) => ErrorDialog(
      //           title: "error".tr,
      //           message: "unexpected error occured",
      //         ));
      return;
    }, (response) {
      if (response.responsecode == 0) {
        BotToast.showWidget(
            toastBuilder: (_) => ErrorDialog(
                  title: "error".tr,
                  message: response.response,
                ));
      } else {
        BotToast.showWidget(
          toastBuilder: (_) => SuccessDialog(
            title: "success".tr,
            message: response.response,
            ontap: () {
              BotToast.cleanAll();
              Get.offAllNamed('/SignInUI');
            },
          ),
        );
      }
    });
  }

  logout() async {
    BotToast.showLoading();
    store.erase();
    await networkCall.postRequest(
      url: Urls.logout,
      json: {
        Params.riderId: userModel.riderid,
      },
    );
    BotToast.closeAllLoading();
    Get.offAllNamed('/IntroUI');
  }

  forgotPassword(String email) async {
    BotToast.showLoading();
    final result = await networkCall.postRequest(
      url: Urls.forgotPassword,
      json: {
        Params.email: email,
      },
    );
    BotToast.closeAllLoading();

    return result.fold((l) {
      // BotToast.showWidget(
      //   toastBuilder: (_) => ErrorDialog(
      //     title: "error".tr,
      //     message: l,
      //   ),
      // );
    }, (response) {
      BotToast.showText(text: response.response);
      Get.back();
    });
  }

  getCountries() async {
    final result = await networkCall.getRequest(url: Urls.country);

    return result.fold((l) {
      // BotToast.showWidget(
      //     toastBuilder: (_) => ErrorDialog(
      //           title: "Error".tr,
      //           message: "Unexcpected error during get MapMatching",
      //         ));
      return;
    }, (_response) {
      final data = _response.data;
      data['countries'].forEach((e) {
        countries.add(CountryModel.fromJson(e));
      });
      return countries;
    });
  }

  Future<void> initPlatformState() async {
    try {
      if (Platform.isAndroid) {
        final androidInfo = await deviceInfoPlugin.androidInfo;
        deviceId = androidInfo.androidId;
        deviceType = 1;
      } else if (Platform.isIOS) {
        final iosInfo = await deviceInfoPlugin.iosInfo;
        deviceId = iosInfo.identifierForVendor;
        deviceType = 2;
      }
    } on PlatformException {
      print("device id not found");
    }
  }

  Future<void> notificationInit() async {
    //
    var initializationSettingsAndroid = AndroidInitializationSettings(
      'mipmap/ic_launcher',
    );
    var initializationSettingsIOS = IOSInitializationSettings(
        defaultPresentSound: true, requestSoundPermission: true);
    var initializationSettings = InitializationSettings(
        android: initializationSettingsAndroid, iOS: initializationSettingsIOS);
    flutterLocalNotificationsPlugin.initialize(initializationSettings,
        onSelectNotification: onSelectNotification);

    _firebaseMessaging.configure(
      onBackgroundMessage:
          Platform.isAndroid ? myBackgroundMessageHandler : null,
      onMessage: (Map<String, dynamic> message) async {
        print("onMessage: $message");
        try {
          if (message["data"]["body"] == "Your booking accepted") {
            tripTo.rideStatus.value = RideStatus.started;
            tripTo.getRideDetail().then((value) {
              // if (tripTo?.ride?.rideStatus == RideStatus.booked)
              // if (Get.routing.current == '/HomeUI')
              if (tripTo?.ride?.prebookingFee != null)
                Get.toNamed('/TripAceeptUI');
              // print("current route -- " + Get.routing.current);
            });
          }
        } catch (e) {
          print("error from notif" + e.toString());
        }

        showNotificationWithDefaultSound(message);

        //Get.snackbar("onMessage", "$message");
      },
      onLaunch: (Map<String, dynamic> message) async {
        print("onLaunch: $message");
        showNotificationWithDefaultSound(message);
        // Get.snackbar("onLaunch", "$message");
      },
      onResume: (Map<String, dynamic> message) async {
        // back app is in background and you click on notification
        print("onResume: $message");
        onSelectNotification("");
        // Get.snackbar("onResume", "$message");
      },
    );
    _firebaseMessaging.requestNotificationPermissions(
      const IosNotificationSettings(
        sound: true,
        badge: true,
        alert: true,
        provisional: true,
      ),
    );
    _firebaseMessaging.onIosSettingsRegistered
        .listen((IosNotificationSettings settings) {
      print("Settings registered: $settings");
    });
    await _firebaseMessaging.requestNotificationPermissions();
    tokenId = await _firebaseMessaging.getToken();
    print("tokenId $tokenId");
  }

  Future<dynamic> onSelectNotification(String payload) async {
    print("click $payload");
    if (userModel != null && userModel?.riderid != null) {
      Get.offAllNamed('/HomeUI');
      Get.toNamed('/TripAceeptUI');
    }
  }
}
