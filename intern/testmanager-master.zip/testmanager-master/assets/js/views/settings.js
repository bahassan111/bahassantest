(function () {
    var view = $('#users_view');
    if (!view.length) return;

    var table = $('.users_list');

    $(view)
        .ready(function () {
            table.twTable({

                url     : site_url + 'settings/get_users',
                key     : 'id',

                dblclick : function(id, tr){
                    log(id);
                },

                columns : [
                    {name : 'id', data : 'ref', title : 'ID', orderable : true, searchable : false},
                    {name : 'username', data : 'username', title : 'Username', orderable : true, searchable : false},
                    {name : 'group', data : 'group', title : 'Group', orderable : true, searchable : true},
                    {name : 'name', data : 'name', title : 'Full name', orderable : true, searchable : true},
                    {name : 'email', data : 'email', title : 'E-Mail', orderable : true, searchable : true},
                    {name : 'active', data : 'status', title : 'Status', orderable : true, searchable : true},
                    {name : 'last_login', data : 'login', title : 'Last seen', orderable : false, searchable : false},
                ],

                buttons : [
                    {
                        text : 'Add',
                        icon : 'fas fa-plus',
                        color : 'primary',
                        global : true,
                        action : function(){
                            oneUser();
                        },
                    },
                    {
                        separator : true,
                    },


                    {
                        icon : 'fas fa-pencil-alt',
                        global : false,
                        action : function(id){
                            oneUser(id);

                        },
                    },
                    {
                        icon : 'fas fa-times',
                        global : false,
                        action : function(id){
                            deleteUser(id);
                        },
                    },
                    {
                        text : 'RUN',
                        icon : 'fas fa-play',
                        color : 'success',
                        global : false,
                        condition : function(row){
                            return row.run_type === 'auto';
                        },
                        action : function(){},
                    },
                    {separator : true}
                ],

            });
        })
    ;


    function oneUser(id) {
        ajaxSideModal('settings/one_user/' + (id || '') ,(id ? 'Update' : 'Create') + ' user', 'far fa-paper-plane', {
            close_text : 'Cancel',
            confirm_text : 'Save',
            size: 'md',
            whenLoaded : function(modal, data){
                $('.selectpicker').selectpicker({
                    liveSearch: true,
                    size : 8,
                });


                modal.find('form')
                    .validate();
                modal
                    .on('submit', 'form', function (e) {
                        e.preventDefault();
                        var btn = modal.find('.confirm').prop('disabled', true);

                        var form = $(this);

                        if(form.valid()){
                            post('settings/save_user/' +(id || ''), form.serialize(), function (rep) {
                                if(rep.status === 'OK'){
                                    toastr_('The user was successfully added', 'success', 'success', 6000);
                                    modal.sideModal('hide');
                                    table.twTable('refresh');
                                }else{
                                    toastr_(rep.message || 'Error while saving the data', 'error', 'danger', 9000);
                                }
                            }, function () {
                                btn.prop('disabled', false);
                            }, function () {
                                toastr_('Error while saving the data', 'error', 'danger', 9000);
                            })
                        }



                    })
            },
            whenConfirm : function(modal, data){
                modal.find('form').submit();
            },
            whenError : function(modal, error){},
            whenClosed : function(modal){},

        });
    }

    function deleteUser(id) {
        post('settings/delete_user/' + id, {}, function (rep) {
            if(rep.status === 'OK'){
                toastr_('The user was successfully deleted', 'success', 'success', 6000);
                table.twTable('refresh');
            }else{
                toastr_(rep.message || 'Error while deleting the user', 'error', 'danger', 9000);
            }
        }, function () {


        }, function () {
            toastr_('Error while deleting the user', 'error', 'danger', 9000);
        })
    }

})();

// groups
(function () {
    var view = $('#groups_view');
    if (!view.length) return;

    var table = $('.groups_list');

    $(view)

        .ready(function () {
            table.twTable({

                url     : site_url + 'settings/get_groups',
                key     : 'id',

                dblclick : function(id, tr){
                    log(id);
                },

                columns : [
                    {name : 'id', data : 'ref', title : 'ID', orderable : true, searchable : false},
                    {name : 'name', data : 'name', title : 'Name', orderable : true, searchable : false},
                    {name : 'status', data : 'status', title : 'Status', orderable : true, searchable : false},
                    {name : 'description', data : 'description', title : 'Note', orderable : true, searchable : true},
                ],

                buttons : [
                    {
                        text : 'Add',
                        icon : 'fas fa-plus',
                        color : 'primary',
                        global : true,
                        action : function(){
                            oneGroup();
                        },
                    },
                    {
                        separator : true,
                    },
                    {
                        text : 'Permissions',
                        icon : 'fas fa-lock',
                        color : 'success',
                        global : false,
                        action : function(id){
                            permissions(id);
                        },
                    },
                    {
                        separator : true,
                    },


                    {
                        icon : 'fas fa-pencil-alt',
                        global : false,
                        action : function(id){

                            oneGroup(id);

                        },
                    },
                    {
                        icon : 'fas fa-times',
                        global : false,
                        action : function(id){
                            deleteGroup(id);
                        },
                    },
                    {
                        text : 'RUN',
                        icon : 'fas fa-play',
                        color : 'success',
                        global : false,
                        condition : function(row){
                            return row.run_type === 'auto';
                        },
                        action : function(){},
                    },
                    {separator : true}
                ],

            });
        })
    ;


    function oneGroup(id) {
        ajaxSideModal('settings/one_group/' + (id || '') , (id ? 'Edit' : 'Create') + ' group', 'far fa-paper-plane', {
            close_text : 'Cancel',
            confirm_text : id ? 'Update' : 'Save',
            size: 'md',
            whenLoaded : function(modal, data){
                $('.selectpicker').selectpicker({
                    liveSearch: true,
                    size : 8,
                });


                modal.find('form')
                    .validate();
                modal
                    .on('submit', 'form', function (e) {
                        e.preventDefault();
                        var btn = modal.find('.confirm').prop('disabled', true);

                        var form = $(this);

                        if(form.valid()){
                            post(form.prop('action'), form.serialize(), function (rep) {
                                if(rep.status === 'OK'){
                                    toastr_('The group was successfully saved', 'success', 'success', 6000);
                                    modal.sideModal('hide');
                                    table.twTable('refresh');
                                }else{
                                    toastr_(rep.message || 'Error while saving the data', 'error', 'danger', 9000);
                                }
                            }, function () {
                                btn.prop('disabled', false);
                            }, function () {
                                toastr_('Error while saving the data', 'error', 'danger', 9000);
                            })
                        }



                    })
            },
            whenConfirm : function(modal, data){
                modal.find('form').submit();
            },
            whenError : function(modal, error){},
            whenClosed : function(modal){},

        });
    }
    function permissions(id) {
        ajaxSideModal('settings/group_permissions/' + id , 'Group Permissions', 'far fa-paper-plane', {
            close_text : 'Cancel',
            confirm_text : 'Save',
            size: 'lg',
            whenLoaded : function(modal, data){
                $('.selectpicker').selectpicker({
                    liveSearch: true,
                    size : 8,
                });


                modal.find('form')
                    .on('click', '.snone', function () {
                        $(this).closest('form').find('.tw_box input').attr('checked', false).trigger('change');
                    })
                    .on('click', '.sall', function () {
                        $(this).closest('form').find('.tw_box input').attr('checked', true).trigger('change');
                    })
                    .validate();
                modal
                    .on('submit', 'form', function (e) {
                        e.preventDefault();
                        var btn = modal.find('.confirm').prop('disabled', true);

                        var form = $(this);

                        if(form.valid()){
                            post(form.prop('action'), form.serialize(), function (rep) {
                                if(rep.status === 'OK'){
                                    toastr_('The group permissions were successfully saved', 'success', 'success', 6000);
                                    modal.sideModal('hide');
                                    table.twTable('refresh');
                                }else{
                                    toastr_(rep.message || 'Error while saving the data', 'error', 'danger', 9000);
                                }
                            }, function () {
                                btn.prop('disabled', false);
                            }, function () {
                                toastr_('Error while saving the data', 'error', 'danger', 9000);
                            })
                        }



                    })
            },
            whenConfirm : function(modal, data){
                modal.find('form').submit();
            },
            whenError : function(modal, error){},
            whenClosed : function(modal){},

        });
    }

    function deleteGroup(id) {
        post('settings/delete_group/' + id, {}, function (rep) {
            if(rep.status === 'OK'){
                toastr_('The group was successfully deleted', 'success', 'success', 6000);
                table.twTable('refresh');
            }else{
                toastr_(rep.message || 'Error while deleting the group', 'error', 'danger', 9000);
            }
        }, function () {


        }, function () {
            toastr_('Error while deleting the group', 'error', 'danger', 9000);
        })
    }

})();