import 'package:flutter/material.dart';

class AppThemes {
  AppThemes._();
  static const _deepPink = Color(0xffFF0782);
  static const _lightPink = Color(0xffFC537C);
  static const _amber = Color(0xffFDB515);

  static const _paua = Color(0xff1B1B48);
  static const _black = Colors.black;
  static const _concrete = Color(0xffF2F2F2);
  static const _textPaua = Color(0xff222B45);
  static const _grey = Color(0xff222B45);
  static const _athensGray = Color(0xffE7EAF0);
  static const _raven = Color(0xff727C8E);
  static const _darkGrey = Color(0xff727C8E);
  static const _textGreyColor = Color(0xff707070);
  static const _doveGray = Color(0xff707070);
  static const _green = Color(0xff1AFF07);

  // background color
  static const Color lightGreenbackGroundColor = _green;

  // Borders
  static const Color pauaBorderColor = _paua;
  static const Color lightinputBorderColor = _concrete;
  static const Color lightActiveInputBorder = _deepPink;
  static const Color lightAthensGrayBorderColor = _athensGray;
  static Color lightravenBackGroundColor = _raven.withOpacity(0.2);
  static Color lightInputBorderColor = _darkGrey;

  //buttons
  static Color lightRounderAuthButtonColor = _lightPink;
  static Color lightRounderButtonColor = _amber;

  // into indicators
  static const Color lightSelectedIntro = _deepPink;
  static const Color lightunSelectedIntro = _grey;

  //Icon Colors
  static Color lightravenIconColor = _raven;
  static Color lightdeepPinkDropDownIconColor = _deepPink;
  static Color lightBackButtonColor = _amber;

  //Divider color
  static const Color lightDividerColor = _doveGray;

  static ThemeData lightTheme = ThemeData(
    fontFamily: 'Poppins',
    textTheme: TextTheme(
      headline1: TextStyle(color: _black),
      headline2: TextStyle(color: _textPaua),
      headline3: TextStyle(
        color: _grey.withOpacity(0.5),
      ),
      headline4: TextStyle(color: _textGreyColor),
      headline5: TextStyle(color: _lightPink),
      headline6: TextStyle(color: Colors.white),
      subtitle1: TextStyle(color: _amber),
    ),
  );
}
