import React, { Component } from "react";
import { View, Text, Constants } from "react-native-ui-lib";
import {
  ScrollView,
  StyleSheet,
  FlatList,
  ActivityIndicator,
  AsyncStorage,
} from "react-native";
import { NavigationActions, StackActions } from "react-navigation";

import { Audio } from "expo-av";

import {
  fetchFontSize,
  changeFont,
  changeLanguage,
  editLanguageFr,
  editLanguageAr,
} from "../Redux/actions/FontSizeActions";

import {
  fetchArticleDetails,
  saveInfo,
} from "../Redux/actions/ChapitresActions";
import { fetchCountriesData } from "../Redux/actions/CountriesActions";
import { fetchBanners } from "../Redux/actions/BannersActions";

import { connect } from "react-redux";

import Config from "../constants/Config";
import CountryItem from "./CountryItem";

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    marginTop: Constants.isIphoneX ? 100 : 40,
    // backgroundColor: "#f2f2f2",
  },

  inner_countries: {
    paddingLeft: 2,
    paddingRight: 10,
    paddingVertical: 12,
    flexDirection: "row",
    alignItems: "flex-start",
  },
  image_countries: {
    width: 20,
    height: 20,
    borderRadius: 20,
  },
  contentHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 6,
    marginLeft: 10,
  },
  icon_right: {
    fontSize: 11,
    color: "#808080",
    alignItems: "flex-end",
  },
  name: {
    fontSize: 12,
    fontWeight: "bold",
  },
  root: {
    paddingTop: 10,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    flexWrap: "wrap",
    flex: 1,
    width: "100%",
  },

  Card_Container: {
    backgroundColor: "#fff",
    padding: 15,
    margin: 1.4,
    borderRadius: 4,
    width: 110,
    height: 110,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 15,
    marginRight: 2,
    elevation: 4,
  },

  title: {
    fontSize: 15,
    fontWeight: "bold",
    color: "#000",
    marginTop: 8,
  },
});

class ChangeCountries extends Component {
  constructor(props) {
    super(props);
    this._isMounted = true;
  }
  static navigationOptions = ({ navigation }) => ({
    header: null,
  });

  state = {
    itemsCount: this.props.fontSizeValue.fontSize,
    shouldPlay: false,
    data: [],
    result: null,
    userID: "",
    userName: "",
    userEmail: "",
    userImage: "",
    fetchDataCountries: [],
    isLoadingCountries: true,
    lang_index: "",
    id_lang: "",
    id_country: "",
    change_country: "Change Country",
  };
  componentDidMount() {
    AsyncStorage.multiGet([
      "id",
      "name",
      "email",
      "image",
      "lang",
      "id_country",
      "change_country",
    ]).then((data) => {
      let id = data[0][1];
      let name = data[1][1];
      let email = data[2][1];
      let image = data[3][1];
      let lang = data[4][1];
      let id_country = data[5][1];
      let change_country = data[6][1];

      this.setState({
        userID: id,
        userName: name,
        userEmail: email,
        userImage: image,
      });
      console.log(
        this.state.userID + " " + this.state.userEmail,
        "ha detailss"
      );
      Audio.setAudioModeAsync({
        allowsRecordingIOS: false,
        interruptionModeIOS: Audio.INTERRUPTION_MODE_IOS_DO_NOT_MIX,
        playsInSilentModeIOS: true,
        shouldDuckAndroid: true,
        interruptionModeAndroid: Audio.INTERRUPTION_MODE_ANDROID_DO_NOT_MIX,
        playThroughEarpieceAndroid: false,
      });
      this.props.fetchFontSize();

      this.setState({ id_country: id_country, change_country: change_country });

      this.fetchCountries();
    });
  }
  async componentDidUpdate(nextProps) {
    if (nextProps.hasIntro !== this.props.hasIntro) {
      let id_country = await AsyncStorage.getItem("id_country");
      let change_country = await AsyncStorage.getItem("change_country");
      this.setState({ id_country: id_country, change_country: change_country });

      console.log("this.props.hasIntro", this.props.hasIntro);
      if (this.props.hasIntro == 500) {
        // this.resetStack();
      }
    }
    if (nextProps.isCountriesLoading !== this.props.isCountriesLoading) {
      this.redirect_Tolang();
      // this.props.fetchArticleDetails(
      //   nextProps.id_country,
      //   nextProps.lang_index
      // );
      // this.props.fetchBanners();
      // this.props.changeFont(this.props.fontSizeValue.fontSize, 500);
      // this.props.navigation.dispatch(
      //   StackActions.reset({
      //     index: 0,
      //     key: null,
      //     actions: [
      //       NavigationActions.navigate({
      //         routeName: "Main",
      //       }),
      //     ],
      //   })
      // );
    }
  }

  resetStack = async () => {
    let user_id = this.state.userID;
    await fetch(Config.API_URL + "includes/encode/index.php", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        post: "save_langueUser",
        user_id: user_id,
        lang: "ar",
      }),
    })
      .then((res) => res.json())
      .then((responseJson) => {
        if (responseJson.lang) {
          AsyncStorage.multiSet([["lang", responseJson.lang]]);
        }
      })
      .catch((error) => {
        console.log("error save Save Lang ", error);
      });
    this.props.fetchArticleDetails("ar");
    this.props.fetchBanners();

    this.props.changeFont(this.props.fontSizeValue.fontSize, 500);
    this.props.navigation.dispatch(
      StackActions.reset({
        index: 0,
        key: null,
        actions: [
          NavigationActions.navigate({
            routeName: "Main",
          }),
        ],
      })
    );

    this.props.fetchFontSize("ar");
    this.props.editLanguageAr();
  };
  resetStackFr = async () => {
    let user_id = this.state.userID;
    await fetch(Config.API_URL + "includes/encode/index.php", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        post: "save_langueUser",
        user_id: user_id,
        lang: "fr",
      }),
    })
      .then((res) => res.json())
      .then((responseJson) => {
        if (responseJson.lang) {
          AsyncStorage.multiSet([["lang", responseJson.lang]]);
        }
      })
      .catch((error) => {
        console.log("error save Save Lang ", error);
      });

    this.props.fetchArticleDetails("fr");
    this.props.fetchBanners();

    this.props.changeFont(this.props.fontSizeValue.fontSize, 500);
    this.props.navigation.dispatch(
      StackActions.reset({
        index: 0,
        key: null,
        actions: [
          NavigationActions.navigate({
            routeName: "Main",
          }),
        ],
      })
    );

    this.props.fetchFontSize("fr");
    this.props.editLanguageFr();
  };

  check_langUser = async (user_id) => {
    await fetch(Config.API_URL + "includes/encode/index.php", {
      method: "post",
      body: JSON.stringify({
        post: "check_langue",
        user_id: user_id,
      }),

      headers: {
        Accept: "application/json",
        "content-type": "multipart/form-data",
      },
    })
      .then((res) => res.json())
      .then((responseJson) => {
        console.log("lang iss", responseJson);
        AsyncStorage.multiSet([["lang", responseJson.lang]]);

        if (responseJson.lang === "fr" || responseJson.lang === "ar")
          this.redirect_Tolang(responseJson.lang);
      })
      .catch((error) => {});
  };

  fetchCountries() {
    fetch(
      "http://ifes-esll.com/new/api/includes/encode/index.php/?get=fetchCountries"
    )
      .then((res) => res.json())
      .then((responseJson) => {
        console.log("fetchCountries", responseJson);

        this.setState({
          fetchDataCountries: responseJson.countries,
          isLoadingCountries: false,
        });
      })
      .catch((error) => {
        console.log("error", error);
      });
  }

  redirect_Tolang = async () => {
    console.log("redirect_Tolang");
    let id_country = await AsyncStorage.getItem("id_country");
    let lang_index = await AsyncStorage.getItem("lang_index");
    let lang = await AsyncStorage.getItem("lang");
    let rtl = await AsyncStorage.getItem("rtl");

    this.props.fetchArticleDetails(id_country, lang_index);
    this.props.fetchBanners();
    this.props.changeFont(this.props.fontSizeValue.fontSize, 500);
    this.props.navigation.dispatch(
      StackActions.reset({
        index: 0,
        key: null,
        actions: [
          NavigationActions.navigate({
            routeName: "Main",
          }),
        ],
      })
    );
    this.props.fetchFontSize(lang, id);

    if (rtl === 1) this.props.editLanguageAr();
    else this.props.editLanguageFr();
  };

  chooseCountry = async (id_country) => {
    await this.props.fetchCountriesData(id_country, this.state.userID);
  };

  renderListItem = ({ item, index }) => {
    let borderColor = item.id === this.state.id_country ? "#1a264d" : "#96a4ab";
    let borderWidth = item.id === this.state.id_country ? 2 : 1;

    return (
      <CountryItem
        borderWidth={borderWidth}
        data={item}
        borderColor={borderColor}
        onPress={() => this.chooseCountry(item.id)}
      />
    );
  };

  render() {
    const { fetchDataCountries } = this.state;
    return (
      <View style={styles.container} useSafeArea>
        <ScrollView
          ref={(ref) => {
            this.scrollview_ref = ref;
          }}
        >
          <Text style={{ fontWeight: "bold", fontSize: 16 }} center>
            {this.state.change_country}
          </Text>

          {this.state.isLoadingCountries ? (
            <ActivityIndicator
              size="large"
              color="#0000ff"
              style={{
                flex: 1,
                justifyContent: "center",
                alignItems: "center",
                paddingVertical: 20,
              }}
            />
          ) : (
            <View center>
              <FlatList
                horizontal={false}
                numColumns={3}
                keyExtractor={(item, index) => item.id || index}
                data={fetchDataCountries}
                renderItem={this.renderListItem}
              />
            </View>
          )}
        </ScrollView>
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  const fontSizeValue = state.fontSize;
  const hasIntro = state.fontSize.hasIntro;
  const lang = state.fontSize.lang;

  const data = state.searchAll.data;
  const isLoadingData = state.searchAll.isLoadingData;

  const country = state.countries.data;
  const isCountriesLoading = state.countries.isLoadingData;

  // console.log("state.countries", state.countries.data);

  return {
    lang,
    fontSizeValue,
    hasIntro,
    isLoadingData,
    data,
    country,
    isCountriesLoading,
  };
};

export default connect(mapStateToProps, {
  fetchFontSize,
  changeLanguage,
  editLanguageAr,
  editLanguageFr,
  fetchBanners,
  changeFont,
  fetchArticleDetails,
  fetchCountriesData,
  saveInfo,
})(ChangeCountries);
