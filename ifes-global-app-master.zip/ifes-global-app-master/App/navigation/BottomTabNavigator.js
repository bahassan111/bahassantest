import { createBottomTabNavigator } from "react-navigation";

import HomeScreen from "../screens/HomeScreen";
import SettingsScreen from "../screens/SettingsScreen";
import Colors from "../constants/Colors";

const BottomTabNavigator = createBottomTabNavigator(
  {
    HomeScreen,
    SettingsScreen
  },
  {
    tabBarOptions: {
      showLabel: false,
      activeTintColor: "#F8F8F8",
      inactiveTintColor: Colors.gray,
      style: {
        backgroundColor: Colors.tabBar
      },
      tabStyle: { paddingTop: 5 }
    }
  }
);



export default BottomTabNavigator;
