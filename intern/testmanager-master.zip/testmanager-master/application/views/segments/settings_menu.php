<?php ?>
<div class="project_menu">
    <ul class="pmenu">
        <li class="<?= $active == 'settings' ? 'active' : ''; ?>">
            <a href="<?= site_url('settings'); ?>">
                <span class="i"><i class="fas fa-wrench"></i></span>
                <span class="t">General Settings</span>
            </a>
        </li>
        <li class="<?= $active == 'users' ? 'active' : ''; ?>">
            <a href="<?= site_url('settings/users'); ?>">
                <span class="i"><i class="far fa-user-circle"></i></span>
                <span class="t">Users</span>
            </a>
        </li>
        <li class="<?= $active == 'groups' ? 'active' : ''; ?>">
            <a href="<?= site_url('settings/groups'); ?>">
                <span class="i"><i class="fas fa-users"></i></span>
                <span class="t">User Groups</span>
            </a>
        </li>

    </ul>
</div>