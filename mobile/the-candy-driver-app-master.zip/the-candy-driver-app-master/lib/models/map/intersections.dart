class Intersections {
  List<bool> entry;
  List<int> bearings;
  var duration;
  bool isUrban;
  var adminIndex;
  var out;
  var weight;
  var geometryIndex;
  List<double> location;
  var turnWeight;
  var turnDuration;

  Intersections(
      {this.entry,
      this.bearings,
      this.duration,
      this.isUrban,
      this.adminIndex,
      this.out,
      this.weight,
      this.geometryIndex,
      this.location,
      this.turnWeight,
      this.turnDuration});

  Intersections.fromJson(Map<String, dynamic> json) {
    entry = json['entry'].cast<bool>();
    bearings = json['bearings'].cast<int>();
    duration = json['duration'];
    isUrban = json['is_urban'];
    adminIndex = json['admin_index'];
    out = json['out'];
    weight = json['weight'];
    geometryIndex = json['geometry_index'];
    location = json['location'].cast<double>();
    turnWeight = json['turn_weight'];
    turnDuration = json['turn_duration'];
  }
}
