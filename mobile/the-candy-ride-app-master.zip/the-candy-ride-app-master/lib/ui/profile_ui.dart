import 'dart:convert';
import 'dart:io';

import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:rider_app/constants/constants.dart';
import 'package:rider_app/controllers/controllers.dart';
import 'package:rider_app/helpers/pickers.dart';
import 'package:rider_app/ui/components/components.dart';
import 'package:get/get.dart';
import 'package:rider_app/home.dart';

class ProfileUI extends StatefulWidget {
  @override
  _ProfileUIState createState() => _ProfileUIState();
}

class _ProfileUIState extends State<ProfileUI> {
  double height, width;
  static AuthController authTo = Get.find();
  static ProfileController to = Get.find();
  bool isPasswordVisiable = true;
  @override
  void initState() {
    to.email.text = authTo.userModel.email;
    to.country = authTo.userModel.country;
    to.fullName.text = authTo.userModel.fullname;
    to.password.text = authTo.userModel.password;
    to.mobileNo.text = authTo.userModel.mobile;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          child: Column(
            children: [
              CustomeBackButton(),
              SizedBox(
                height: 10,
              ),
              Image.asset(
                AllImages.theCandy,
                width: (3 * width) / 4,
              ),
              SizedBox(
                height: 10,
              ),
              GestureDetector(
                onTap: () async {
                  PickedFile newPickedImage = await imgFromGallery();
                  if (newPickedImage != null) {
                    setState(() {
                      to.profileImage = newPickedImage;
                    });
                  }
                },
                child: profilePicture(
                  size: 125,
                ),
              ),
              SizedBox(
                height: 40,
              ),
              getForm,
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 35.0, vertical: 20),
                child: RoundButton(
                  text: "save".tr.toUpperCase(),
                  onTap: () {
                    if (to.fullName.text.trim() == '') {
                      BotToast.showWidget(
                        toastBuilder: (_) => ErrorDialog(
                          title: "error".tr,
                          message: "errorFullName".tr,
                        ),
                      );
                    } else if (to.country == null) {
                      BotToast.showWidget(
                        toastBuilder: (_) => ErrorDialog(
                          title: "error".tr,
                          message: "errorCountry".tr,
                        ),
                      );
                    } else if (to.mobileNo.text.trim() == '') {
                      BotToast.showWidget(
                        toastBuilder: (_) => ErrorDialog(
                          title: "error".tr,
                          message: "errorMobileNo".tr,
                        ),
                      );
                    } else if (to.email.text.trim() == '') {
                      BotToast.showWidget(
                        toastBuilder: (_) => ErrorDialog(
                          title: "error".tr,
                          message: "errorEmail".tr,
                        ),
                      );
                    } else if (to.validator.email(to.email.text.trim())) {
                      BotToast.showWidget(
                        toastBuilder: (_) => ErrorDialog(
                          title: "error".tr,
                          message: "errorValidEmail".tr,
                        ),
                      );
                    } else if (to.password.text.trim() == '') {
                      BotToast.showWidget(
                        toastBuilder: (_) => ErrorDialog(
                          title: "error".tr,
                          message: "errorPassword".tr,
                        ),
                      );
                    } else {
                      String base64Image;
                      if (to.profileImage != null) {
                        List<int> imageBytes =
                            File(to.profileImage.path).readAsBytesSync();
                        base64Image = base64Encode(imageBytes);
                      }
                      print("to.password.text ${to.password.text}");
                      to.updateProfile(
                          riderId: int.parse(authTo.userModel.riderid),
                          email: to.email.text,
                          fullName: to.fullName.text,
                          mobileNo: int.parse(to.mobileNo.text),
                          countryId: int.parse(to.country),
                          base64Image: base64Image,
                          password: to.password.text);
                    }
                  },
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  get getForm => Container(
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 35),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "fullName".tr,
                style: Theme.of(context)
                    .textTheme
                    .headline2
                    .copyWith(fontSize: 17),
              ),
              FormInputField(
                controller: to.fullName,
                isReadOnly: to.isEditFullName,
                iconSuffix: GestureDetector(
                  onTap: () {
                    setState(() {
                      to.isEditFullName = !to.isEditFullName;
                    });
                  },
                  child: Image.asset(
                    AllImages.edit,
                    height: 25,
                    width: 25,
                  ),
                ),
              ),
              getSpacer,
              Text(
                "country".tr,
                style: Theme.of(context)
                    .textTheme
                    .headline2
                    .copyWith(fontSize: 17),
              ),
              CustomDropDownMenu(
                dropDownValue: to.country,
                items: authTo.countries,
                onChange: (String country) {
                  to.country = country;
                },
              ),
              SizedBox(
                height: 10,
              ),
              Text(
                "mobileNo".tr,
                style: Theme.of(context)
                    .textTheme
                    .headline2
                    .copyWith(fontSize: 17),
              ),
              FormInputField(
                controller: to.mobileNo,
                keyboardType: TextInputType.number,
                isReadOnly: to.isEditMobileNo,
                iconSuffix: GestureDetector(
                  onTap: () {
                    setState(() {
                      to.isEditMobileNo = !to.isEditMobileNo;
                    });
                  },
                  child: Image.asset(
                    AllImages.edit,
                    height: 25,
                    width: 25,
                  ),
                ),
              ),
              getSpacer,
              Text(
                "e-mailId".tr,
                style: Theme.of(context)
                    .textTheme
                    .headline2
                    .copyWith(fontSize: 17),
              ),
              FormInputField(
                controller: to.email,
                keyboardType: TextInputType.emailAddress,
                isReadOnly: to.isEditEmailId,
                iconSuffix: GestureDetector(
                  onTap: () {
                    setState(() {
                      to.isEditEmailId = !to.isEditEmailId;
                    });
                  },
                  child: Image.asset(
                    AllImages.edit,
                    height: 25,
                    width: 25,
                  ),
                ),
              ),
              getSpacer,
              Text(
                "password".tr,
                style: Theme.of(context)
                    .textTheme
                    .headline2
                    .copyWith(fontSize: 17),
              ),
              FormInputField(
                controller: to.password,
                obscureText: isPasswordVisiable,
                iconSuffix: GestureDetector(
                  onTap: () {
                    setState(() {
                      isPasswordVisiable = !isPasswordVisiable;
                    });
                  },
                  child: Image.asset(
                    AllImages.showPassword,
                    height: 10,
                    width: 10,
                  ),
                ),
              ),
              getSpacer,
            ],
          ),
        ),
      );

  profilePicture({double size}) {
    print("authTo.userModel.userImage ${authTo.userModel.userImage}");
    return Container(
      height: size,
      width: size,
      decoration: BoxDecoration(
        border: Border.all(
          color: AppThemes.lightDividerColor,
        ),
        shape: BoxShape.circle,
      ),
      child: Container(
        margin: EdgeInsets.all(3),
        decoration: BoxDecoration(
          image: DecorationImage(
            image: to.profileImage != null
                ? FileImage(File(to.profileImage.path))
                : authTo.userModel.userImage != Urls.imageBaseUrl
                    ? NetworkImage(
                        authTo.userModel.userImage,
                      )
                    : AssetImage(
                        AllImages.adddp,
                      ),
            fit: BoxFit.cover,
          ),
          shape: BoxShape.circle,
        ),
      ),
    );
  }

  get getSpacer => const SizedBox(
        height: 15,
      );
}
