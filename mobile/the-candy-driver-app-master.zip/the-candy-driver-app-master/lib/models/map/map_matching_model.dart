import 'package:driver/models/models.dart';

class MapMatchingModel {
  List<Matchings> matchings;
  List<Tracepoints> tracepoints;
  String code;
  String uuid;

  MapMatchingModel({this.matchings, this.tracepoints, this.code, this.uuid});

  MapMatchingModel.fromJson(Map<String, dynamic> json) {
    if (json['matchings'] != null) {
      matchings = [];
      json['matchings'].forEach((v) {
        matchings.add(new Matchings.fromJson(v));
      });
    }
    /* if (json['tracepoints'] != null) {
      tracepoints = new List<Tracepoints>();
      json['tracepoints'].forEach((v) {
        tracepoints.add(new Tracepoints.fromJson(v));
      });
    }*/
    code = json['code'];
    uuid = json['uuid'];
  }
}
