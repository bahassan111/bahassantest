<?php
?>

<div class="" id="member_form">


    <form method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="id_user">Member</label>
            <select data-livesearch="true" title="Select a member" required name="id_user" id="id_user" class="selectpicker">
                <?php foreach($users as $user){ ?>
                    <option data-subtext="<?= $user->username; ?>" value="<?= $user->id; ?>"><?= $user->name; ?></option>
                <?php } ?>
            </select>
        </div>
        <input type="hidden" name="id_project" value="<?= $project->id; ?>">
        <div class="form-group">
            <label for="type">Affectation</label>
            <select required title="Select an affectation type" name="type" id="type" class="selectpicker">
                <option value="dev">Developer</option>
                <option value="tester">Tester</option>
                <option value="manager">Responsible</option>
                <option value="viewer">Observator</option>
            </select>
        </div>
    </form>


</div>
