import {

  PENDING_FETCH_All,
  SET_ARTICLE_All,
  SUCCESS_FETCH_ALL

} from "../actions/types";

export default function(
  state = { isLoadingData: false, isDoSearch: false, data: [], keyword: null },
  action
) {

  console.log("Log_action_Search => ", action.type);

  switch (action.type) {
    case PENDING_FETCH_All:
      return {
        ...state,
        isLoadingData: true
      };

    case SET_ARTICLE_All:
      return { ...state, data: action.payload };
    case SUCCESS_FETCH_ALL:

      return {
        ...state,
        isLoadingData: false
      };
    default:
      return state;
  }

}
