﻿namespace CCISFMMND
{
    partial class history
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.WinControls.UI.ListViewDetailColumn listViewDetailColumn4 = new Telerik.WinControls.UI.ListViewDetailColumn("Column 0", "Date");
            Telerik.WinControls.UI.ListViewDetailColumn listViewDetailColumn5 = new Telerik.WinControls.UI.ListViewDetailColumn("Column 1", "remise");
            Telerik.WinControls.UI.ListViewDetailColumn listViewDetailColumn6 = new Telerik.WinControls.UI.ListViewDetailColumn("Column 2", "Date d\'enregistrement");
            this.list = new Telerik.WinControls.UI.RadListView();
            this.del = new Telerik.WinControls.UI.RadButton();
            ((System.ComponentModel.ISupportInitialize)(this.list)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.del)).BeginInit();
            this.SuspendLayout();
            // 
            // list
            // 
            this.list.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            listViewDetailColumn4.HeaderText = "Date";
            listViewDetailColumn5.HeaderText = "remise";
            listViewDetailColumn6.HeaderText = "Date d\'enregistrement";
            this.list.Columns.AddRange(new Telerik.WinControls.UI.ListViewDetailColumn[] {
            listViewDetailColumn4,
            listViewDetailColumn5,
            listViewDetailColumn6});
            this.list.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.list.ItemSpacing = -1;
            this.list.Location = new System.Drawing.Point(12, 12);
            this.list.MultiSelect = true;
            this.list.Name = "list";
            this.list.ShowGridLines = true;
            this.list.Size = new System.Drawing.Size(791, 549);
            this.list.TabIndex = 1;
            this.list.ViewType = Telerik.WinControls.UI.ListViewType.DetailsView;
            this.list.SelectedItemChanged += new System.EventHandler(this.list_SelectedItemChanged);
            this.list.ItemMouseClick += new Telerik.WinControls.UI.ListViewItemEventHandler(this.list_ItemMouseClick);
            this.list.ItemMouseDoubleClick += new Telerik.WinControls.UI.ListViewItemEventHandler(this.list_ItemMouseDoubleClick);
            // 
            // del
            // 
            this.del.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.del.Enabled = false;
            this.del.Location = new System.Drawing.Point(600, 567);
            this.del.Name = "del";
            this.del.Size = new System.Drawing.Size(203, 38);
            this.del.TabIndex = 3;
            this.del.Text = "Supprimer";
            this.del.Click += new System.EventHandler(this.del_Click);
            // 
            // history
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(815, 617);
            this.Controls.Add(this.del);
            this.Controls.Add(this.list);
            this.Name = "history";
            this.Text = "Historique";
            this.Load += new System.EventHandler(this.DbExplore_Load);
            this.Resize += new System.EventHandler(this.DbExplore_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.list)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.del)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Telerik.WinControls.UI.RadListView list;
        private Telerik.WinControls.UI.RadButton del;

    }
}