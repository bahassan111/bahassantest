import 'package:driver/constants/constants.dart';

class Urls {
  static String imageBaseUrl = "https://thecandytech.com/dms/uploads/driver/";
  static String baseRiderUrl = "https://thecandytech.com/dms/api/riderapi/";
  static String baseDriverUrl = 'https://thecandytech.com/dms/api/driverapi/';
  static String baseDriverImageUrl =
      "https://thecandytech.com/dms/uploads/driver/profile_photo";
  static String currency = baseDriverUrl + 'currency';
  static String country = baseRiderUrl + 'rider_country';
  static String vehicleCategory = baseDriverUrl + 'vehicle_category';
  static String vehicleSubtype = baseDriverUrl + 'vehicle_subtype';
  static String getFleet = baseDriverUrl + 'get_fleet';
  static String login = baseDriverUrl + 'login';
  static String logout = baseDriverUrl + 'logoutdata';
  static String forgotPassword = baseDriverUrl + 'forgot_password';
  static String driverProfile = baseDriverUrl + 'driver_profile';
  static String prebookingJobs = baseDriverUrl + 'prebooking_jobs';
  static String tripHistory = baseDriverUrl + 'trip_history';
  static String changeStatus = baseDriverUrl + 'change_status';
  static String driverLatlong = baseDriverUrl + 'driver_latlong';
  static String getTrip = baseDriverUrl + 'get_trip';
  static String rideStatus = baseDriverUrl + 'ride_status';
  static String rideStatusArrived = baseDriverUrl + 'ride_status_arrived';
  static String completedRide = baseDriverUrl + 'completed_ride';
  static String tokenidUpdate = baseDriverUrl + 'tokenid_update';
  static String driverRating = baseDriverUrl + 'driver_rating';
  static String driverCancelRide = baseDriverUrl + 'driver_cancel_ride';
  static String driverTolltax = baseDriverUrl + 'driver_tolltax';
  static String driverNoshowride = baseDriverUrl + 'driver_noshowride';
  static String driverRideDetail = baseDriverUrl + 'driver_ride_detail';
  static String driverPrebookingstatusTrip =
      baseDriverUrl + 'driver_prebookingstatus_trip';
  static String driverPrebookCheck = baseDriverUrl + 'driver_prebook_check';
  static String driverUpcomingbooking =
      baseDriverUrl + 'driver_upcomingbooking';
  static String driverPrebookingstatusCancel =
      baseDriverUrl + 'driver_prebookingstatus_cancel';
  static String driverEwallet = baseDriverUrl + 'driver_ewallet';
  static String driverPrebookingstatusChange =
      baseDriverUrl + 'driver_prebookingstatus_change';
  static String driverUninstallapp = baseDriverUrl + 'driver_uninstallapp';
  static String driverUpdateprofile = baseDriverUrl + 'driver_updateprofile';
  static String driverAlreadyassignRide =
      baseDriverUrl + "driver_alreadyassign_ride";
  static String driverBlockCheck = baseDriverUrl + "driver_blockcheck";

  // map related APIs
  static String mapBoxThirPartyUrl =
      "https://api.mapbox.com/styles/v1/thecandy/ckj6xb7nwewvw19qmx8iywiq5/tiles/256/{z}/{x}/{y}@2x?access_token=${ProjectKeys.mapBoxKey}";
  static String getRoute =
      "https://api.mapbox.com/directions/v5/mapbox/driving/";
  static String searchPlacesUrl(String searchText) =>
      'https://api.mapbox.com/geocoding/v5/mapbox.places/$searchText.json?access_token=${ProjectKeys.mapBoxKey}';
  static String getNavigationUrl(String points) =>
      'https://api.mapbox.com/directions/v5/mapbox/driving/$points?alternatives=true&geometries=polyline&steps=true&access_token=${ProjectKeys.mapBoxKey}';
  static String getMapMatchingUrl(String points) =>
      'https://api.mapbox.com/matching/v5/mapbox/driving/$points?overview=full&geometries=geojson&access_token=${ProjectKeys.mapBoxKey}';
}
