import 'package:bot_toast/bot_toast.dart';
import 'package:driver/constants/app_themes.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:driver/ui/components/components.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class EmergencyContactDetails extends StatefulWidget {
  @override
  _EmergencyContactDetailsState createState() =>
      _EmergencyContactDetailsState();
}

class _EmergencyContactDetailsState extends State<EmergencyContactDetails> {
  final AuthController authController = AuthController.to;
  @override
  void initState() {
    super.initState();
    if (authController.userModel != null) {
      authController.contactPersonNameController.text =
          authController.userModel.emergencypserson;
      authController.emergencyMobileNumberController.text =
          authController.userModel.emergencycontact;
      authController.alternateNumberController.text =
          authController.userModel.alternateEmgNum;

      //authController.accoutNameController.text = authController.userModel.acc;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 15),
      child: Column(
        children: [
          SizedBox(
            height: 30,
          ),
          Text(
            "emergency_contact_detail".tr + ":",
            style: Theme.of(context).textTheme.headline2.copyWith(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
          ),
          SizedBox(
            height: 10,
          ),
          FormInputField(
            labelText: "contact_person_name".tr,
            controller: authController.contactPersonNameController,
          ),
          SizedBox(
            height: 10,
          ),
          Row(children: [
            Expanded(
              child: FormInputField(
                labelText: "mobile_number".tr,
                controller: authController.emergencyMobileNumberController,
                keyboardType: TextInputType.phone,
              ),
            ),
            SizedBox(
              width: 20,
            ),
            Expanded(
              child: FormInputField(
                labelText: "alternate_number".tr,
                controller: authController.alternateNumberController,
                keyboardType: TextInputType.phone,
              ),
            ),
          ]),
          SizedBox(
            height: 30,
          ),
          if (authController.userModel == null)
            Row(children: [
              Expanded(
                child: FormInputField(
                  labelText: "password".tr,
                  controller: authController.passwordController,
                ),
              ),
              SizedBox(
                width: 20,
              ),
              Expanded(
                child: FormInputField(
                  labelText: "confirmPassword".tr,
                  controller: authController.confirmPasswordController,
                ),
              ),
            ]),
          if (authController.userModel == null)
            SizedBox(
              height: 20,
            ),
          if (authController.userModel == null)
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Checkbox(
                  activeColor: AppThemes.lightdeepPinkDropDownIconColor,
                  value: authController.isTermAndConditionAccept,
                  onChanged: (value) {
                    setState(() {
                      authController.isTermAndConditionAccept = value;
                    });
                  },
                ),
                SizedBox(
                  width: 10,
                ),
                Expanded(
                  child: Text(
                    "term_and_condition".tr,
                  ),
                )
              ],
            ),
          SizedBox(
            height: 30,
          ),
          Container(
            width: 200,
            child: RoundButton(
              text: authController.userModel == null
                  ? "submit".tr.toUpperCase()
                  : "update".tr.toUpperCase(),
              backgroundColor: AppThemes.lightRounderAuthButtonColor,
              onTap: onSubmit,
            ),
          ),
          SizedBox(
            height: 30,
          ),
        ],
      ),
    );
  }

  onSubmit() {
    // select fleet validation
    print(
        "authController.userModel == null ${authController.userModel == null}");
    if (authController.selectedFleet == null) {
      showErroMessage("please_select".tr + "errorSelectFleet".tr);
    } else if (authController.userProfileImg == null &&
        authController.userModel == null) {
      showErroMessage("please_select".tr + "profile_picture".tr);
    } else if (authController.fnameController.text.trim() == "") {
      showErroMessage("please_enter".tr + "first_name".tr);
    } else if (authController.lnameController.text.trim() == "") {
      showErroMessage("please_enter".tr + "last_name".tr);
    } else if (authController.selectedCountry == null) {
      showErroMessage("please_select".tr + "country".tr);
    } else if (authController.stateController.text.trim() == "") {
      showErroMessage("please_enter".tr + "state".tr);
    } else if (authController.postCodeController.text.trim() == "") {
      showErroMessage("please_enter".tr + "post_code".tr);
    } else if (authController.addressController.text.trim() == "") {
      showErroMessage("please_enter".tr + "address".tr);
    } else if (authController.emailController.text.trim() == "") {
      showErroMessage("please_enter".tr + "e_mail".tr);
    } else if (authController.personalMobileNumberController.text.trim() ==
        "") {
      showErroMessage("please_enter".tr + "mobile_number".tr);
    } else if (authController.drivingLicenseImg == null &&
        authController.userModel == null) {
      showErroMessage("please_upload".tr + "driving_license".tr);
    } else if (authController.vocationalLicenseImg == null &&
        authController.userModel == null) {
      showErroMessage("please_upload".tr + "vocational_license".tr);
    } else if (authController.drivingLicenseExp == null) {
      showErroMessage("please_select".tr + "error_driving_license_exp".tr);
    } else if (authController.vocationalLicenseExp == null) {
      showErroMessage("please_select".tr + "error_vocation_license_exp".tr);
    }
    // your vehicle details
    else if (authController.plateNumberController.text.trim() == "") {
      showErroMessage("please_enter".tr + "plate_number".tr);
    } else if (authController.selectedVehicleCategorytype == null) {
      showErroMessage("please_select".tr + "vehicle_category".tr);
    } else if (authController.selectedVehicleType == null) {
      showErroMessage("please_select".tr + "vehicle_type".tr);
    } else if (authController.vehicleInsuranceImg == null &&
        authController.userModel == null) {
      showErroMessage("please_upload".tr + "vehicle_insurance".tr);
    } else if (authController.vehiclePermitImg == null &&
        authController.userModel == null) {
      showErroMessage("please_upload".tr + "vehicle_permit".tr);
    } else if (authController.yearOfReg == null) {
      showErroMessage("please_select".tr + "yeat_of_registration".tr);
    } else if (authController.insuranceExp == null) {
      showErroMessage("please_select".tr + "vehicle_insurance".tr);
    } else if (authController.permitExp == null) {
      showErroMessage("please_select".tr + "permit_expiry_date".tr);
    } else if (authController.selectedColor == null) {
      showErroMessage("please_enter".tr + "vehicle_color".tr);
    } else if (authController.vehicleModelController.text.trim() == "") {
      showErroMessage("please_enter".tr + "vehicle_model".tr);
    }
    //bank detail confirmation
    else if (authController.bankNameController.text.trim() == "") {
      showErroMessage("please_enter".tr + "bank_name".tr);
    } else if (authController.accoutNameController.text.trim() == "") {
      showErroMessage("please_enter".tr + "accout_name".tr);
    } else if (authController.accountNumberController.text.trim() == "") {
      showErroMessage("please_enter".tr + "account_number".tr);
    }
    // emergency details
    else if (authController.contactPersonNameController.text.trim() == "") {
      showErroMessage("please_enter".tr + "contact_person_name".tr);
    } else if (authController.emergencyMobileNumberController.text.trim() ==
        "") {
      showErroMessage("please_enter".tr + "mobile_number".tr);
    } else if (authController.passwordController.text.trim() == "" &&
        authController.userModel == null) {
      showErroMessage("errorPassword".tr);
    } else if (authController.confirmPasswordController.text.trim() !=
            authController.passwordController.text.trim() &&
        authController.userModel == null) {
      showErroMessage("errorValidConfirmPassword".tr);
    } else if (!authController.isTermAndConditionAccept &&
        authController.userModel == null) {
      showErroMessage("errorselectTermsAndCondition".tr);
    } else {
      // call sign up api
      authController.singUp();
    }
  }

  showErroMessage(String message) {
    BotToast.showWidget(
      toastBuilder: (_) => ErrorDialog(
        title: "error".tr,
        message: message,
      ),
    );
  }
}
