import Model from '../model'
export default class Claps extends Model {
  static schema = {
    name: 'Claps',
    primaryKey: 'id', // id == postId
    properties: {
      id : {type: 'int'},
      interessant : {type: 'bool', default: false},
      pas_interessant : {type: 'bool', default: false},
      jaime : {type: 'bool', default: false},
      jaime_pas : {type: 'bool', default: false},
      nimporte_quoi : {type: 'bool', default: false}
    }
  }
}