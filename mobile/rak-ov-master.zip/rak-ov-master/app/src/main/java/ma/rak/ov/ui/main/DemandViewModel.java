package ma.rak.ov.ui.main;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.HashMap;

import io.realm.Realm;
import io.realm.RealmList;
import io.realm.Sort;
import io.realm.exceptions.RealmException;
import ma.rak.ov.LoginActivity;
import ma.rak.ov.api.RetrofitClient;
import ma.rak.ov.api.TwDatabase;
import ma.rak.ov.bodyResponse.AbonnementResponse;
import ma.rak.ov.bodyResponse.AgentsResponse;
import ma.rak.ov.bodyResponse.HistoriqueAbonnementResponse;
import ma.rak.ov.bodyResponse.HistoriqueBranchementResponse;
import ma.rak.ov.bodyResponse.SettingsResponse;
import ma.rak.ov.bodyResponse.SettingsResponseBr;
import ma.rak.ov.bodyResponse.StatistiqueResponse;
import ma.rak.ov.models.Categorie;
import ma.rak.ov.models.CategorieBr;
import ma.rak.ov.models.Emplacement;
import ma.rak.ov.models.Motif;
import ma.rak.ov.models.MotifBr;
import ma.rak.ov.models.Nature;
import ma.rak.ov.models.NatureBr;
import ma.rak.ov.storage.SharedPrefManager;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DemandViewModel extends ViewModel {

    public MutableLiveData<ArrayList<HashMap<String, String>>> BranchementMutableLiveData = new MutableLiveData<>();
    public MutableLiveData<ArrayList<HashMap<String, String>>> BrResponseMutableLiveData = new MutableLiveData<>();

    public MutableLiveData<ArrayList<HashMap<String, String>>> AbonnementMutableLiveData = new MutableLiveData<>();
    public MutableLiveData<ArrayList<HashMap<String, String>>> AbResponseMutableLiveData = new MutableLiveData<>();

    public MutableLiveData<HistoriqueBranchementResponse> HistoriqueBrResponseMutableLiveData = new MutableLiveData<>();
    public MutableLiveData<HistoriqueAbonnementResponse> HistoriqueAbResponseMutableLiveData = new MutableLiveData<>();

    public MutableLiveData<StatistiqueResponse> StResponseMutableLiveData = new MutableLiveData<>();
    public MutableLiveData<SettingsResponse> SettingsMutableLiveData = new MutableLiveData<>();

    public MutableLiveData<ArrayList<HashMap<String, String>>> AgentsMutableLiveData = new MutableLiveData<>();


    Realm realm;

    public DemandViewModel() {
        super();
    }

    public void getBrachments(String token, int page, Context ctx, int status, String search) {
        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);

        String s = "like '%" + search.trim() + "%'";
        String search_filter = search.trim().equals("") ? "1=1" : "NOM # OR ANNDEMDE # OR NUMDEMDE # OR LIBCATDE # OR ADRESDEVI # OR LIBSTADE # OR OBSEVEDE # OR COMOSTOP # ".replaceAll("#", s);


        ArrayList demandes = dbh.query(TwDatabase.BRDemandes.TABLE_NAME, "STATOPER = " + String.valueOf(status) + " AND (" + search_filter + ")", null, TwDatabase.BRDemandes.DATSAIDE + " DESC");


        BranchementMutableLiveData.setValue(demandes);
        BrResponseMutableLiveData.setValue(demandes);
    }

    public void getHistoriquesBr(String token, Context ctx) {

        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);


        ArrayList demandes = dbh.query(TwDatabase.BRDemandes.TABLE_NAME, "STATDEVI not in (1, 2)", null, TwDatabase.BRDemandes.DATSAIDE + " DESC");


        BranchementMutableLiveData.setValue(demandes);
        BrResponseMutableLiveData.setValue(demandes);

    }


    public void getHistoriquesAb(String token, int status, Context ctx) {
        this.getAbonnements(token, status, ctx, "");
        return;
    }

    public void getAbonnements(String token, int status, Context ctx, String search) {

        if (search == null) search = "";

        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);

        String s = "like '%" + search.trim() + "%'";
        String search_filter = search.trim().equals("") ? "1=1" : "NOM # OR CIN # OR CODE_CLIENT # OR LIBNATCL # OR RAISSOCI # OR ADRECORR # OR NUMEDOSS # OR ANNEDOSS # OR NUMEPOLI # OR TELECLIE #  OR NOMPRERE # OR ADRELOCA #  OR LIBELOCA # ".replaceAll("#", s);

        ArrayList<HashMap<String, String>> demandes = dbh.query(TwDatabase.ABDemandes.TABLE_NAME, "STATOPER = ? AND (" + search_filter + ")", new String[]{String.valueOf(status)}, TwDatabase.ABDemandes.DATCREAB + " DESC");


        AbonnementMutableLiveData.setValue(demandes);
        AbResponseMutableLiveData.setValue(demandes);

    }

    public void getAbonnements_old(String token, int status) {
        realm = Realm.getDefaultInstance();
        Call<AbonnementResponse> call = null;
        if (status == 0) {
            call = RetrofitClient.getApi(token).abonnemnts(1);
        } else if (status == 1) {
            call = RetrofitClient.getApi(token).nonExecutee(1);
        } else if (status == 2) {
            call = RetrofitClient.getApi(token).executee(1);
        } else {
            call = RetrofitClient.getApi(token).rejetee(1);
        }

        /*
        call.enqueue(new Callback<AbonnementResponse>() {
            @Override
            public void onResponse(Call<AbonnementResponse> call, Response<AbonnementResponse> response) {
                if (response.code() == 200 && response.body().getData() != null) {
                    AbonnementMutableLiveData.setValue((RealmList<Abonnement>) response.body().getData());
                    AbResponseMutableLiveData.setValue(response.body());

                    try {
                        realm.executeTransaction(realm -> {

                            realm.copyToRealmOrUpdate(response.body());
                        });
                    } catch (RealmException realmException) {
                        Log.e("demandesResponse", realmException.getMessage());
                    } finally {
//                realm.close();
                    }
                }
            }

            @Override
            public void onFailure(Call<AbonnementResponse> call, Throwable t) {
                Log.i("onFailure", t.getMessage().toString());

                realm.executeTransaction(new Realm.Transaction() {
                    @Override
                    public void execute(Realm realm) {
                        AbonnementResponse realmResponse = realm.where(AbonnementResponse.class).findFirst();
                        if (realmResponse != null)
                            AbResponseMutableLiveData.setValue(realmResponse);
                    }
                });

            }
        });

         */
    }

    public void getStatistique(String token, Context context) {
        realm = Realm.getDefaultInstance();

        try {

            Call<StatistiqueResponse> call = RetrofitClient.getApi(token).statstiques();
            call.enqueue(new Callback<StatistiqueResponse>() {
                @Override
                public void onResponse(Call<StatistiqueResponse> call, Response<StatistiqueResponse> response) {
                    if (response.code() == 403) {
                        SharedPrefManager.getInstance(context).clear();
                        Intent intent = new Intent(context, LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

                        context.startActivity(intent);
                    }
                    StResponseMutableLiveData.setValue(response.body());
                    try {
                        realm.executeTransaction(realm -> {
                            //realm.copyToRealmOrUpdate(response.body());
                        });
                    } catch (RealmException realmException) {
                        Log.e("newStatistiqueResponse", realmException.getMessage());
                    } finally {
                        realm.close();
                    }
                }

                @Override
                public void onFailure(Call<StatistiqueResponse> call, Throwable t) {
                    Log.i("onFailure", t.getMessage().toString());

                    realm.executeTransaction(new Realm.Transaction() {
                        @Override
                        public void execute(Realm realm) {
                            StatistiqueResponse realmResponse = realm.where(StatistiqueResponse.class).sort("createdAt", Sort.DESCENDING).findFirst();
                            if (realmResponse != null)
                                StResponseMutableLiveData.setValue(realmResponse);
                        }
                    });

                }
            });
        } catch (IllegalArgumentException e) {
            Log.i("onFailure", e.getMessage().toString());
            realm.close();
        }
    }

    ;

    public void getSettings(String token, Context mContext, String gerance) {

        boolean isAb = SharedPrefManager.getInstance(mContext).getMode() == 0;

        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(mContext);

        ArrayList<HashMap<String, String>> motifs = dbh.query(TwDatabase.ABMotifs.TABLE_NAME, TwDatabase.ABMotifs.COL_GERANCE + " = ?", new String[]{gerance}, TwDatabase.ABMotifs.COL_LABEL);
        ArrayList<HashMap<String, String>> natures = dbh.query(TwDatabase.ABNatures.TABLE_NAME, TwDatabase.ABNatures.COL_GERANCE + " = ?", new String[]{gerance}, TwDatabase.ABNatures.COL_LABEL);
        ArrayList<HashMap<String, String>> emplacements = dbh.query(TwDatabase.ABEmplacements.TABLE_NAME, null, null, TwDatabase.ABEmplacements.COL_LABEL);
        ArrayList<HashMap<String, String>> cats = dbh.query(TwDatabase.ABCats.TABLE_NAME, TwDatabase.ABCats.COL_GERANCE + " = ?", new String[]{gerance}, TwDatabase.ABCats.COL_LABEL);

        ArrayList<HashMap<String, String>> cats_br = dbh.query(TwDatabase.BRCats.TABLE_NAME, TwDatabase.BRCats.COL_GERANCE + " = ?", new String[]{gerance}, TwDatabase.BRCats.COL_LABEL);
        ArrayList<HashMap<String, String>> natures_br = dbh.query(TwDatabase.BRNatures.TABLE_NAME, null, null, TwDatabase.BRNatures.COL_LABEL);
        ArrayList<HashMap<String, String>> motifs_br = dbh.query(TwDatabase.BRMotifs.TABLE_NAME, TwDatabase.BRMotifs.COL_GERANCE + " = ?", new String[]{gerance}, TwDatabase.BRMotifs.COL_LABEL);


        RealmList<Motif> _motifs = new RealmList<Motif>();
        for (HashMap<String, String> mot : motifs) {
            _motifs.add(new Motif(Integer.valueOf(mot.get("key")), mot.get("label"), mot.get("codegera")));
        }

        RealmList<Nature> _naturs = new RealmList<Nature>();
        for (HashMap<String, String> nat : natures) {
            _naturs.add(new Nature(Integer.valueOf(nat.get("key")), nat.get("label"), nat.get("codegera"), nat.get("CODCATAB")));
        }

        RealmList<Categorie> _cats = new RealmList<Categorie>();
        for (HashMap<String, String> cat : cats) {
            _cats.add(new Categorie(Integer.valueOf(cat.get("key")), cat.get("label"), cat.get("codegera")));
        }

        RealmList<Emplacement> _emplacements = new RealmList<Emplacement>();
        for (HashMap<String, String> em : emplacements) {
            _emplacements.add(new Emplacement(Integer.valueOf(em.get("key")), em.get("label")));
        }


        RealmList<CategorieBr> _cats_br = new RealmList<CategorieBr>();
        for (HashMap<String, String> cat : cats_br) {
            _cats_br.add(new CategorieBr(Integer.valueOf(cat.get("key")), cat.get("label"), cat.get("codegera")));
        }

        RealmList<NatureBr> _naturs_br = new RealmList<NatureBr>();
        for (HashMap<String, String> nat : natures_br) {
            _naturs_br.add(new NatureBr(
                    Integer.valueOf(nat.get("key")),
                    nat.get("label"),
                    nat.get("CODCATAB"),
                    nat.get("CODNATIN"),
                    nat.get("CALICOMP"),
                    nat.get("NOMBFILS"),
                    nat.get("INTENSIT"),
                    nat.get("TENSELEC"),
                    nat.get("PUISSANC")
            ));
        }
        RealmList<MotifBr> _motifs_br = new RealmList<MotifBr>();
        for (HashMap<String, String> mot : motifs_br) {
            _motifs_br.add(new MotifBr(Integer.valueOf(mot.get("key")), mot.get("label"), mot.get("codegera"), mot.get(TwDatabase.BRMotifs.CODSTAOP)));
        }


        SettingsResponse rep = new SettingsResponse(1, isAb ? "Abonnement" : "Branchement", "SUCESS", "", _naturs, _cats, _motifs, _emplacements, new SettingsResponseBr(
                _naturs_br, _cats_br, _motifs_br
        ));

        SettingsMutableLiveData.setValue(rep);
    }

    public void getAgents(Context ctx) {

        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(ctx);
        SQLiteDatabase db = dbh.getReadableDatabase();

        ArrayList<HashMap<String, String>> agents = dbh.query(TwDatabase.ALLAgents.TABLE_NAME, null, null, TwDatabase.ALLAgents.COL_LABEL + " ASC");

        AgentsMutableLiveData.setValue(agents);
    }

    public void getAgents_old(String token) {
        realm = Realm.getDefaultInstance();
        Call<AgentsResponse> call = RetrofitClient.getApi(token).agents();
        call.enqueue(new Callback<AgentsResponse>() {
            @Override
            public void onResponse(Call<AgentsResponse> call, Response<AgentsResponse> response) {
                //AgentsMutableLiveData.setValue(response.body());
                try {
                    realm.executeTransaction(realm -> {
                        realm.copyToRealmOrUpdate(response.body());
                    });
                } catch (RealmException realmException) {
                    Log.e("AgentsResponse", realmException.getMessage());
                } finally {
                    realm.close();
                }
            }

            @Override
            public void onFailure(Call<AgentsResponse> call, Throwable t) {
                Log.i("onFailure", t.getMessage().toString());
                realm.executeTransaction(new Realm.Transaction() {
                    @Override
                    public void execute(Realm realm) {
                        AgentsResponse realmResponse = realm.where(AgentsResponse.class).sort("id", Sort.DESCENDING).findFirst();
                        //if (realmResponse != null)
                        //AgentsMutableLiveData.setValue(realmResponse);
                    }
                });

            }
        });
    }
}
