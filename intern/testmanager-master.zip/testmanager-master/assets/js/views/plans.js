(function () {
    var view = $('#plans_view');
    if (!view.length) return;

    $(view)
        .on('click', '.getplans', getPlans)
        .on('click', '.add_plan', function () {
            ajaxSideModal('project/one_plan/', 'Create Plan', 'far fa-paper-plane', {
                close_text : 'Cancel',
                size : 'md',
                confirm_text : 'Save plan',
                whenLoaded : function(modal, data){
                    $('.selectpicker').selectpicker();
                    modal.on('change', '#id_group', function () {
                        var inp = $('#groupe_input'), sel = $('#group_select');

                        log($(this).val());
                        if($(this).val() === 'new_group'){
                            inp.slideDown();
                        }else{
                            inp.slideUp();
                        }
                    })
                },
                whenConfirm : function(modal, data){
                    modal.find('input, textarea, button').prop('disabled', true);

                    $.post(site_url + 'project/save_plan/'+ project_id, {
                        title : modal.find('#title').val(),
                        desc : modal.find('#desc').val(),
                        type : modal.find('#type').val(),
                        group : modal.find('#group').val(),
                        id_group : modal.find('#id_group').val(),
                        url : modal.find('#url').val(),
                    }, function (rep) {

                        if(rep.status === 'OK'){
                            toastr_('The Test plan was added successfully', 'success', 'success');
                            getPlans();
                            modal.sideModal('hide');
                        }else{
                            toastr_('Error', 'error', 'danger', 9000);
                        }

                    })
                        .always(function () {
                            modal.find('input, textarea, button').prop('disabled', false);
                        })
                        .fail(function () {
                            toastr_('Error', 'error', 'danger', 9000);
                        })
                },
                whenError : function(modal, error){},
                whenClosed : function(modal){},
                post_data : {id_project : project_id},

            });
        })
        .on('click', '[data-editplan]', function () {
            var id = this.dataset.editplan;
            log(id);
            ajaxSideModal('project/one_plan/' + id, 'Create Plan', 'far fa-paper-plane', {
                close_text : 'Cancel',
                size : 'md',
                confirm_text : 'Save plan',
                whenLoaded : function(modal, data){
                    $('.selectpicker').selectpicker();
                    $('#type').trigger('change');
                    modal.on('change', '#id_group', function () {
                        var inp = $('#groupe_input'), sel = $('#group_select');

                        log($(this).val());
                        if($(this).val() === 'new_group'){
                            inp.slideDown();
                        }else{
                            inp.slideUp();
                        }
                    })
                },
                whenConfirm : function(modal, data){
                    modal.find('input, textarea, button').prop('disabled', true);

                    $.post(site_url + 'project/save_plan/'+ project_id, {
                        title : modal.find('#title').val(),
                        desc : modal.find('#desc').val(),
                        type : modal.find('#type').val(),
                        group : modal.find('#group').val(),
                        id_group : modal.find('#id_group').val(),
                        id : id,
                        url : modal.find('#url').val(),
                    }, function (rep) {

                        if(rep.status === 'OK'){
                            toastr_('The Test plan was added successfully', 'success', 'success');
                            getPlans();
                            modal.sideModal('hide');
                        }else{
                            toastr_('Error', 'error', 'danger', 9000);
                        }

                    })
                        .always(function () {
                            modal.find('input, textarea, button').prop('disabled', false);
                        })
                        .fail(function () {
                            toastr_('Error', 'error', 'danger', 9000);
                        })
                },
                whenError : function(modal, error){},
                whenClosed : function(modal){},

            });
        })

        .on('click', '[data-deleteplan]', function () {
            var plan_id = this.dataset.deleteplan;

            ask('Are you sur?', 'Do you really want to delete this plan', function (ok) {
                if(ok){
                    post('project/delete_plan/' + plan_id, null, function (rep) {
                        if(rep.status === 'OK'){
                            toastr_('The plan was successfully deleted', 'success', 'success');
                            getPlans();
                        }else{
                            toastr_('Unable to delete the selected plan', 'error', 'danger', 9000);
                        }
                    })
                }
            }, 'Yes', 'No');

        })
        .on('click', '[data-plan]', function () {
            $(this).addClass('active').parent().find('> .active').not(this).removeClass('active');
            getPlan(this.dataset.plan);
        })
        .on('click', '.pplan_group > div', function () {
            var open = $(this).parent().toggleClass('open').hasClass('open');

            if(open){
                $(this).parent().find('ul').hide().slideDown(100);
            }else{
                $(this).parent().find('ul').slideUp();
            }
        })










        .ready(function () {
            getPlans();
        })
    ;


    function getPlans() {
        var list = $('#project_plans_list');


        post('project/get_plans/' + project_id, {}, function (rep) {
            var data = rep.data || [];
            list.html('');

            if(data.length === 0){
                list.append('<div class="nodata">No Plans yet.</div>');
                $('.ppi_noplan').fadeIn();
                $('.ppi_selectplan').hide();
            }else{
                $('.ppi_noplan').hide();
                $('.ppi_selectplan').fadeIn();
            }

            $.each(data, function (i, g) {
                var group = $(`<div class="pplan_group open">
                <div><span class="t">${g.title} <b>${g.items.length}</b></span><span class="f"><i class="fas fa-angle-down"></i><i class="fas fa-angle-up"></i></span></div><ul></ul></div>`).appendTo(list);

                $.each(g.items, function (i, plan) {
                    group.find('ul').append(`<div class="pplan_item" data-plan="${plan.id}">
                                
                              
                                <div class="b">
                                    <small><i class="case_type ${plan.type}">${plan.type}</i></small>
                                    <label>${plan.title || '(No title)'}</label>
                                    <span> <i class="badge badge-dark">${plan.tasks || 0}</i></span>
                                   
                                </div>
                                
                            </div>`);
                })
            })

        }, function () {

        });

        switchView(plans_infos);
    }

    function getPlan(id) {
        if(!id) return;
        var container = $('#plan_infos');

        switchView(container);

        container.html('<div class="nodata">Loading ..</div>');

        post('project/plan/' + id, {}, function (rep) {
            container.html(rep);
        }, function () {

        }, function () {
            container.html('<div class="nodata">Error while loading the plan details :(</div>');
        })

    }

    function getCases() {
        var list = $('.test_cases_list'),
            title = list.closest('.card').find('h6');

        title.html('Test Cases <small class="tx-gray-400">(Loading ..)</small>');

        post('project/get_cases/' + plan_id, {}, function (rep) {

            list.html('');

            $.each(rep.data, function (i, item) {

                list.append(`<li class="tcl_item" data-caseid="${item.id}">
                            <div class="i"><i class="fas fa-info"></i></div>
                            <div class="d">
                                <b>${item.title}</b>
                                <p>${item.short}</p>
                                <div>
                                    <span class="badge badge-${item.auto ? 'info' : 'light'}">${item.auto ? 'Auto' : 'Manual'}</span>
                                    <span>${item.time}</span>
                                </div>
                            </div>
                            <div class="r">
                                <i class="fas fa-angle-double-right"></i>
                            </div>
                        </li>`)


            })


        }, function () {
            title.html('Test Cases');
        })
    }


    function switchView(to) {
        var container = $('.pproject_info');
        to = $(to);

        container.find('>div').hide();
        to.fadeIn();

    }
})();