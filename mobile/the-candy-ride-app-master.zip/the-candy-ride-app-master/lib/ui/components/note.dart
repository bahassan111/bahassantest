import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rider_app/constants/app_themes.dart';
import 'package:rider_app/controllers/controllers.dart';
import 'package:rider_app/ui/components/components.dart';

class Note extends StatefulWidget {
  Note({this.onSubmit});
  final Function onSubmit;

  @override
  _NoteState createState() => _NoteState();
}

class _NoteState extends State<Note> {
  static HomeController to = Get.find();

  @override
  void initState() {
    super.initState();
    to.noteController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
      decoration: BoxDecoration(
          color: AppThemes.lightWhitebackGroundColor,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(10),
            topRight: Radius.circular(10),
          )),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            "note".tr,
            style: Theme.of(context)
                .textTheme
                .headline2
                .copyWith(fontSize: 16, fontWeight: FontWeight.w700),
          ),
          FormInputField(
            controller: to.noteController,
            disableBorderColor: AppThemes.lightBoxshadow,
          ),
          SizedBox(height: 5),
          SquareButton(
            text: "submit".tr.toUpperCase(),
            onTap: widget.onSubmit,
          )
        ],
      ),
    );
  }
}
