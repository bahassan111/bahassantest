class Ride {
  String id;
  String currency;
  String dispatchId;
  String userId;
  String driverId;
  String clientId;
  String managerId;
  String adminId;
  String countryId;
  int flightnumber;
  String pickupaddress;
  String pickuplat;
  String pickuplong;
  String dropaddress;
  String droplat;
  String droplong;
  String dropotheraddress;
  String dropotherLat;
  String dropotherLong;
  String driverLat;
  String driverLong;
  String driverMobile;
  String bookType;
  String carCategory;
  String vichleType;
  String carMake;
  String carModel;
  String carColor;
  String drivergender;
  String note;
  String bookDate;
  String bookDatetime;
  String pickupDate;
  String pickupTime;
  String dropDate;
  String startTime;
  String endTime;
  String driverArrivaltime;
  String waypoint;
  String leaveondate;
  String leaveontime;
  String returnondate;
  String returnontime;
  String distance;
  String duration;
  String fareid;
  String totalfare;
  String tolltaxamount;
  String clientfees;
  String dispatchfees;
  String adminfees;
  String gatewayFee;
  String taxFees;
  String prebookingFee;
  String managerfee;
  String driverfees;
  String royalityFees;
  String surge;
  String fullname;
  String mobile;
  String passport;
  String email;
  String paymentmode;
  String rideStatus;
  String preStatus;
  String reason;
  String cancelledBy;
  String driverEta;
  String refundamount;
  String cancelcharge;
  String cancelServiceFee;
  String passengerStatus;
  String blockStatus;
  String subuserId;
  String mailStatus;
  String reassignStatus;
  String waitingTimeCharge;
  String waitingTime;
  String paymentTokenId;
  String driverPaymentMode;
  String updatedDriverEarning;
  String agentBookerTax;
  String fname;
  String lname;
  String carcategory;
  String plateNo;
  String categoryName;
  String profilePhoto;
  String supplierPartnerTax;
  String categoryCode;
  String vehicleModel;
  String vehicleColor;

  Ride({
    this.id,
    this.categoryName,
    this.profilePhoto,
    this.dispatchId,
    this.userId,
    this.driverId,
    this.clientId,
    this.managerId,
    this.adminId,
    this.countryId,
    this.flightnumber,
    this.pickupaddress,
    this.pickuplat,
    this.pickuplong,
    this.dropaddress,
    this.droplat,
    this.droplong,
    this.dropotheraddress,
    this.dropotherLat,
    this.plateNo,
    this.currency,
    this.dropotherLong,
    this.driverLat,
    this.driverLong,
    this.bookType,
    this.carCategory,
    this.vichleType,
    this.carMake,
    this.carModel,
    this.carColor,
    this.drivergender,
    this.note,
    this.bookDate,
    this.bookDatetime,
    this.pickupDate,
    this.pickupTime,
    this.dropDate,
    this.startTime,
    this.endTime,
    this.driverArrivaltime,
    this.waypoint,
    this.leaveondate,
    this.leaveontime,
    this.driverMobile,
    this.returnondate,
    this.returnontime,
    this.distance,
    this.duration,
    this.fareid,
    this.totalfare,
    this.tolltaxamount,
    this.clientfees,
    this.dispatchfees,
    this.supplierPartnerTax,
    this.adminfees,
    this.gatewayFee,
    this.taxFees,
    this.prebookingFee,
    this.managerfee,
    this.driverfees,
    this.royalityFees,
    this.surge,
    this.fullname,
    this.mobile,
    this.passport,
    this.email,
    this.paymentmode,
    this.rideStatus,
    this.preStatus,
    this.reason,
    this.cancelledBy,
    this.driverEta,
    this.refundamount,
    this.cancelcharge,
    this.cancelServiceFee,
    this.passengerStatus,
    this.blockStatus,
    this.subuserId,
    this.mailStatus,
    this.reassignStatus,
    this.waitingTimeCharge,
    this.waitingTime,
    this.paymentTokenId,
    this.driverPaymentMode,
    this.updatedDriverEarning,
    this.agentBookerTax,
    this.fname,
    this.lname,
    this.carcategory,
    this.categoryCode,
    this.vehicleColor,
    this.vehicleModel,
  });

  Ride.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    currency = json['currency'];
    dispatchId = json['dispatch_id'];
    userId = json['user_id'];
    driverId = json['driver_id'];
    clientId = json['client_id'];
    managerId = json['manager_id'];
    adminId = json['admin_id'];
    countryId = json['country_id'];
    flightnumber = json['flightnumber'];
    pickupaddress = json['pickupaddress'];
    pickuplat = json['pickuplat'];
    pickuplong = json['pickuplong'];
    dropaddress = json['dropaddress'];
    droplat = json['droplat'];
    droplong = json['droplong'];
    dropotheraddress = json['dropotheraddress'];
    dropotherLat = json['dropother_lat'];
    dropotherLong = json['dropother_long'];
    driverLat = json['driver_lat'];
    driverLong = json['driver_long'];
    bookType = json['book_type'];
    carCategory = json['car_category'];
    vichleType = json['vichle_type'];
    carMake = json['car_make'];
    carModel = json['car_model'];
    carColor = json['car_color'];
    drivergender = json['drivergender'];
    note = json['note'];
    bookDate = json['book_date'];
    bookDatetime = json['book_datetime'];
    pickupDate = json['pickup_date'];
    pickupTime = json['pickup_time'];
    dropDate = json['drop_date'];
    startTime = json['start_time'];
    endTime = json['end_time'];
    driverArrivaltime = json['driver_arrivaltime'];
    waypoint = json['waypoint'];
    leaveondate = json['leaveondate'];
    leaveontime = json['leaveontime'];
    returnondate = json['returnondate'];
    returnontime = json['returnontime'];
    distance = json['distance'];
    duration = json['duration'];
    fareid = json['fareid'];
    totalfare = json['totalfare'];
    tolltaxamount = json['tolltaxamount'];
    clientfees = json['clientfees'];
    dispatchfees = json['dispatchfees'];
    adminfees = json['adminfees'];
    gatewayFee = json['gateway_fee'];
    taxFees = json['tax_fees'];
    prebookingFee = json['prebooking_fee'];
    managerfee = json['managerfee'];
    driverfees = json['driverfees'];
    royalityFees = json['royality_fees'];
    surge = json['surge'];
    fullname = json['fullname'];
    mobile = json['mobile'];
    passport = json['passport'];
    email = json['email'];
    paymentmode = json['paymentmode'];
    rideStatus = json['ride_status'];
    preStatus = json['pre_status'];
    reason = json['reason'];
    cancelledBy = json['cancelled_by'];
    driverEta = json['driver_eta'];
    refundamount = json['refundamount'];
    cancelcharge = json['cancelcharge'];
    cancelServiceFee = json['cancel_service_fee'];
    passengerStatus = json['passenger_status'];
    blockStatus = json['block_status'];
    subuserId = json['subuser_id'];
    mailStatus = json['mail_status'];
    reassignStatus = json['reassign_status'];
    waitingTimeCharge = json['waiting_time_charge'];
    waitingTime = json['waiting_time'];
    paymentTokenId = json['payment_token_id'];
    driverPaymentMode = json['driver_payment_mode'];
    updatedDriverEarning = json['updated_driver_earning'];
    agentBookerTax = json['agent_booker_tax'];
    fname = json['fname'];
    lname = json['lname'];
    carcategory = json['carcategory'];
    driverMobile = json['drivermobile'];
    plateNo = json['plate_no'];
    categoryName = json['category_name'];
    profilePhoto = json['profile_photo'];
    categoryCode = json['category_code'];
    supplierPartnerTax = json['supplier_partner_tax'];
    vehicleColor = json['vehicle_color'];
    vehicleModel = json['vehicle_model'];
  }
}
