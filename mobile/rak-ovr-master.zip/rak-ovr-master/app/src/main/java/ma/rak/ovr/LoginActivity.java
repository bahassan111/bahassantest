package ma.rak.ovr;

import android.Manifest;
import android.app.ActivityOptions;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Base64;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import ma.rak.ovr.api.RetrofitClient;
import ma.rak.ovr.bodyResponse.LoginResponse;
import ma.rak.ovr.storage.SharedPrefManager;
import ma.rak.ovr.ui.main.AdminFragment;
import ma.rak.ovr.ui.main.ProgressButton;
import ma.rak.ovr.ui.main.SyncUI;
import ma.rak.ovr.utils.NetworkUtility;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {
    private static final int REQUEST_READ_PHONE_STATE = 22;
    View btnLogin;
    ImageView loginLogo;
    EditText loginEmail;
    EditText LoginPassword;
    FrameLayout progressOverlay;
    ProgressButton progressButton;

    @Override
    protected void onStart() {
        super.onStart();
        progressButton = new ProgressButton(LoginActivity.this, R.string.se_connecter, "SE CONNECTER");
        if (SharedPrefManager.getInstance(this).isLogged()) {
            Intent intent = new Intent(LoginActivity.this, SyncUI.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (SharedPrefManager.getInstance(this).isLogged()) {
            Intent intent = new Intent(LoginActivity.this, SyncUI.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }


        setContentView(R.layout.activity_login);

        btnLogin = findViewById(R.id.btn_login);
        loginLogo = (ImageView) findViewById(R.id.login_logo);
        loginEmail = (EditText) findViewById(R.id.login_email);
        LoginPassword = (EditText) findViewById(R.id.login_password);
        progressOverlay = findViewById(R.id.progress_overlay);
        progressOverlay.setVisibility(View.INVISIBLE);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                progressButton.buttonActivated();

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        String email = loginEmail.getText().toString().trim();
                        String password = LoginPassword.getText().toString().trim();

                        if (email.isEmpty()) {
                            loginEmail.setError("Email required");
                            loginEmail.requestFocus();
                            return;
                        }

                        if (password.isEmpty()) {
                            LoginPassword.setError("Password required");
                            LoginPassword.requestFocus();
                            return;
                        }

                        if (password.equals("12345678") && email.equals("admin")) {

                            Intent intent = new Intent(LoginActivity.this, AdminFragment.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(LoginActivity.this).toBundle());
                            }
                            return;

                        }


                        String auth = Base64.encodeToString((email + ":" + password).trim().getBytes(), Base64.NO_WRAP | Base64.URL_SAFE);

                        String imei = NetworkUtility.getIMEI(LoginActivity.this);

                        RetrofitClient.resetInstance();

                        try {
                            Call<LoginResponse> call = RetrofitClient
                                    .getApiNoHeaders()
                                    .auth("Basic " + auth, "work_access", imei);

                            call.enqueue(new Callback<LoginResponse>() {
                                @Override
                                public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                                    LoginResponse s = null;
                                    if (response.code() == 200) {
                                        progressButton.buttonFinished();
                                        s = response.body();
                                        SharedPrefManager.getInstance(LoginActivity.this).saveUser(email, s.getData().token, s.getData().expires.toString(), s.getData().scoop, s.getData().fullname, email, password);
                                        progressOverlay.setVisibility(View.INVISIBLE);
                                        Handler handler1 = new Handler();
                                        handler1.postDelayed(new Runnable() {
                                            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
                                            @Override
                                            public void run() {
                                                Intent intent = new Intent(LoginActivity.this, SyncUI.class);
                                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

                                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                                    startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(LoginActivity.this).toBundle());
                                                }
                                            }
                                        }, 500);


                                    } else {
                                        progressOverlay.setVisibility(View.INVISIBLE);
                                        progressButton.buttonCancled(R.string.se_connecter);
                                        Toast.makeText(LoginActivity.this, "Les informations de connexion fournies sont incorrectes, veuillez réessayer", Toast.LENGTH_LONG).show();
                                    }
                                }

                                @Override
                                public void onFailure(Call<LoginResponse> call, Throwable t) {
                                    progressOverlay.setVisibility(View.INVISIBLE);
                                    progressButton.buttonCancled(R.string.se_connecter);
                                    Toast.makeText(LoginActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();
                                }


                            });
                        } catch (Exception e) {
                            progressOverlay.setVisibility(View.INVISIBLE);
                            progressButton.buttonCancled(R.string.se_connecter);
                            Toast.makeText(LoginActivity.this, "L'hôte de l'API n'est pas valide", Toast.LENGTH_LONG).show();
                        }
                    }

                }, 1000);


            }
        });

        loginLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, SyncUI.class));
            }
        });


        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE);

        if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE}, REQUEST_READ_PHONE_STATE);
        } else {
            //TODO
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case REQUEST_READ_PHONE_STATE:
                if ((grantResults.length > 0) && (grantResults[0] == PackageManager.PERMISSION_GRANTED)) {

                }
                break;

            default:
                break;
        }
    }

}