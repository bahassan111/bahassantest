<?php
addJS([
    'assets/js/views/plans.js',
]);

viewHeader(
    'Test Plans',
    'Configure Tests using Groups and Test Plans and Test Cases',
    [
        (object) ['name' => 'Dashboard', 'url' => site_url()],
        (object) ['name' => 'Projects', 'url' => site_url('projects')],
        (object) ['name' => $project->name, 'url' => getProjectUrl($project)],
        (object) ['name' => 'Test Plans', 'url' => ''],
    ], true);

projectMenu('test_plans', $project);
?>



<div class="project_plans_body n_menu">

    <div class="pproject_list">

        <div class="smart_list">
            <div class="sml_head">
                <div class="sml_search">
                    <div>
                        <input data-search=".pplan_item" type="search" id="pp_search" placeholder="Search ..">
                        <a href="javascript:void(0);"><i class="fas fa-search"></i></a>
                    </div>
                </div>
                <div class="sml_actions">
                    <?php if(hasPermission('plans', 'add')){?>
                        <button class="btn btn-sm add_plan"><i class="fas fa-plus"></i></button>
                    <?php } ?>
                    <button class="btn btn-sm getplans"><i class="fas fa-sync"></i></button>
                </div>
            </div>

            <div class="sml_list" id="project_plans_list">


            </div>
        </div>

    </div>
    <div class="pproject_info">

        <div id="plans_infos">

            <div class="ppi_selectplan">
                <p>Select a plan from the list on your left to view its details</p>
            </div>
            <div class="ppi_noplan">
                <p>No plans available for the current project,</br> Try to <a class="add_plan" href="javascript:void(0);">create a new plan</a>.</p>
            </div>

        </div>
        <div id="plan_infos"></div>


    </div>

</div>

<script>
    var project_id = <?= $project->id ?: 0; ?>;
</script>
