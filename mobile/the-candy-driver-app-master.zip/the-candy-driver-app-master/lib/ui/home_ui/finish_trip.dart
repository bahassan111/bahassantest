import 'package:bot_toast/bot_toast.dart';
import 'package:driver/constants/constants.dart';
import 'package:driver/constants/helpers/helpers.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:driver/ui/components/components.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:wakelock/wakelock.dart';

class FinishTrip extends StatefulWidget {
  static HomeController to = HomeController.to;
  static AuthController authTo = AuthController.to;
  static PreBookingController bookingTo = PreBookingController.to;

  @override
  _FinishTripState createState() => _FinishTripState();
}

class _FinishTripState extends State<FinishTrip> with WidgetsBindingObserver {
  final store = GetStorage();
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  AppLifecycleState _appLifecycleState;

  static HomeController to = Get.find();
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    setState(() {
      _appLifecycleState = state;
    });
    if (state == AppLifecycleState.paused) {
      print('AppLifecycleState state: Paused audio playback');
    }
    if (state == AppLifecycleState.resumed) {
      to.tickerSubscription?.cancel();
      to.startCountingCharterTime();
      preTo.showNotif();

      print('AppLifecycleState state: resumed audio playback');
    }
    print('AppLifecycleState state:  $state');
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          SizedBox(
            height: 20,
          ),
          /*displayDetail(
              title: "booking_date".tr + ": ",
              value: datedayddMMMyyyyhhMMss(
                  strinToDateTime(to.rideDetail.bookDate))),
          SizedBox(
            height: 5,
          ),
          displayDetail(
              title: "booking_number".tr + ": ",
              value: getBookType(to.rideDetail.bookType) +
                  to.rideDetail.id +
                  (to.rideDetail?.categoryCode ?? "T")),
          SizedBox(
            height: 5,
          ),*/
          displayDetail(
              title: "drop_off_location".tr + ": ",
              value: FinishTrip.to.rideDetail.dropaddress),
          SizedBox(
            height: 5,
          ),
          displayDetail(
            title: "charter_time".tr + ": ",
            value: FinishTrip.to.rideDetail.waitingTime + " " + "hours".tr,
          ),
          /*displayDetail(
            title: "journey_time".tr + ": ",
            value: minutesToDateTime(to.rideDetail.duration).minute.toString() +
                " min".tr +
                " 00" +
                " sec".tr,
          ),*/
          SizedBox(
            height: 15,
          ),
          GetBuilder<HomeController>(builder: (_) {
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: RoundButton(
                backgroundColor:
                    !FinishTrip.to.canFinishTrip ? Colors.grey : null,
                text: "finish_trip".tr,
                onTap: !FinishTrip.to.canFinishTrip
                    ? null
                    : () async {
                        await FinishTrip.to.driverRideDetail();
                        // print(
                        //     "driverArrivaltime time  ${to.rideDetail.driverArrivaltime}");
                        // print("start time  ${to.rideDetail.startTime}");
                        // print("wait time ${to.rideDetail.waitingTime}");
                        // TimeOfDay startTime =
                        //     stringtoTimeOfDay(to.rideDetail.startTime);
                        final double distanceInMeters =
                            Geolocator.distanceBetween(
                                FinishTrip.to.currentLocation.latitude,
                                FinishTrip.to.currentLocation.longitude,
                                double.tryParse(
                                    FinishTrip.to.rideDetail.droplat),
                                double.tryParse(
                                    FinishTrip.to.rideDetail.droplong));
                        if (distanceInMeters > 500) {
                          BotToast.showWidget(
                            toastBuilder: (_) => ErrorDialog(
                              title: "alert".tr,
                              message: "far_away_drop_off_location".tr,
                            ),
                          );
                        } else {
                          Wakelock.disable();
                          FinishTrip.to.completeRide(
                            rideId: int.tryParse(FinishTrip.to.rideDetail.id),
                            statusType: 4,
                            bookType:
                                int.tryParse(FinishTrip.to.rideDetail.bookType),
                            endTime: DateTime.now(),
                            navigateTo: HomeScreenStatus.FinishTrip,
                          );
                          store.remove("current_ride");
                        }
                      },
                // },
                textStyle: !FinishTrip.to.canFinishTrip
                    ? AppThemes.lightTheme.textTheme.headline1
                        .copyWith(color: Colors.white)
                    : AppThemes.lightTheme.textTheme.headline1
                        .copyWith(fontSize: 15, fontWeight: FontWeight.w600),
              ),
            );
          }),
          SizedBox(
            height: 15,
          ),
        ],
      ),
    );
  }

  tripDetail(context, {String name, String number}) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          Image.asset(
            AllImages.passangerIcon,
            height: 50,
            fit: BoxFit.cover,
          ),
          SizedBox(
            width: 10,
          ),
          Text(
            name,
            style:
                AppThemes.lightTheme.textTheme.headline1.copyWith(fontSize: 18),
          ),
          Spacer(),
          Image.asset(AllImages.callIcon),
          SizedBox(
            width: 15,
          ),
          Text(
            number,
            style:
                AppThemes.lightTheme.textTheme.headline5.copyWith(fontSize: 16),
          ),
          SizedBox(
            width: 20,
          ),
        ],
      ),
    );
  }

  displayDetail({String title, String value, bool ispadded = true}) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: ispadded ? 20 : 0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(fontSize: 14),
              maxLines: 2,
            ),
          ),
        ],
      ),
    );
  }
}
