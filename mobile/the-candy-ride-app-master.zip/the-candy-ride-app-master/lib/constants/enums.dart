enum Status {
  none,
  locationSelect,
  noteAdded,
  dateTimeSelect,
  vehicleSelect,
  vehiclecategorySelect,
  chooseFare,
  payment
}

List<String> rideStatus = [
  "Waiting",
  "Accepted",
  "Canceled",
  "Proceed",
  "Completed"
];

abstract class RideStatus {
  static const finished = "4";
  static const started = "3";
  static const canceled = "2";
  static const booked = "1";
  static const notBokked = "0";
}
