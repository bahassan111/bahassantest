<?php
defined('BASE') OR die('Direct access is not allowed');
$page_data = get_page_data($page);
?>
<!doctype html>
<html class="no-js" lang="">

<head>

    <meta charset="utf-8">
    <title><?= $title; ?></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?= site_url('images/a_propos.png'); ?>">

    <!--<link rel="manifest" href="site.webmanifest">-->

    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= site_url('assets/js/vendor/bootsraap/bootsraap.min.css'); ?>">
    <link rel="stylesheet" href="<?= site_url('assets/js/vendor/bootstrap-select/dist/css/bootstrap-select.css'); ?>">
    <link rel="stylesheet" href="<?= site_url('assets/js/vendor/dropify/dist/css/dropify.css'); ?>">
    <link rel="stylesheet" href="<?= site_url('assets/js/vendor/toastr/toastr.min.css'); ?>">
    <link rel="stylesheet" href="<?= site_url('assets/js/vendor/sweetalert/sweetalert.css'); ?>">
    <link rel="stylesheet" href="<?= site_url('assets/js/vendor/file_input_master/fileinput.css'); ?>">
    <link rel="stylesheet" href="<?= site_url('assets/js/vendor/file_input_master/themes/explorer-fa/theme.css'); ?>">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= site_url('assets/css/normalize.css'); ?>">
    <link rel="stylesheet" href="<?= site_url('assets/css/standard.css'); ?>">
    <link rel="stylesheet" href="<?= site_url('assets/js/vendor/datatables/Responsive-2.2.1/css/responsive.dataTables.min.css'); ?>">
    <link rel="stylesheet" href="<?= site_url('assets/css/admin.css'); ?>">
    <link rel="stylesheet" href="<?= site_url('assets/css/admin.sm.css'); ?>">

    <script src="https://maps.googleapis.com/maps/api/js?v=weekly&key=AIzaSyBP4oTbEMyhcBTp4J--isC8Mi9D1YXq5f0&libraries=visualization" type="text/javascript"></script>
    <script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/43/3/intl/en_gb/common.js"></script>
    <script type="text/javascript" charset="UTF-8" src="https://maps.googleapis.com/maps-api-v3/api/js/43/3/intl/en_gb/util.js"></script>

    <meta name="theme-color" content="#fafafa">

    <script>
        var ifes = {
            url : '<?= site_url('admin') ?>',
            language : {
                loading : 'Loading',
            },
        };


    </script>
</head>
<body>

<div class="loading"><div class="loader"><span><i></i></span> <b>Chargement ..</b></div></div>

<div class="content">

    <div class="sidebar">
        <div class="mtogler tr">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
        </div>
        <div class="sheader">
            <div class="i">
                <img src="<?= site_url('images/logo_square.png'); ?>" alt="LOGO">
            </div>
            <div class="n">
                <span>MTIP</span>
                <small>Espace d'administration</small>
            </div>
        </div>

        <div class="smenu">
            <ul>


                <?php foreach(config()->admin_menu as $name => $menu){

                    if($name=='dashboard' || current_admin()->role === '-1' || in_array($name,$sections_actifs)){

                    $menu['url'] = $menu['url'] != '#' ? site_url($menu['url']) : '#';
                    ?>

                    <li <?= $page === $name ? 'class="active"' : ''; ?>>
                        <a href="<?= $menu['url']; ?>">
                            <span class="i"><i class="<?= $menu['icon']; ?>"></i></span>
                            <span class="t"><?= $menu['text']; ?></span>
                            <?php if(isset($menu['items'])){?>
                                <span class="d tr"><i class="fa fa-angle-down"></i></span>
                            <?php } ?>
                        </a>
                        <?php if(isset($menu['items'])){?>
                            <ul>
                                <?php foreach($menu['items'] as $sub => $item){
                                    $item['url'] = $item['url'] != '#' ? site_url($item['url']) : '#';
                                    ?>
                                    <li <?= $page === $sub ? 'class="active"' : ''; ?>>
                                        <a href="<?= $item['url']; ?>">
                                            <span class="i"><i class="<?= $item['icon']; ?>"></i></span>
                                            <span class="t"><?= $item['text']; ?></span>
                                        </a>
                                    </li>
                                <?php } ?>
                            </ul>
                        <?php } ?>
                    </li>


                <?php } } ?>

            </ul>
        </div>
    </div>

    <div class="topbar">
        <div class="page_head">
            <h3 class="page_title"><i class="<?= $page_data->icon; ?>"></i><span><?= $page_data->text; ?></span></h3>
            <p class="page_desc"><?= $page_data->description; ?></p>
        </div>
        <div class="select_country">


        </div>
        <div class="user_menu">
            <div class="usm">
                <div class="usm_inner">
                    <span><?= current_admin()->fullname; ?></span>
                    <small><?= current_admin()->email; ?></small>
                </div>
                <div class="usm_img">
                    <div style="background-image: url('<?= site_url('images/user.jpg') ?>')"></div>
                </div>
            </div>
            <div class="usm_dropdown">
                <div class="usm_dd_inner">
                    <a href="#"><i class="fas fa-tachometer-alt"></i> <span>Mon tableau de bord</span></a>
                    <i></i>
                    <a href="#"><i class="fas fa-cog"></i> <span>Réglages</span></a>
                    <i></i>
                    <a href="<?= site_url('admin/?c=login&page=logout'); ?>"><i class="fas fa-sign-out-alt"></i> <span>Se déconnecter</span></a>
                </div>
            </div>
        </div>
    </div>

    <div id="view_holder">

