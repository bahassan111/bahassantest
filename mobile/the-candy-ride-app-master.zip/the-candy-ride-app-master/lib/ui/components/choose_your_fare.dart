import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rider_app/controllers/controllers.dart';
import 'package:rider_app/ui/components/components.dart';
import '../../constants/app_themes.dart';

class ChooseYourFare extends StatefulWidget {
  const ChooseYourFare({this.onFareSelected});
  final Function onFareSelected;

  @override
  _ChooseYourFareState createState() => _ChooseYourFareState();
}

class _ChooseYourFareState extends State<ChooseYourFare> {
  static HomeController to = Get.find();
  static AuthController authTo = Get.find();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: AppThemes.lightWhitebackGroundColor,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(10),
            topRight: Radius.circular(10),
          )),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(height: 5),
          Container(
            width: 75,
            child: Divider(
              color: AppThemes.lightPinkBackGroundColor,
              thickness: 3,
            ),
          ),
          Text(
            "Vehicle Category : " + to.selectedSubTypeOfVehicle.categoryName,
            style: Theme.of(context)
                .textTheme
                .headline2
                .copyWith(fontSize: 15, fontWeight: FontWeight.w700),
          ),
          Text(
            " Fare : ${authTo.currency} ${to.availableFleets[0].fare.toPrecision(2)}",
            style: Theme.of(context).textTheme.headline2.copyWith(
                  fontSize: 19,
                  fontWeight: FontWeight.w700,
                ),
          ),

          // Divider(
          //   color: AppThemes.lightPinkBackGroundColor,
          //   thickness: 2,
          // ),
          //MediaQuery.removePadding(
          //  removeTop: true,
          //  removeBottom: true,
          //  context: context,
          //  child: ListView.builder(
          //    itemCount: to.availableFleets.length,
          //    shrinkWrap: true,
          //    padding: EdgeInsets.zero,
          //    itemBuilder: (context, index) {
          //      return GestureDetector(
          //        onTap: () {
          //        },
          //        child: Container(
          //          decoration: BoxDecoration(
          //            color: to.selectedFleet?.fleetId ==
          //                    to.availableFleets[index].fleetId
          //                ? AppThemes.lightDividerColor.withOpacity(0.2)
          //                : AppThemes.lightWhitebackGroundColor,
          //            border: Border(
          //              bottom: BorderSide(
          //                color: AppThemes.lightDividerColor,
          //              ),
          //            ),
          //          ),
          //          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 7),
          //          child: Row(
          //            mainAxisAlignment: MainAxisAlignment.center,
          //            children: [
          //              ProfilePicture(
          //                size: 40,
          //                image: to.availableFleets[index].fleetlogo,
          //              ),
          //              SizedBox(width: 15),
          //              Text(
          //                to.availableFleets[index].fleetnamne ?? '',
          //                style: Theme.of(context).textTheme.headline2.copyWith(
          //                      fontSize: 16,
          //                      fontWeight: FontWeight.w700,
          //                    ),
          //                textAlign: TextAlign.center,
          //              ),
          //              Spacer(),
          //              Text(
          //                "${authTo.currency} ${to.availableFleets[index].fare.toPrecision(2)}",
          //                style: Theme.of(context).textTheme.headline2.copyWith(
          //                      fontSize: 16,
          //                      fontWeight: FontWeight.w700,
          //                    ),
          //              )
          //            ],
          //          ),
          //        ),
          //      );
          //    },
          //  ),
          //),
          SizedBox(height: 15),
          GestureDetector(
            onTap: () {
              if (to.availableFleets[0] != null) {
                widget.onFareSelected(to.availableFleets[0]);
              } else {
                BotToast.showWidget(
                  toastBuilder: (_) => ErrorDialog(
                    title: "error".tr,
                    message: "pleaseSelectAnyDriver".tr,
                  ),
                );
              }
            },
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 5),
              width: 300,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: AppThemes.lightPinkBackGroundColor,
              ),
              child: Center(
                child: Text(
                  "confirm".tr,
                  style: Theme.of(context).textTheme.subtitle1.copyWith(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w700),
                ),
              ),
            ),
          ),
          SizedBox(height: 15),
        ],
      ),
    );
  }
}
