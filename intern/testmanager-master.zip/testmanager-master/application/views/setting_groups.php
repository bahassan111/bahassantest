<?php
addJS([
    'assets/js/views/settings.js',
]);

viewHeader(
    'Manage Groups',
    '',
    [
        (object) ['name' => 'Dashboard', 'url' => site_url()],
        (object) ['name' => 'Manage Groups', 'url' => ''],
    ], true);
settingsMenu('groups');
?>



<div class="groups_holder n_menu">
    <div class="groups_list">

    </div>

</div>



