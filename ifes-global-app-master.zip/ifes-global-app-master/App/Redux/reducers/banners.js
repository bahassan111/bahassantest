import {
  PENDING_FETCH_BANNER,
  SET_BANNERS,
  SUCCESS_FETCH_BANNER
} from "../actions/types";

export default function(state = { isLoadingData: false, data: [] }, action) {
  console.log("action => ", action);
  switch (action.type) {
    case PENDING_FETCH_BANNER:
      return {
        ...state,
        isLoadingData: true
      };
    case SET_BANNERS:
      return { ...state, data: action.payload };
    case SUCCESS_FETCH_BANNER:
      return {
        ...state,
        isLoadingData: false
      };
    default:
      return state;
  }
}
