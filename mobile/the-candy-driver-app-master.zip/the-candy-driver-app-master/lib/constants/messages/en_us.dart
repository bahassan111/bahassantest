Map<String, String> enUS = {
  // Intro
  "itro_title_1": "Future of Mobility",
  "itro_subtitle_1":
      "We are The Candy Technologies Ltd, a London Start-Up with over 15 years of expertise",
  "itro_title_2": "Driver Self-Onboarding",
  "itro_subtitle_2":
      "Licensed Drivers with a Licensed Vehicle, may Self-Onboard to their preferred Fleet",
  "itro_title_3": "Incoming Bookings",
  "itro_subtitle_3":
      "The Candy Application brings Network & International Bookings from various Booking Aggregators",
  "itro_title_4": "Maximize Earning - Minimize Waiting Time",
  "itro_subtitle_4": "Continuous Bookings with 0%-10% Deductions",
  "lets_started": "LET'S GET STARTED",
  "got_it": "GOT IT",

  // language
  "chooseLanguage": "Choose Language",

  // sign  up
  "register_message": "Register Yourself as a Driver",
  "choose_your_fleet": "Choose Your Fleet",
  "upload_message": "Upload\nYour\nPhoto",
  "personal_details": "Personal Details:",
  "your_vehicle_details": "Your Vehicle Details:",
  "your_bank_details": "Your Bank Details",
  "emergency_contact_detail": "Emergency Contact Details:",

  // personal details
  "profile_picture": "Profile picture",
  "first_name": "First Name",
  "last_name": "Last Name",
  "country": "Country",
  "currency": "Currency",
  "state": "State",
  "post_code": "Post Code",
  "address": "Address",
  "e_mail": "E-mail",
  "mobile_number": "Mobile Number",
  "driving_license": "Driving License",
  "vocational_license": "Vocational License",
  "exp_driving_license": "Driving License Expires On",
  "exp_vocational_license": "Vocational License Expires On",

  // vehicle Details
  "plate_number": "Plate Number",
  "vehicle_type": "Vehicle Type",
  "vehicle_category": "Vehicle Category",
  "yeat_of_registration": "Year of Registration",
  "vehicle_insurance": "Vehicle Insurance",
  "insurance_expiry_date": "Insurance Expiry Date",
  "vehicle_permit": "Vehicle Permit",
  "permit_expiry_date": "Permit Expiry Date",

  // bank details
  "bank_name": "Bank Name",
  "accout_name": "Account Name",
  "account_number": "Account Number",

  //emergency contact details
  "contact_person_name": "Contact Person Name",
  "alternate_number": "Alternate Number",

  "password": "Password",
  "confirmPassword": "Confirm Password",

  "term_and_condition":
      "I do agree to accept the Terms and Conditions of TheCandy.",
  "submit": "Submit",

  "please_select": "Please select ",
  "please_enter": "Please enter ",
  "please_upload": "Please upload",

  // errors
  "ok": "Ok",
  "error": "Error",
  "errorSelectFleet": "Fleet",
  "error_driving_license_exp": "Driving license expiry date",
  "error_vocation_license_exp": "Vocational license expiry date",

  "errorPassword": "Please enter password",
  "errorValidConfirmPassword": "Confirm password does not match",
  "errorselectTermsAndCondition": "Please accept select terms and condition",

  //sign in
  "mobile_number_email": "Mobile Number / Email",
  "login": "Log in",
  "forgot_password": "Forgot Password",
  "remember_me": "Remember Me",

  "don’thaveAnAccount": "Don’t have an Account",
  "forfot_password_explanation":
      "Enter the email address you used to create your account and we will email you your password.",
  "send_password": "Send Password",
  "password_send": "Password Sent!",

  "signUp": "Sign Up",
  "signIn": "Sign in",
  "forgotPassword": "Forgot Password?",
  "already_have_account": "Already have Account",
  "candy": "Candy",
  "mobileNo": "Mobile number",
  "e-mailId": "E-Mail ID",

  "recoverPassword": "Recover Password",
  "enter": "Enter",
  "recoverAccountSuggestion":
      "Enter the E-mail ID previously used to register with TheCandy",
  "sendPassword": "SEND PASSWORD",

  //home page
  "youare": "You're ",
  "offline": "offline",
  "online": "online",
  "acceptance": "Acceptance",
  "rating": "Driver Rating",
  "cancelleation": "Cancellation",

  "booking_date": "Booking Date",
  "booking_number": "Booking Number",
  "remark": "Remark",
  "pick_up_location": "Pick Up Location",
  "proceed": "Proceed",
  "cancel": "Cancel",
  "picking_up": "Picking Up",
  "i_have_arrived": "I have Arrived",
  "drop_off_location": "Drop-Off Location",
  "start_trip": "Start Trip",
  "distance": "Distance",
  "journey_time": "Journey Time",
  "finish_trip": "Finish Trip",

  //drawer
  "home": "Home",
  "prebooking_jobs": "Prebooking Jobs",
  "upcoming_jobs": "Upcoming Jobs",
  "trip_history": "Trip History",
  "e_wallet": "E-Wallet",
  "notifications": "Notifications",
  "logout": "Log Out",
  "booking_id": "Booking ID",

  // trip History
  "tripHistory": "Trip History",
  "totalTripsMade": "Total Trips Made",
  "totalEarningFromTrips": "Total Earning from Trips",
  "selectDate": "Select Date",

  "rideStatus": "Ride Status",
  "fareDetails": "Fare Details",
  "adminFees": "Admin Fee",
  "DriverEarnings": "Driver Earnings",
  "totalPaidAmount": "Total Paid Amount",
  "pick-upLocation": "Pick-up Location",
  "drop-offLocation": "Drop-Off Location",

  // prebooking jobs
  "passanger_name": "Passenger Name",
  "contact_name": "Contact Number",
  "select_job": "Select Job",

  // my wallet
  "total_earning": "Total Earning",
  "my_wallet": "My Wallet",

  "booking_received": "Booking Received",
  "booking_type": "Booking Type",
  "instant_booking": "Instant Booking",
  "pre_booking": "Pre Booking",
  "accept": "Accept",
  "reject": "Reject",

  // finish trip details show
  "my_earning": "My Earning",
  "fare_details": "Fare Details",
  "admin_fee": "Admin Fee",
  "total_paid_amount": "Total Paid Amount",
  "toll": "Toll/Misc",

  "min": "Min",
  "sec": "Sec",

  "toll/erp/road_pricing": "Toll/ERP/Road Pricing",
  "enter_additional_charges_on_journey": "Enter Additional Charges on Journey",
  "choose_your_payment_mode": "Choose payment mode",
  "pay": "Pay",
  "cash/pilot_pay": "Cash/Pilot Pay",
  "no_show": "No Show",

  "pick_up_date_and_time": "Pick-Up Date & Time",
  "fare": "Fare",
  "charter": "Charter",
  "hours": "Hours",
  "charter_time": "Charter Time",

  "far_away_pick_up_location": "Far away than pick up location",
  "far_away_drop_off_location": "Far away than drop off location",
  "charter_time_more": "can no complete before charter time complete",
  "alert": "Alert",

  "logout_all_other_device": "Logout from all other device and login here",
  "fail_logout_all_other_device": "Fail to logout from all other device",
  "connot_complete_ride_before_charter_time":
      "Kindly Complete Charter Time to Finish Trip(contact Fleet for further assistance)",
  "profile_updated": "Your account has been updated successfully",

  "rider": "Rider",
  "pickupFrom": "Pickup From",
  "dropAt": "Drop At",
  "prebook": "Prebook",
  "enterCharterTime": "Enter Charter Time(optional)",
  "hourlyTerms": "*Upon entering Pick-up and Drop-Off",
  "note": "Note",

  "scheduleAPre-Booking": "Schedule a Pre-booking",
  "selectADate": "Select A Date",
  "selectTime": "Select Time",
  "setPickUpWindow": "Set pick-up window",
  "chooseAVehicle": "Choose a vehicle",
  "vehicleCategory": "Vehicle Category",
  "confirmPaymentMethod": "Confirm Payment Method",
  "profile": "Profile",
  "myRatings": "My Ratings",
  "currentTrip": "Current Trip",
  "thankYouForRidingWithUs": "Thank you for riding with us",
  "howWasYourTrip": "How was your trip?",
  "rate": "Rate",
  "time": "Time",
  "price": "Price",
  "additionalComment": "Additional comment",
  "yourDriver": "Your Driver",
  "tripFare": "Trip Fare",
  "vehiclereRegistrationNo": "Vehicle Registration No",
  "vehicleType": "Vehicle Type",
  'cancelTrip': "Cancel Trip",
  "wishYouASafeRide": "Wish you a safe ride!",
  "yourRideHasStarted": "Your Ride has started",
  "destinationArrived": "Destination Arrived",
  "chooseYourFare": "Choose Your fare",
  "confirm": "Confirm",
  "weDoNotHaveRideForSelectedLocation":
      "We do not have ride for selected location",
  "ride_cancel": "Your ride is cancelled",
  "no_show_only_click": "No show can be avilable after 10 min of arrival time",
  "success": "Success",
  "profileUpdatedMessage": "Your Profile updated successfully",
  "somethingWentWrong": "Something went wrong",
  "noRidersAreAvailable": "No riders are available right now",
  "pleaseSelectAnyDriver": "Please select any driver",
  "tripCancelSuccessFully": "Trip cancelled successfully",
  "thankYouForFeedBack": "Thank you for feedback!",
  "noRide": "No ride",
  "noRideAvailableAtTheMoment": "No current ride",
  "rideBookSuccessFully": "Ride Successfully Booked!",
  "rideDoesNotBookSuccessFully": "Your Ride Does not book successFully",
  "driverNotFoundText": "Couldn't Find a driver, Rebook Please!",
  "driverFound": "We found you a Driver",
  "rebook": "Rebook",
  "youAlreadyRatedAllRide": "You already rated last ride",
  "mins": "Mins",
  "kms": "Kms",
  "noTripHistoryFound": "No trip history found",
  "tripId": "Trip ID",
  "exitAppMessage": "Are you sure you want to exit? One trip is going on.",
  "exit": "Exit",
  "yes": "Yes",

  "fleet_markup": "FL & AB M/Up",
  "fleet_tax": "FL & AB Tax",
  "total_ride_fare": "Total Ride Fare",
  "fleet_agent_booker_markup": "FL & AB M/UP",
  "flee_agent_booker_tax": "FL & AB Tax",
  "total_fare": "Total Fare",
  "vehicle_color": "Vehicle Color",
  "vehicle_model": "Vehicle Model",
  "collected": "Collected",
  "please_collect": "Please Collect"
};
