<?php
?>
<div data-label="Details for : <?= $case->title; ?>" class="df-example demo-forms case_view">


    <div class="case_show">
        <div class="scase_head">
            <h3 class="scase_title"><?= $case->title; ?></h3>
            <p class="scase_subtitle">
                Created by <?= $case->user->username; ?> <?= fromNow($case->date_added); ?><?php if($case->date_added != $case->date_modified){?>
                    , Last update <?= ($case->user->id != $case->maj_user->id ? ('by '.$case->maj_user->username) : '') . ' ' . fromNow($case->date_modified); ?>
                <?php } ?>
            </p>
        </div>
        <div class="group scase_dets">
            <label>Details</label>
            <ul>
                <li><span class="t">Type</span><span class="v"><?= $case->type->name; ?></span></li>
                <li><span class="t">Priority</span><span class="v"><span style="color: <?= $case->priority->color2 ?>; background-color: <?= $case->priority->color ?>;" class="priority"><?= '<i class="'.$case->priority->icon.'"></i> ' . strtoupper($case->priority->name); ?></span></span></li>
                <li><span class="t">Estimate</span><span class="v"><?= $case->time_estimate; ?> Minutes</span></li>
                <li><span class="t">Status</span><span class="v"><?= $case->status === '0' ? '<span class="badge badge-primary">OPEN</span>' : '<span class="badge badge-dark">CLOSED</span>'; ?></span></li>
                <li><span class="t">Run Method</span><span class="v"><span class="case_type <?= $case->run_type; ?>"><?= strtoupper($case->run_type); ?></span></span></li>
                <li><span class="t">Order</span><span class="v"><b>#<?= $case->order; ?></b></span></span></li>
                <li><span class="t">Creation date</span><span class="v"><?= date('Y-m-d H:i', $case->date_added); ?></span></span></li>
                <li><span class="t">Last Update</span><span class="v"><?= date('Y-m-d H:i', $case->date_modified); ?></span></span></li>
                <li><span class="t">Created By</span><span class="v"><?= $case->user->username; ?></span></span></li>
                <?php if($case->user->id !== $case->maj_user->id){?>
                    <li><span class="t">Updated By</span><span class="v"><?= $case->maj_user->username; ?></span></span></li>
                <?php } ?>
            </ul>
        </div>

        <div class="scase_desc group">
            <label>Description</label>
            <p><?= $case->desc; ?></p>
        </div>


        <div class="scase_steps group">
            <label><?= $case->run_type == 'auto' ? 'Request' : 'Steps'; ?></label>


            <?php if($case->run_type == 'auto'){?>

                <div class="">
                    <ul class="scase_auto_request">
                        <li>
                            <label>Method</label>
                            <span><?= $case->method; ?></span>
                        </li>
                        <li>
                            <label>URL</label>
                            <span><?= $case->url; ?></span>
                        </li>
                        <li>
                            <label>Headers</label>
                            <ul>
                                <?php foreach(json_decode($case->headers) as $k => $value){ ?>
                                    <li>
                                        <span><?= $k; ?></span>
                                        <b><?= $value; ?></b>
                                    </li>
                                <?php } ?>
                            </ul>
                        </li>
                        <li>
                            <label>Body Parameters</label>
                            <ul>
                                <?php foreach((json_decode($case->params) ?: []) as $k => $value){ ?>
                                    <li>
                                        <span><?= $k; ?></span>
                                        <b><?= $value; ?></b>
                                    </li>
                                <?php } ?>
                            </ul>
                        </li>

                    </ul>
                </div>

            <?php }else{?>
                <div class="scase_steps">
                    <?php foreach($case->steps as $step){ ?>
                        <div class="scase_step">
                            <span class="i"><?= $step->order; ?></span>
                            <div>
                                <span class="t"><small>Todo</small><?= $step->todo; ?></span>
                                <span class="v"><small>Expects</small><?= $step->expect; ?></span>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            <?php } ?>


        </div>

    </div>





</div>