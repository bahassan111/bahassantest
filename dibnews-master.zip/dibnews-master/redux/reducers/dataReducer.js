import {UPDATE_DATA} from '../constants';
import * as Localization from 'expo-localization';
import i18n from 'i18n-js';
import storage from "../../storage/TwStorage";
import moment from "moment-with-locales-es6";

const initialState = {
    data : {
        language : 'fr',
        notifications: true,
        cats_notif: [],
    }
};

const dataReducer = (state = initialState, action) => {

    switch(action.type) {
        case UPDATE_DATA:

            i18n.locale = action.payload.language;
            moment.locale(action.payload.language);

            storage.setStorage('__data', action.payload);



            return {
                ...state,
                data:action.payload
            };
        default:
            return state;
    }
};

export default dataReducer;
