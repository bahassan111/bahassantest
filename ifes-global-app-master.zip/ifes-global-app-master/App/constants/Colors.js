const tintColor = "#2f95dc";

export default {
  tintColor,
  tabIconDefault: "#ccc",
  tabIconSelected: tintColor,
  tabBar: "#1a3156",
  errorBackground: "red",
  errorText: "#fff",
  warningBackground: "#EAEB5E",
  warningText: "#666804",
  noticeBackground: tintColor,
  noticeText: "#fff",
  white: "#fff",
  green: "#6eb94f",
  greenLight: "#4fb4aa",
  gray: "#ccc",
  menuItemBg: "#4f5151",
  arrowColor: "#0264a3",
  titleBg: "#0264a3",
  redColor: "#FF0000",
  orange: "#372554",
};
