import 'package:bot_toast/bot_toast.dart';
import 'package:get/get.dart';
import 'package:dio/dio.dart' as dio;
import 'package:rider_app/constants/constants.dart';
import 'package:rider_app/controllers/controllers.dart';
import 'package:rider_app/helpers/helpers.dart';
import 'package:rider_app/models/ride.dart';
import 'package:rider_app/ui/components/components.dart';

class TripHistoryController extends GetxController {
  static TripHistoryController to = Get.find();
  static AuthController authTo = Get.find();
  List<Ride> rides = [];
  List<Ride> filteredRides = [];
  DateTime selectedDate;
  NetWorkCall networkCall = NetWorkCall();

  Future getTrips() async {
    to.selectedDate = DateTime.now();
    BotToast.showLoading();
    rides.clear();
    filteredRides.clear();
    final result = await networkCall.postRequestWithResponse(
      url: Urls.riderRideHistory,
      json: {
        Params.riderId: authTo.userModel.riderid,
      },
    );

    BotToast.closeAllLoading();
    return result.fold((l) {
      BotToast.showWidget(
        toastBuilder: (_) => ErrorDialog(
          title: "error".tr,
          message: "noTripHistoryFound".tr,
        ),
      );
    }, (response) {
      response.data['getridehistory'].forEach((e) {
        rides.add(Ride.fromJson(e));
        if (isSameDate(
            stringToDateTime(to.rides.last.bookDate), to.selectedDate)) {
          filteredRides.add(rides.last);
        }
      });
      print("reponse ${response.data}");
    });
  }

  onDateChange() {
    filteredRides.clear();
    rides.forEach((ride) {
      if (isSameDate(stringToDateTime(ride.bookDate), to.selectedDate)) {
        filteredRides.add(ride);
      }
    });
  }
}
