package ma.rak.ovr.models;

import io.realm.RealmObject;

public class Resultat extends RealmObject {
    private String CODRESRE;
    private String LIBRESRE;

    public Resultat() {
    }

    public Resultat(String code, String lib) {

        CODRESRE = code;
        LIBRESRE = lib;
    }

    public String getCODRESRE() {
        return CODRESRE;
    }

    public void setCODRESRE(String CODRESRE) {
        this.CODRESRE = CODRESRE;
    }

    public String getLIBRESRE() {
        return LIBRESRE;
    }

    public void setLIBRESRE(String LIBRESRE) {
        this.LIBRESRE = LIBRESRE;
    }

    @Override
    public String toString() {
        return "Statuses{" +
                "CODRESRE='" + CODRESRE + '\'' +
                ", LIBRESRE='" + LIBRESRE + '\'' +
                '}';
    }
}

