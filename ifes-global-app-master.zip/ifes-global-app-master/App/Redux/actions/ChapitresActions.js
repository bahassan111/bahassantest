import {
  SUCCESS_FETCH_ARTICLE,
  SET_ARTICLE_DETAILS,
  PENDING_FETCH_ARTICLE,
  PENDING_SEARCH_ARTICLE,
  SEARCH_ARTICLE,
  SUCCESS_FETCH_SUBCHAPITRE,
  SET_ARTICLE_SUBCHAPITRE,
  PENDING_FETCH_SUBCHAPITRE,
  PENDING_FETCH_GALLERIES,
  SET_ARTICLE_GALLERIES,
  SUCCESS_FETCH_GALLERIES,
  PENDING_FETCH_All,
  SET_ARTICLE_All,
  SUCCESS_FETCH_ALL,
  PENDING_LOGIN_FB,
  SET_LOGIN_FB,
  SUCCESS_LOGIN_FB,
  PENDING_FETCH_FILE,
  SET_FILE,
  SUCCESS_FETCH_FILE,
  PENDING_SAVE_COMMENT,
  SET_COMMENTS_ALL,
  COMMENT_SAVE_SUCCESS,
  PENDING_FETCH_COMMENTS,
  SET_COMMENTS,
  SUCCESS_FETCH_COMMENTS,
  PENDING_DELETE_COMMENT,
  SET_COMMENT_DELETE,
  SUCCESS_DELETE_COMMENT,
  PENDING_FETCH_COMMENT,
  SET_COMMENT,
  SUCCESS_FETCH_COMMENT,
} from "./types";
import _ from "lodash";
import Config from "../../constants/Config";
export function fetchArticleDetails(id_country, lang_index) {
  return (dispatch) => {
    dispatch({ type: PENDING_FETCH_ARTICLE });
    fetch(
      Config.API_URL +
        "includes/encode/index.php/?get=chapitres&id_country=" +
        id_country +
        "&lang_index=" +
        lang_index
    )
      .then((res) => res.json())
      .then((responseJson) => {
        dispatch({ type: SET_ARTICLE_DETAILS, payload: responseJson });
        dispatch({ type: SUCCESS_FETCH_ARTICLE });
        console.log(responseJson);
      })
      .catch((error) => {
        console.log("error", error);
        dispatch({ type: SUCCESS_FETCH_ARTICLE });
      });
  };
}

export function fetchSousChapitre(lang_index, chapitreId) {
  return (dispatch) => {
    dispatch({ type: PENDING_FETCH_SUBCHAPITRE });
    console.log(
      "-----fetchSousChapitre-----",
      Config.API_URL +
        "includes/encode/index.php/?get=sousChapitres&chapitreId=" +
        chapitreId +
        "&lang_index=" +
        lang_index
    );
    fetch(
      Config.API_URL +
        "includes/encode/index.php/?get=sousChapitres&chapitreId=" +
        chapitreId +
        "&lang_index=" +
        lang_index
    )
      .then((res) => res.json())
      .then((responseJson) => {
        dispatch({ type: SET_ARTICLE_SUBCHAPITRE, payload: responseJson });
        dispatch({ type: SUCCESS_FETCH_SUBCHAPITRE });
      })
      .catch((error) => {
        console.log("error", error);
        dispatch({ type: SUCCESS_FETCH_SUBCHAPITRE });
      });
  };
}

export function fetchGalleries(chapitreId) {
  return (dispatch) => {
    dispatch({ type: PENDING_FETCH_GALLERIES });
    fetch(
      Config.API_URL +
        "includes/encode/index.php/?get=galleries&chapitreId=" +
        chapitreId
    )
      .then((res) => res.json())
      .then((responseJson) => {
        dispatch({ type: SET_ARTICLE_GALLERIES, payload: responseJson });
        dispatch({ type: SUCCESS_FETCH_GALLERIES });
      })
      .catch((error) => {
        console.log("error", error);
        dispatch({ type: SUCCESS_FETCH_GALLERIES });
      });
  };
}

export function searchChapitre(keyword) {
  return (dispatch, getState) => {
    const { chapitres } = getState();
    dispatch({ type: PENDING_SEARCH_ARTICLE });
    dispatch({ type: SEARCH_ARTICLE, keyword: keyword.trim().toLowerCase() });
  };
}

export function searchChapitreAll(id_country, lang_index, keyword) {
  return (dispatch) => {
    if (keyword) keyword = keyword.trim();

    dispatch({ type: PENDING_FETCH_All });
    fetch(
      Config.API_URL +
        "includes/encode/index.php/?get=searchAll&search=" +
        keyword +
        "&id_country=" +
        id_country +
        "&lang_index=" +
        lang_index
    )
      .then((res) => res.json())
      .then((responseJson) => {
        dispatch({ type: SET_ARTICLE_All, payload: responseJson });
        dispatch({ type: SUCCESS_FETCH_ALL });
      })
      .catch((error) => {
        console.log("error", error);
        dispatch({ type: SUCCESS_FETCH_ALL });
      });
  };
}

export function saveInfo(id, name, email, img, type_login) {
  return (dispatch) => {
    console.log("save Info => ", id, name, email, img, type_login);
    dispatch({ type: PENDING_LOGIN_FB });
    fetch(Config.API_URL + "includes/encode/index.php", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        post: "saveLogin",
        id: id,
        name: name,
        email: email,
        img: img,
        type_login: type_login,
      }),
    })
      .then((res) => res.json())
      .then((responseJson) => {
        dispatch({ type: SET_LOGIN_FB, payload: responseJson });
        dispatch({ type: SUCCESS_LOGIN_FB });
        console.log("mzyna hadi", responseJson);
      })
      .catch((error) => {
        console.log("error save Login ", error);
        dispatch({ type: SUCCESS_LOGIN_FB });
      });
  };
}

export function postFile(file, nameFile) {
  return (dispatch) => {
    // console.log("Save BASE64 File=> ", nameFile, file);
    dispatch({ type: PENDING_FETCH_FILE });
    fetch(Config.API_URL + "includes/encode/index.php", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        post: "baseFile",
        data: file,
        nameFile: nameFile,
      }),
    })
      .then((res) => res.json())
      .then((responseJson) => {
        dispatch({ type: SET_FILE, payload: responseJson });
        dispatch({ type: SUCCESS_FETCH_FILE });
        console.log("mzyna hadi", responseJson);
      })
      .catch((error) => {
        console.log("error save File ", error);
        dispatch({ type: SUCCESS_FETCH_FILE });
      });
  };
}

export function saveComment(
  user_id,
  comment,
  chapitre_id,
  comment_id,
  dataImage
) {
  return (dispatch) => {
    console.log("save comment => ", user_id, comment, chapitre_id);
    dispatch({ type: PENDING_SAVE_COMMENT });
    fetch(
      Config.API_URL +
        "includes/encode/index.php/?get=saveComment&user_id=" +
        user_id +
        "&comment=" +
        comment +
        "&chapitreId=" +
        chapitre_id +
        "&comment_id=" +
        comment_id +
        "&dataImage=" +
        dataImage
    )
      .then((res) => res.json())
      .then((responseJson) => {
        dispatch({ type: SET_COMMENTS_ALL, payload: responseJson });
        dispatch({ type: COMMENT_SAVE_SUCCESS });
        console.log("mzyna hadi", responseJson);
      })
      .catch((error) => {
        console.log("error save Login ", error);
        dispatch({ type: COMMENT_SAVE_SUCCESS });
      });
  };
}

export function fetchComment(chapitre_id) {
  return (dispatch) => {
    dispatch({ type: PENDING_FETCH_COMMENTS });
    fetch(
      Config.API_URL +
        "includes/encode/index.php/?get=fetchComments&chapitreId=" +
        chapitre_id
    )
      .then((res) => res.json())
      .then((responseJson) => {
        dispatch({ type: SET_COMMENTS, payload: responseJson });
        dispatch({ type: SUCCESS_FETCH_COMMENTS });
        console.log("responseJson___", responseJson);
      })
      .catch((error) => {
        console.log("error", error);
        dispatch({ type: SET_COMMENTS });
      });
  };
}

export function deleteComment(user_id, comment_id) {
  return (dispatch) => {
    dispatch({ type: PENDING_DELETE_COMMENT });
    fetch(
      Config.API_URL +
        "includes/encode/index.php/?get=deleteComment&user_id=" +
        user_id +
        "&comment_id=" +
        comment_id
    )
      .then((res) => res.json())
      .then((responseJson) => {
        dispatch({ type: SET_COMMENT_DELETE, payload: responseJson });
        dispatch({ type: SUCCESS_DELETE_COMMENT });
        console.log("DeleteComment", responseJson);
      })
      .catch((error) => {
        console.log("error", error);
        dispatch({ type: SUCCESS_DELETE_COMMENT });
      });
  };
}

export function getComment(user_id, comment_id) {
  return (dispatch) => {
    dispatch({ type: PENDING_FETCH_COMMENT });
    fetch(
      Config.API_URL +
        "IFES2/api/includes/encode/index.php/?get=getComment&user_id=" +
        user_id +
        "&comment_id=" +
        comment_id
    )
      .then((res) => res.json())
      .then((responseJson) => {
        dispatch({ type: SET_COMMENT, payload: responseJson });
        dispatch({ type: SUCCESS_FETCH_COMMENT });
        console.log(responseJson);
      })
      .catch((error) => {
        console.log("error", error);
        dispatch({ type: SET_COMMENT });
      });
  };
}
