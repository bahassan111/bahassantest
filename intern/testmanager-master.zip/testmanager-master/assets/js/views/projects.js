// projects
(function () {
    var view = $('#projects_view');
    if(!view.length) return;


    view
        .on('click', '.create_project', function () {
            ajaxModal('projects/create', 'Create Project', 'Please provide all the required informations', 'fa fa-globe', {
                close_text : 'Cancel',
                confirm_text : 'Save',
                whenLoaded : function(modal, data){

                },
                whenConfirm : function(modal, data){
                    modal.find('input, textarea, button').prop('disabled', true);

                    $.post(site_url + 'projects/save', {
                        name : modal.find('#name').val(),
                        url : modal.find('#url').val(),
                        desc : modal.find('#desc').val(),
                        tags : modal.find('#tags').val(),
                    }, function (rep) {

                        if(rep.status === 'OK'){
                            toastr_('Project added successfully', 'success', 'success');
                            $('[data-lprojects].active').trigger('click');
                            getStats();
                            modal.modal('hide');
                        }else{
                            toastr_('Error', 'error', 'danger', 9000);
                        }

                    })
                        .always(function () {
                            modal.find('input, textarea, button').prop('disabled', false);
                        })
                        .fail(function () {
                            toastr_('Error', 'error', 'danger', 9000);
                        })
                },
                whenError : function(modal, error){},
                whenClosed : function(modal){},

            });
        })
        .on('click', '[data-editproject]', function () {
            var id = this.dataset.editproject;

            ajaxModal('projects/edit/' + id, 'Edit Project', 'Please provide all the required informations', 'fa fa-globe', {
                close_text : 'Cancel',
                confirm_text : 'Update',
                whenLoaded : function(modal, data){
                    jscolor.installByClassName('jscolor');
                },
                whenConfirm : function(modal, data){
                    modal.find('input, textarea, button').prop('disabled', true);

                    $.post(site_url + 'projects/save/' + id, {
                        name : modal.find('#name').val(),
                        url : modal.find('#url').val(),
                        desc : modal.find('#desc').val(),
                        tags : modal.find('#tags').val(),
                        color : '#' + modal.find('#color').val(),

                    }, function (rep) {

                        if(rep.status === 'OK'){
                            toastr_('Project Updated successfully', 'success', 'success');
                            $('[data-lprojects].active').trigger('click');
                            getStats();
                            modal.modal('hide');
                        }else{
                            toastr_('Error', 'error', 'danger', 9000);
                        }

                    })
                        .always(function () {
                            modal.find('input, textarea, button').prop('disabled', false);
                        })
                        .fail(function () {
                            toastr_('Error', 'error', 'danger', 9000);
                        })
                },
                whenError : function(modal, error){},
                whenClosed : function(modal){},

            });
        })
        .on('click', '[data-deleteproject]', function () {
            var id = this.dataset.deleteproject;

            ask('Are you sure ?!', 'Do you really want to delete this project', function (yes) {

                if(yes){

                    post('projects/delete_project/' + id, {}, function (rep) {
                        if(rep.status === 'OK'){
                            toastr_('Project was deleted successfully', 'success', 'success');
                        }else{
                            toastr_('Unable to remove the selected project :(', 'error', 'danger');
                        }
                        $('[data-lprojects].active').trigger('click');
                        getStats();

                    })

                }

            }, 'Yes', 'No');
        })
        .on('click', '[data-lprojects]', function () {
            getProjects(this.dataset.lprojects, this);
        })



        .ready(function () {

            getProjects();
            getStats();



        });


    function getProjects(type, item){
        var holder = $('#projects_holder'),
            page = $(item).data('page') || null,
            btn = $('.prj_lm button')
        ;

        type = type || 'active';
        var p = page || 1;

        if(page === null) {
            holder.addClass('loading');
            btn.data('page', 2).attr('data-lprojects', type);
        }else{
            btn.data('page', page+1).prop('disabled', true).html('loading ..');
        }


        post('projects/get_list/' + type + '/' + p, {}, function (rep) {
            var data = rep.data ? rep.data : [],
                rest = rep.rest ? rep.rest : 0
            ;
            $('.prj_lm')[rest ? 'show' : 'hide']();

            if(page === null){
                holder.html('');
            }


            $.each(data, function (i, project) {

                var item = $(`<div class="col-sm-4 col-md-3 col-lg-4 col-xl-3 mb-4">
                        <div class="project_card">
                            <div class="dropdown">
                              <a href="javascript:void(0);" class="" id="dropdownMenuButton${project.id}" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right " aria-labelledby="dropdownMenuButton${project.id}">
                              <a class="dropdown-item" href="${project.url}">View</a>
                                ${project.edit ? '<a data-editproject="'+project.id+'" class="dropdown-item" href="#">Edit</a>' : ''}
                                ${project.delete ? '<a data-deleteproject="'+project.id+'" class="dropdown-item" href="#">Delete</a>' : ''}
                              </div>
                            </div>
                            <div style="background: linear-gradient(280deg, ${shadeColor(project.color, 0)}, ${shadeColor(project.color, 10)})" class="project_card_bg"></div>
                            <div class="pcard_body">
                                <div>
                                    <a href="${project.url}">
                                        <div class="pcard_avatar"><span class="rounded-circle" style="background-color: ${project.color}">${project.code}</span></div>
                                    </a>
                                    <h5><a title="${project.name}" href="${project.url}">${project.name}</a></h5>
                                    <p>${project.description}</p>
                                    <a href="${project.url}" class="btn btn-sm btn-block btn-outline-dark">View</a>
                                </div>
                            </div>
                        </div>
                    
                    </div>`);

                holder.append(item);

            });


            if(data.length === 0 && page === null){
                holder.html('<div class="col-12 nodata">No projects found, try to <a class="create_project" href="javascript:void(0);">create</a> a project</div>')
            }



        }, function () {
            if(page === null) {
                holder.removeClass('loading');
            }else{
                btn.prop('disabled', false).html('Load more');
            }
        })
    }

    function getStats() {
        var tags_holder = $('#tags_list');


        post('projects/get_stats/', {}, function (rep) {
            var stats = rep || {};
            tags_holder.html('');

            log(stats);
            $.each(stats.tags, function (i, tag) {
                tags_holder.append(`<a href="javascript:void(0);" data-ltag="${tag.tag}" class="nav-link"><span>${tag.tag}</span> <span class="badge">${tag.value}</span></a>`);
            });
            $('[ data-pcount="active"]').html(stats.active);
            $('[ data-pcount="closed"]').html(stats.closed);
            $('[ data-pcount="others"]').html(stats.others);
        })
    }

})();