import React, { Component, useState, useEffect, useRef  } from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    ImageBackground,
    ActivityIndicator,
    Button, Dimensions,
    TouchableOpacity,
    Animated, AppState, SafeAreaView,ScrollView,
    BackHandler,Alert, Platform
} from "react-native";

import HTMLView from 'react-native-htmlview';
import YoutubePlayer from "react-native-youtube-iframe";
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {updateData} from "../redux/actions/dataAction";
import TopHeader from "../componants/TopHeader";
import css, {colors, sizes} from "../global/GlobalStyle";
import Carousel from 'react-native-snap-carousel';
import GestureRecognizer from 'react-native-swipe-gestures';
import Loader from "./_loader";
import {AntDesign, FontAwesome5, FontAwesome, MaterialIcons} from '@expo/vector-icons';
import news from "../data/newsDemo";


const win = Dimensions.get('window');
const ofHeight = (p)=> p * win.height / 100;
const ofWidth = (p)=> p * win.width / 100;


class cardsScreen extends Component {

    state = {
        appState: AppState.currentState,
        isModalVisible : false,
        animation: new Animated.Value(0),
        sport : news.sport.reverse(),
        buzz : news.buzz.reverse(),
        videos : news.videos,
    };


    componentDidMount() {

    }

    logoPressed = ()=>{

    };
    menuPressed = ()=>{
        const {navigation} = this.props;

        navigation.toggleDrawer();
    };

    viewItem = (item, isVideo)=>{
        const {navigation} = this.props;

        navigation.navigate('display', {item, isVideo});
    };

    viewCategory = (items, title)=>{
        const {navigation} = this.props;

        navigation.navigate('category', {items: items, name : title});
    };

    _renderItem = (data, isVideo) => {
        let image = {uri:data.item.image};
        return (

            <View style={[styles.ci]}>
                <ImageBackground resizeMode={'cover'} style={[styles.ci_bg]} source={image}>

                    <TouchableOpacity onPress={()=>{this.viewItem(data.item, isVideo)}} style={[styles.ci_inner]}>
                        {
                            (!isVideo) ? (null) : (
                                <View style={[styles.ci_play]}>
                                    <FontAwesome5 style={[styles.ci_play_icon]} name="play" size={24} />
                                </View>
                            )
                        }
                        <View style={[styles.ci_inner_h]}>
                            <View style={[styles.ci_title_holder]}>
                                <Text style={[styles.ci_title]}>{data.item.title}</Text>
                            </View>
                            <View style={[styles.ci_foot]}>
                                <Text style={[styles.ci_foot_txt]}>{data.item.date}</Text>
                            </View>
                        </View>
                    </TouchableOpacity>


                </ImageBackground>
            </View>


        );

    };
    _renderVideo = (data) => {
        return this._renderItem(data, true);
    };


    render() {

        return (

            <View style={[css.background, {height:'100%', position:'relative',}]}>
                <TopHeader transparent={false} semi_transparent={false} floatable={false} title={"Démo 2 de l'écran de d'accueil"} onMenu={this.menuPressed} onUser={this.logoPressed}/>

                <SafeAreaView style={[styles.scrollholder]}>
                    <ScrollView style={[styles.sections]}>

                        <SafeAreaView>
                            {/*Videos*/}
                            <View style={[styles.section]}>

                                <TouchableOpacity onPress={()=>{this.viewCategory(this.state.videos, 'Vidéos')}} style={[styles.section_head]}>
                                    <View style={[styles.section_ind, {backgroundColor: colors.primary1}]}/>
                                    <MaterialIcons style={[css.section_icon]} color={'#fff'} name="ondemand-video" size={24} />
                                    <Text style={[styles.section_title]}>Vidéos</Text>
                                    <View style={[styles.section_action]}>
                                        <Text style={[styles.section_atext]}>Explorer</Text>
                                        <FontAwesome style={[styles.section_aicon]} name="angle-right" size={24} color="#fff" />
                                    </View>
                                </TouchableOpacity>


                                <Carousel
                                    activeAnimationOptions={null}
                                    onPress={this.onPress}
                                    layout={'stack'} layoutCardOffset={18}
                                    ref={(c) => { this._carousel = c; }}
                                    data={this.state.videos}
                                    renderItem={this._renderVideo}
                                    sliderWidth={ofWidth(100)}
                                    itemWidth={ofWidth(90)}
                                    firstItem={Platform.OS !== 'ios' ? (this.state.videos.length - 1) : 0}
                                    style={{overflow:'visible', paddingHorizontal: 22}}
                                />



                            </View>

                            {/*Buzz*/}
                            <View style={[styles.section]}>

                                <TouchableOpacity onPress={()=>{this.viewCategory(this.state.buzz, 'Buzz')}} style={[styles.section_head]}>
                                    <View style={[styles.section_ind, {backgroundColor: colors.primary2}]}/>
                                    <MaterialIcons style={[css.section_icon]} color={'#fff'} name="whatshot" size={24} />
                                    <Text style={[styles.section_title]}>Buzz</Text>
                                    <View style={[styles.section_action]}>
                                        <Text style={[styles.section_atext]}>Explorer</Text>
                                        <FontAwesome style={[styles.section_aicon]} name="angle-right" size={24} color="#fff" />
                                    </View>
                                </TouchableOpacity>


                                <Carousel
                                    activeAnimationOptions={null}
                                    onPress={this.onPress}
                                    layout={'stack'} layoutCardOffset={18}
                                    ref={(c) => { this._carousel = c; }}
                                    data={this.state.buzz}
                                    renderItem={this._renderItem}
                                    sliderWidth={ofWidth(100)}
                                    itemWidth={ofWidth(90)}
                                    firstItem={Platform.OS !== 'ios' ? (this.state.buzz.length - 1) : 0}
                                    style={{overflow:'visible', paddingHorizontal: 22}}
                                />


                            </View>

                            {/*Sport*/}
                            <View style={[styles.section]}>

                                <TouchableOpacity  onPress={()=>{this.viewCategory(this.state.sport, 'Sport')}} style={[styles.section_head]}>
                                    <View style={[styles.section_ind, {backgroundColor: colors.primary3}]}/>
                                    <FontAwesome style={[css.section_icon]} color={'#fff'} name="soccer-ball-o" size={24} />
                                    <Text style={[styles.section_title]}>Sport</Text>
                                    <View style={[styles.section_action]}>
                                        <Text style={[styles.section_atext]}>Explorer</Text>
                                        <FontAwesome style={[styles.section_aicon]} name="angle-right" size={24} color="#fff" />
                                    </View>
                                </TouchableOpacity>


                                <Carousel
                                    activeAnimationOptions={null}
                                    onPress={this.onPress}
                                    layout={'stack'} layoutCardOffset={18}
                                    ref={(c) => { this._carousel = c; }}
                                    data={this.state.sport}
                                    renderItem={this._renderItem}
                                    sliderWidth={ofWidth(100)}
                                    itemWidth={ofWidth(90)}
                                    firstItem={Platform.OS !== 'ios' ? (this.state.sport.length - 1) : 0}
                                    style={{overflow:'visible', paddingHorizontal: 22}}
                                />


                            </View>

                            <View style={[styles.section, {marginBottom: 80}]}>

                                <TouchableOpacity  onPress={()=>{this.viewCategory(this.state.buzz, 'TV')}} style={[styles.section_head]}>
                                    <View style={[styles.section_ind, {backgroundColor: colors.primary2}]}/>
                                    <MaterialIcons style={[css.section_icon]} color={'#fff'} name="whatshot" size={24} />
                                    <Text style={[styles.section_title]}>TV</Text>
                                    <View style={[styles.section_action]}>
                                        <Text style={[styles.section_atext]}>Explorer</Text>
                                        <FontAwesome style={[styles.section_aicon]} name="angle-right" size={24} color="#fff" />
                                    </View>
                                </TouchableOpacity>


                                <Carousel
                                    activeAnimationOptions={null}
                                    onPress={this.onPress}
                                    layout={'stack'} layoutCardOffset={18}
                                    ref={(c) => { this._carousel = c; }}
                                    data={this.state.buzz}
                                    renderItem={this._renderItem}
                                    sliderWidth={ofWidth(100)}
                                    itemWidth={ofWidth(90)}
                                    firstItem={Platform.OS !== 'ios' ? (this.state.buzz.length - 1) : 0}
                                    style={{overflow:'visible', paddingHorizontal: 22}}
                                />


                            </View>
                        </SafeAreaView>

                    </ScrollView>
                </SafeAreaView>






            </View>

        );
    }

}

const styles = StyleSheet.create({
    sections : {
        flex:1,
    },
    section : {
        marginTop: 22,
        padding: 12,
    },
    section_head : {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 12,
    },
    section_title : {
        flex:1,
        color : "#fff",
        fontSize: sizes.lg,
        paddingHorizontal: 12,
    },
    section_action : {
        flexDirection: 'row',
        alignItems: 'center',
    },
    section_atext : {
        color:colors.front,
        padding: 4,
    },
    section_aicon : {},
    section_ind : {
        height: 4,
        width: 4,
        borderRadius: 2,
        marginRight: 12,
    },
    section_icon : {
        color:'#fff',
    },

    ci : {
        borderRadius: 6,
        //overflow:'hidden',
        elevation: 16,
        height: (ofWidth(90) / 1.61803398875),
        position:'relative',
        //maxWidth: 400,
        margin: 12,
    },
    ci_bg : {
        height:'100%',
        width:'100%',
    },
    ci_inner : {
        width:'100%',
        height:'100%',
        justifyContent: 'flex-end',
    },
    ci_inner_h : {
        backgroundColor: 'rgba(0,0,0,0.68)',
        paddingHorizontal: 12,
        paddingVertical: 8,
    },
    ci_title_holder : {},
    ci_title : {
        color: colors.front,
        fontWeight: 'bold',
        fontSize: sizes.md,
    },
    ci_foot : {},
    ci_foot_txt : {
        color: 'rgba(255,255,255,0.69)',
        padding: 12,
    },
    scrollholder : {
        flex:1,
    },
    ci_play: {
        position: 'absolute',
        left:0,
        top:0,
        right:0,
        bottom : 0,
        zIndex: 8,
        alignItems: 'center',
        justifyContent: 'center',
    },
    ci_play_icon: {
        color : '#fff',
        fontSize: 42,
        elevation: 12,
        textShadowColor: '#000',
        textShadowOffset: {width: 2, height: 2},
    },


});

const mapDispatchToProps = dispatch => (
    bindActionCreators({
        updateData: updateData,
    }, dispatch)
);

const mapStateToProps = (state) => {
    const { data } = state;
    return { data }
};

export default connect(mapStateToProps, mapDispatchToProps)(cardsScreen);
