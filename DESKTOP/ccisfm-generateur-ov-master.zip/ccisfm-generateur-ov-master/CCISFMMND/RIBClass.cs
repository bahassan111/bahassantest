﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CCISFMMND
{
    public class RIBClass
    {
        public string Nom;
        public string RIB;
        public string AMT;
        public DateTime generated;

        public RIBClass(string nom, string rib, string hint_amt)
        {
            this.Nom = nom;
            this.RIB = rib;
            this.AMT = hint_amt.Replace(',', '.');
        }
    }
}
