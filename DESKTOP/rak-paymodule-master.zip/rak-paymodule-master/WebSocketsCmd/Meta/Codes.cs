﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace WebSocketsCmd.Meta
{
    public class Codes
    {
        public const string CODE_0000 = "Processus bien exécuté. OK";
        public const string CODE_1058 = "Abandon de l’opération impossible Attendre la réponse du TPE";
        public const string CODE_1066 = "Opération impossible : aucune session disponible. OpenSession";
        public const string CODE_1067 = "Opération impossible : Numéro Session fournie incorrect. Vérifier SessionID";
        public const string CODE_1068 = "Echec d’exécution d’opération. Réessayer";
        public const string CODE_106B = "Opération échouée : Timeout Réessayer, si Payment appeler";
        public const string CODE_1063 = "Echec connexion : Connexion déjà établie. SignOff puis SignOn";
        public const string CODE_1051 = "Echec d’ouverture de session : Aucune connexion ECR-EFT existante. SignOn";
        public const string CODE_1052 = "Echec d’ouverture de session : Attribution de numéro de session";
        public const string CODE_1062 = "Echec d’ouverture de session : Session en cours non fermée. CloseSession puis OpenSession";
        public const string CODE_105B = "Fermeture de session impossible : Existence d’opérations non achevés Attente avant de réessayer";
        public const string CODE_105C = "Fermeture de session impossible : Aucune session disponible Continuer";
        public const string CODE_1069 = "Fermeture de session impossible : Numéro Session fournie incorrect Vérifier SessionID";
        public const string CODE_1053 = "Carte illisible ou invalide Rendre la main à l’hôtesse";
        public const string CODE_1054 = "Code carte erroné Rendre la main à l’hôtesse";
        public const string CODE_1055 = "Transaction impossible : aucune session disponible. OpenSession";
        public const string CODE_1056 = "Opération impossible";
        public const string CODE_1057 = "Transaction de paiement impossible : Données fournies incorrectes (en cas de paiement manuel) Rendre la main à l’hôtesse";
        public const string CODE_106A = "opération impossible : Numéro Session fournie incorrect. Vérifier SessionID";
        public const string CODE_105E = "Forçage de fin de journée réussi Ok";
        public const string CODE_105F = "Forçage de fin de journée échoué Réessayer ManualEndOfDay";
        public const string CODE_1060 = "Forçage de fin de journée impossible Réessayer ManualEndOfDay";
        public const string CODE_1061 = "Télécollecte manuelle échouée ou non permise. Réessayer ManualEndOfDay";
        public const string CODE_1064 = "Télécollecte manuelle échouée : Aucune session disponible OpenSession";
        public const string CODE_1065 = "Télécollecte manuelle échouée : Numéro Session fournie incorrect. Vérifier SessionID";
        public const string CODE_105D = "Déconnexion impossible : Session déjà ouverte CloseSession puis SignOff";
        public const string CODE_1050 = "Echec de connexion ECR-EFT. Vérifier le matériel";
        public const string CODE_106C = "Echec de connexion : Terminal ID erroné. Vérifier TerminalID";
        public const string CODE_1059 = "Transaction à annuler est introuvable Réintroduire le STAN";
        public const string CODE_105A = "Annulation de transaction impossible Réessayer Void, ou donner la main à l’hôtesse";
        //public const string CODE_0000 = "Au moins une recharge est passée avec succès Vérifier le DC3";
        public const string CODE_1070 = "Toutes les recharges sont échouées Rendre la main à l’hôtesse et le DC3 est consultable";
        //public const string CODE_1055 = "Recharge impossible : aucune session disponible. OpenSession";
        //public const string CODE_1056 = "Recharge impossible : Opération refusée par le prestataire Rendre la main à l’hôtesse";
        //public const string CODE_106A = "Recharge impossible : Numéro Session fournie incorrect. Vérifier SessionID ";


        public static RepCode getCode(string code)
        {
            FieldInfo[] fieldInfos = (typeof(Codes)).GetFields(BindingFlags.Public |
                                                                     BindingFlags.Static | BindingFlags.FlattenHierarchy);

            foreach (var field in fieldInfos)
            {

                var val = field.GetValue(new Codes()).ToString();

                if (field.Name == ("CODE_" + code))
                {
                    return new RepCode(code, val);
                }
            }

            return null;
        }
    }

    public class RepCode
    {
        public string code;
        public string message;
        public string todo;

        public RepCode(string code, string message, string todo)
        {
            this.code = code;
            this.message = message;
            this.todo = todo;
        }

        public RepCode(string code, string message)
        {
            this.code = code;
            this.message = message;
     
        }

        override public string ToString()
        {
            return this.code + " : " + this.message;
        }
    }


}
