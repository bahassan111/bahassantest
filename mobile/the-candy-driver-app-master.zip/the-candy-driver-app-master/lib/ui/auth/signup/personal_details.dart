import 'package:driver/constants/constants.dart';
import 'package:driver/constants/helpers/helpers.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:driver/models/models.dart';
import 'package:driver/ui/components/components.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

class PersonalDetails extends StatefulWidget {
  @override
  _PersonalDetailsState createState() => _PersonalDetailsState();
}

class _PersonalDetailsState extends State<PersonalDetails> {
  final AuthController authController = AuthController.to;

  @override
  void initState() {
    super.initState();
    if (authController.userModel != null) {
      authController.fnameController.text = authController.userModel.firstname;
      authController.lnameController.text = authController.userModel.lastname;
      authController.stateController.text = authController.userModel.state;
      authController.postCodeController.text =
          authController.userModel.postcode;
      authController.addressController.text = authController.userModel.address;
      authController.emailController.text = authController.userModel.email;
      authController.personalMobileNumberController.text =
          authController.userModel.mobile;
      authController.drivingLicenseExp =
          stringToDate(authController.userModel.drivinglicense);
      authController.vocationalLicenseExp =
          stringToDate(authController.userModel.vcexpiry);

      authController.countries.forEach((element) {
        if (element.id == authController.userModel.country) {
          authController.selectedCountry = element;
          authController.getCurrency(int.tryParse(element.id)).then((value) {
            setState(() {});
          });
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 15),
      child: Column(
        children: [
          SizedBox(
            height: 20,
          ),
          Text(
            "personal_details".tr,
            style: Theme.of(context).textTheme.headline2.copyWith(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Expanded(
                child: FormInputField(
                  labelText: "first_name".tr,
                  controller: authController.fnameController,
                ),
              ),
              SizedBox(
                width: 20,
              ),
              Expanded(
                child: FormInputField(
                    labelText: "last_name".tr,
                    controller: authController.lnameController),
              )
            ],
          ),
          SizedBox(
            height: 15,
          ),
          Row(
            children: [
              Expanded(
                child: countyDropDown(),
              ),
              SizedBox(
                width: 20,
              ),
              Expanded(
                  child: Container(
                decoration: BoxDecoration(
                  border: Border(
                    bottom: BorderSide(color: Colors.grey, width: 2.0),
                  ),
                ),
                child: Text(
                  authController.currency != null
                      ? authController.currency
                      : "currency".tr,
                  style: Theme.of(context).textTheme.headline2.copyWith(
                        fontSize: 16,
                      ),
                ),
              )),
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Expanded(
                child: FormInputField(
                    labelText: "state".tr,
                    controller: authController.stateController),
              ),
              SizedBox(
                width: 20,
              ),
              Expanded(
                child: FormInputField(
                    labelText: "post_code".tr,
                    controller: authController.postCodeController),
              )
            ],
          ),
          SizedBox(
            height: 10,
          ),
          FormInputField(
              labelText: "address".tr,
              controller: authController.addressController),
          SizedBox(
            height: 10,
          ),
          FormInputField(
              labelText: "e_mail".tr,
              controller: authController.emailController),
          SizedBox(
            height: 10,
          ),
          FormInputField(
              labelText: "mobile_number".tr,
              controller: authController.personalMobileNumberController),
          SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Expanded(
                child: CustomImageSelector(
                  label: "driving_license".tr + " *",
                  onImageSelect: (PickedFile image) {
                    authController.drivingLicenseImg = image;
                  },
                  image: authController.userModel?.licensephoto,
                ),
              ),
              SizedBox(
                width: 20,
              ),
              Expanded(
                child: CustomPicker(
                  selectedDate: authController.drivingLicenseExp,
                  label: "exp_driving_license".tr + " *",
                  onDateSelect: (DateTime selectedDate) {
                    authController.drivingLicenseExp = selectedDate;
                  },
                  isClickAble: authController.userModel == null,
                ),
              )
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Expanded(
                  child: CustomImageSelector(
                label: "vocational_license".tr + " *",
                onImageSelect: (PickedFile image) {
                  authController.vocationalLicenseImg = image;
                },
                image: authController.userModel?.vocationallicense,
              )),
              SizedBox(
                width: 20,
              ),
              Expanded(
                  child: CustomPicker(
                isClickAble: authController.userModel == null,
                selectedDate: authController.vocationalLicenseExp,
                label: "exp_vocational_license".tr + " *",
                onDateSelect: (DateTime selectedDate) {
                  authController.vocationalLicenseExp = selectedDate;
                },
              ))
            ],
          ),
        ],
      ),
    );
  }

  countyDropDown() {
    return Container(
      height: 40.0,
      padding: EdgeInsets.symmetric(horizontal: 15),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(40),
        border: Border.all(
          color: AppThemes.lightInputBorderColor,
        ),
      ),
      child: DropdownButton<CountryModel>(
        value: authController.selectedCountry,
        hint: Text(
          "country".tr,
          style: Theme.of(context).textTheme.headline2.copyWith(
                fontSize: 15,
              ),
        ),
        icon: Icon(
          Icons.keyboard_arrow_down,
          color: AppThemes.lightdeepPinkDropDownIconColor,
          size: 30,
        ),
        iconSize: 24,
        elevation: 16,
        style: Theme.of(context).textTheme.headline2.copyWith(
              fontSize: 15,
            ),
        isExpanded: true,
        underline: SizedBox.shrink(),
        onChanged: (newValue) async {
          setState(() {
            authController.selectedCountry = newValue;
          });
          await authController.getCurrency(int.tryParse(newValue.id));
          setState(() {});
        },
        items: authController.countries
            .map<DropdownMenuItem<CountryModel>>((country) {
          return DropdownMenuItem(
            value: country,
            child: Text(country.countryName, overflow: TextOverflow.ellipsis),
          );
        }).toList(),
      ),
    );
  }
}
