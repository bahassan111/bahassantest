package ma.rak.ovr.models;

import io.realm.RealmObject;

public class Nature extends RealmObject {
    private int ID;
    private String label;
    private String codegera;
    private String CODCATAB;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Nature() {
    }

    public Nature(int ID, String label, String codegera, String codcatab) {
        this.ID = ID;
        this.label = label;
        this.codegera = codegera;
        CODCATAB = codcatab;
    }

    @Override
    public String toString() {
        return "Nature{" +
                "ID=" + ID +
                ", label='" + label + '\'' +
                ", codegera='" + codegera + '\'' +
                ", CODCATAB='" + CODCATAB + '\'' +
                '}';
    }

    public String getCodegera() {
        return codegera;
    }

    public void setCodegera(String codegera) {
        this.codegera = codegera;
    }

    public String getCODCATAB() {
        return CODCATAB;
    }

    public void setCODCATAB(String CODCATAB) {
        this.CODCATAB = CODCATAB;
    }
}

