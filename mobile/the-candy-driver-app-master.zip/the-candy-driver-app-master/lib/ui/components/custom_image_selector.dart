import 'dart:io';

import 'package:driver/constants/constants.dart';
import 'package:driver/constants/helpers/helpers.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class CustomImageSelector extends StatefulWidget {
  final String label;
  final Function onImageSelect;
  final String image;
  CustomImageSelector({Key key, this.label, this.onImageSelect, this.image})
      : super(key: key);

  @override
  _CustomImageSelectorState createState() => _CustomImageSelectorState();
}

class _CustomImageSelectorState extends State<CustomImageSelector> {
  PickedFile file;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        if (widget.image == null) {
          PickedFile image = await imgFromGallery(context);
          if (image != null) {
            setState(() {
              file = image;
              widget.onImageSelect(image);
            });
          }
        }
      },
      child: file != null || widget.image != null
          ? Container(
              height: 100,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: file != null
                      ? FileImage(
                          File(file.path),
                        )
                      : NetworkImage(widget.image),
                ),
              ),
            )
          : Container(
              height: 40.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(40),
                border: Border.all(
                  color: AppThemes.lightInputBorderColor,
                ),
              ),
              child: Row(
                children: [
                  SizedBox(
                    width: 10,
                  ),
                  Text(
                    widget.label,
                    style: Theme.of(context).textTheme.headline2.copyWith(
                          fontSize: 11,
                        ),
                    overflow: TextOverflow.clip,
                  ),
                  Spacer(),
                  Image.asset(
                    AllImages.imagePickerIcon,
                    height: 20,
                    width: 10,
                    fit: BoxFit.cover,
                  ),
                  SizedBox(
                    width: 10,
                  )
                ],
              ),
            ),
    );
  }
}
