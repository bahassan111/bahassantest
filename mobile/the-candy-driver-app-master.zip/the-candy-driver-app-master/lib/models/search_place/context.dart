class Context {
  String id;
  String wikidata;
  String shortCode;
  String text;

  Context({this.id, this.wikidata, this.shortCode, this.text});

  Context.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    wikidata = json['wikidata'];
    shortCode = json['short_code'];
    text = json['text'];
  }
}
