import { StatusBar } from 'expo-status-bar';
import React, {useState, useRef, useEffect} from 'react';
import { StyleSheet, Text, View, Linking } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { Provider } from 'react-redux';
import { createStore } from 'redux';
import dataReducer from './redux/reducers/dataReducer';
import * as Localization from 'expo-localization';
import fr from "./languages/fr";
import i18n from 'i18n-js';
import StackNav from "./nav/StackNav";
import DrawerNav from "./nav/DrawerNav";
import en from "./languages/en";
import ar from "./languages/ar";
import Constants from 'expo-constants';
import * as Notifications from 'expo-notifications';


i18n.translations = {
    fr: fr,
    en: en,
    ar: ar,
};
// Set the locale once at the beginning of your app.
i18n.locale = "fr";




export default function App() {

    const store = createStore(dataReducer);
    console.log('started old');


    return (
        <Provider store={store}>
            <NavigationContainer>
                {StackNav()}
            </NavigationContainer>
        </Provider>

    );


}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
