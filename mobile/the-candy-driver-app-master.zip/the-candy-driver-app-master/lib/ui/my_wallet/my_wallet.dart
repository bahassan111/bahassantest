import 'package:driver/constants/constants.dart';
import 'package:driver/constants/helpers/helpers.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'my_wallet_item.dart';

class MyWallet extends StatefulWidget {
  MyWallet({Key key}) : super(key: key);

  @override
  _MyWalletState createState() => _MyWalletState();
}

class _MyWalletState extends State<MyWallet> {
  double height, width;

  final HistoryController to = HistoryController();
  static AuthController authTo = Get.find();

  bool isLoading = true;
  @override
  void initState() {
    super.initState();
    to.getDriverEwallet().then((value) {
      setState(() {
        isLoading = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: AppThemes.lightdeepPinkDropDownIconColor,
      body: SafeArea(
        child: Container(
          color: AppThemes.lightAthensGrayBorderColor,
          child: Column(
            children: [
              appbar(context),
              SizedBox(
                height: 30,
              ),
              isLoading
                  ? Expanded(
                      child: Center(
                        child: CircularProgressIndicator(),
                      ),
                    )
                  : Expanded(
                      child: ListView.builder(
                        itemCount: to.driverEwalletDetails.length,
                        itemBuilder: (context, index) {
                          return MyWalletItem(
                            driverEwalletModel: to.driverEwalletDetails[index],
                          );
                        },
                      ),
                    )
            ],
          ),
        ),
      ),
    );
  }

  appbar(context) => Container(
        color: AppThemes.lightdeepPinkDropDownIconColor,
        child: Column(
          children: [
            Container(
              width: width,
              margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
              color: AppThemes.lightdeepPinkDropDownIconColor,
              child: Stack(
                children: [
                  Center(
                      child: Text(
                    "my_wallet".tr,
                    style: Theme.of(context).textTheme.headline1.copyWith(
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                        ),
                  )),
                  GestureDetector(
                    onTap: () => Get.back(),
                    child: Image.asset(
                      AllImages.backIcon,
                      height: 20,
                      width: 20,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
            ),
            Divider(
              color: AppThemes.lightDividerColor,
              thickness: 1,
            ),
            Container(
              padding: EdgeInsets.symmetric(vertical: 40),
              child: Column(
                children: [
                  Text(
                    to?.totalwalletsum != null
                        ? "${authTo?.userModel?.currency ?? ""} ${numberFormating?.format(to?.totalwalletsum ?? 0) ?? 0}"
                        : "None",
                    style: Theme.of(context).textTheme.headline1.copyWith(
                        fontSize: 30,
                        fontWeight: FontWeight.w700,
                        fontFamily: "NunitoSans"),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    "total_earning".tr.toUpperCase(),
                    style: Theme.of(context).textTheme.headline1.copyWith(
                          fontSize: 14,
                          fontFamily: "NunitoSans",
                          fontWeight: FontWeight.w600,
                        ),
                  )
                ],
              ),
            )
          ],
        ),
      );
}
