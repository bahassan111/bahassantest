<?php
define('BASE', __DIR__.'/');

require_once "includes/helper.php";
require_once "includes/Session.php";
require_once "includes/Database.php";


$page       = __($_GET)->page;

if(isset($_GET['404'])){
    include "404.html";
    die;
}

if($page){
    require_once "includes/Controller.php";

    $controller = new Controller();
    $current_country = current_country();

    if(method_exists($controller, $page)){
        $controller->{$page}();
    }else{
        include "404.html";
    }

}else{
    Header("Location: ?page=home");
}




