<?php
$language = [

    'loading' => 'Loading',
    'home' => 'Home Page',
    'chapters' => 'Chapters',
    'chapter' => 'Chapter',
    'about' => 'About us',
    'mobile_app' => 'Mobile APP',
    'android' => 'Android',
    'iphone' => 'iPhone',
    'search_chapters' => 'Search in chapters',
    'insert_keyword' => 'Type a keyword',
    'or' => 'OR',
    'explore' => 'Explore',
    'download_app' => "Download now the official mobile app for your mobile device",
    'search' => "Search",
    'read_more' => "Read more",
    'no_result_for' => "No result found for this keyword",
    'use_diffrent_word' => "Try using a diffrent keyword",
    'share_friends' => "Share with your friends",
    'more_chapter' => "More in this Chapter",
    'who' => "About us",
    '' => "",



];