import React from "react";
import PropTypes from "prop-types";
import { createIconSetFromFontello } from "@expo/vector-icons";

import fontelloConfig from "../assets/fontello/config.json";
import Colors from "../constants/Colors";

const FriIcon = createIconSetFromFontello(fontelloConfig, "FriIcon");

const Icon = ({
  rendered = true,
  name,
  color = Colors.gray,
  iconSize = 20,
  style,
  ...props
}) =>
  !rendered ? null : (
    <FriIcon
      name={name}
      {...props}
      color={color}
      style={[{ fontSize: iconSize }, style]}
    />
  );
Icon.propTypes = {
  rendered: PropTypes.bool,
  name: PropTypes.string,
  iconSize: PropTypes.number,
  color: PropTypes.string,
  style: PropTypes.any
};
export default Icon;
