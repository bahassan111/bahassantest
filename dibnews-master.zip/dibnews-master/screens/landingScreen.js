import React, { Component } from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    ImageBackground,
    ActivityIndicator, Dimensions,
    TouchableOpacity
} from "react-native";
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {updateData} from "../redux/actions/dataAction";
import TopHeader from "../componants/TopHeader";
import css from "../global/GlobalStyle";
import Carousel from "react-native-snap-carousel";

const win = Dimensions.get('screen');
const ofHeight = (p)=> p * win.height / 100;
const ofWidth = (p)=> p * win.width / 100;


class landingScreen extends Component {

    state = {
        news : [
            {
                title : "Volée de mouettes survolant la mer au port d’Essaouira “Mogador”",
                image : 'https://lp-cms-production.imgix.net/2019-06/56e4a8e265a1f7a3a246b85bcf88d672-essaouira.jpg?auto=compress&fit=crop&fm=auto&sharp=10&vib=20&w=1200',
                cat : 'Tourisme',
                date : '11 DÉCEMBRE 2020',
            },
            {
                title : "Lewandowski joueur UEFA de la saison",
                image : 'http://dibnews.twinsgroupe.com/wp-content/uploads/2020/12/lowdofski.jpg',
                cat : 'Sport',
                date : '11 DÉCEMBRE 2020',
            },
            {
                title : "L'UE durement affectée par les mesures restrictives et protectionnistes adoptées par l'Algérie",
                image : 'http://dibnews.twinsgroupe.com/wp-content/uploads/2020/12/ue-algerie.jpg',
                cat : 'INTERNATIONAL',
                date : '11 DÉCEMBRE 2020',
            },
        ],
    };


    componentDidMount() {
    }

    menuClick = () => {
        const {navigation} = this.props;

    };

    logoPressed = () => {
        const {navigation} = this.props;

    };



    _renderItem(data){
        let image = {uri:data.item.image};

        return (

            <View style={[css.news_item]}>
                <ImageBackground style={[css.ni_bg]} source={image}>

                    <TouchableOpacity onPress={()=>{console.log(this.state.news)}}>
                        <View style={[css.ni_inner]}>
                            <View style={[css.ni_tags]}>
                                <Text style={[css.ni_tag]}>{data.item.cat}</Text>
                            </View>
                            <View style={[css.ni_title_holder]}>
                                <Text style={[css.ni_title]}>{data.item.title}</Text>
                            </View>
                            <View style={[css.ni_foot]}>
                                <Text style={[css.ni_foot_txt]}>{data.item.date}</Text>
                            </View>
                        </View>
                    </TouchableOpacity>



                </ImageBackground>
            </View>


        );

    }

    render() {
        return (

            <View style={[css.background]}>
                <TopHeader transparent={true} floatable={true} title={''} onMenu={this.menuClick} onUser={this.logoPressed}/>
                <Carousel
                    activeAnimationOptions={null}
                    layout={'default'} layoutCardOffset={2}
                    ref={(c) => { this._carousel = c; }}
                    data={this.state.news}
                    renderItem={this._renderItem}
                    sliderWidth={ofWidth(100)}
                    itemWidth={ofWidth(100)}
                />

            </View>

        );
    }

}

const styles = StyleSheet.create({
    bg:{
        flex:1,
        resizeMode: "center",
        justifyContent: "center"
    },
    whole: {
        display:'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height:'100%',
        backgroundColor: '#fff',
    },

});

const mapDispatchToProps = dispatch => (
    bindActionCreators({
        updateData: updateData,
    }, dispatch)
);

const mapStateToProps = (state) => {
    const { data } = state;
    return { data }
};

export default connect(mapStateToProps, mapDispatchToProps)(landingScreen);
