import 'package:flutter/material.dart';
import 'package:flutter_dash/flutter_dash.dart';
import 'package:rider_app/constants/constants.dart';
import 'package:get/get.dart';
import 'package:rider_app/controllers/controllers.dart';
import 'package:rider_app/helpers/helpers.dart';
import 'package:rider_app/models/ride.dart';
import 'package:intl/intl.dart';

class HistoryItem extends StatelessWidget {
  final Ride ride;
  static AuthController to = Get.find();
  static HomeController homeTo = Get.find();
  final numberFormating = NumberFormat("##0.00", "en_US");

  HistoryItem({this.ride});
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          margin: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          padding: EdgeInsets.symmetric(horizontal: 15, vertical: 20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border:
                Border.all(color: AppThemes.lightHistoryCardBorder, width: 2),
          ),
          child: Column(
            children: [
              rideStatusDetail(
                context,
                "bookingDate".tr + ' :',
                datedayddMMMyyyyhhMMss(stringToDateTime(ride.bookDate)),
              ), //"Fri, 20 Sep "
              SizedBox(height: 5),
              rideStatusDetail(
                context,
                "bookingId".tr + ' :',
                homeTo.tripId(
                  id: ride.id,
                  bookingType: ride.bookType,
                  type: ride.carcategory,
                ),
              ),
              SizedBox(height: 5),
              rideStatusDetail(context, "driver_name".tr + ' :',
                  "${ride.fname ?? ""} ${ride.lname ?? ""}"),
              Divider(
                color: AppThemes.lightpauaBackGroundColor,
                thickness: 2,
              ),
              rideStatusDetail(context, "rideStatus".tr + ' :',
                  "${rideStatus[int.parse(ride.rideStatus)]}"),
              rideStatusDetail(context, "distance".tr + ' :',
                  "${double.parse(ride.distance).toPrecision(2)} Km"),
              rideStatusDetail(context, "charter time".tr + ' :',
                  "${ride.waitingTime} Hours"),
              SizedBox(height: 10),
              Center(
                child: Text(
                  "fareDetails".tr,
                  style: Theme.of(context).textTheme.headline4.copyWith(
                        fontSize: 14,
                        fontFamily: 'NunitoSans',
                        fontWeight: FontWeight.w900,
                        decoration: TextDecoration.underline,
                      ),
                ),
              ),
              /*rideFareDetail(context, "adminFees".tr,
                  "${numberFormating.format(double.parse(ride.adminfees).toPrecision(2))} ${ride.currency}"),*/
              rideFareDetail(context, "ride_fare".tr,
                  "${ride.currency} ${(double.parse(ride.totalfare)).toPrecision(2)}"),
              rideFareDetail(context, "toll".tr,
                  "${ride.currency} ${numberFormating.parse(ride.tolltaxamount ?? '0').toString()}"),
              totalRideFareDetail(context, "totalPaidAmount".tr,
                  "${ride.currency} ${(double.parse(ride.tolltaxamount ?? '0') + double.parse(ride.totalfare)).toDouble().toPrecision(2)}"),
              SizedBox(height: 15),
              pickUpDropDetail(context)
            ],
          ),
        ),
        if (ride.rideStatus == '2')
          Positioned(
              top: Get.height * 0.2,
              left: Get.width * 0.5 - Get.width * 0.4,
              child: Container(
                width: Get.width * 0.8,
                child: Image.asset(
                  AllImages.cancel,
                  fit: BoxFit.cover,
                ),
              )),
      ],
    );
  }

  pickUpDropDetail(context) => Container(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                SizedBox(height: 8),
                Container(
                  height: 10,
                  width: 10,
                  decoration: BoxDecoration(
                    color: AppThemes.lightPinkBackGroundColor,
                    shape: BoxShape.circle,
                  ),
                ),
                SizedBox(height: 8),
                Dash(
                  direction: Axis.vertical,
                  length: 40,
                  dashLength: 5,
                  dashGap: 6,
                  dashColor: AppThemes.lightBorderColor,
                  dashBorderRadius: 4,
                  dashThickness: 5,
                ),
                SizedBox(height: 8),
                Container(
                  height: 10,
                  width: 10,
                  decoration: BoxDecoration(
                    color: AppThemes.lightGreenbackGroundColor,
                    shape: BoxShape.circle,
                  ),
                )
              ],
            ),
            SizedBox(width: 25),
            Expanded(
              child: Column(
                children: [
                  rideLocation(
                    context,
                    "pick-upLocation".tr,
                    "${ride.pickupaddress}",
                  ),
                  SizedBox(height: 15),
                  rideLocation(
                    context,
                    "drop-offLocation".tr,
                    "${ride.dropaddress}",
                  ),
                ],
              ),
            )
          ],
        ),
      );

  rideLocation(context, String title, String data) => Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            title,
            style: Theme.of(context).textTheme.headline4.copyWith(
                  fontSize: 14,
                  fontFamily: 'NunitoSans',
                  fontWeight: FontWeight.w900,
                ),
            textAlign: TextAlign.center,
          ),
          Text(
            data,
            style: Theme.of(context)
                .textTheme
                .headline4
                .copyWith(fontSize: 14, fontFamily: 'NunitoSans'),
            maxLines: 2,
            softWrap: true,
            overflow: TextOverflow.clip,
            textAlign: TextAlign.center,
          ),
        ],
      );

  totalRideFareDetail(context, String title, String data) => Row(
        children: [
          Text(
            title,
            style: Theme.of(context).textTheme.headline4.copyWith(
                fontSize: 15,
                fontFamily: 'NunitoSans',
                fontWeight: FontWeight.w900),
          ),
          Spacer(),
          Text(
            data,
            style: Theme.of(context).textTheme.headline4.copyWith(
                fontSize: 15,
                fontFamily: 'NunitoSans',
                fontWeight: FontWeight.w900),
          ),
          SizedBox(width: 10),
        ],
      );
  rideFareDetail(context, String title, String data) => Row(
        children: [
          Text(
            title,
            style: Theme.of(context)
                .textTheme
                .headline4
                .copyWith(fontSize: 14, fontFamily: 'NunitoSans'),
          ),
          Spacer(),
          Text(
            data,
            style: Theme.of(context)
                .textTheme
                .headline4
                .copyWith(fontSize: 14, fontFamily: 'NunitoSans'),
          ),
          SizedBox(width: 10),
        ],
      );
  rideStatusDetail(context, String title, String data) => Row(
        children: [
          Text(
            title,
            style: Theme.of(context).textTheme.headline4.copyWith(
                fontSize: 14,
                fontFamily: 'NunitoSans',
                fontWeight: FontWeight.w900),
          ),
          SizedBox(width: 5),
          Text(
            data,
            style: Theme.of(context)
                .textTheme
                .headline4
                .copyWith(fontSize: 14, fontFamily: 'NunitoSans'),
          ),
        ],
      );
}
