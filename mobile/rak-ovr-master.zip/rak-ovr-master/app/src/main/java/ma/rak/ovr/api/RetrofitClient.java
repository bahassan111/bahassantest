package ma.rak.ovr.api;

import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import ma.rak.ovr.bodyResponse.AgentsResponse;
import ma.rak.ovr.storage.SharedPrefManager;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {

//    public static String BASE_URL = "http://192.168.1.43/RAK/VERF_API/public/";
//    public static String DEFAULT_BASE_URL = "http://192.168.1.43/RAK/VERF_API/public/";
    public static String BASE_URL = "https://mock-electron.herokuapp.com/api/";
    public static String DEFAULT_BASE_URL = "https://mock-electron.herokuapp.com/api/";
    private static RetrofitClient mInstance;
    private static Retrofit retrofit;
    private Context mContext;

    public static String getBaseUrl() {
        String url = SharedPrefManager.getInstance(getInstance().mContext).getBaseUrl();
        if (url == null) {
            return BASE_URL;
        }
        return url;
    }

    public static void setBaseUrl(String baseUrl) {
        if (baseUrl.isEmpty()) {
            BASE_URL = DEFAULT_BASE_URL;
        } else {
            BASE_URL = baseUrl;
        }
    }

    public static synchronized RetrofitClient getInstance() {
        if (mInstance == null) {
            mInstance = new RetrofitClient();
        }
        return mInstance;
    }

    public static void resetInstance() {
        if (mInstance != null) {
            mInstance = null;
            retrofit = null;
        }
    }

    public static Retrofit getClient(String token) {
        Gson gson = new GsonBuilder().serializeNulls().create();
        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client = new OkHttpClient.Builder()
                .readTimeout(60, TimeUnit.SECONDS)
                .connectTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .addInterceptor(new Interceptor() {
                    @NotNull
                    @Override
                    public okhttp3.Response intercept(@NotNull Chain chain) throws IOException {
                        Request request = chain.request().newBuilder()
                                .addHeader("Authorization", "Bearer " + token)
                                .build();
                        return chain.proceed(request);
                    }
                })
                .addInterceptor(loggingInterceptor)
                .build();

        if (retrofit == null || token != null) {
            try {
                retrofit = new Retrofit.Builder()
                        .baseUrl(getBaseUrl())
                        .client(client)
                        .addConverterFactory(GsonConverterFactory.create(gson))
                        .build();
            } catch (IllegalArgumentException e) {
                Log.e("error", e.getMessage());
            }
        }

        return retrofit;
    }

    public static Retrofit getClientTest(String baseUrl) {
        Gson gson = new GsonBuilder().serializeNulls().create();
        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client = new OkHttpClient.Builder()
                .readTimeout(60, TimeUnit.SECONDS)
                .connectTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .addInterceptor(new Interceptor() {
                    @NotNull
                    @Override
                    public okhttp3.Response intercept(@NotNull Chain chain) throws IOException {
                        Request request = chain.request().newBuilder()
                                .build();
                        return chain.proceed(request);
                    }
                })
                .addInterceptor(loggingInterceptor)
                .build();
        return new Retrofit.Builder()
                .baseUrl(baseUrl)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
    }

    public static Retrofit getClient() {
        Gson gson = new GsonBuilder().serializeNulls().create();
        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client = new OkHttpClient.Builder()
                .readTimeout(60, TimeUnit.SECONDS)
                .connectTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .addInterceptor(new Interceptor() {
                    @NotNull
                    @Override
                    public okhttp3.Response intercept(@NotNull Chain chain) throws IOException {
                        Request request = chain.request().newBuilder()
                                .build();
                        return chain.proceed(request);
                    }
                })
                .addInterceptor(loggingInterceptor)
                .build();
        return new Retrofit.Builder()
                .baseUrl(getBaseUrl())
                .client(client)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
    }

    public static Api getApi(String token) {
        return RetrofitClient.getClient(token).create(Api.class);
    }

    public static Api getApiBaseUrl(String token, String baseUrl) {
        return RetrofitClient.getClientTest(baseUrl).create(Api.class);
    }

    public static boolean testApi(String token, String baseUrl) {
        boolean status = true;
        try {
            RetrofitClient.getClientTest(baseUrl).create(Api.class);
        } catch (Exception e) {
            status = false;
        }
        return status;
    }

    public static Api getApiNoHeaders() {
        return RetrofitClient.getClient().create(Api.class);
    }

    public static void initSync(Context ctx, Runnable after){

        Call<AgentsResponse> call = RetrofitClient.getApiBaseUrl(SharedPrefManager.getInstance(ctx).getToken(), RetrofitClient.getBaseUrl()).agents();

        call.enqueue(new Callback<AgentsResponse>() {
            @Override
            public void onResponse(Call<AgentsResponse> call, Response<AgentsResponse> response) {
                after.run();

            }
            @Override
            public void onFailure(Call<AgentsResponse> call, Throwable t) {
                after.run();
            }
        });
    }
}
