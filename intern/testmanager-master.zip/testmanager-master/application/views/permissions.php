<?php



?>

<div class="" id="permissions_form">


    <form method="post" enctype="multipart/form-data" action="<?= site_url('settings/save_permissions/' . $group->id) ?>">

        <div class="permissions_actions">
            <span>Select</span>
            <a href="javascript:void(0);" class="sall">ALL</a>
            <i></i>
            <a href="javascript:void(0);" class="snone">NONE</a>
        </div>
        <div class="permissions_list">

            <input type="hidden" name="id_group" value="<?= $group->id; ?>">
            <?php foreach($pages as $page){
                $actions = json_decode($page->actions);
                $pers = [];
                foreach ($permissions as $permission){
                    if($permission->id_page === $page->id) $pers[] = $permission;
                }
                ?>

                <div class="permission_page">
                    <h3><?= $page->title; ?></h3>

                    <?php foreach($actions as $action){
                        $hasIt = FALSE;
                        foreach ($pers as $per){
                            if($per->action === $action->name) $hasIt = TRUE;
                        }
                        ?>

                        <div class="permission_item">
                            <div class="tw_box">
                                <input <?= $hasIt ? 'checked' : ''; ?> type="checkbox" name="permissions[<?= $page->id; ?>][]" value="<?= $action->name; ?>" id="<?= $page->id.'__'.$action->name; ?>">
                                <label for="<?= $page->id.'__'.$action->name; ?>"><?= $action->title; ?></label>

                            </div>
                        </div>

                    <?php } ?>

                </div>

            <?php } ?>

        </div>

    </form>




</div>
