<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Projects extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!isLoggedIn()) {
            callback_whenNotLoggedIn();
        }
    }

    public function index()
    {
        $data = [
            '_page' => 'project',
            '_action' => Pages::ACTION_READ,
        ];


        loadView('projects', $data);
    }

    public function datatable2()
    {
        $input = (object)$this->input->get();
        $length = $input->length ?: 10;
        $page = $input->start / $length;
        $order = $input->columns[intval($input->order[0]['column'])]['name'];
        $dir = $input->order[0]['dir'];
        $search = $input->search['value'] ?: '';

        $sfilter = '';

        foreach ($this->input->get('columns') as $col){
            $col = (object) $col;
            if($col->searchable === "false") continue;
            $sfilter .= ($sfilter ? ' OR ' : ' ') . "{$col->name} like '%$search%' ";
        }

        $query = $this->db
            ->select('*')
            ->order_by($order, $dir)
            ->limit($length, $page)
            ->get_where('projects', "deleted = 0 AND ($sfilter)")
            ->result();
        $total = $this->db
            ->select('count(*) as total')
            ->get_where('projects', "deleted = 0 AND ($sfilter)")
            ->row();
        $total = $total ? $total->total : 0;
        $total_nfiltre = $this->db
            ->select('count(*) as total')
            ->get_where('projects', "deleted = 0")
            ->row();
        $total_nfiltre = $total_nfiltre ? $total_nfiltre->total : 0;

        foreach ($query as $row){


        }


        $return = array(
            'draw' => $input->draw ?: 0,
            'recordsTotal' => $total_nfiltre,
            'recordsFiltered' => $total,
            'data' => $query
        );

        echo json_encode((object)$return);

    }

    public function datatable(){

        $datatable = doDatatable("SELECT * FROM projects WHERE deleted = 0", function($in, &$row){
            $row->_status = '<a class="ui label red"><i class="mail icon"></i> Ouvert</a>';
            $row->date_added = $row->date_added ?: date('Y-m-d H:i');
            $row->cases = 0;
            $row->_name = "<a href='".getProjectUrl($row)."'>$row->name</a>";


            $row->action = '<div class="dropdown">
                              <button class="btn btn-secondary btn-xs dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Actions
                              </button>
                              <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <a class="dropdown-item" href="'.getProjectUrl($row).'">Open</a>
                                <a class="dropdown-item" href="#">Edit</a>
                                <a class="dropdown-item" href="#">Remove</a>
                              </div>
                            </div>';
        });

        responseJSON($datatable);

    }

    public function get_list($type = 'active', $page = 1, $tag = FALSE){
        $filter = "status " . ($type == 'others' ? '> 1' : ($type == 'closed' ? '=1' : '=0'));
        $length = 20;
        $p = ($page - 1) * $length;

        $j = "";

        if(!hasPermission('project', 'view_all')){
            $j = "JOIN projects_users pu ON pu.id_project = p.id AND pu.id_user = ".userInfo()->id;
        }

        $query_str = "SELECT p.* FROM projects p $j WHERE p.deleted = 0 AND $filter";
        $query = $this->db->query("$query_str ORDER BY date_added DESC LIMIT $p, $length");
        $total = $this->db->query("SELECT count(*) total FROM ($query_str) t")->row()->total ?: 0;

        $data = [];

        foreach ($query->result() as $row){

            $tags = $this->db->query("SELECT * from projects_tags WHERE id_project = {$row->id}")->result();

            $data[] = [
                'edit' => hasPermission('project', Pages::ACTION_EDIT),
                'delete' => hasPermission('project', Pages::ACTION_DELETE),
                'id' => $row->id,
                'name' => $row->name,
                'url' => getProjectUrl($row),
                'code' => name_abbr($row->name ?: ' '),
                'description' => "Last update " . fromNow($row->date_modified),
                'color' => $row->color ?: (color_for_str($row->name) ?: '#00cccc'),
                'tags' => $tags,
            ];
        }

        $rest = $total - (($page) * $length);




        responseJSON(['data' => $data, 'total' => $total, 'rest' => $rest > 0 ? $rest : 0]);

    }

    public function get_stats(){
        $stats = new stdClass();
        $j = "";

        if(!hasPermission('project', 'view_all')){
            $j = "JOIN projects_users pu ON pu.id_project = p.id AND pu.id_user = ".userInfo()->id;
        }

        $stats->active = $this->db->query("SELECT count(*) t FROM projects p $j WHERE p.deleted = 0 AND p.status = 0")->row()->t ?: 0;
        $stats->closed = $this->db->query("SELECT count(*) t FROM projects p $j WHERE p.deleted = 0 AND p.status = 1")->row()->t ?: 0;
        $stats->others = $this->db->query("SELECT count(*) t FROM projects p $j WHERE p.deleted = 0 AND p.status > 1")->row()->t ?: 0;

        $stats->tags = $this->db->query("SELECT tag, count(tag) value FROM projects_tags t JOIN projects p ON t.id_project = p.id AND p.deleted = 0 $j GROUP BY tag ORDER BY count(tag) DESC LIMIT 8")->result();

        responseJSON($stats);
    }

    public function create(){
        $data = [
            '_page' => 'project',
            '_action' => Pages::ACTION_EDIT,
            'edit' => false,
        ];


        loadView('projects_form', $data, FALSE);
    }
    public function edit($id){
        if(!$id)callback_whenNotFound();
        $project = $this->db->get_where('projects', ['deleted' => 0, 'id' => $id])->row();
        if(!$project) callback_whenNotFound();

        $tags = $this->db->get_where('projects_tags', ['id_project' => $id])->result() ?: [];

        $data = [
            '_page' => 'project',
            '_action' => Pages::ACTION_EDIT,
            'edit' => true,
            'project' => $project,
            'tags' => $tags,
        ];


        loadView('projects_form', $data, FALSE);
    }

    public function save($id = FALSE){
        $rep = "ERROR";
        $edit = !!$id;

        $name = $this->input->post('name');
        $desc = $this->input->post('desc');
        $url = $this->input->post('url');
        $tags = $this->input->post('tags');

        $tags = explode(',', $tags);


        if($name){

            $set = [
                'name' => $name,
                'desc' => $desc,
                'url' => $url,
                'date_modified' => time(),
                'updated_by' => userInfo()->id,
                'color' => $this->input->post('color') ?: color_for_str($name),

            ];

            if(!$id){
                $set['date_added'] = time();
                $set['id_user'] = userInfo()->id;

                $query = $this->db->insert('projects', $set);
            }else{
                $query  = $this->db->update('projects', $set, ['id' => $id]);
            }




            if($query && !$id) $id = $this->db->insert_id();

            if($query) $rep = "OK";
        }


        $q = $this->db->delete('projects_tags', ['id_project' => $id]);
        foreach ($tags as $tag){

            $this->db->insert('projects_tags', [
                'id_project' => $id,
                'tag' => trim(strtoupper($tag))
            ]);

        }

        if(!$edit && !userInfo()->is_admin){
            $u = $this->db->get_where('projects_users', ['id_project' => $id, 'id_user' => userInfo()->id]);
            if($u->num_rows() === 0){
                $this->db->insert('projects_users', [
                    'id_project' => $id,
                    'id_user' => userInfo()->id,
                    'type' => 'viewer',
                ]);
            }
        }

        responseJSON(['status' => $rep]);

    }
    public function delete_project($id = FALSE){
        $rep = "ERROR";
        $msg = "";

        if(!$id)callback_whenNotFound();
        $project = $this->db->get_where('projects', ['deleted' => 0, 'id' => $id])->row();
        if(!$project) callback_whenNotFound();

        $query = $this->db->update('projects', ['deleted'=>1], ['id' => $id]);

        $rep = $query ? 'OK' : 'ERROR';

        responseJSON(['status' => $rep]);

    }
}
