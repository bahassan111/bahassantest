import 'package:driver/constants/constants.dart';
import 'package:flutter/material.dart';

class CustomBackButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.pop(context);
      },
      child: Container(
        padding: EdgeInsets.only(left: 15, top: 15),
        child: Icon(
          Icons.arrow_back_ios,
          color: AppThemes.lightdeepPinkDropDownIconColor,
        ),
      ),
    );
  }
}
