import Realm from "realm";
import Preferences from "./models/Preferences";

export default class DB {
  /**
   * @type {Realm}
   *
   * @static
   * @memberof DB
   */
  static db = null;

  static models = {
    Preferences
  };

  static async open() {
    let realmOptions = {
      path: Realm.defaultPath,
      schemaVersion: 3,
      schema: [Preferences]
    };
    if (realmOptions.schemaVersion > Realm.schemaVersion(realmOptions.path)) {
      return new Promise((resolve, reject) => {
        try {
          let db = new Realm(realmOptions);
          DB.db = db;
          resolve(db);
        } catch (error) {
          reject(error);
        }
      });
    }
    return Realm.open(realmOptions).then(db => {
      DB.db = db;
    });
  }
}
