<?php
?>
<div data-label="Details for : <?= $task->title; ?>" class="df-example demo-forms case_view">

    <div class="preview_case">
        <div class="pcase_head">
            <h3><?= $task->title; ?></h3>
            <p>Last update <?= fromNow($task->date_modified); ?></p>
            <div class="dets">
                <ul>
                    <li><span>Runs</span><b><label class="case_type <?= $task->plan->type; ?>"><?= $task->plan->type; ?></label></b></li>
                    <li><span>Type</span><b><?= $task->type->name; ?></b></li>
                    <li><span>Plan</span><b><?= $task->plan->title; ?></b></li>
                </ul>
                <ul>
                    <li><span>Date Created</span><b><?= date('Y-m-d H:i', $task->date_added); ?></b></li>
                    <li><span>Date Updated</span><b><?= date('Y-m-d H:i', $task->date_modified); ?></b></li>
                    <li><span>Note</span><b><?= $task->desc ?: '<i><small>(No note)</small></i>' ?></b></li>
                </ul>
            </div>
        </div>

        <div class="pcase_body">

            <?php if($task->plan->type == 'auto'){?>
                <div class="pcase_auto_info">
                    <label>Request as designed :</label>
                    <div class="pcase_auto_dets">
                        <table class="table table-bordered">
                            <tbody>
                            <tr>
                                <td>Request Method</td>
                                <td><b><?= strtoupper($task->method); ?></b></td>
                            </tr>
                            <tr>
                                <td>Request URL</td>
                                <td><b><?= $task->url; ?></b></td>
                            </tr>
                            <tr>
                                <td>Headers</td>
                                <td>
                                    <table class="table table-bordered">
                                        <thead><tr><th>Header</th><th>Value</th></tr></thead>
                                        <tbody>
                                        <?php foreach(json_decode($task->headers ?: '[]') as $key => $val){ ?>
                                            <td><?= $key; ?></td><td><b><?= $val; ?></b></td>
                                        <?php } ?>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td>Headers</td>
                                <td>
                                    <table class="table table-bordered">
                                        <thead><tr><th>Parameter</th><th>Value</th></tr></thead>
                                        <tbody>
                                        <?php foreach(json_decode($task->params ?: '[]') as $key => $val){ ?>
                                            <td><?= $key; ?></td><td><b><?= $val; ?></b></td>
                                        <?php } ?>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            </tbody>
                        </table>


                    </div>
                    <label>Conditions :</label>
                    <div class="pcase_auto_dets">
                        <table class="table table-bordered">
                            <tbody>
                            <?php foreach($task->asserts as $assert){ ?>
                                <tr>
                                    <td><?= asserts($assert->id_assert)->title; ?></td>
                                    <td>
                                        <?php foreach(asserts($assert->id_assert)->values as $i => $value){ ?>
                                            <div><?= $value->title; ?> = <b> <?= $assert->{'value' . ($i+1)}; ?></b></div>
                                        <?php } ?>
                                    </td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>


                    </div>
                </div>
            <?php }else{?>
                <div class="pcase_info">
                    <label>Steps todo :</label>
                    <div class="pcase_dets">
                        <div class="pcase_steps">
                            <?php foreach($task->steps as $step){ ?>
                                <div class="pcase_step">
                                    <span class="i"><?= $step->order; ?></span>
                                    <div>
                                        <span class="t"><?= $step->todo; ?></span>
                                        <span class="v"><?= $step->expect; ?></span>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            <?php } ?>

        </div>
    </div>





</div>