import 'package:flutter/material.dart';
import 'package:rider_app/constants/app_themes.dart';
import 'package:get/get.dart';
import 'package:rider_app/controllers/controllers.dart';

import 'components.dart';

class CharterTime extends StatefulWidget {
  const CharterTime({Key key}) : super(key: key);

  @override
  _CharterTimeState createState() => _CharterTimeState();
}

class _CharterTimeState extends State<CharterTime> {
  int selectedTime;
  static HomeController to = Get.find();

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        int time = await showDialog(
            context: context,
            builder: (context) {
              return HoursSelector();
            });
        setState(() {
          to.charterTime = time;
          selectedTime = time;
        });

        /*
        
         BotToast.showWidget(
          toastBuilder: (_) => HoursSelector(),
        );
         final time = await selectTime(context);
        if (time != null)
          setState(() {
            to.charterTime = time;
            selectedTime = time;
          });*/
      },
      child: Container(
        margin: EdgeInsets.only(left: 20, top: 3, right: 20),
        padding: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
        decoration: BoxDecoration(
            color: AppThemes.lightWhitebackGroundColor,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: AppThemes.lightCardBorder,
            ),
            boxShadow: [
              BoxShadow(
                color: AppThemes.shadowColor.withOpacity(0.2),
                blurRadius: 15,
                spreadRadius: 1,
              ),
            ]),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "enterCharterTime".tr,
              style: Theme.of(context).textTheme.headline2.copyWith(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    height: 1.2,
                  ),
            ),
            Text(
              "hourlyTerms".tr,
              style:
                  Theme.of(context).textTheme.headline2.copyWith(fontSize: 13),
            ),
            SizedBox(width: 5),
            selectedTime == null
                ? Container()
                : Text(
                    "$selectedTime hours",
                    style: Theme.of(context).textTheme.headline2.copyWith(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          height: 1.2,
                        ),
                  ),
          ],
        ),
      ),
    );
  }
}
