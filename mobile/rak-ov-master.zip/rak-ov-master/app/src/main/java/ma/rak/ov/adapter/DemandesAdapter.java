package ma.rak.ov.adapter;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import io.realm.RealmList;
import ma.rak.ov.BranchementFragment;
import ma.rak.ov.R;
import ma.rak.ov.api.TwDatabase;
import ma.rak.ov.models.Abonnement;
import ma.rak.ov.models.Branchement;
import ma.rak.ov.models.Dossier;
import ma.rak.ov.storage.SharedPrefManager;
import ma.rak.ov.ui.main.AffecterFragment;
import ma.rak.ov.ui.main.DevisActivity;
import ma.rak.ov.ui.main.DevisFragment;
import ma.rak.ov.ui.main.ExecutionFragment;
import ma.rak.ov.ui.main.RejectFragment;

import static ma.rak.ov.R.drawable.bg_electricite;
import static ma.rak.ov.R.drawable.button_bg;
import static ma.rak.ov.R.drawable.gradient_background2;
import static ma.rak.ov.R.drawable.gradient_background4;
import static ma.rak.ov.R.drawable.item_assi;
import static ma.rak.ov.R.drawable.item_button_bg;

public class DemandesAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;

    private FragmentActivity mContext;
    private ArrayList<HashMap<String, String>> branchementList;
    private ArrayList<HashMap<String, String>> abonnementList;
    private final String TAG = getClass().getSimpleName();
    public boolean isBR;

    private PopupWindow mPopupWindow;


    public DemandesAdapter(FragmentActivity mContext, ArrayList<HashMap<String, String>> branchementList, ArrayList<HashMap<String, String>> abonnementList) {
        this.mContext = mContext;
        this.branchementList = branchementList;
        this.abonnementList = abonnementList;
        isBR = SharedPrefManager.getInstance(mContext).getMode() == 1;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_pending_list, parent, false);
            return new DemandesAdapter.ItemViewHolder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_loading, parent, false);
            return new DemandesAdapter.LoadingViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int position) {

        if (viewHolder instanceof ItemViewHolder) {

            populateItemRows((ItemViewHolder) viewHolder, position);
        } else if (viewHolder instanceof LoadingViewHolder) {
            showLoadingView((LoadingViewHolder) viewHolder, position);
        }

    }

    @Override
    public int getItemCount() {
        if (branchementList != null)
            return branchementList.size();
        else if (abonnementList != null)
            return abonnementList.size();
        else
            return 0;
    }

    public void addAllAb(List<HashMap<String, String>> items) {
        for (HashMap<String, String> item : items)
            addAb(item);
    }

    public void addAb(HashMap<String, String> item) {
        abonnementList.add(item);
        notifyItemInserted(abonnementList.size() - 1);
    }

    public void addAllBr(List<HashMap<String, String>> items) {
        for (HashMap<String, String> item : items)
            addBr(item);
    }

    public void addBr(HashMap<String, String> item) {
        branchementList.add(item);
        notifyItemInserted(branchementList.size() - 1);
    }

    public void setList(ArrayList<HashMap<String, String>> branchementList, ArrayList<HashMap<String, String>> abonnementList) {
        this.branchementList = branchementList;
        this.abonnementList = abonnementList;
        notifyDataSetChanged();
    }

    public void clear(){
        this.branchementList = null;
        this.abonnementList = null;
        notifyDataSetChanged();
    }

    /**
     * The following method decides the type of ViewHolder to display in the RecyclerView
     *
     * @param position
     * @return
     */
    @Override
    public int getItemViewType(int position) {
        if (branchementList != null) {
            return branchementList.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
        } else if (abonnementList != null) {
            return abonnementList.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
        }

        return VIEW_TYPE_ITEM;
    }


    private class ItemViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView tvItem;
        public final View mView;
        public final TextView mContentView, mAddressView, mSectorView, mLIBEGERA, clientdoss, lblv, pending, dossierId;
        ArrayList<HashMap<String, String>> pendings;
        ArrayList<HashMap<String, String>> pendings2;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            mView = itemView;
            mContentView = (TextView) itemView.findViewById(R.id.client_name);
            mAddressView = (TextView) itemView.findViewById(R.id.client_address);
            dossierId = (TextView) itemView.findViewById(R.id.dossier_id);
            mSectorView = (TextView) itemView.findViewById(R.id.client_sector);
            mLIBEGERA = (TextView) itemView.findViewById(R.id.LIBEGERA);
            clientdoss = (TextView) itemView.findViewById(R.id.clientdoss);
            lblv = (TextView) itemView.findViewById(R.id.lblv);
            pending = (TextView) itemView.findViewById(R.id.pending);
            itemView.setOnClickListener(this);

            TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(itemView.getContext());
            pendings = dbh.query(isBR ? TwDatabase.BRPending.TABLE_NAME : TwDatabase.ABPending.TABLE_NAME, null, null, null);

            pendings2 = pendings;

        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            Log.d(TAG, "Clicked!" + position);
            final View customView = LayoutInflater.from(mContext).inflate(R.layout.custom_layout, null);
            String scoop = SharedPrefManager.getInstance(mContext).getScoop();

            TextView client_name = customView.findViewById(R.id.client_name);
            TextView dossier_id = customView.findViewById(R.id.dossier_id);
            TextView devi = customView.findViewById(R.id.devi);
            TextView client_address = customView.findViewById(R.id.client_address);
            TextView date_operation = customView.findViewById(R.id.date_operation);
            //TextView client_reference = customView.findViewById(R.id.client_reference);
            TextView type_id = customView.findViewById(R.id.type_id);
            ImageView image = customView.findViewById(R.id.image);
            //TextView nature_operation = customView.findViewById(R.id.nature_operation);
            Button operationExecute = customView.findViewById(R.id.operationExecute);
            Button operationReject = customView.findViewById(R.id.operationReject);
            Button operationNoExecution = customView.findViewById(R.id.operationNoExecution);
            Button operationReaf = customView.findViewById(R.id.operationReaf);
            Button openDevis = customView.findViewById(R.id.opendevis);


            Intent execution = new Intent(mContext, ExecutionFragment.class);
            Intent reject = new Intent(mContext, RejectFragment.class);
            Intent noExecution = new Intent(mContext, RejectFragment.class);
            Intent affecter = new Intent(mContext, AffecterFragment.class);
            Intent devis = new Intent(mContext, DevisActivity.class);

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String currentDateandTime = sdf.format(new Date());

            mPopupWindow = new PopupWindow(
                    customView,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    true
            );

            if (SharedPrefManager.getInstance(mContext).getMode() == 1) {
                HashMap<String, String> clickerItem = branchementList.get(position);
                lblv.setText("BR");
                client_name.setText(clickerItem.get("NOM"));
                dossier_id.setText(clickerItem.get("NUMDEMDE") + "/" + clickerItem.get("ANNDEMDE"));
                devi.setText("DEVIS : ");
                client_address.setText(clickerItem.get("ADRESDEVI"));
                date_operation.setText(clickerItem.get("DATSAIDE"));
                //client_reference.setText(clickerItem.get("NUMDEMDE"));
                //client_reference.setVisibility(View.INVISIBLE);
                type_id.setVisibility(View.INVISIBLE);
                //nature_operation.setVisibility(View.INVISIBLE);

                String base64Image = clickerItem.get(TwDatabase.BRDemandes.IMAGE);
                if(base64Image!=null){
                    byte[] decodedString = Base64.decode(base64Image, Base64.DEFAULT);
                    Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                    image.setImageBitmap(decodedByte);
                }


                devis.putExtra("address", clickerItem.get("ADRESDEVI"));


                boolean inHisto = clickerItem.get("STATOPER") != null && Integer.valueOf(clickerItem.get("STATOPER")) > 1;
                operationExecute.setVisibility(inHisto ? View.INVISIBLE : View.VISIBLE);
                operationNoExecution.setVisibility(inHisto ? View.INVISIBLE : View.VISIBLE);
                operationReject.setVisibility(inHisto ? View.INVISIBLE : View.VISIBLE);
                operationReaf.setVisibility(inHisto ? View.INVISIBLE : (scoop.equals("Superviseur") ? View.VISIBLE : View.INVISIBLE));

                execution.putExtra("CONSULT", false);
                reject.putExtra("CONSULT", false);
                noExecution.putExtra("CONSULT", false);

                if(inHisto){

                    fillHistoDetailsBranchement(customView, clickerItem);
                }


                execution.putExtra("br", true);
                execution.putExtra("status", "3");
                execution.putExtra("date", currentDateandTime);
                execution.putExtra("ITEM", clickerItem);


                reject.putExtra("br", true);
                reject.putExtra("status", "3");
                reject.putExtra("date", currentDateandTime);
                reject.putExtra("ITEM", clickerItem);

                noExecution.putExtra("br", true);
                noExecution.putExtra("status", "4");
                noExecution.putExtra("date", currentDateandTime);
                noExecution.putExtra("ITEM", clickerItem);

                affecter.putExtra("br", true);
                affecter.putExtra("status", "4");
                affecter.putExtra("date", currentDateandTime);
                affecter.putExtra("ITEM", clickerItem);

            } else {
                HashMap<String, String> clickerItem = abonnementList.get(position);
                lblv.setText("AB");
                client_name.setText(clickerItem.get("NOM"));
                dossier_id.setText(clickerItem.get("NUMEDOSS") + "/" + clickerItem.get("ANNEDOSS"));
                client_address.setText(clickerItem.get("ADRELOCA"));
                date_operation.setText(clickerItem.get("DATDEMAB"));
                //client_reference.setText(clickerItem.get("NUMOPRAB"));
                type_id.setText(clickerItem.get(TwDatabase.ABDemandes.TELECLIE));
//                String base64Image = TwDatabase.ABDemandes.IMAGE.split(",")[1];
                String base64Image = clickerItem.get(TwDatabase.ABDemandes.IMAGE);
                if(!base64Image.equals("")){
                    byte[] decodedString = Base64.decode(base64Image, Base64.DEFAULT);
                    Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                    image.setImageBitmap(decodedByte);
                }

                //nature_operation.setText(clickerItem.get("CODNATCL"));

                devis.putExtra("address", clickerItem.get("ADRELOCA"));

                String dosss = clickerItem.get("DOSSIERS");
                ArrayList<Dossier> arrayList = new ArrayList<>();
                try {
                    JSONArray jdossiers = new JSONArray(dosss);
                    for (int i = 0; i < jdossiers.length(); i++) {
                        JSONObject doss = jdossiers.getJSONObject(i);
                        arrayList.add(new Dossier(doss.getString("GERANCE"), doss.getString("NUM"), doss.getString("ADRESSE")));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }


                boolean inHisto = Integer.valueOf(clickerItem.get("STATOPER")) > 1;
                operationExecute.setVisibility(inHisto ? View.INVISIBLE : View.VISIBLE);
                operationNoExecution.setVisibility(inHisto ? View.INVISIBLE : View.VISIBLE);
                operationReject.setVisibility(inHisto ? View.INVISIBLE : View.VISIBLE);
                operationReaf.setVisibility(inHisto ? View.INVISIBLE : (scoop.equals("Superviseur") ? View.VISIBLE : View.INVISIBLE));

                execution.putExtra("CONSULT", false);
                reject.putExtra("CONSULT", false);
                noExecution.putExtra("CONSULT", false);

                if(inHisto){

                    fillHistoDetails(customView, clickerItem);
                }


                execution.putExtra("br", false);
                execution.putExtra("status", "2");
                execution.putExtra("date", currentDateandTime);
                execution.putExtra("doss_annee", clickerItem.get("ANNEDOSS"));
                execution.putExtra("doss_numm", clickerItem.get("NUMEDOSS"));
                execution.putExtra("num_operation", clickerItem.get("NUMOPRAB"));
                execution.putExtra("gerance", clickerItem.get("CODEGERA"));
                execution.putExtra("adreloca", clickerItem.get("ADRELOCA"));
                execution.putExtra("nature_install", clickerItem.get("NATU_LOT"));
                execution.putExtra("etage", clickerItem.get("CODEETAG"));
                execution.putParcelableArrayListExtra("dossier", arrayList);

                execution.putExtra("ITEM", clickerItem);

                reject.putExtra("br", false);
                reject.putExtra("status", "3");
                reject.putExtra("date", currentDateandTime);
                reject.putExtra("doss_annee", clickerItem.get("ANNEDOSS"));
                reject.putExtra("doss_numm", clickerItem.get("NUMEDOSS"));
                reject.putExtra("num_operation", clickerItem.get("NUMOPRAB"));
                reject.putExtra("gerance", clickerItem.get("CODEGERA"));
                reject.putExtra("adreloca", clickerItem.get("ADRELOCA"));
                reject.putParcelableArrayListExtra("dossier", arrayList);
                reject.putExtra("ITEM", clickerItem);

                noExecution.putExtra("br", false);
                noExecution.putExtra("status", "4");
                noExecution.putExtra("date", currentDateandTime);
                noExecution.putExtra("doss_annee", clickerItem.get("ANNEDOSS"));
                noExecution.putExtra("doss_numm", clickerItem.get("NUMEDOSS"));
                noExecution.putExtra("num_operation", clickerItem.get("NUMOPRAB"));
                noExecution.putExtra("gerance", clickerItem.get("CODEGERA"));
                noExecution.putExtra("adreloca", clickerItem.get("ADRELOCA"));
                noExecution.putParcelableArrayListExtra("dossier", arrayList);
                noExecution.putExtra("ITEM", clickerItem);

                affecter.putExtra("br", false);
                affecter.putExtra("status", "4");
                affecter.putExtra("date", currentDateandTime);
                affecter.putExtra("doss_annee", clickerItem.get("ANNEDOSS"));
                affecter.putExtra("doss_numm", clickerItem.get("NUMEDOSS"));
                affecter.putExtra("num_operation", clickerItem.get("NUMOPRAB"));
                affecter.putExtra("gerance", clickerItem.get("CODEGERA"));
                affecter.putExtra("AGENT", clickerItem.get("CODUTIEX"));
                affecter.putExtra("ITEM", clickerItem);
            }

            operationExecute.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mPopupWindow.dismiss();
                    mContext.startActivity(execution);
                }
            });

            operationReject.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mPopupWindow.dismiss();
                    mContext.startActivity(reject);
                }
            });
            openDevis.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mPopupWindow.dismiss();
                    mContext.startActivity(devis);
                }
            });




            operationReaf.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mPopupWindow.dismiss();
                    mContext.startActivity(affecter);
                }
            });

            operationNoExecution.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mPopupWindow.dismiss();
                    //noExecution.putExtra("status", "4");
                    mContext.startActivity(noExecution);
                }
            });


            // Initialize a new instance of popup window


            // Set an elevation value for popup window
            // Call requires API level 21
            if (Build.VERSION.SDK_INT >= 21) {
                mPopupWindow.setElevation(100);
            }

            // Get a reference for the custom view close button
            ImageButton closeButton = (ImageButton) customView.findViewById(R.id.ib_close);

            // Set a click listener for the popup window close button
            closeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // Dismiss the popup window
                    mPopupWindow.dismiss();
                }
            });

            mPopupWindow.setBackgroundDrawable(new ColorDrawable(Color.argb(80, 59, 59, 59)));

            ConstraintLayout constraintLayout = (ConstraintLayout) mContext.findViewById(R.id.constraintLayoutMap);
            mPopupWindow.showAtLocation(customView, Gravity.BOTTOM, 0, 0);
        }
    }

    private class LoadingViewHolder extends RecyclerView.ViewHolder {

        ProgressBar progressBar;

        public LoadingViewHolder(@NonNull View itemView) {
            super(itemView);
            progressBar = itemView.findViewById(R.id.progressBar);
        }
    }

    private void showLoadingView(LoadingViewHolder viewHolder, int position) {
        //ProgressBar would be displayed

    }

    private void populateItemRows(ItemViewHolder viewHolder, int position) {

//        String item = mItemList.get(position);
//        viewHolder.tvItem.setText(item);
        viewHolder.mLIBEGERA.setBackground(ContextCompat.getDrawable(this.mContext, item_button_bg));

        if (branchementList != null) {
            HashMap<String, String> branchement = branchementList.get(position);

            boolean isPending = false;
            for (HashMap<String, String> p: viewHolder.pendings){
                if(p.get("ANNDEMDE").equals(branchement.get("ANNDEMDE")) && p.get("NUMDEMDE").equals(branchement.get("NUMDEMDE")) && p.get("CODEGERA").equals(branchement.get("CODEGERA"))){
                    isPending = true;
                    break;
                }
            }


            String aff_txt = "", aff = branchement.get("CODUTIEX");
            if(aff != null) aff_txt = " #" + aff;
            viewHolder.mContentView.setText(branchement.get("NOM") + " #" + branchement.get("CODUTIEX"));
            viewHolder.mAddressView.setText(branchement.get("ADRESDEVI"));
            viewHolder.dossierId.setText(branchement.get("ANNDEMDE") + "/" + branchement.get("NUMDEMDE"));
            if (branchement.get("CODEGERA").equals("2")) {
                viewHolder.mLIBEGERA.setText("⚡️ "+branchement.get("LIBEGERA"));
                viewHolder.mLIBEGERA.setBackground(ContextCompat.getDrawable(this.mContext, bg_electricite));
            }
            else if (branchement.get("CODEGERA").equals("1")){
                viewHolder.mLIBEGERA.setText("⚡️ "+ branchement.get("LIBEGERA"));

                viewHolder.mLIBEGERA.setBackground(ContextCompat.getDrawable(this.mContext, item_assi));
            }

            if(isPending){
                viewHolder.pending.setVisibility(View.VISIBLE);
            }else{
                viewHolder.pending.setVisibility(View.INVISIBLE);
            }

            viewHolder.mSectorView.setText(branchement.get("LIBCATDE"));
            viewHolder.lblv.setText("🔗  BR");
            viewHolder.lblv.setBackground(ContextCompat.getDrawable(this.mContext, gradient_background4));
            viewHolder.clientdoss.setVisibility(View.INVISIBLE);
            viewHolder.clientdoss.setHeight(0);

        }

        if (abonnementList != null) {
            HashMap<String, String> abonnement = abonnementList.get(position);

            boolean isPending = false;
            for (HashMap<String, String> p: viewHolder.pendings){
                if(p.get("ANNEDOSS").equals(abonnement.get("ANNEDOSS")) && p.get("NUMEDOSS").equals(abonnement.get("NUMEDOSS")) && p.get("NUMOPRAB").equals(abonnement.get("NUMOPRAB"))){
                    isPending = true;
                    break;
                }
            }

            String aff_txt = "", aff = abonnement.get("CODUTIEX");
            if(aff != null) aff_txt = " #" + aff;


            viewHolder.mContentView.setText(abonnement.get("NOM") + aff_txt);
            viewHolder.mAddressView.setText(abonnement.get("ADRELOCA"));
            viewHolder.clientdoss.setText("DOSSIER : " + abonnement.get("ANNEDOSS") + "/" + abonnement.get("NUMEDOSS"));

            if (abonnement.get("CODEGERA").equals("2")){
                viewHolder.mLIBEGERA.setText("⚡️ "+abonnement.get("LIBEGERA"));
                viewHolder.mLIBEGERA.setBackground(ContextCompat.getDrawable(this.mContext, bg_electricite));
            }
            else if (abonnement.get("CODEGERA").equals("3")){
                viewHolder.mLIBEGERA.setText("💧️ "+ abonnement.get("LIBEGERA"));
                viewHolder.mLIBEGERA.setBackground(ContextCompat.getDrawable(this.mContext, item_assi));
            }

            if(isPending){
                viewHolder.pending.setVisibility(View.VISIBLE);
            }else{
                viewHolder.pending.setVisibility(View.INVISIBLE);
            }
            viewHolder.mSectorView.setText("Secteur : " + abonnement.get("CODESECT") + " | Tournée: " + abonnement.get("NUMETOUR") + " | Ordre: 0  ");
            viewHolder.lblv.setText("📂 AB");
            viewHolder.lblv.setBackground(ContextCompat.getDrawable(this.mContext, gradient_background2));
//            notifyItemChanged(holder.getAdapterPosition());

        }

    }

    public void fillHistoDetails(View view, HashMap<String, String> row){

        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(mContext);

        ((LinearLayout) view.findViewById(R.id.dem_actions)).setVisibility(View.GONE);

        if(row.get("STATOPER").equals("2")){

            ((LinearLayout) view.findViewById(R.id.histo_inf)).setVisibility(View.VISIBLE);


            String code_nat = row.get("CODNATIN");
            String code_cat = row.get("CODCATAB");
            String code_emp = row.get("CODEMPCO");

            if(code_nat != null && !code_nat.equals("")){

                ArrayList<HashMap<String, String>> r = dbh.query(TwDatabase.ABNatures.TABLE_NAME, "key = ?", new String[]{code_nat}, null);

                if(r.size() > 0) code_nat = r.get(0).get(TwDatabase.ABNatures.COL_LABEL);

            }

            if(code_cat != null && !code_cat.equals("")){

                ArrayList<HashMap<String, String>> r = dbh.query(TwDatabase.ABCats.TABLE_NAME, "key = ?", new String[]{code_cat}, null);

                if(r.size() > 0) code_cat = r.get(0).get(TwDatabase.ABCats.COL_LABEL);

            }

            if(code_emp != null && !code_emp.equals("")){

                ArrayList<HashMap<String, String>> r = dbh.query(TwDatabase.ABEmplacements.TABLE_NAME, "key = ?", new String[]{code_emp}, null);

                if(r.size() > 0) code_emp = r.get(0).get(TwDatabase.ABEmplacements.COL_LABEL);

            }

            String devis = row.get("AVESANDE");

            devis = devis.equals("1") ? "avec devis" : "sans devis";

            ((TextView) view.findViewById(R.id.h_cat)).setText(code_cat);
            ((TextView) view.findViewById(R.id.h_nat)).setText(code_nat);
            ((TextView) view.findViewById(R.id.h_dosr)).setText(row.get("ANDORESI") + "/" + row.get("ANDORESI"));
            ((TextView) view.findViewById(R.id.h_devis)).setText(devis);
            ((TextView) view.findViewById(R.id.h_empl)).setText(code_emp);
            ((TextView) view.findViewById(R.id.h_natlot)).setText(row.get("NATU_LOT"));
            ((TextView) view.findViewById(R.id.h_obser)).setText(row.get("RESTRAOP"));

                        /*operationExecute.setVisibility(View.VISIBLE);
                        operationExecute.setText(R.string.consult);
                        execution.putExtra("CONSULT", true);*/

        }else if(row.get("STATOPER").equals("3") || row.get("STATOPER").equals("4")){

            ((LinearLayout) view.findViewById(R.id.dem_actions)).setVisibility(View.GONE);
            ((LinearLayout) view.findViewById(R.id.histo_n_inf)).setVisibility(View.VISIBLE);

            String code_motif = row.get("COMOSTOP");

            if(code_motif != null && !code_motif.equals("")){

                ArrayList<HashMap<String, String>> r = dbh.query(TwDatabase.ABMotifs.TABLE_NAME, "key = ?", new String[]{code_motif}, null);

                if(r.size() > 0) code_motif = r.get(0).get(TwDatabase.ABEmplacements.COL_LABEL);

            }



            ((TextView) view.findViewById(R.id.h_res)).setText(row.get("STATOPER").equals("3") ? "Rejetée" : "Non exécutée");
            ((TextView) view.findViewById(R.id.h_motif)).setText(code_motif);
            ((TextView) view.findViewById(R.id.h_motifobs)).setText(row.get("RESTRAOP"));




        }
    }

    public void fillHistoDetailsBranchement(View view, HashMap<String, String> row){

        TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(mContext);

        ((LinearLayout) view.findViewById(R.id.dem_actions)).setVisibility(View.GONE);

        if(row.get("STATOPER").equals("2")){

            ((LinearLayout) view.findViewById(R.id.histo_inf)).setVisibility(View.VISIBLE);

            ((LinearLayout) view.findViewById(R.id.h_remove_1)).setVisibility(View.GONE);
            ((LinearLayout) view.findViewById(R.id.h_remove_2)).setVisibility(View.GONE);
            ((LinearLayout) view.findViewById(R.id.h_remove_3)).setVisibility(View.GONE);
            ((LinearLayout) view.findViewById(R.id.h_remove_4)).setVisibility(View.GONE);



            String code_nat = row.get("CODNATIN");
            String code_cat = row.get("CODCATAB");
            String code_emp = row.get("CODEMPCO");

            if(code_nat != null && !code_nat.equals("")){

                ArrayList<HashMap<String, String>> r = dbh.query(TwDatabase.BRNatures.TABLE_NAME, "key = ?", new String[]{code_nat}, null);

                if(r.size() > 0) code_nat = r.get(0).get(TwDatabase.BRNatures.COL_LABEL);

            }

            if(code_cat != null && !code_cat.equals("")){

                ArrayList<HashMap<String, String>> r = dbh.query(TwDatabase.BRCats.TABLE_NAME, "key = ?", new String[]{code_cat}, null);

                if(r.size() > 0) code_cat = r.get(0).get(TwDatabase.BRCats.COL_LABEL);

            }

            ((TextView) view.findViewById(R.id.h_cat)).setText(code_cat);
            ((TextView) view.findViewById(R.id.h_nat)).setText(code_nat);
            ((TextView) view.findViewById(R.id.h_obser)).setText(row.get("OBSEVEDE"));

        }else if(row.get("STATOPER").equals("3") || row.get("STATOPER").equals("4")){

            ((LinearLayout) view.findViewById(R.id.dem_actions)).setVisibility(View.GONE);
            ((LinearLayout) view.findViewById(R.id.histo_n_inf)).setVisibility(View.VISIBLE);

            String code_motif = row.get("COMOSTOP");

            if(code_motif != null && !code_motif.equals("")){

                ArrayList<HashMap<String, String>> r = dbh.query(TwDatabase.BRMotifs.TABLE_NAME, "key = ?", new String[]{code_motif}, null);

                if(r.size() > 0) code_motif = r.get(0).get(TwDatabase.BRMotifs.COL_LABEL);

            }

            ((TextView) view.findViewById(R.id.h_res)).setText(row.get("STATOPER").equals("3") ? "Rejetée" : "Non exécutée");
            ((TextView) view.findViewById(R.id.h_motif)).setText(code_motif);
            ((TextView) view.findViewById(R.id.h_motifobs)).setText(row.get("OBSEVEDE"));




        }
    }


}
