import I18n from "i18next";
import fr from "./locales/fr.json";
import ar from "./locales/ar.json";

I18n.locale = "ar";
I18n.fallbacks = true;
I18n.translations = { ar, fr };
export default I18n;
