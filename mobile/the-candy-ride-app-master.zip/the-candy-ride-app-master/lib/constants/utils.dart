import 'package:intl/intl.dart';

final numberFormating = NumberFormat("##0.00", "en_US");
