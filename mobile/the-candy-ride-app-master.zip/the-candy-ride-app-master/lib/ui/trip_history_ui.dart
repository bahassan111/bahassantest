import 'package:flutter/material.dart';
import 'package:rider_app/constants/constants.dart';
import 'package:get/get.dart';
import 'package:rider_app/controllers/controllers.dart';
import 'package:rider_app/helpers/helpers.dart';

import 'components/components.dart';

class TripHistoryUI extends StatefulWidget {
  @override
  _TripHistoryUIState createState() => _TripHistoryUIState();
}

class _TripHistoryUIState extends State<TripHistoryUI> {
  double height, width;

  static TripHistoryController to = Get.find();

  @override
  void initState() {
    to.rides = [];
    to.getTrips().then((value) {
      setState(() {});
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      body: SafeArea(
        child: Container(
          child: Column(
            children: [
              appbar(context),
              generalHistory(context),
              Expanded(
                  child: ListView.builder(
                itemCount: to.filteredRides.length,
                itemBuilder: (context, index) {
                  return HistoryItem(
                    ride: to.filteredRides[index],
                  );
                },
              ))
            ],
          ),
        ),
      ),
    );
  }

  appbar(context) => Container(
        width: width,
        margin: EdgeInsets.symmetric(horizontal: 20, vertical: 30),
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        color: AppThemes.lightPinkBackGroundColor,
        child: Stack(
          children: [
            Center(
                child: Text(
              "tripHistory".tr,
              style: Theme.of(context).textTheme.subtitle1.copyWith(
                  fontSize: 20,
                  fontFamily: 'NunitoSans',
                  fontWeight: FontWeight.w700),
            )),
            GestureDetector(
              onTap: () => Get.back(),
              child: Image.asset(
                AllImages.backIcon,
                height: 25,
                width: 25,
                color: AppThemes.lightWhitebackGroundColor,
              ),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: GestureDetector(
                onTap: () async {
                  final date = await selectAllDate(context,
                      selectedDate: to.selectedDate);
                  if (date != null) {
                    setState(() {
                      to.selectedDate = date;
                      to.onDateChange();
                    });
                  }
                },
                child: Image.asset(
                  AllImages.calender,
                  height: 30,
                  width: 30,
                  color: AppThemes.lightWhitebackGroundColor,
                  fit: BoxFit.cover,
                ),
              ),
            )
          ],
        ),
      );

  generalHistory(context) => Container(
        padding: EdgeInsets.only(left: 40),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              "totalRides".tr + ': ${to.filteredRides.length}',
              style: Theme.of(context).textTheme.headline4.copyWith(
                  fontSize: 18,
                  fontFamily: 'NunitoSans',
                  fontWeight: FontWeight.w900),
            ),
            SizedBox(height: 5),
            Text(
              "selectDate".tr +
                  ': ${dateddMMMyyyy(to.selectedDate)}', //20 Sep 2020
              style: Theme.of(context).textTheme.headline4.copyWith(
                  fontSize: 18,
                  fontFamily: 'NunitoSans',
                  fontWeight: FontWeight.w900),
            ),
          ],
        ),
      );
}
