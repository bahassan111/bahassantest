export default class Helper {


    static escapeHtml(unsafe){
        return unsafe
            .replace(/&amp;/g, "&")
            .replace(/&lt;/g, "<")
            .replace(/&gt;/g, ">")
            .replace(/&quot;/g, "\"")
            .replace(/&#8220;/g, "\"")
            .replace(/&#8221;/g, "\"")
            .replace(/&#039;/g, "'")
            .replace(/&#8211;/g, "-")
            .replace(/&#1128;/g, "-")
            .replace(/&rsquo;/g, "'")
            .replace(/&#8217;/g, "'")
            .replace(/&#8230;/g, "...")
            .replace(/&#038;/g, "&");
    };


    static random(min, max){

        return Math.floor(Math.random() * max) + min;

    }

    static randomColor(){

        let colors = [
            '#1254cc',
            '#00d6fc',
            '#fc403b',
            '#fcd332',
            '#1cffac',
            '#bcfc50',
            '#fc008a',
            '#d379fc',
            '#5d16fc',
        ];

        return colors[this.random(0, colors.length - 1)];

    }
    static randomIcon(){

        let icons = [
            'whatshot',
            'show-chart',
            'bubble-chart',
            'article',
            'label',
            'landscape',
            'local-offer',
        ];

        return icons[this.random(0, icons.length - 1)];

    }

    static catIcon(category){

        switch (category.toLowerCase()) {
            case 'sport' : return 'sports-volleyball';
            case 'international' : return 'public';
            case 'tourism' : return 'house';
            case 'national' : return 'flag';
            case 'business' : return 'business-center';
            case 'music' :case 'musique' : return 'music-note';
            case 'cinema' : return 'local-movies';
            case 'tech' : return 'computer';
            case 'fashion' : return 'checkroom';
            case 'lifestyle' : return 'deck';
            case 'société' : return 'eco';
            case 'santé' : return 'free-breakfast';
            case 'food' : return 'fastfood';
            case 'travel' : return 'airplanemode-active';
            case 'séries' : return 'ondemand-video';
            case 'gaming' : return 'videogame-asset';
            case 'foot' : return 'sports-soccer';
            case 'arts' : return 'color-lens';
            case 'documentary' : return 'videocam';
            case 'health' : return 'medical-services';
            default : return this.randomIcon();
        }


    }

}
