<?php
?>

<div class="excase_list">

    <div class="smart_list">
        <div class="sml_head">
            <div class="sml_search">
                <div>
                    <input data-search=".excase_item" type="search" placeholder="Search ..">
                    <a href="javascript:void(0);"><i class="fas fa-search"></i></a>
                </div>
            </div>
            <div class="sml_actions">

            </div>
        </div>

        <div class="sml_list" id="excases_list">

            <?php foreach($cases as $case){ ?>
                <div data-excase="<?= $case->id; ?>" class="excase_item">
                    <label><?= $case->title; ?></label>
                    <p><?= $case->type_name; ?></p>
                    <span>Project <?= $case->project; ?></span>
                    <div>

                        <span>Added <?= fromNow($case->date_added) ?>, By <?= $case->username ?></span>
                    </div>
                </div>
            <?php } ?>

        </div>
    </div>

</div>
