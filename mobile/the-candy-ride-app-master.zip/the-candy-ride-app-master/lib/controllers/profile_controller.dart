import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:rider_app/controllers/controllers.dart';
import '../constants/constants.dart';
import '../helpers/helpers.dart';
import '../models/models.dart';
import '../ui/components/components.dart';
import 'package:dio/dio.dart' as dio;

class ProfileController extends GetxController {
  static ProfileController to = Get.find();
  static AuthController authTo = Get.find();
  final store = GetStorage();
  NetWorkCall networkCall = NetWorkCall();
  Validator validator = Validator();
  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController fullName = TextEditingController();
  TextEditingController mobileNo = TextEditingController();
  bool isEditFullName = true;
  bool isEditMobileNo = true;
  bool isEditEmailId = true;
  String country;
  PickedFile profileImage;

  updateProfile(
      {int riderId,
      String fullName,
      int mobileNo,
      int countryId,
      String email,
      String base64Image,
      @required String password}) async {
    BotToast.showLoading();
    final result = await networkCall.postRequestWithResponse(
      url: Urls.updateprofile,
      json: {
        Params.riderId: riderId,
        Params.name: fullName,
        Params.mobile: mobileNo,
        Params.countryId: countryId,
        Params.email: email,
        Params.userImage: base64Image,
        Params.password: password
      },
    );
    BotToast.closeAllLoading();

    return result.fold((l) {
      BotToast.showWidget(
        toastBuilder: (_) => ErrorDialog(
          title: "error".tr,
          message: "somethingWentWrong".tr,
        ),
      );
    }, (response) async {
      print("reponse ${response.data['response']}");
      authTo.userModel = UserModel.fromJson(response.data['alldetails']);
      await store.write('user', authTo.userModel.toJson());
      getCurrency(int.parse(authTo.userModel.country));
      BotToast.showWidget(
        toastBuilder: (_) => ErrorDialog(
          title: "success".tr,
          message: response.data['response'],
        ),
      );
    });
  }

  getCurrency(int countryId) async {
    final result = await networkCall.postRequestWithResponse(
      url: Urls.currency,
      json: {
        Params.countryId: countryId,
      },
    );

    return result.fold((l) {
      BotToast.showWidget(
        toastBuilder: (_) => ErrorDialog(
          message: "Error while getting Currency of Your Country ",
        ),
      );
    }, (response) async {
      await store.write('currency', response.data['currency']);
      authTo.currency = response.data['currency'];
    });
  }
}
