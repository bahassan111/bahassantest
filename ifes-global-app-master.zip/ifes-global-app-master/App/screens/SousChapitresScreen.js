import React, { Component } from "react";
import {
  FlatList,
  ScrollView,
  ImageBackground,
  RefreshControl, AsyncStorage
} from "react-native";
import {
  AnimatableManager,
  View,
  Button,
  Constants
} from "react-native-ui-lib"; //eslint-disable-line
import Text from "../components/CustomText";
import { changeLanguage } from "../Redux/actions/FontSizeActions";
import { fetchSousChapitre } from "../Redux/actions/ChapitresActions";
import { connect } from "react-redux";
import Colors from "../constants/Colors";
import Items from "./Items";
import I18n from "../commons/i18n";
import _ from "lodash";
import Config from "../constants/Config";

import * as Animatable from "react-native-animatable";
const images = {
  "33": require("../assets/images/33.png"),
  "34": require("../assets/images/34.png"),
  "35": require("../assets/images/35.png"),
  "36": require("../assets/images/36.png"),
  "37": require("../assets/images/37.png"),
  "38": require("../assets/images/38.png"),
  "39": require("../assets/images/39.png"),
  "40": require("../assets/images/40.png")
};

class SousChapitresScreen extends Component {
  static navigationOptions = ({ navigation }) => ({
    headerRight: (
      <Button
        size="small"
        label={navigation.getParam("lang")}
        avoidMinWidth
        avoidInnerPadding
        bg-green20
        marginH-10
        style={{ paddingHorizontal: 5, fontSize: 10 }}
        onPress={navigation.getParam("changeLanguage")}
      />
    )
  });
  state = {
    loading: false,
    data: [],
    page: 1,
    seed: 1,
    error: null,
    refreshing: false,
    see_more:'',
    rtl:"0"
  };
 async componentDidMount() {
    let lang=await AsyncStorage.getItem('lang');
     let see_more=await AsyncStorage.getItem('see_more');
     let count_languages=await AsyncStorage.getItem('count_languages');
     let rtl=await AsyncStorage.getItem('rtl');
     this.setState({see_more:see_more,rtl:rtl});
    const { navigation } = this.props;
    const chapitre = navigation.getParam("row", {});
    this.fetchData();
    this.props.navigation.setParams({
      changeLanguage: this._changeLanguage,
      lang: count_languages > 1 ? lang : ''
    });
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.lang !== this.props.lang) {
      this.fetchData();
      this.props.navigation.setParams({
        changeLanguage: this._changeLanguage,
        lang: I18n.t("Commons.lang", { locale: this.props.lang })
      });
    }
    if (prevProps.keyword !== this.props.keyword) {
      this.getData();
    }
    if (prevProps.data !== this.props.data) {
      this.getData();
    }
  }

 async fetchData() {

   let lang_index=await AsyncStorage.getItem('lang_index');

    if (lang_index != null) {
      const { navigation } = this.props;
      const chapitre = navigation.getParam("row", {});
      this.props.fetchSousChapitre(lang_index, chapitre.chapitreId);
    }
  }

  _changeLanguage = async() => {

    let id_country=await AsyncStorage.getItem('id_country');
    let lang_index=await AsyncStorage.getItem('lang_index');
    let rtl=await AsyncStorage.getItem('rtl');
    let lang=await AsyncStorage.getItem('lang');
    let lang_index2=await AsyncStorage.getItem('lang_index2');
    let rtl2=await AsyncStorage.getItem('rtl2');
    let lang2=await AsyncStorage.getItem('lang2');
    let lang_header='';
    this.props.changeLanguage();
    this.setState({ data: null });
    await this.setState({rtl:rtl});
    this.changeFields(id_country,lang_index2);

    console.log('index_');
    console.log(lang_index);
    console.log(lang_index2);


    await AsyncStorage.setItem("lang_index", lang_index2);
    await AsyncStorage.setItem("rtl", rtl2);
    await AsyncStorage.setItem("lang", lang2);
    await AsyncStorage.setItem("lang_index2", lang_index);
    await AsyncStorage.setItem("rtl2", rtl);
    await AsyncStorage.setItem("lang2", lang);
    lang_header=lang2;




    this.props.navigation.setParams({
      changeLanguage: this._changeLanguage,
      lang: lang_header
    });

    this.props.changeLanguage();
    this.setState({ data: null });
    const { navigation } = this.props;
    const chapitre = navigation.getParam("row", {});
    this.setState({ chapitre: navigation.getParam("row", {}) });



      this.props.fetchSousChapitre(lang_index2, chapitre.chapitreId);

  };


    async changeFields(id_country,lang_index){

        fetch(
            "http://ifes-esll.com/new/api/includes/encode/index.php",{
                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    post: 'change_lang',
                    id_country: id_country,
                    lang_index: lang_index,
                }),
            }
        )
            .then(res => res.json())
            .then(responseJson => {

                console.log('data fields');
                console.log(responseJson);
                AsyncStorage.setItem("fields", JSON.stringify(responseJson.fields));
                AsyncStorage.setItem("see_more", responseJson.see_more);
                AsyncStorage.setItem("search", responseJson.search);
                AsyncStorage.setItem("see_less", responseJson.see_less);
                AsyncStorage.setItem("homeScreen", responseJson.homeScreen);
                AsyncStorage.setItem("settingScreen", responseJson.settingScreen);
                AsyncStorage.setItem("countries", responseJson.countries);
                AsyncStorage.setItem("change_country", responseJson.change_country);

                this.setState({see_more:responseJson.see_more});

            })
            .catch(error => {
                console.log("error", error);
            });
    }



    getData() {
    const { keyword, data } = this.props;
    var dataSearch = [];
    var filter = null;
    if (keyword.length > 0) {
      filter = _.find(data, function(o) {
        var test = o.titre.toLowerCase().includes(keyword);
        console.log('***********')
        console.log(o.titre)
        console.log('***********')
        return test;
      });
    }

    if (filter != undefined) {
      dataSearch.push(filter);
      this.setState({
        data: dataSearch
      });
    } else {
      if (keyword.length > 0) {
        this.setState({
          data: []
        });
      } else {
        this.setState({
          data: data
        });
      }
    }
  }

  _onRefresh = async () => {

    let lang_index=await AsyncStorage.getItem('lang_index');

    const { navigation } = this.props;
    const chapitre = navigation.getParam("row", {});
    console.log("chapitre on refresh", chapitre);
    this.setState({ chapitre: navigation.getParam("row", {}) });
    this.props.fetchSousChapitre(lang_index, chapitre.chapitreId);
  };

  keyExtractor = item => item.id;

  renderRow(row, id,see_more,rtl) {
    const animationProps = AnimatableManager.presets.fadeInRight;
    const imageAnimationProps = AnimatableManager.getRandomDelay();
    const imageChapitre = Config.SOUS_CHAPITRE_IMAGE + row.imageCover;
    return (
      <Items
        row={row}
        key={id}
        animationProps={animationProps}
        imageAnimationProps={imageAnimationProps}
        imageChapitre={imageChapitre}
        lang={this.props.lang}
        see_more={see_more}
        rtl={rtl}
        onPress={() =>
          this.props.navigation.navigate("DetailChapitre", {
            chapitre: row
          })
        }
      />
    );
  }

  renderHeader = () => {
    const { navigation } = this.props;
    const chapitre = navigation.getParam("row", {});
    return (
      <ImageBackground
        source={images[chapitre.chapitreId]}
        style={{
          justifyDirection: "flex-end",
          padding: 10
          // width: "50%"
        }}
        imageStyle={{
          flex: 1,
          tintColor: Colors.menuItemBg,
          width: "50%",
          opacity: 0.2,
          left: this.props.lang == "fr" ? Constants.screenWidth / 1.5 : 0
        }}
        resizeMode={"contain"}
      >
        <Animatable.View
          animation={"bounceInUp"}
          style={{
            padding: 20
          }}
          column
        >
          <Text
            dark10
            text40
            numberOfLines={2}
            uppercase
            style={{ fontWeight: "bold" }}
          >
            {this.props.lang == "fr"
              ? chapitre.ch_titre_fr
              : chapitre.ch_titre_ar}
          </Text>
          <Text
            dark10
            text70
            numberOfLines={2}
            uppercase
            style={{ fontWeight: "bold", color: Colors.tabBar }}
          >
            {I18n.t("Commons.sousChapitre", { locale: this.props.lang })}
          </Text>
        </Animatable.View>
      </ImageBackground>
    );
  };
  renderFooter = () => {
    if (this.props.isLoadingData == true && this.props.data.length == 0) {
      return (
        <View centerH flex-3 paddingV-50>
          <Text text50 center>
            {I18n.t("Commons.empty_message", { locale: this.props.lang })}
          </Text>
        </View>
      );
    } else {
      return null;
    }
  };

  render() {

      let see_more=this.state.see_more;
      let rtl=this.state.rtl;

    return (
      <View bg-white column flex>
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={this.props.isLoadingData}
              onRefresh={this._onRefresh}
            />
          }
        >
          <FlatList
            ref={flatlist => {
              this.flatlist = flatlist;
            }}
            data={this.state.data}
            renderItem={({ item, index }) => this.renderRow(item, index,see_more,rtl)}
            keyExtractor={this.keyExtractor}
            ListHeaderComponent={this.renderHeader}
            ListFooterComponent={this.renderFooter}
          />
        </ScrollView>
      </View>
    );
  }
}

const mapStateToProps = state => {
  const fontSizeValue = state.fontSize.fontSize;
  const lang = state.fontSize.lang;
  const data = state.sousChapitre.data;
  const isLoadingData = state.sousChapitre.isLoadingData;

  const keyword = state.sousChapitre.keyword || "";

  return {
    fontSizeValue,
    lang,
    isLoadingData,
    data,
    keyword
  };
};

export default connect(
  mapStateToProps,
  {
    changeLanguage,
    fetchSousChapitre
  }
)(SousChapitresScreen);
