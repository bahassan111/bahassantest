import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rider_app/constants/app_themes.dart';
import 'package:rider_app/controllers/controllers.dart';

class HoursSelector extends StatefulWidget {
  const HoursSelector({Key key}) : super(key: key);

  @override
  _HoursSelectorState createState() => _HoursSelectorState();
}

class _HoursSelectorState extends State<HoursSelector> {
  double _currentSliderValue = 0;
  static HomeController to = Get.find();

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: Center(
        child: Container(
          padding: EdgeInsets.all(10),
          margin: EdgeInsets.symmetric(horizontal: 30),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.black),
          ),
          height: 200,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Text(
                  "selectTime".tr,
                  style: Theme.of(context).textTheme.headline2.copyWith(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        height: 1.2,
                      ),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Row(
                textBaseline: TextBaseline.alphabetic,
                children: [
                  Text(
                    _currentSliderValue.toInt().toString(),
                    style: Theme.of(context).textTheme.headline2.copyWith(
                          fontSize: 25,
                          fontWeight: FontWeight.w700,
                        ),
                  ),
                  Text(
                    " hours",
                    style: Theme.of(context).textTheme.headline2.copyWith(
                          fontSize: 15,
                        ),
                  ),
                ],
              ),
              SizedBox(
                height: 20,
              ),
              Slider(
                value: _currentSliderValue,
                min: 0,
                max: 24,
                activeColor: AppThemes.lightpauaBackGroundColor,
                inactiveColor: AppThemes.lightpauaBackGroundColor,
                label: _currentSliderValue.round().toString(),
                onChangeStart: (value) {},
                onChangeEnd: (double value) {},
                onChanged: (double value) {
                  setState(() {
                    _currentSliderValue = value;
                  });
                },
              ),
              SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  GestureDetector(
                    onTap: () {
                      to.charterTime = null;
                      Get.back();
                    },
                    child: Text(
                      "cancel".tr,
                      style: Theme.of(context).textTheme.headline2.copyWith(
                            fontSize: 16,
                          ),
                    ),
                  ),
                  SizedBox(
                    width: 20,
                  ),
                  GestureDetector(
                    onTap: () {
                      to.charterTime = _currentSliderValue.toInt();
                      Get.back(result: to.charterTime);
                    },
                    child: Text(
                      "ok".tr,
                      style: Theme.of(context).textTheme.headline2.copyWith(
                            fontSize: 16,
                          ),
                    ),
                  ),
                  SizedBox(
                    width: 20,
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
