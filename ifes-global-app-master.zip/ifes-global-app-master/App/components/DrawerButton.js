import React from "react";
import PropTypes from "prop-types";
import { DrawerActions } from "react-navigation";
import { TouchableOpacity } from "react-native";
import Icon from "../constants/Icons";

export const DrawerButton = ({ navigation }) => (
  <TouchableOpacity
    onPress={() => navigation.dispatch(DrawerActions.openDrawer())}
  >
    <Icon icon="menu" iconSize={20} key="DrawerButton" />
  </TouchableOpacity>
);
DrawerButton.propTypes = { navigation: PropTypes.object.isRequired };
