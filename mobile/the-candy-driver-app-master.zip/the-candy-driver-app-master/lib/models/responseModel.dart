class ResponseModel {
  int responsecode;
  dynamic response;

  ResponseModel({this.responsecode, this.response});

  ResponseModel.fromJson(Map<String, dynamic> json) {
    responsecode = json['responsecode'];
    response = json['response'];
  }
}
