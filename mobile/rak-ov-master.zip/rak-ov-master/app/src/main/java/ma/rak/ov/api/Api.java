package ma.rak.ov.api;

import ma.rak.ov.bodyResponse.AbonnementResponse;
import ma.rak.ov.bodyResponse.AgentsResponse;
import ma.rak.ov.bodyResponse.BranchementResponse;
import ma.rak.ov.bodyResponse.DevisResponse;
import ma.rak.ov.bodyResponse.ForgetPasswordResponse;
import ma.rak.ov.bodyResponse.HistoriqueAbonnementResponse;
import ma.rak.ov.bodyResponse.HistoriqueBranchementResponse;
import ma.rak.ov.bodyResponse.LoginResponse;
import ma.rak.ov.bodyResponse.OperationResponse;
import ma.rak.ov.bodyResponse.RootResponse;
import ma.rak.ov.bodyResponse.SettingsResponse;
import ma.rak.ov.bodyResponse.StatistiqueResponse;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Query;
import retrofit2.http.QueryName;

public interface Api {
    @FormUrlEncoded
    @POST("auth/refresh_token")
    Call<LoginResponse> auth(@Header("Cookie") String debugCookie,@Header("Authorization") String basicAuth,
                             @Field("grant_type") String grants,
                             @Field("imei") String imei
    );

    @FormUrlEncoded
    @POST("auth/change_password")
    Call<ForgetPasswordResponse> change_password(
            @Field("Username") String Username,
            @Field("old_pass") String old_pass,
            @Field("new_pass") String new_pass
    );

    // TODO: 12/18/20 body or data of statistiques
    @GET("statstiques/1")
    Call<StatistiqueResponse> statstiques();

    @GET("info")
    Call<RootResponse> root();

    // TODO: 12/18/20 body or data of settings
    @GET("settings/abonnement")
    Call<SettingsResponse> settingsAb();

    @GET("settings/branchement")
    Call<SettingsResponse> settingsBr();

    @GET("agents/")
    Call<AgentsResponse> agents();

    @FormUrlEncoded
    @POST("devis")
    Call<DevisResponse> devis(@Header("Cookie") String debugCookie,@Field("search") String search);

    @GET("demandes/abonnement/")
    Call<AbonnementResponse> abonnemnts(@Query("page") int page);

    @GET("demandes/abonnement/all")
    Call<AbonnementResponse> new_abonnemnts(@Query("fdate") String filter_date);
    @GET("demandes/branchement/all")
    Call<BranchementResponse> new_branchement(@Query("fdate") String filter_date);

    @GET("demandes/abonnement/rejetee?_limit=300")
    Call<AbonnementResponse> rejetee(@Query("page") int page);

    @GET("demandes/abonnement/executee?_limit=300")
    Call<AbonnementResponse> executee(@Query("page") int page);

    @GET("demandes/abonnement/non-executee?_limit=300")
    Call<AbonnementResponse> nonExecutee(@Query("page") int page);

    @GET("demandes/abonnement/all")
    Call<AbonnementResponse> allAbonnemnts(@Query("page") int page);

    @FormUrlEncoded
    @POST("demandes/abonnement/executer")
    Call<OperationResponse> executer(
            @Header("Cookie") String debugCookie,
            @Field("status") String status,
            @Field("observation") String observation,
            @Field("date") String date,
            @Field("nature_install") String nature_install,
            @Field("CODCATAB") String CODCATAB,
            @Field("emplacement") String emplacement,
            @Field("etage") String etage,
            @Field("doss_annee") String doss_annee,
            @Field("doss_numm") String doss_numm,
            @Field("num_operation") String num_operation,
            @Field("gerance") String gerance,
            @Field("nature_lot") String nature_lot,
            @Field("avec_devis") String avec_devis,
            @Field("anndos") String anndos,
            @Field("numdos") String numdos,
            @Field("motif") String motif,
            @Field("photo") String photo,
            @Field("lat") String lat,
            @Field("lng") String lng,
            @Field("disj") String disj
    );

    @FormUrlEncoded
    @POST("demandes/branchement/executer")
    Call<OperationResponse> executerBr(
            @Header("Cookie") String debugCookie,
            @Field("status") String status,
            @Field("observation") String observation,
            @Field("date") String date,
            @Field("nature_install") String nature_install,
            @Field("CODCATAB") String CODCATAB,
            @Field("CATEDEVI") String CATEDEVI,
            @Field("annee") String doss_annee,
            @Field("numero") String doss_numm,
            @Field("num_operation") String num_operation,
            @Field("gerance") String gerance,
            @Field("motif") String motif,
            @Field("photo") String photo,
            @Field("lat") String lat,
            @Field("lng") String lng
    );

    @FormUrlEncoded
    @POST("demandes/abonnement/reaffecter")
    Call<OperationResponse> reaffecter(
            @Header("Cookie") String debugCookie,
            @Field("ANNEDOSS") String ANNEDOSS,
            @Field("NUMEDOSS") String NUMEDOSS,
            @Field("NUMOPRAB") String NUMOPRAB,
            @Field("CODEGERA") String CODEGERA,
            @Field("agent") String agent
    );

    @GET("demandes/branchement")
    Call<BranchementResponse> branchements(@Query("page") int page);

    @GET("demandes/branchement/history")
    Call<HistoriqueBranchementResponse> historiquesBr(@Query("page") int page);

    @GET("demandes/abonnement/history")
    Call<HistoriqueAbonnementResponse> historiquesAb(@Query("page") int page);


}
