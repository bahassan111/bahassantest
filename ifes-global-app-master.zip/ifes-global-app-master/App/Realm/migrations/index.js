/**
 * 
 * 
 * @export
 * @param {Realm} oldRealm 
 * @param {Realm} newRealm 
 */
export default function runMigration (oldRealm, newRealm) {
    // if (oldRealm.schemaVersion < 2) {
    //   migratefromVersion1()
    // }
    console.info(`db migrated from ${oldRealm.schemaVersion} to ${newRealm.schemaVersion}`);
  }