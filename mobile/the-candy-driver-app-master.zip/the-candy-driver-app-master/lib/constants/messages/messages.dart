import 'package:get/route_manager.dart';
import 'en_us.dart';

class Messages extends Translations {
  @override
  Map<String, Map<String, String>> get keys => {
        'en_US': enUS,
        'hi_IN': {"hello": "Namskar"}
      };
}
