package ma.rak.ov.models;

import io.realm.RealmObject;

public class Etage extends RealmObject {

    private int ID;
    private String label;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Etage(int ID, String label) {
        this.ID = ID;
        this.label = label;
    }

    public Etage() {
    }

    @Override
    public String toString() {
        return "Etage{" +
                "ID=" + ID +
                ", label='" + label + '\'' +
                '}';
    }
}
