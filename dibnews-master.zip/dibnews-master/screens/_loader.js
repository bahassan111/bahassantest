import React, { Component } from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    ImageBackground,
    ActivityIndicator,
} from "react-native";
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as Localization from 'expo-localization';
import i18n from 'i18n-js';
import {updateData} from "../redux/actions/dataAction";
import storage from "../storage/TwStorage";
import API from "../storage/TwAPIClient";
import fetchNewsData from "../data/NewsData";
import { CommonActions } from '@react-navigation/native';

class Loader extends Component {

    state = {};



    UNSAFE_componentWillMount() {

    }

    render() {
        return (

            <View style={styles.whole}>
                <ActivityIndicator style={styles.loader} size="large" color={this.props.data.theme === 'dark' ? '#fff' : '#000'} />
            </View>

        );
    }

}

const styles = StyleSheet.create({
    whole: {
        flexDirection:'row',
        alignItems: 'center',
        justifyContent: 'center',
    },

    loader:{
      marginBottom: 40,
      marginTop: 40,
    },
});


const mapStateToProps = (state) => {
    const { data } = state;
    return { data }
};

export default connect(mapStateToProps)(Loader);
