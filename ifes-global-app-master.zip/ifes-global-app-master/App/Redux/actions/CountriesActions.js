import {
  PENDING_FETCH_PAYS,
  SET_PAYS_DETAILS,
  SUCCESS_FETCH_PAYS,
  ERROR_FETCH_PAYS,
} from "./types";
import _ from "lodash";
import { AsyncStorage } from "react-native";
import Config from "../../constants/Config";

export function fetchCountriesData(id_country, userID) {
  return (dispatch) => {
    dispatch({ type: PENDING_FETCH_PAYS });
    fetch(Config.API_URL + "includes/encode/index.php", {
      method: "POST",
      body: JSON.stringify({
        post: "addCountry",
        user_id: userID,
        id_country: id_country,
      }),
    })
      .then((res) => res.json())
      .then((responseJson) => {
        dispatch({ type: SET_PAYS_DETAILS, payload: responseJson });
        console.log("countries charged =========> ");
        try {
          AsyncStorage.setItem("id_country", id_country);
          AsyncStorage.setItem("id_lang", responseJson.id_lang);
          AsyncStorage.setItem("lang_index", responseJson.lang_index);
          AsyncStorage.setItem("rtl", responseJson.rtl);
          AsyncStorage.setItem("lang", responseJson.lang2);
          AsyncStorage.setItem("lang_index2", responseJson.lang_index2);
          AsyncStorage.setItem("rtl2", responseJson.rtl2);
          AsyncStorage.setItem("lang2", responseJson.lang);
          AsyncStorage.setItem("fields", JSON.stringify(responseJson.fields));
          AsyncStorage.setItem("see_more", responseJson.see_more);
          AsyncStorage.setItem("search", responseJson.search);
          AsyncStorage.setItem("see_less", responseJson.see_less);
          AsyncStorage.setItem("homeScreen", responseJson.homeScreen);
          AsyncStorage.setItem("settingScreen", responseJson.settingScreen);
          AsyncStorage.setItem("countries", responseJson.countries);
          AsyncStorage.setItem("count_languages", responseJson.count_languages);
          AsyncStorage.setItem("name_country", responseJson.name_country);
          AsyncStorage.setItem("iso_country", responseJson.iso_country);

          dispatch({ type: SUCCESS_FETCH_PAYS });
        } catch (error) {
          console.log("countries error =========> ", error);
          dispatch({ type: ERROR_FETCH_PAYS });
        }
      })
      .catch((error) => {
        console.log("error", error);
        dispatch({ type: ERROR_FETCH_PAYS });
      });
  };
}
