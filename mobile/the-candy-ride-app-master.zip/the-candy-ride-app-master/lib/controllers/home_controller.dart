import 'dart:convert';
import 'dart:ffi';
import "package:latlong/latlong.dart";
import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:logger/logger.dart';
import 'package:rider_app/constants/constants.dart';
import 'package:rider_app/controllers/controllers.dart';
import 'package:rider_app/helpers/helpers.dart';
import 'package:rider_app/models/models.dart';
import 'package:dio/dio.dart' as dio;
import 'package:rider_app/ui/components/components.dart';

class HomeController extends GetxController {
  static HomeController to = Get.find();
  static AuthController authTo = Get.find();

  Status status = Status.none;
  TextEditingController pickUpController = TextEditingController();
  TextEditingController dropAtController = TextEditingController();
  TextEditingController noteController = TextEditingController();
  FocusNode pickUpFocusNode = FocusNode();
  List<ChooseAVehicleModel> typesOfVehicle;
  List<RiderVehicleSubTypeModel> subtypeOfVehicles;
  List<ZoneModel> zoneAreas;
  NetWorkCall networkCall = NetWorkCall();
  MapMatchingModel mapMatchingModel;
  RouteDetailModel routeDetail;
  LatLng currentLocation;
  Features pickUp;
  Features dropAt;
  DateTime preBookingDate;
  TimeOfDay prebookingTime;
  int charterTime;
  ChooseAVehicleModel selectedTypeOfVehicle;
  RiderVehicleSubTypeModel selectedSubTypeOfVehicle;
  int zoneId;
  List<Fleet> availableFleets = [];
  Fleet selectedFleet;

  @override
  void onReady() {
    super.onReady();
    getVehicles();
  }

  Future rideBooking({bool isDialogShow = true}) async {
    try {
      var timeoftheday;
      if (preBookingDate != null) {
        timeoftheday = stringToDateTimeFromDateTime(
          getddMMyyyyHHMMSSInDateTime(
            timeOfDay: prebookingTime,
            dateTime: preBookingDate,
          ),
        );
      }

      var total = (selectedFleet.adminfees ?? 0) +
          (selectedFleet.driverfees ?? 0) +
          (selectedFleet.agentfees ?? 0);
      var time = charterTime ?? 0;

      BotToast.showLoading();
      final result = await networkCall.postRequestWithResponse(
        url: Urls.ridebook,
        json: {
          Params.riderId: int.parse(authTo.userModel.riderid),
          Params.fleetId: int.parse(selectedFleet.fleetId),
          Params.driverId: selectedFleet.driverId,
          Params.fleetfees: selectedFleet.fleetfees.toDouble().toString(),
          Params.adminfees: selectedFleet.adminfees.toDouble().toString(),
          Params.bookType: preBookingDate == null ? 1 : 2,
          Params.prebookTime: getddMMyyyyHHMMSS(
            timeOfDay: prebookingTime,
            dateTime: preBookingDate,
          ),
          Params.adminfees: selectedFleet.adminfees,
          Params.countryId: int.parse(authTo.userModel.country),
          Params.agentId: selectedFleet.agentId,
          Params.pickupaddress: pickUpController.text.trim(),
          Params.pickuplat: pickUp.center[1].toString(),
          Params.pickuplong: pickUp.center[0].toString(),
          Params.dropaddress: dropAtController.text.trim(),
          Params.droplat: dropAt.center[1].toString(),
          Params.droplong: dropAt.center[0].toString(),
          Params.vehicleCategory: int.parse(selectedTypeOfVehicle.id),
          Params.vehicleSubtype: int.parse(selectedSubTypeOfVehicle.id),
          Params.distance:
              (mapMatchingModel.matchings.first.distance / 1000).toString(),
          Params.duration: mapMatchingModel.matchings.first.duration / 60,
          Params.note: noteController.text.trim(),
          Params.driverfees: selectedFleet.driverfees.toString(),
          Params.totalfees: selectedFleet.fare.toString(),
          Params.gatewayfees: selectedFleet.gatewayFee,
          /*((selectedFleet.adminfees ?? 0) +
                (selectedFleet.driverfees ?? 0) +
                (selectedFleet.agentfees ?? 0))
            .toString()*/
          Params.charterTimeCharge: selectedFleet.charterTimeCharge,
          Params.zonedistance: 0,
          Params.paymentmode: 1,
          Params.charterTime: to.charterTime ?? 0,
          Params.zonedistance: 0,
          Params.surge: 0,
          Params.zoneId: zoneId ?? 0,
          Params.fleettax: selectedFleet.fleettax.toDouble(),
          Params.candytechmarkup: selectedFleet.candytechmarkup.toDouble(),
          Params.candytechtax: selectedFleet.candytechtax.toDouble(),
          Params.currency: authTo.currency
        },
      );
      return result.fold((l) => {}, (response) async {
        if (response.statusCode == 200) {
          final riderSetfeedbackResponse = await networkCall.postRequest(
            url: Urls.riderSetfeedback,
            json: {
              Params.riderId: int.parse(authTo.userModel.riderid),
              Params.rideId: response.data['id'],
              Params.driverId: selectedFleet.driverId,
              Params.rating: 0.0,
              Params.feedback: ""
            },
          );
          riderSetfeedbackResponse.fold((l) {
            print(l);
          }, (r) {
            print("response ${r.response}");
            dropAtController.clear();
            to.mapMatchingModel = null;
            if (isDialogShow) {
              if (preBookingDate == null) {
                BotToast.showWidget(
                  toastBuilder: (_) => RideBookSuccessDialog(
                    rideId: response.data['id'],
                  ),
                );
              } else {
                clearData();
                BotToast.showWidget(
                  toastBuilder: (_) => SuccessDialog(
                    title: "success".tr,
                    message: "rideBookSuccessFully".tr,
                    ontap: () {
                      BotToast.cleanAll();
                    },
                  ),
                );
              }
            } else {
              BotToast.closeAllLoading();
              return response.data['id'];
            }
          });
        } else {
          status = Status.none;
          BotToast.showWidget(
            toastBuilder: (_) => ErrorDialog(
              title: "error".tr,
              message: "rideDoesNotBookSuccessFully".tr,
            ),
          );
        }
        // clear data
        //clearData();
        BotToast.closeAllLoading();
      });
    } catch (e) {
      Logger().e(e);
    }
  }

  Future rideReBook(int tripId) async {
    print(
        "authTo.userModel.riderid ${authTo.userModel.riderid} tripId $tripId");
    final result = await networkCall.postRequestWithResponse(
      url: Urls.riderRideRebook,
      json: {
        Params.rideId: tripId,
        Params.riderId: int.parse(authTo.userModel.riderid),
      },
    );

    return result.fold((l) {
      // BotToast.showWidget(
      //     toastBuilder: (_) => ErrorDialog(
      //           title: "Error".tr,
      //           message: l ?? "Unexcpected error during ride Rebooking",
      //         ));
      return;
    }, (r) {
      print("successFully booked again");
    });
  }

  Future cancelTrip(int tripId,
      {bool isLoader = true, bool isCleardata = true}) async {
    if (isLoader) {
      BotToast.showLoading();
    }
    final result = await networkCall.postRequestWithResponse(
      url: Urls.cancelride,
      json: {
        Params.rideId: tripId,
        Params.reason: "",
        Params.statusType: 2,
        Params.cancelDateTime: DateTime.now().toString(),
        Params.bookType: preBookingDate == null ? 1 : 2
      },
    );

    return result.fold((l) {
      // BotToast.showWidget(
      //     toastBuilder: (_) => ErrorDialog(
      //           title: "Error".tr,
      //           message: "Unexcpected error during cancel Trip",
      //         ));
      return;
    }, (r) {
      print("successFully Cancel");
      if (isCleardata) {
        clearData();
      }
      if (isLoader) {
        BotToast.closeAllLoading();
      }
    });
  }

  getSuggestionLocations(String inputText) async {
    String searchUrl = Urls.searchPlacesUrl(inputText);
    final result = await networkCall.getRequest(
      url: searchUrl,
    );

    return result.fold((l) {}, (response) {
      return SearchPlaceModel.fromJson(jsonDecode(response.data));
    });
  }

  // following function will call basic route for path
  Future getRouteBetweenPath() async {
    if (pickUp == null) {
      pickUp = Features(
        center: [currentLocation.longitude, currentLocation.latitude],
      );
    }
    String pickAndDropPins =
        '${pickUp.center.first},${pickUp.center.last};${dropAt.center.first},${dropAt.center.last}';
    print("pickAndDropPins $pickAndDropPins");
    String directionUrl = Urls.getNavigationUrl(pickAndDropPins);

    print("url $directionUrl");
    final result = await networkCall.getRequest(
      url: directionUrl,
    );

    return result.fold((l) {
      pathNotFound();
    }, (response) async {
      routeDetail = RouteDetailModel.fromJson(response.data);

      if (routeDetail.code == "Ok") {
        // print("get path ${routeDetail.routes.first.legs.length}");
        await getMapMatchingPoints();
      } else {
        pathNotFound();
      }
    });
  }

  // this method will get detail points of path
  Future getMapMatchingPoints() async {
    print("HMEEEEEEEEEEEED");
    String points = '';
    List<MapMatchingModel> allMapMatching = [];
    // it 100 is limit to pass points, so to make api will not break set to 90
    int i = 0;
    print(
        "routeDetail.routes.first.legs ${routeDetail.routes.first.legs.length}");

    for (int leg = 0; leg < routeDetail.routes.first.legs.length; leg++) {
      for (int step = 0;
          step < routeDetail.routes.first.legs[leg].steps.length;
          step++) {
        for (int intersection = 0;
            intersection <
                routeDetail
                    .routes.first.legs[leg].steps[step].intersections.length;
            intersection++) {
          if (i < 90) {
            points +=
                '${routeDetail.routes.first.legs[leg].steps[step].intersections[intersection].location.first},${routeDetail.routes.first.legs[leg].steps[step].intersections[intersection].location.last};';
          } else {
            i = 0;
            points +=
                '${routeDetail.routes.first.legs[leg].steps[step].intersections[intersection].location.first},${routeDetail.routes.first.legs[leg].steps[step].intersections[intersection].location.last}';
            MapMatchingModel model = await getMapMatchingBetweenPoints(points);
            points = "";
            if (model != null) {
              allMapMatching.add(model);
            }
          }
          i++;
        }
      }
    }
    points += '${dropAt.center.first},${dropAt.center.last}';
    MapMatchingModel model = await getMapMatchingBetweenPoints(points);
    print("+++++" + model.toString());
    if (model != null) {
      allMapMatching.add(model);
    }

    mapMatchingModel = null;
    print("allMapMatching ${allMapMatching.length}");
    allMapMatching.forEach((element) {
      print("++++++++++++" + element.toString());
      if (mapMatchingModel == null) {
        mapMatchingModel = element;
      } else {
        mapMatchingModel.matchings.first.geometry.coordinates
            .addAll(element.matchings.first.geometry.coordinates);
        mapMatchingModel.matchings.first.duration +=
            element.matchings.first.duration;
        mapMatchingModel.matchings.first.distance +=
            element.matchings.first.distance;
      }
    });

    /*routeDetail.routes.first.legs.forEach((leg) {
      print("leg.steps ${leg.steps.length} ");
      leg.steps.forEach((step) {
        print("step.intersections ${step.intersections.length}");
        step.intersections.forEach((inter) async {
          if (i < 90) {
            print("point ${inter.location.first} ${inter.location.last}");
            points += '${inter.location.first},${inter.location.last};';
          } else {
            MapMatchingModel model = await getMapMatchingBetweenPoints();
          }
          i++;
        });
      });
    });*/

    //  print("total poins $i object $points");
    // points += '${dropAt.center.first},${dropAt.center.last}';
    //String mapMatchingUrl = Urls.getMapMatchingUrl(points);
    // print("mapMatchingUrl $mapMatchingUrl");
  }

  getMapMatchingBetweenPoints(String points) async {
    String mapMatchingUrl = Urls.getMapMatchingUrl(points);

    print("mapMatchingUrl $mapMatchingUrl");
    MapMatchingModel matchingModel;
    final result = await networkCall.getRequest(
      url: mapMatchingUrl,
    );

    return result.fold((l) {
      pathNotFound();
    }, (response) {
      {
        if (response.data['code'] == "NoMatch") {
          pathNotFound();
        } else if (routeDetail.code == "Ok") {
          matchingModel = MapMatchingModel.fromJson(response.data);
          return matchingModel;
          // print("cordinates ${mapMatchingModel.matchings.first.geometry.coordinates}");
        } else {
          pathNotFound();
        }
      }
    });
  }

  Future getVehicles() async {
    BotToast.showLoading();

    final result = await networkCall.getRequest(
      url: Urls.vehicleCategory,
    );

    return result.fold((l) {
      BotToast.closeAllLoading();
      // BotToast.showWidget(
      //     toastBuilder: (_) => ErrorDialog(
      //           title: "Error".tr,
      //           message: l ?? "Unexcpected error during get get Vehicles ",
      //         ));
    }, (response) {
      BotToast.closeAllLoading();
      typesOfVehicle = [];
      response.data['vehicle_details'].forEach((vehicle) {
        typesOfVehicle.add(ChooseAVehicleModel.fromJson(vehicle));
      });
      typesOfVehicle = typesOfVehicle.reversed.toList();
    });
  }

  Future getVehicleCategory(String id) async {
    BotToast.showLoading();
    final result = await networkCall.postRequest(
      url: Urls.vehicleSubtype,
      json: {
        Params.id: id,
      },
    );

    return result.fold((l) {
      BotToast.closeAllLoading();
      // BotToast.showWidget(
      //     toastBuilder: (_) => ErrorDialog(
      //           title: "Error".tr,
      //           message: l ?? "Unexcpected error during get get Vehicles ",
      //         ));

      return;
    }, (response) {
      subtypeOfVehicles = [];
      response.response.forEach((vehicle) {
        subtypeOfVehicles.add(RiderVehicleSubTypeModel.fromJson(vehicle));
      });
      BotToast.closeAllLoading();
    });
  }

  Future getZones(int countryId) async {
    BotToast.showLoading();
    String pickUpString = pickUp.center
        .map((e) => e.toStringAsFixed(2))
        .toList()
        .reversed
        .join(',');
    final result = await networkCall.postRequest(
      url: Urls.zoneRide,
      json: {
        Params.countryId: countryId,
      },
    );

    return result.fold((l) {
      // BotToast.showWidget(
      //     toastBuilder: (_) => ErrorDialog(
      //           title: "Error".tr,
      //           message: "Unexcpected error during get Zones",
      //         ));
      BotToast.closeAllLoading();
      return;
    }, (response) {
      zoneAreas = [];
      if (response.responsecode == 1)
        response.response.forEach((zone) {
          zoneAreas.add(ZoneModel.fromJson(zone));
        });
      zoneAreas.forEach((zone) {
        zone.latlng.forEach((element) {
          print("element.compareLatLngData ${element.compareLatLngData}");
          if (element.compareLatLngData == pickUpString) {
            zoneId = int.parse(element.id);
          }
        });
      });
      BotToast.closeAllLoading();
    });
  }

  Future getFleets() async {
    print(getTimeInHHMM(prebookingTime));
    print("selectedTypeOfVehicle.id ${selectedTypeOfVehicle.id}");
    print(" selectedSubTypeOfVehicle.id ${selectedSubTypeOfVehicle.id}");
    Map data = {
      Params.vehicleCategory: selectedTypeOfVehicle.id, // taxi
      Params.vehicleSubtype: selectedSubTypeOfVehicle.id, // taxi_5
      Params.latitude: pickUp.center[1],
      Params.longitude: pickUp.center[0],
      Params.distance: mapMatchingModel.matchings.first.distance / 1000,
      Params.duration: mapMatchingModel.matchings.first.duration / 60,
      Params.zoneId: zoneId ?? 0,
      /**  
      * fleet id set for specific fleet 
      * setting fleet id to 0 will get all avaialble fleets
      */
      Params.fleetId: authTo.fleetId,
      Params.zoneareaId: 0,
      Params.zonedistance: 0,
      Params.surge: 0,
      Params.bookType: prebookingTime == null ? 1 : 2,
      Params.charterTime: to.charterTime ?? 0,
      Params.countryId: int.parse(authTo.userModel.country),
      Params.prebookTime: getTimeInHHMM(prebookingTime),
    };
    print("data $data");
    final result = await networkCall.postRequest(
      url: Urls.fleetShow,
      json: data,
    );

    return result.fold((l) {
      availableFleets = [];
      status = Status.vehicleSelect;
      // BotToast.showWidget(
      //   toastBuilder: (_) => SuccessDialog(
      //     title: "".tr,
      //     message: "weDoNotHaveRideForSelectedLocation".tr,
      //     ontap: () {
      //       BotToast.cleanAll();
      //     },
      //   ),
      // );
      BotToast.closeAllLoading();
    }, (response) {
      availableFleets = [];
      if (response.responsecode == 1) if (response.response is List)
        response.response.forEach((e) {
          availableFleets.add(
            Fleet.fromJson(e),
          );
        });
      else {
        availableFleets = [];
        status = Status.vehicleSelect;
        BotToast.showWidget(
          toastBuilder: (_) => SuccessDialog(
            title: "".tr,
            message: "weDoNotHaveRideForSelectedLocation".tr,
            ontap: () {
              BotToast.cleanAll();
            },
          ),
        );
      }
      BotToast.closeAllLoading();
    });
  }

  pathNotFound() {
    status = Status.none;
    BotToast.showWidget(
      toastBuilder: (_) => ErrorDialog(
        title: "".tr,
        message: "weDoNotHaveRideForSelectedLocation".tr,
      ),
    );
  }

  getVehicleTypeFromId(int id) {
    for (int i = 0; i < typesOfVehicle.length; i++) {
      if (typesOfVehicle[i].id == id.toString()) {
        return typesOfVehicle[i].name.trim();
      }
    }
  }

  clearData() {
    print("data is clear");
    routeDetail = null;
    preBookingDate = null;
    prebookingTime = null;
    charterTime = null;
    selectedTypeOfVehicle = null;
    selectedSubTypeOfVehicle = null;
    zoneId = null;
    selectedFleet = null;
    to.charterTime = null;
    dropAt = null;
    dropAtController.clear();
    noteController.clear();
  }

  tripId({String type, String id, String bookingType}) {
    return (bookingType == "1" ? 'IB' : "PB") +
        id.toString() +
        type; //int.parse(type) - 1
  }
}
