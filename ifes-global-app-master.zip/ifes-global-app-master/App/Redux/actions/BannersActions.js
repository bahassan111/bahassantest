import {
  PENDING_FETCH_BANNER,
  SET_BANNERS,
  SUCCESS_FETCH_BANNER
} from "./types";
import Config from "../../constants/Config";

export function fetchBanners(id_country) {
  return dispatch => {
    dispatch({ type: PENDING_FETCH_BANNER });
    fetch(Config.API_URL+"includes/encode/index.php/?get=banners&id_country="+id_country)
      .then(res => res.json())
      .then(responseJson => {
        dispatch(
          { type: SET_BANNERS, payload: responseJson },
          { type: SUCCESS_FETCH_BANNER }
        );
      })
      .catch(error => {
        console.log("error", error);
      });
  };
}
