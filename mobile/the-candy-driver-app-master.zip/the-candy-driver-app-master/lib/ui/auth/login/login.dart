import 'package:bot_toast/bot_toast.dart';
import 'package:driver/constants/constants.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:driver/ui/components/components.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class LoginUI extends StatefulWidget {
  LoginUI({Key key}) : super(key: key);

  @override
  _LoginUIState createState() => _LoginUIState();
}

class _LoginUIState extends State<LoginUI> {
  double height, width;
  final AuthController authController = AuthController.to;
  final HomeController homeController = HomeController.to;

  @override
  void initState() {
    super.initState();
    authController.clearSignUpForm();
  }

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomBackButton(),
              SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 20),
                child: Image.asset(
                  AllImages.theCandy,
                  width: (2.5 * width) / 4,
                ),
              ),
              SizedBox(
                height: 30,
              ),
              Container(
                width: width,
                height: 150,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage(
                      AllImages.groupCar,
                    ),
                    fit: BoxFit.fitWidth,
                  ),
                ),
              ),
              form(),
              SizedBox(
                height: 30,
              ),
              loginButton(),
              SizedBox(
                height: 20,
              ),
              Container(
                width: width,
                child: Column(
                  children: [
                    GestureDetector(
                      onTap: () {
                        Get.toNamed('/ForgotPassword');
                      },
                      child: Text(
                        "forgot_password".tr.toUpperCase(),
                        style: Theme.of(context).textTheme.headline4.copyWith(
                            fontSize: 16, fontWeight: FontWeight.w600),
                      ),
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Checkbox(value: false, onChanged: (value) {}),
                        Text(
                          "remember_me".tr,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 30,
                    ),
                    GestureDetector(
                      onTap: () {
                        Get.offAndToNamed('/SignUpUI');
                      },
                      child: Text(
                        "don’thaveAnAccount".tr,
                        style: Theme.of(context).textTheme.headline3.copyWith(
                            fontSize: 16, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  form() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 20),
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            blurRadius: 5,
            color: AppThemes.lightAthensGrayBorderColor,
            spreadRadius: 2,
          )
        ],
      ),
      child: Column(
        children: [
          input(
              title: "mobile_number_email".tr,
              controller: authController.emailController,
              obscureText: false,
              image: AllImages.profileIcon),
          SizedBox(
            height: 15,
          ),
          input(
              title: "password".tr,
              controller: authController.passwordController,
              obscureText: true,
              image: AllImages.passwordIcon),
          SizedBox(
            height: 15,
          ),
        ],
      ),
    );
  }

  loginButton() {
    return GestureDetector(
      onTap: () async {
        if (authController.emailController.text.trim() == "") {
          showErroMessage("please_enter".tr + "email".tr);
        } else if (authController.passwordController.text.trim() == "") {
          showErroMessage("please_enter".tr + "password".tr);
        } else {
          authController.signIn(
              email: authController.emailController.text.trim(),
              password: authController.passwordController.text.trim());
        }
      },
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 20),
        padding: EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: AppThemes.lightRounderAuthButtonColor,
          borderRadius: BorderRadius.circular(30),
        ),
        child: Stack(
          children: [
            Center(
              child: Text(
                "login".tr.toUpperCase(),
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: Container(
                margin: EdgeInsets.only(right: 10),
                padding: EdgeInsets.all(6),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                ),
                child: Icon(
                  Icons.arrow_forward_ios,
                  size: 18,
                  color: AppThemes.lightdeepPinkDropDownIconColor,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  showErroMessage(String message) {
    BotToast.showWidget(
      toastBuilder: (_) => ErrorDialog(
        title: "error".tr,
        message: message,
      ),
    );
  }

  input(
      {String title,
      TextEditingController controller,
      bool obscureText,
      String image}) {
    return Row(
      children: [
        Image.asset(
          image,
        ),
        SizedBox(
          width: 20,
        ),
        Expanded(
          child: FormInputField(
            labelText: title,
            controller: controller,
            obscureText: obscureText,
          ),
        )
      ],
    );
  }
}
