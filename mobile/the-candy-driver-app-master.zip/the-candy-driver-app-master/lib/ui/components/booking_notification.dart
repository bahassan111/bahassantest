import 'package:audioplayers/audio_cache.dart';
import 'package:bot_toast/bot_toast.dart';
import 'package:driver/constants/constants.dart';
import 'package:driver/constants/helpers/helpers.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:driver/ui/components/components.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:intl/intl.dart';

class BookingNotification extends StatefulWidget {
  static HomeController to = Get.find();

  @override
  _BookingNotificationState createState() => _BookingNotificationState();
}

class _BookingNotificationState extends State<BookingNotification> {
  AudioCache cache = AudioCache();
  AudioPlayer player;
  static HomeController to = Get.find();

  @override
  void initState() {
    super.initState();
    startTone();
  }

  startTone() async {
    print(" Tones.instantBookingTone ${Tones.instantBookingTone}");
    player =
        await cache.play(Tones.instantBookingTone).onError((error, stackTrace) {
      print("loop error $error");
      return null;
    }).whenComplete(() {
      print("loop complete");
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
      child: Container(
        color: Colors.white,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            closeButton(),
            header(),
            tripDetail(),
            buttons(),
          ],
        ),
      ),
    );
  }

  buttons() {
    return Container(
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () async {
                player.stop();
                player.dispose();
                BotToast.cleanAll();
                to.homeScreenStatus.value = HomeScreenStatus.TripDetail;
                print("ride id  ${to.rideDetail.id}");
              },
              child: Container(
                padding: EdgeInsets.symmetric(vertical: 8),
                color: AppThemes.lightdeepPinkDropDownIconColor,
                child: Center(
                  child: Text(
                    "accept".tr,
                    style: AppThemes.lightTheme.textTheme.headline2
                        .copyWith(fontWeight: FontWeight.w600, fontSize: 17),
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            child: GestureDetector(
              onTap: () async {
                await player.stop();
                player.dispose();
                BotToast.cleanAll();
                to.rideDetail = null;
              },
              child: Container(
                padding: EdgeInsets.symmetric(vertical: 8),
                color: AppThemes.pauaBorderColor,
                child: Center(
                  child: Text(
                    "reject".tr,
                    style: AppThemes.lightTheme.textTheme.subtitle1.copyWith(
                      fontWeight: FontWeight.w600,
                      fontSize: 17,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  tripDetail() {
    return Container(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            height: 5,
          ),
          Text(
            "passanger_name".tr,
            style: AppThemes.lightTheme.textTheme.headline2
                .copyWith(fontWeight: FontWeight.w600, fontSize: 15),
          ),
          Text(
            BookingNotification.to.rideDetail.fullname,
            style: AppThemes.lightTheme.textTheme.headline2
                .copyWith(fontSize: 14, fontWeight: FontWeight.normal),
          ),
          SizedBox(
            height: 5,
          ),
          Text(
            "booking_id".tr,
            style: AppThemes.lightTheme.textTheme.headline2
                .copyWith(fontWeight: FontWeight.w600, fontSize: 15),
          ),
          Text(
            getBookType(BookingNotification.to.rideDetail.bookType) +
                BookingNotification.to.rideDetail.id +
                BookingNotification.to.rideDetail.categoryCode,
            style: AppThemes.lightTheme.textTheme.headline2
                .copyWith(fontSize: 14, fontWeight: FontWeight.normal),
          ),
          SizedBox(
            height: 5,
          ),
          Text(
            "pick_up_location".tr,
            style: AppThemes.lightTheme.textTheme.headline2
                .copyWith(fontWeight: FontWeight.w600, fontSize: 15),
          ),
          Text(
            BookingNotification.to.rideDetail.pickupaddress,
            textAlign: TextAlign.center,
            style: AppThemes.lightTheme.textTheme.headline2
                .copyWith(fontSize: 14, fontWeight: FontWeight.normal),
          ),
          SizedBox(
            height: 5,
          ),
          Text(
            "drop_off_location".tr,
            style: AppThemes.lightTheme.textTheme.headline2
                .copyWith(fontWeight: FontWeight.w600, fontSize: 15),
          ),
          Text(
            BookingNotification.to.rideDetail.dropaddress,
            textAlign: TextAlign.center,
            style: AppThemes.lightTheme.textTheme.headline2
                .copyWith(fontSize: 14, fontWeight: FontWeight.normal),
          ),
          SizedBox(
            height: 5,
          ),
          Text(
            "booking_type".tr,
            style: AppThemes.lightTheme.textTheme.headline2
                .copyWith(fontWeight: FontWeight.w600, fontSize: 15),
          ),
          Text(
            BookingNotification.to.rideDetail.bookType == '1'
                ? "instant_booking".tr
                : "pre_booking".tr,
            style: AppThemes.lightTheme.textTheme.headline2
                .copyWith(fontSize: 14, fontWeight: FontWeight.normal),
          ),
          SizedBox(
            height: 5,
          ),
          Text(
            "charter_time".tr,
            style: AppThemes.lightTheme.textTheme.headline2
                .copyWith(fontWeight: FontWeight.w600, fontSize: 15),
          ),
          Text(
            (BookingNotification.to.rideDetail.waitingTime.toString() ?? '0') +
                " " +
                "hours".tr,
            style: AppThemes.lightTheme.textTheme.headline2
                .copyWith(fontSize: 14, fontWeight: FontWeight.normal),
          ),
          SizedBox(
            height: 5,
          ),
        ],
      ),
    );
  }

  header() {
    return Container(
      child: Column(
        children: [
          Text(
            "booking_received".tr,
            style: AppThemes.lightTheme.textTheme.headline2
                .copyWith(fontWeight: FontWeight.w600, fontSize: 17),
          ),
          SizedBox(
            height: 5,
          ),
          Text(
            datedayddMMMyyyyhhMMssWithSpace(
                BookingNotification.to.rideDetail.bookDatetime),
            style: AppThemes.lightTheme.textTheme.headline2.copyWith(
              fontWeight: FontWeight.w600,
              fontSize: 15,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15),
            child: Divider(
              indent: 2,
              thickness: 1.5,
              color: AppThemes.lightDividerColor,
            ),
          )
        ],
      ),
    );
  }

  closeButton() {
    return Align(
      alignment: Alignment.topRight,
      child: GestureDetector(
        onTap: () {
          player.stop();
          player.dispose();
          BotToast.cleanAll();
        },
        child: Padding(
          padding: const EdgeInsets.only(top: 5, right: 10),
          child: Icon(
            Icons.close,
            size: 25,
          ),
        ),
      ),
    );
  }
}
