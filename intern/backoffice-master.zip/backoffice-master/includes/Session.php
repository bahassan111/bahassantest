<?php

class Session{

    public function __construct()
    {
        if(!isset($_SESSION)) session_start();
    }

    public function get($key, $default = ''){
        return __($_SESSION)->{$key} ?: $default;
    }


    public function set($obj, $obj2 = FALSE){
        if(gettype($obj) !== "string" && !$obj2){
            __($obj)->each(function ($k, $v){ $_SESSION[$k] = $v; });
        }else{
            $_SESSION[$obj] = $obj2;
        }

        $this->commit();
        return $this;
    }

    public function delete($key){
        if(isset($_SESSION[$key]))
            unset($_SESSION[$key]);
        return $this;
    }

    public function commit(){
        session_commit();
        return $this;
    }


}