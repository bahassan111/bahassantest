import 'package:bot_toast/bot_toast.dart';
import 'package:driver/constants/constants.dart';
import 'package:driver/constants/helpers/helpers.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:driver/models/models.dart';
import 'package:driver/ui/components/components.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dash/flutter_dash.dart';
import 'package:get/get.dart';

class UpcomingItem extends StatefulWidget {
  final String title;
  final RideDetailModel rideDetailModel;
  final bool isNotif;
  UpcomingItem({this.rideDetailModel, this.isNotif = false, this.title});

  @override
  _UpcomingItemState createState() => _UpcomingItemState();
}

class _UpcomingItemState extends State<UpcomingItem> {
  bool isSelected = false;
  static PreBookingController to = Get.find();
  static HomeController homeTo = Get.find();
  static AuthController authTo = Get.find();

  @override
  Widget build(BuildContext context) {
    if (isSelected) {
      return Container();
    } else {
      return Stack(
        alignment: Alignment.bottomCenter,
        children: [
          Container(
            key: Key(widget.rideDetailModel.id),
            width: MediaQuery.of(context).size.width,
            margin: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
            padding: EdgeInsets.only(left: 15, right: 15, top: 20, bottom: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                  color: AppThemes.lightRounderButtonColor, width: 2),
            ),
            child: Column(
              children: [
                if (widget.title != null)
                  Text(
                    widget.title,
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                rideStatusDetail(
                    context,
                    "pick_up_date_and_time".tr + ' :',
                    datedayddMMMyyyyhhMMss(historystringToDateTime(
                        widget.rideDetailModel.bookDate))),
                SizedBox(height: 5),
                rideStatusDetail(
                  context,
                  "booking_number".tr + ' :',
                  "PB" +
                      widget.rideDetailModel.id +
                      widget.rideDetailModel.categoryCode,
                ),
                Divider(
                  color: AppThemes.lightdeepPinkDropDownIconColor,
                  thickness: 2,
                ),
                Row(
                  children: [
                    Image.asset(
                      AllImages.passangerIcon,
                      height: 50,
                      width: 50,
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          rideStatusDetail(context, "passanger_name".tr + ' :',
                              widget.rideDetailModel.fullname), //Completed
                          rideStatusDetail(context, "contact_name".tr + ' :',
                              widget.rideDetailModel.mobile),
                        ],
                      ),
                    )
                  ],
                ),
                SizedBox(height: 10),
                pickUpDropDetail(context),
                SizedBox(height: 10),
                Container(
                  width: Get.width * 0.8,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      rideStatusDetail(
                        context,
                        "charter".tr + ' :',
                        widget.rideDetailModel.waitingTime + " " + "hours".tr,
                      ),
                      rideStatusDetail(
                          context,
                          "fare".tr + " : ",
                          widget?.rideDetailModel?.totalfare ??
                              "--" +
                                  double.parse(
                                          widget?.rideDetailModel?.currency)
                                      .toStringAsFixed(2) ??
                              "--"),
                    ],
                  ),
                ),
                rideStatusDetail(
                    context, "remark".tr + ' :', widget.rideDetailModel.note),
                SizedBox(height: 25),
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              GestureDetector(
                onTap: () async {
                  to.cancelAll(int.tryParse(widget.rideDetailModel.id),);
                
                  homeTo.rideDetail = widget.rideDetailModel;
                  if (widget.isNotif) {
                    BotToast.cleanAll();
                  }
                  // homeTo.selectedJobType = "PB";
                  homeTo.homeScreenStatus.value = HomeScreenStatus.TripDetail;
                  Get.offAllNamed('/HomeUI');
                  // call proceed api
                },
                child: Container(
                  width: 140,
                  height: 50,
                  child: RoundButton(
                    backgroundColor: AppThemes.lightGreenbackGroundColor,
                    text: "proceed".tr,
                    verticalPadding: 8,
                    textStyle: Theme.of(context).textTheme.headline1.copyWith(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1),
                  ),
                ),
              ),
              SizedBox(
                width: 20,
              ),
              GestureDetector(
                onTap: () {
                  if (widget.isNotif) {
                    BotToast.cleanAll();
                  } else {
                    to.cancelLocalNotification(
                        int.tryParse(widget.rideDetailModel.id));
                    /*to.selectPreBooking(
                            preBookingModel: widget.preBookingModel);*/
                    to.cancelPreBooking(
                        rideDetailModel: widget.rideDetailModel);
                    setState(() {
                      isSelected = true;
                    });
                  }
                },
                child: Container(
                  width: 150,
                  height: 50,
                  child: RoundButton(
                    backgroundColor: AppThemes.lightRounderAuthButtonColor,
                    text: widget.isNotif ? "Not Now" : "cancel".tr,
                    verticalPadding: 8,
                    textStyle: Theme.of(context).textTheme.headline1.copyWith(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1),
                  ),
                ),
              ),
            ],
          )
        ],
      );
    }
  }

  pickUpDropDetail(context) => Container(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                SizedBox(height: 8),
                Container(
                  height: 10,
                  width: 10,
                  decoration: BoxDecoration(
                    color: AppThemes.lightdeepPinkDropDownIconColor,
                    shape: BoxShape.circle,
                  ),
                ),
                SizedBox(height: 8),
                Dash(
                  direction: Axis.vertical,
                  length: 40,
                  dashLength: 5,
                  dashGap: 6,
                  dashColor: AppThemes.lightunSelectedIntro.withOpacity(0.5),
                  dashBorderRadius: 4,
                  dashThickness: 5,
                ),
                SizedBox(height: 8),
                Container(
                  height: 10,
                  width: 10,
                  decoration: BoxDecoration(
                    color: AppThemes.lightGreenbackGroundColor,
                    shape: BoxShape.circle,
                  ),
                )
              ],
            ),
            SizedBox(width: 25),
            Expanded(
              child: Column(
                children: [
                  rideLocation(
                    context,
                    "pick-upLocation".tr,
                    widget.rideDetailModel.pickupaddress,
                  ),
                  SizedBox(height: 15),
                  rideLocation(
                    context,
                    "drop-offLocation".tr,
                    widget.rideDetailModel.dropaddress,
                  ),
                ],
              ),
            )
          ],
        ),
      );

  rideLocation(context, String title, String data) => Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            title,
            style: Theme.of(context).textTheme.headline2.copyWith(
                  fontSize: 17,
                  fontFamily: 'NunitoSans',
                  fontWeight: FontWeight.w900,
                ),
            textAlign: TextAlign.center,
          ),
          Row(
            children: [
              Expanded(
                child: Column(
                  children: [
                    Text(
                      data,
                      style: Theme.of(context)
                          .textTheme
                          .headline2
                          .copyWith(fontSize: 15, fontFamily: 'NunitoSans'),
                      maxLines: 2,
                      softWrap: true,
                      overflow: TextOverflow.clip,
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      );

  totalRideFareDetail(context, String title, String data) => Row(
        children: [
          Text(
            title,
            style: Theme.of(context).textTheme.headline2.copyWith(
                fontSize: 17,
                fontFamily: 'NunitoSans',
                fontWeight: FontWeight.w900),
          ),
          Spacer(),
          Text(
            data,
            style: Theme.of(context).textTheme.headline2.copyWith(
                fontSize: 17,
                fontFamily: 'NunitoSans',
                fontWeight: FontWeight.w900),
          ),
          SizedBox(width: 10),
        ],
      );

  rideStatusDetail(context, String title, String data) => Container(
        width: MediaQuery.of(context).size.width * 0.7,
        height: 40,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Flexible(
              flex: 4,
              child: Text(
                title,
                style: Theme.of(context).textTheme.headline2.copyWith(
                    fontSize: 13,
                    fontFamily: 'NunitoSans',
                    fontWeight: FontWeight.w900),
              ),
            ),
            Flexible(
              flex: 3,
              child: Column(
                children: [
                  Text(
                    data,
                    style: Theme.of(context)
                        .textTheme
                        .headline2
                        .copyWith(fontSize: 14, fontFamily: 'NunitoSans'),
                    maxLines: 3,
                    softWrap: true,
                    overflow: TextOverflow.clip,
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ],
        ),
      );
}
