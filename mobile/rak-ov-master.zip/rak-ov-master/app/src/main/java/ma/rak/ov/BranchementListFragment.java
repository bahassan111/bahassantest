package ma.rak.ov;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import io.realm.Realm;
import io.realm.exceptions.RealmException;
import ma.rak.ov.adapter.DemandesAdapter;
import ma.rak.ov.bodyResponse.AbonnementResponse;
import ma.rak.ov.bodyResponse.BranchementResponse;
import ma.rak.ov.models.Abonnement;
import ma.rak.ov.models.Branchement;
import ma.rak.ov.storage.SharedPrefManager;
import ma.rak.ov.ui.main.DemandViewModel;
import ma.rak.ov.ui.main.MainActivity;

public class BranchementListFragment extends Fragment implements
        AdapterView.OnItemSelectedListener {

    public RecyclerView recyclerView;
    private SwipeRefreshLayout swipeContainer;
    private FrameLayout progressOverlay;
    private TabLayout tabLayout;
    private ArrayList<HashMap<String, String>> branchementsList = null;
    private ArrayList<HashMap<String, String>> abonnementList = null;

    String[] status = {"En instance", "Non Executee"};
    int archivePosition = 1;
    int spinnerPosition = 0;

    private TextView listTitle, notFoundMsg;
    private Spinner spinner;

    private DemandViewModel demandViewModel;
    TextView hamMenu;
    DemandesAdapter demandeAdapter = null;

    ArrayList<HashMap<String, String>> newBrResponse = null;
    ArrayList<HashMap<String, String>> newAbResponse = null;
    EditText searchbox;

    public static BranchementFragment newInstance() {
        return new BranchementFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_pending_list_list, container, false);
        listTitle = (TextView) rootView.findViewById(R.id.listTitle);
        tabLayout = (TabLayout) getActivity().findViewById(R.id.tab_layout);
        progressOverlay = rootView.findViewById(R.id.progress_overlay);
        progressOverlay.setVisibility(View.VISIBLE);
        spinner = (Spinner) rootView.findViewById(R.id.status_spinner);
        spinner.setOnItemSelectedListener(this);
        spinner.setVisibility(View.INVISIBLE);

        searchbox = getActivity().findViewById(R.id.search);

        searchbox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                fetchData(archivePosition, searchbox.getText().toString());
            }
        });

        if(((MainActivity)getActivity()).showHisto){
            TabLayout.Tab tab = tabLayout.getTabAt(1);
            tab.select();
        }


        if (SharedPrefManager.getInstance(getActivity()).getMode() == 1) {

        } else {
            progressOverlay.setVisibility(View.VISIBLE);
        }

        hamMenu = getActivity().findViewById(R.id.toolbarUserMenu);
        hamMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // If the navigation drawer is not open then open it, if its already open then close it.
//                Toast.makeText(MainActivity.this, "Toolbar", Toast.LENGTH_SHORT).show();
                showPopup(v);
            }
        });

        recyclerView = rootView.findViewById(R.id.list);

        swipeContainer = rootView.findViewById(R.id.swipeContainer);
        swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                fetchData(archivePosition, searchbox.getText().toString());
                swipeContainer.setRefreshing(false);
            }
        });
        swipeContainer.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light);

        ArrayAdapter aa = new ArrayAdapter(getActivity(), android.R.layout.simple_spinner_item, status);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        aa.notifyDataSetChanged();
        spinner.setAdapter(aa);

        return rootView;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    public void showPopup(View v) {
        PopupMenu popup = new PopupMenu(getActivity(), v);
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {

                    case R.id.action_branchement:
                        if (SharedPrefManager.getInstance(getActivity()).isLogged()) {
                            SharedPrefManager.getInstance(getActivity()).operationMode(1);
                            Toast.makeText(getActivity(), R.string.mode_branchement, Toast.LENGTH_SHORT).show();
                            fetchData(archivePosition, searchbox.getText().toString());
                            spinner.setVisibility(View.INVISIBLE);
                            hamMenu.setText("Branchement");
                            getActivity().finish();
                            startActivity(getActivity().getIntent());
                        }
                        return true;
                    case R.id.action_abonnements:
                        if (SharedPrefManager.getInstance(getActivity()).isLogged()) {
                            SharedPrefManager.getInstance(getActivity()).operationMode(2);
                            Toast.makeText(getActivity(), R.string.mode_abonnement, Toast.LENGTH_SHORT).show();
                            fetchData(archivePosition, searchbox.getText().toString());
                            spinner.setVisibility(View.VISIBLE);
                            hamMenu.setText("Abonnement");
                            getActivity().finish();
                            startActivity(getActivity().getIntent());
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });
        popup.inflate(R.menu.toolbar_menu);
        popup.show();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        demandViewModel = ViewModelProviders.of(this).get(DemandViewModel.class);
        if (SharedPrefManager.getInstance(getActivity()).getMode() == 1) {
            demandViewModel.getBrachments(null, 1, getContext(), 0, "");
        } else {
            demandViewModel.getAbonnements(null, 0, getContext(), "");
        }
        fetchData(archivePosition, searchbox.getText().toString());
    }

    public void fetchData(int status, String search) {
        progressOverlay.setVisibility(View.VISIBLE);
        demandeAdapter = new DemandesAdapter(getActivity(), branchementsList, abonnementList);

        if (SharedPrefManager.getInstance(getActivity()).getMode() == 1) {
            listTitle.setText(getString(R.string.listTitleBrIns));

            demandViewModel.getBrachments(null, 1, getActivity(), status, search);
            newBrResponse = new ArrayList<HashMap<String, String>>();
            demandViewModel.BrResponseMutableLiveData.observe(getActivity(), new Observer<ArrayList<HashMap<String, String>>>() {
                @Override
                public void onChanged(ArrayList<HashMap<String, String>> branchementResponse) {
                    newBrResponse = branchementResponse;
                    demandeAdapter.setList(branchementResponse, null);
                    tabLayout.getTabAt(0).setText("EN INSTANCE (" + branchementResponse.size() + ")");
                }

            });
            if (newBrResponse != null && newBrResponse != null) {


                tabLayout.getTabAt(0).setText("EN INSTANCE (" + newBrResponse.size() + ")");
            }


        } else {
            listTitle.setText(getString(R.string.listTitleAbIns));
            demandViewModel.getAbonnements(null, status, getContext(), search);
            newAbResponse = new ArrayList<HashMap<String, String>>();
            demandViewModel.AbResponseMutableLiveData.observe(getActivity(), new Observer<ArrayList<HashMap<String, String>>>() {
                @Override
                public void onChanged(ArrayList<HashMap<String, String>> abonnementResponse) {
                    demandeAdapter.setList(null, abonnementResponse);
                    newAbResponse = abonnementResponse;
                    tabLayout.getTabAt(0).setText("EN INSTANCE (" + newAbResponse.size() + ")   ");
                }
            });
            if (newAbResponse != null && newAbResponse.size() > 0) {

                tabLayout.getTabAt(0).setText("EN INSTANCE (" + newAbResponse.size() + ")   ");
            }

        }
        progressOverlay.setVisibility(View.INVISIBLE);
        recyclerView.setAdapter(demandeAdapter);
    }

    //Performing action onItemSelected and onNothing selected
    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id) {

        spinnerPosition = position;
        if (position == 0) {
            archivePosition = 1;
        } else if (position == 1) {
            archivePosition = 4;
        }

        fetchData(archivePosition, searchbox.getText().toString());

//        Toast.makeText(getActivity(), "" + archivePosition, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }

}