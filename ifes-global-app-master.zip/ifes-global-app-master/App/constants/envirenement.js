let appId = "222171905870053";

let androidClientId =
  "1093855008880-mvgb2eoqpug7u3kn0ab12nksu7qgpamr.apps.googleusercontent.com";

let iosClientId = __DEV__
  ? "210563957621-9ila4sae4i5hicnlsfrnef13danj647o.apps.googleusercontent.com"
  : "com.googleusercontent.apps.30760096106-o1hfh4amp9viisk6t3797ol4go2tt9d6";

const environment = {};

export default environment;
export { appId, androidClientId, iosClientId };
