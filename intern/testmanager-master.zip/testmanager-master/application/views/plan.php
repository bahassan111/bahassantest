<?php
addJS([
    'assets/js/views/plan.js',
]);

?>


<div class="plan_view" id="plan_view">

    <div class="ppv_header">
        <h3><?= $plan->title; ?></h3>
        <div class="ppv_actions">
            <?php if(hasPermission('plans', 'edit')){?>
                <button data-editplan="<?= $plan->id; ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-pencil"></i> Edit</button>
            <?php } ?>
            <?php if(hasPermission('plans', 'delete')){?>
                <button data-deleteplan="<?= $plan->id; ?>" class="btn btn-sm btn-outline-danger"><i class="fas fa-pencil"></i> Remove</button>
            <?php } ?>
        </div>
    </div>
    <div class="ppv_body">
        <div class="cases_list">

        </div>

        <div class="ppv_cases hidden">
            <div class="ppvc_head">
                <span>Test Cases</span>
                <div>
                    <button class="btn btn-outline-dark btn-sm add_case"><i class="fas fa-plus"></i> add Case</button>
                </div>
            </div>
            <div class="ppvc_list">
                <div class="ppvc_case">
                    <div class="i"><small>1</small></div>
                    <div class="d">
                        <label>Open login page</label>
                        <p>Here is Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse expedita necessitatibus pariatur.</p>
                        <small>Added 5 months ago by admin</small>
                    </div>
                    <div class="a">
                        <div class="dropdown">
                            <a href="javascript:void(0);" class="" id="dropdownMenuButton${plan.id}" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="far fa-edit"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right " aria-labelledby="dropdownMenuButton${plan.id}">
                                <a data-editplan="${plan.id}" class="dropdown-item" href="#"><i class="fas fa-pencil-alt"></i> Edit</a>
                                <a data-deleteplan="${plan.id}" class="dropdown-item" href="#"><i class="fas fa-trash"></i> Delete</a>
                                <a data-deleteplan="${plan.id}" class="dropdown-item" href="#"><i class="fas fa-arrow-up"></i> Send UP</a>
                                <a data-deleteplan="${plan.id}" class="dropdown-item" href="#"><i class="fas fa-arrow-down"></i> Send DOWN</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="ppvc_case">
                    <div class="i"><small>2</small></div>
                    <div class="d">
                        <label>Open login page</label>
                        <p>Here is Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse expedita necessitatibus pariatur.</p>
                        <small>Added 5 months ago by admin</small>
                    </div>
                    <div class="a">
                        <div class="dropdown">
                            <a href="javascript:void(0);" class="" id="dropdownMenuButton${plan.id}" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="far fa-edit"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right " aria-labelledby="dropdownMenuButton${plan.id}">
                                <a data-editplan="${plan.id}" class="dropdown-item" href="#"><i class="fas fa-pencil-alt"></i> Edit</a>
                                <a data-deleteplan="${plan.id}" class="dropdown-item" href="#"><i class="fas fa-trash"></i> Delete</a>
                                <a data-deleteplan="${plan.id}" class="dropdown-item" href="#"><i class="fas fa-arrow-up"></i> Send UP</a>
                                <a data-deleteplan="${plan.id}" class="dropdown-item" href="#"><i class="fas fa-arrow-down"></i> Send DOWN</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<script>
    var plan_id = <?= $plan->id ?: 0 ?>;
</script>
