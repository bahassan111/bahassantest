package ma.rak.ovr.ui.main;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import ma.rak.ovr.LoginActivity;
import ma.rak.ovr.R;
import ma.rak.ovr.api.RetrofitClient;
import ma.rak.ovr.storage.SharedPrefManager;

public class Error extends AppCompatActivity {

    Button relogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_error);

        relogin = findViewById(R.id.relogin);

        relogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logout();
            }
        });

    }

    public void logout(){
        String host = SharedPrefManager.getInstance(this).getBaseUrl();
        SharedPrefManager.getInstance(this).clear();
        RetrofitClient.resetInstance();
        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        SharedPrefManager.getInstance(this).saveBaseUrl(host);


        startActivity(intent);
    }
}