import 'package:rider_app/models/models.dart';

class Matchings {
  double confidence;
  String weightName;
  double weight;
  double duration;
  double distance;
  List<Legs> legs;
  Geometry geometry;

  Matchings(
      {this.confidence,
      this.weightName,
      this.weight,
      this.duration,
      this.distance,
      this.legs,
      this.geometry});

  Matchings.fromJson(Map<String, dynamic> json) {
    confidence = double.parse(json['confidence'].toString());
    weightName = json['weight_name'];
    weight = json['weight'];
    duration = double.parse(json['duration'].toString());
    distance = double.parse(json['distance'].toString());
    if (json['legs'] != null) {
      legs = [];
      json['legs'].forEach((v) {
        legs.add(new Legs.fromJson(v));
      });
    }
    geometry = json['geometry'] != null
        ? new Geometry.fromJson(json['geometry'])
        : null;
  }
}
