import 'package:bot_toast/bot_toast.dart';
import 'package:driver/constants/constants.dart';
import 'package:driver/constants/helpers/helpers.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:driver/models/models.dart';
import 'package:driver/ui/components/components.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dash/flutter_dash.dart';
import 'package:intl/intl.dart';
import 'package:get/get.dart';

class PrebookingItem extends StatefulWidget {
  final PreBookingModel preBookingModel;

  static PreBookingController to = Get.find();

  PrebookingItem({this.preBookingModel});

  @override
  _PrebookingItemState createState() => _PrebookingItemState();
}

class _PrebookingItemState extends State<PrebookingItem> {
  bool isSelected = false;
  static AuthController authTo = Get.find();
  static PreBookingController to = Get.find();

  @override
  Widget build(BuildContext context) {
    return isSelected
        ? Container()
        : Container(
            key: Key(widget.preBookingModel.bookingid),
            width: MediaQuery.of(context).size.width,
            margin: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            padding: EdgeInsets.only(left: 15, right: 15, top: 20, bottom: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                  color: AppThemes.lightAthensGrayBorderColor, width: 2),
            ),
            child: Column(
              children: [
                rideStatusDetail(
                  context,
                  "Pick Up Date".tr + ' :',
                  datedayddMMMyyyyhhMMss(
                    stringToDate(widget.preBookingModel.newprebookingdate),
                  ).split("00:00")[0],
                ),
                rideStatusDetail(
                  context,
                  "Time".tr + ' :',
                  
                   DateFormat("HH:mm").parse(widget.preBookingModel.newprebookingdate.split(" ")[1]).toString().split(' ')[1].split(':00.000')[0],
                  
                ),
                SizedBox(height: 5),
                rideStatusDetail(
                  context,
                  "booking_number".tr + ' :',
                  "PB" +
                      widget.preBookingModel.bookingid +
                      widget.preBookingModel.categoryCode,
                ),
                Divider(
                  color: AppThemes.lightdeepPinkDropDownIconColor,
                  thickness: 2,
                ),
                Row(
                  children: [
                    Image.asset(
                      AllImages.passangerIcon,
                      height: 50,
                      width: 50,
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          rideStatusDetail(context, "passanger_name".tr + ' :',
                              widget.preBookingModel.fullname),
                          rideStatusDetail(context, "contact_name".tr + ' :',
                              widget.preBookingModel.mobile),
                        ],
                      ),
                    )
                  ],
                ),
                SizedBox(height: 10),
                pickUpDropDetail(context),
                SizedBox(height: 10),
                rideStatusDetail(
                  context,
                  "fare".tr + ' :',
                  "${widget.preBookingModel.currency} " +
                      numberFormating.format(
                        double.tryParse("${widget.preBookingModel.totalfare}")
                            .toPrecision(2),
                      ),
                ),
                rideStatusDetail(context, "charter_time".tr + ' :',
                    "${widget.preBookingModel.waitingTime}" + ' ' + 'hours'.tr),
                SizedBox(height: 5),
                rideStatusDetail(
                    context, "remark".tr + ' :', widget.preBookingModel.remark),
                SizedBox(height: 15),
                GestureDetector(
                  onTap: () async {
                    var hasPreBook = await to.checkPreBooking();
                    if (hasPreBook) {
                      BotToast.closeAllLoading();

                      BotToast.showWidget(
                          toastBuilder: (_) => ErrorDialog(
                                title: "ALready had a selcted ride ",
                                message:
                                    'Go to Upcoming Jobs Folder to check your selected ride details',
                              ));
                    } else {
                      BotToast.closeAllLoading();
                      to.showNotif();
                      to.setLocalNotification(
                        id: int.tryParse(widget.preBookingModel.bookingid),
                        prebookingTime: stringToDateTime2(
                            widget.preBookingModel.prebookingdate),
                      );
                      to.id = int.tryParse(widget.preBookingModel.bookingid);

                      PrebookingItem.to.selectPreBooking(
                          preBookingModel: widget.preBookingModel);
                      setState(() {
                        isSelected = true;
                      });
                    }
                  },
                  child: Container(
                    width: 250,
                    child: RoundButton(
                      text: "select_job".tr,
                      verticalPadding: 8,
                      textStyle: Theme.of(context)
                          .textTheme
                          .headline1
                          .copyWith(fontSize: 15, fontWeight: FontWeight.w600),
                    ),
                  ),
                )
              ],
            ),
          );
  }

  pickUpDropDetail(context) => Container(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                SizedBox(height: 8),
                Container(
                  height: 10,
                  width: 10,
                  decoration: BoxDecoration(
                    color: AppThemes.lightdeepPinkDropDownIconColor,
                    shape: BoxShape.circle,
                  ),
                ),
                SizedBox(height: 8),
                Dash(
                  direction: Axis.vertical,
                  length: 40,
                  dashLength: 5,
                  dashGap: 6,
                  dashColor: AppThemes.lightunSelectedIntro.withOpacity(0.5),
                  dashBorderRadius: 4,
                  dashThickness: 5,
                ),
                SizedBox(height: 8),
                Container(
                  height: 10,
                  width: 10,
                  decoration: BoxDecoration(
                    color: AppThemes.lightGreenbackGroundColor,
                    shape: BoxShape.circle,
                  ),
                )
              ],
            ),
            SizedBox(width: 25),
            Expanded(
              child: Column(
                children: [
                  rideLocation(
                    context,
                    "pick-upLocation".tr,
                    widget.preBookingModel.pickupaddress,
                  ),
                  SizedBox(height: 15),
                  rideLocation(
                    context,
                    "drop-offLocation".tr,
                    widget.preBookingModel.dropaddress,
                  ),
                ],
              ),
            )
          ],
        ),
      );

  rideLocation(context, String title, String data) => Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            title,
            style: Theme.of(context).textTheme.headline2.copyWith(
                  fontSize: 17,
                  fontFamily: 'NunitoSans',
                  fontWeight: FontWeight.w900,
                ),
            textAlign: TextAlign.center,
          ),
          Row(
            children: [
              Expanded(
                child: Column(
                  children: [
                    Text(
                      data,
                      style: Theme.of(context)
                          .textTheme
                          .headline2
                          .copyWith(fontSize: 15, fontFamily: 'NunitoSans'),
                      maxLines: 2,
                      softWrap: true,
                      overflow: TextOverflow.clip,
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      );

  totalRideFareDetail(context, String title, String data) => Row(
        children: [
          Text(
            title,
            style: Theme.of(context).textTheme.headline2.copyWith(
                fontSize: 17,
                fontFamily: 'NunitoSans',
                fontWeight: FontWeight.w900),
          ),
          Spacer(),
          Text(
            data,
            style: Theme.of(context).textTheme.headline2.copyWith(
                fontSize: 18,
                fontFamily: 'NunitoSans',
                fontWeight: FontWeight.w900),
          ),
          SizedBox(width: 10),
        ],
      );

  rideFareDetail(context, String title, String data) => Row(
        children: [
          Text(
            title,
            style: Theme.of(context)
                .textTheme
                .headline2
                .copyWith(fontSize: 15, fontFamily: 'NunitoSans'),
          ),
          Spacer(),
          Text(
            data,
            style: Theme.of(context)
                .textTheme
                .headline2
                .copyWith(fontSize: 15, fontFamily: 'NunitoSans'),
          ),
          SizedBox(width: 10),
        ],
      );

  rideStatusDetail(context, String title, String data) => Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: Theme.of(context).textTheme.headline2.copyWith(
                fontSize: 15,
                fontFamily: 'NunitoSans',
                fontWeight: FontWeight.w900),
          ),
          SizedBox(width: 5),
          Expanded(
            child: Text(
              data,
              style: Theme.of(context)
                  .textTheme
                  .headline2
                  .copyWith(fontSize: 15, fontFamily: 'NunitoSans'),
              maxLines: 2,
            ),
          ),
        ],
      );
}
