import 'package:driver/ui/ui.dart';
import 'package:get/get.dart';

class AppRoutes {
  AppRoutes._();
  static final routes = [
    GetPage(name: '/', page: () => SplashUI()),
    GetPage(name: '/SignUpUI', page: () => SignUpUI()),
    GetPage(name: '/LoginUI', page: () => LoginUI()),
    GetPage(name: '/ForgotPassword', page: () => ForgotPassword()),
    GetPage(name: '/IntroUI', page: () => IntroUI()),
    GetPage(name: '/LanguageUI', page: () => LanguageUI()),
    GetPage(name: '/HomeUI', page: () => HomeUI()),
    GetPage(name: '/TripHistoryUI', page: () => TripHistoryUI()),
    GetPage(name: '/PrebookingJobsUI', page: () => PrebookingJobsUI()),
    GetPage(name: '/MyWallet', page: () => MyWallet()),
    GetPage(name: '/UpbookingJobsUI', page: () => UpbookingJobsUI()),
  ];
}
