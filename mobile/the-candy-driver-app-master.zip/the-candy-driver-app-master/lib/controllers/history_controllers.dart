import 'package:bot_toast/bot_toast.dart';
import 'package:driver/constants/constants.dart';
import 'package:driver/constants/helpers/helpers.dart';
import 'package:driver/models/models.dart';
import 'package:driver/ui/components/error_dialog.dart';
import 'package:get/get.dart';
import 'package:logger/logger.dart';
import 'controllers.dart';
import 'package:dio/dio.dart' as dio;

class HistoryController extends GetxController {
  static HistoryController to = Get.find();
  static AuthController authTo = Get.find();

  List<DriverEwalletModel> driverEwalletDetails;
  List<RideDetailModel> rideDetails;
  List<RideDetailModel> filteredRides = [];

  double totalwalletsum = 0;
  DateTime selectedDate = DateTime.now();

  NetWorkCall netWorkCall = NetWorkCall();
  Future getDriverEwallet() async {
    final result = await netWorkCall
        .postRequestWithResponse(url: Urls.driverEwallet, json: {
      Params.driverId: authTo.userModel.id,
    });
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return [];
    }, (response) {
      print("_responses ${response.data}");
      if (response != null) {
        final data = response.data;
        print("TOtal WALAAET SUM IS " + data['totalwalletsum'].toString());
        driverEwalletDetails = [];
        totalwalletsum = double.tryParse(data['totalwalletsum'].toString());
        data['ridedetails'].forEach((e) {
          driverEwalletDetails.add(DriverEwalletModel.fromJson(e));
        });
      }
      return driverEwalletDetails;
    });
  }

  Future getDriverHistory() async {
    print("authTo.userModel.id ${authTo.userModel.id}");

    final result = await netWorkCall.postRequestWithResponse(
      url: Urls.tripHistory,
      json: {
        Params.id: authTo.userModel.id,
      },
    );
    return result.fold((l) {
      BotToast.showWidget(
          toastBuilder: (_) => ErrorDialog(
                title: "Error".tr,
                message: l ?? "unexcpected error occured",
              ));
      BotToast.closeAllLoading();
      return [];
    }, (response) {
      if (response != null) {
        final data = response.data;
        rideDetails = [];
        Logger logger = Logger();
        logger.wtf("____" + data['totalwalletsums'].toString());
        totalwalletsum = double.tryParse(data['totalwalletsums'].toString());
        data['mytrip'].forEach((e) {
          rideDetails.add(RideDetailModel.fromJson(e));
          if (isSameDate(historystringToDateTime(rideDetails.last.bookDate),
              selectedDate)) {
            filteredRides.add(rideDetails.last);
          }
        });
      }
      return driverEwalletDetails;
    });
  }

  onDateChange() {
    print("to.selectedDate ${to.selectedDate}");
    filteredRides.clear();
    rideDetails.forEach((ride) {
      if (isSameDate(historystringToDateTime(ride.bookDate), to.selectedDate)) {
        filteredRides.add(ride);
      }
    });
  }
}
