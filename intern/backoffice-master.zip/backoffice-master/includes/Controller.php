<?php

class Controller{

    public $db;
    public $lang;
    public function __construct()
    {
        $this->db = new Database(config()->db_host, config()->db_user, config()->db_password, config()->db_name, config()->port);
        $this->lang = currentLanguage();


    }

    public function regions(){
        $list = $this->db->get('regions', ['deleted' => 0]);

        responseJSON([
            'status' => 'OK',
            'data' => $list,
        ]);
    }

    public function files(){
        $list = $this->db->query("SELECT * FROM files WHERE deleted = 0 and lang is not null AND file is not null");

        foreach ($list as $item){
            $item->file = site_url("/uploads/". $item->file);
        }

        responseJSON([
            'status' => 'OK',
            'data' => $list,
        ]);
    }


}