import 'package:driver/controllers/controllers.dart';
import 'package:driver/ui/auth/signup/header.dart';
import 'package:flutter/material.dart';

import 'emergency_contact_details.dart';
import 'personal_details.dart';
import 'your_bank_details.dart';
import 'your_vehicle_details.dart';
import 'package:get/get.dart';

class SignUpUI extends StatefulWidget {
  SignUpUI({Key key}) : super(key: key);

  @override
  _SignUpUIState createState() => _SignUpUIState();
}

class _SignUpUIState extends State<SignUpUI> {
  double height, width;
  String dropdownValue;

  final AuthController authController = AuthController.to;

  @override
  void initState() {
    super.initState();
    authController.clearSignUpForm();
  }

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;

    return SafeArea(
      child: Scaffold(
        body: SingleChildScrollView(
          child: Container(
            width: width,
            padding: EdgeInsets.symmetric(horizontal: 10),
            child: Column(
              children: [
                Header(),
                PersonalDetails(),
                YourVehicleDetails(),
                YourBankDetails(),
                EmergencyContactDetails(),
                if (authController.userModel == null)
                  GestureDetector(
                    onTap: () {
                      Get.offAndToNamed('/LoginUI');
                    },
                    child: Text(
                      "already_have_account".tr,
                      style: Theme.of(context)
                          .textTheme
                          .headline3
                          .copyWith(fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                  ),
                if (authController.userModel == null)
                  SizedBox(
                    height: 30,
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
