import 'package:flutter/material.dart';
import 'package:rider_app/constants/app_themes.dart';

class AdditionalComment extends StatelessWidget {
  AdditionalComment({
    this.onChanged,
    this.onSaved,
    this.controller,
    this.hintText,
  });
  final void Function(String) onChanged;
  final void Function(String) onSaved;
  final TextEditingController controller;
  final String hintText;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(8),
      decoration: BoxDecoration(
          color: AppThemes.lightWhitebackGroundColor,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: AppThemes.lightBoxshadow.withOpacity(0.15),
              blurRadius: 5,
              spreadRadius: 3,
              offset: Offset(0, 4),
            )
          ]),
      child: TextFormField(
        controller: controller,
        style: Theme.of(context).textTheme.headline4.copyWith(fontSize: 15),
        decoration: InputDecoration(
            hintText: hintText,
            border: InputBorder.none,
            contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 10)),
        maxLines: 3,
      ),
    );
  }
}
