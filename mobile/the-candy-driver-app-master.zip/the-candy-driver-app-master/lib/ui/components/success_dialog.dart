import 'package:driver/constants/app_themes.dart';
import 'package:flutter/material.dart';
import 'package:driver/ui/components/components.dart';
import 'package:get/get.dart';

class SuccessDialog extends StatelessWidget {
  const SuccessDialog({Key key, this.message, this.title, this.ontap})
      : super(key: key);
  final String title;
  final String message;
  final Function ontap;
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      content: Container(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              height: 10,
            ),
            Text(
              message,
              style:
                  Theme.of(context).textTheme.headline2.copyWith(fontSize: 20),
              textAlign: TextAlign.center,
            ),
            SizedBox(
              height: 30,
            ),
            Container(
              padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
              width: 175,
              child: RoundButton(
                onTap: ontap,
                text: "ok".tr,
                backgroundColor: AppThemes.lightRounderAuthButtonColor,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
