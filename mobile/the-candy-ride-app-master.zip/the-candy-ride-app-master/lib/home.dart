import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:location_permissions/location_permissions.dart';

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        padding: EdgeInsets.only(left: 10.0, top: 40.0),
        alignment: Alignment.center,
        child: Column(children: <Widget>[PopupView()]),
      ),
    );
  }
}

class PopupView extends StatelessWidget {
  Future<void> getLocationOfUser(context) async {
    PermissionStatus permission =
        await LocationPermissions().requestPermissions();
    if (permission == PermissionStatus.granted)
      log('location is granted');
    else if (permission == PermissionStatus.denied)
      log('location denied');
    else if (permission == PermissionStatus.unknown) log('location unknown');
    Navigator.pop(context, 'OK');
  }

  _showOpenDialouge(context) async {
    await showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text(
                "Location permission: The Candy Ride app collects location data to indentify nearby customers and drivers, even when the app is closed or not in use"),
            content: SingleChildScrollView(
                child: Text("The Candy Rider app collects location data")),
            actions: [
              TextButton(
                onPressed: () => {
                  getLocationOfUser(context),
                },
                child: Text('OK'),
              )
            ],
          );
        },
        barrierDismissible: false);
  }

  @override
  Widget build(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _showOpenDialouge(context);
    });
    return Text('');
  }
}
