(function () {
    var view = $('#plan_view');
    if(!view.length) return;

    var table = $('.cases_list');

    view

        .on('click', '[data-deletecase]', function () {
            var id = this.dataset.caseid;

            deleteCase(id);
        })
        .on('click', '.add_case', function () {
            var id_plan = $(this).data('planid');
            addCase(id_plan);
        })
        .on('click', '[data-editcase]', function () {
            var id = $(this).data('caseid');
            editCase(id);
        })
        .on('click', '[data-testrun]', function () {
            var id = this.dataset.testrun;

            ajaxModal('project/run_test/' + id, 'Test run', '', 'fas fa-play', {

                hide_header : true,

                close_text : 'Cancel',
                confirm_text : 'RUN TEST',


                whenLoaded : function(modal, data){
                    modal.find('.confirm').addClass('run');
                },
                whenConfirm : function(modal, data){
                    var btn = modal.find('.confirm');

                    if(btn.hasClass('run')){
                        btn.removeClass('runi').prop('disabled', true);
                        var inner = modal.find('.test_runner > .b .stat');

                        inner.html('<div class="l">Running ..</div>');

                        post('project/run/', {id : id, type : 'test'}, function (rep) {



                            inner.html(`<div class="r">
                                <label>Run finished!</label>
                                <div>
                                    <label>Result :</label>
                                    <div class="p">
                                        
                                    </div>
                                    <div class="re">
                                        <div class="result_${rep.result.toLowerCase()}">${rep.result}</div>
                                    </div>
                                </div>
                            </div>`);

                            $.each(rep.props, function () {
                                inner.find('.r .p').append(`<div><span class="k">${this.name}</span><span class="v">${this.value}</span></div>`);
                            });


                        }, function () {
                            btn.removeClass('runed').prop('disabled', false);
                        }, function () {
                            inner.html('<div class="tx-danger text-sm-center">FAILED TO RUN THE TEST</div>');
                        })



                    }else{

                    }

                },
                whenError : function(modal, error){},
                whenClosed : function(modal){},

            });


        })
        .on('click', '.cases_table > tbody tr', function () {
            $(this).toggleClass('active').parent().find('tr.active').not(this).removeClass('active');

            if($(this).hasClass('active')){
                view.trigger('case_selected', $(this).data('casetr'));
            }else{
                view.trigger('case_unselected', $(this));
            }

        })
        .on('case_selected', function (e, id) {
            log(id);
            $('.clist_actions button').attr('data-caseid', id).attr('r', true).prop('disabled', false);
            $('.clist_actions .exp')
                .attr('download', 'case_' + id + '.json')
                .attr('href', site_url + 'project/export_case/' + id);
        })
        .on('case_unselected', function () {
            $('.clist_actions button[r]').not('.g').removeAttr('data-caseid').prop('disabled', true);
            $('.clist_actions .exp').attr('href', 'javascript:void(0);')
        })
        .on('click', '.refresh_cases', function () {
            table.twTable('refresh')
        })

        .on('click', '.add_existing', function () {
            addCaseExisting(plan_id);
        })





        .on('click', '.tcl_item', function () {
            var item = $(this);

            $('.test_cases_list').find('.selected').removeClass('selected');
            item.addClass('selected');


        })
        .on('click', '.copycase[data-caseid]', function () {
            var id = this.dataset.caseid;
            copyCase(id);
        })
        .on('click', '.previewcase[data-caseid]', function () {
            var id = this.dataset.caseid;
            openCase(id);
        })
        .on('dblclick', '[data-casetr]', function () {
            openCase(this.dataset.casetr);
            if(!$(this).hasClass('active')){
                $(this).trigger('click');
            }
        })




        .ready(function () {

            log(table);

            table.twTable({

                url     : site_url + 'project/get_cases/' + plan_id,
                key     : 'id',
                order   : 4,
                order_dir : 'asc',

                dblclick : function(id, tr){
                    showCase(id);
                },

                columns : [
                    {name : 'id', data : 'ref', title : 'REF', orderable : true, searchable : true},
                    {name : 'title', data : 'title', title : 'Name', orderable : true, searchable : true},
                    {name : 'type', data : 'type_name', title : 'Type', orderable : true, searchable : true},
                    {name : 'last_run', data : 'last_run', title : 'Last Run', orderable : true, searchable : true},
                    {name : 'order', data : 'order', title : 'Order', orderable : true, searchable : true},
                    {name : 'desc', data : 'desc', title : 'Note', orderable : true, searchable : true},
                ],

                buttons : [
                    {
                        text : 'Add',
                        icon : 'fas fa-plus',
                        color : 'primary',
                        global : true,
                        remote : 'add',
                        action : function(){
                            addCase(plan_id);
                        },
                    },
                    {
                        title : 'Add Existing',
                        icon : 'far fa-plus-square',
                        color : 'primary',
                        global : true,
                        remote : 'add',
                        action : function(){
                            addCaseExisting(plan_id);
                        },
                    },
                    {
                        separator : true,
                    },



                    {
                        icon : 'far fa-copy',
                        global : false,
                        remote : 'add',
                        action : function(id){
                            copyCase(id, plan_id);
                        },
                    },
                    {
                        icon : 'far fa-eye',
                        global : false,
                        action : function(id){
                            showCase(id);
                        },
                    },
                    {
                        title : 'Test Run this case',
                        icon : 'far fa-paper-plane',
                        global : false,
                        remote : 'test',
                        condition: function(row){
                            return row.run_type === 'auto';
                        },
                        action : function(id){
                            testAcase(id);
                        },
                    },
                    {
                        separator : true,
                    },
                    {
                        icon : 'fas fa-pencil-alt',
                        global : false,
                        remote : 'edit',
                        action : function(id){
                            editCase(id);
                        },
                    },
                    {
                        icon : 'fas fa-times',
                        global : false,
                        remote : 'delete',
                        action : function(id){
                            deleteCase(id);
                        },
                    },
                    {
                        separator : true,
                    },
                    {
                        icon : 'fas fa-arrow-up',
                        global : false,
                        remote : 'edit',
                        condition : function(row){ return row.order > 1},
                        action : function(id){
                            orderCase(id, 'UP');
                        },
                    },
                    {
                        icon : 'fas fa-arrow-down',
                        global : false,
                        remote : 'edit',
                        condition : function(row){

                            return row.order < table.find('[data-trkey]').length;
                        },
                        action : function(id){
                            orderCase(id, 'DOWN');
                        },
                    },

                ],

            });
        })
    ;





    function openCase(id) {
        showCase(id);
    }

    function copyCase(id, id_plan, then) {
        id_plan = id_plan || '';

        post('project/copy_case/' + id + '/' + id_plan, {}, function (rep) {
            if(rep.status === 'OK'){

                table.twTable('refresh', function () {
                    table.twTable('select', id);
                    editCase(rep.id);
                })


            }else{
                toastr_('Error while creating a copy of the selected case', 'error', 'danger', 9000);
            }
        }).always(function () {
            (then || function(){})();
        })
    }

    function addCase(id_plan) {
        ajaxSideModal('project/one_case/', 'Create Test Case', 'far fa-paper-plane', {
            close_text : 'Cancel',
            confirm_text : 'Save',
            size: 'md',
            whenLoaded : function(modal, data){
                $('.selectpicker').selectpicker();
            },
            whenConfirm : function(modal, data){
                modal.find('#case_form_view form').submit();
                table.twTable('refresh');
            },
            whenError : function(modal, error){},
            whenClosed : function(modal){},
            post_data : {id_plan : id_plan}

        });
    }
    function addCaseExisting(id_plan) {
        ajaxSideModal('project/existing_case/' + id_plan, 'Import existing Test Case', 'far fa-paper-plane', {
            close_text : 'Cancel',
            size : 'md',
            confirm_text : 'Import',
            whenLoaded : function(modal, data){

                modal.find('.confirm').prop('disabled', true);
                modal
                    .on('click', '.excase_item', function () {
                        var on = $(this).toggleClass('selected').hasClass('selected');
                        $(this).parent().find('.selected').not(this).removeClass('selected');

                        modal.find('.confirm').prop('disabled', !on);
                    })

            },
            whenConfirm : function(modal, data){

                var id = modal.find('.excase_item.selected').data('excase');
                if(!id) return;

                modal.find('input, textarea, button').prop('disabled', true);

                copyCase(id, plan_id, function () {
                    modal.sideModal('hide');
                });
            },
            whenError : function(modal, error){},
            whenClosed : function(modal){
                table.twTable('refresh');
            },

        });
    }
    function editCase(id) {
        ajaxSideModal('project/one_case/'+id, 'Create Test Case', 'far fa-paper-plane', {
            close_text : 'Cancel',
            confirm_text : 'Save',
            size: 'md',
            whenLoaded : function(modal, data){
                $('.selectpicker').selectpicker();
            },
            whenConfirm : function(modal, data){
                modal.on('submit_finished', function () {
                    log('finished');
                    modal.sideModal('hide');
                    table.twTable('refresh',function () {
                        table.twTable('select', id);
                    });
                });
                modal.find('form').submit();

            },
            whenError : function(modal, error){},
            whenClosed : function(modal){

            },

        });
    }
    function deleteCase(id) {
        ask('Are you sure?', 'Do you really want to delete this Test Case?, this action will clear all the records for this test.', function (yes) {

            if(yes){

                post('project/delete_case/' + id, {}, function (rep) {
                    if(rep.status === 'OK'){
                        toastr_('The case was successfully deleted!', 'success', 'success');
                        table.twTable('refresh');
                        view.trigger('case_unselected');
                    }else{
                        toastr_("We couldn't remove the selected case", 'error', 'danger');
                    }
                })

            }else{

            }

        }, 'Yes', 'Cancel', true);
    }
    function orderCase(id, dir) {
        post('project/order_case/' + id + '/' + dir, {}, function (rep) {
            if(rep.status === 'OK'){
                table.twTable('refresh', function () {
                    table.twTable('select', id);
                });
                view.trigger('case_unselected');
            }else{
                toastr_("We couldn't remove the selected case", 'error', 'danger');
            }
        })
    }

})();