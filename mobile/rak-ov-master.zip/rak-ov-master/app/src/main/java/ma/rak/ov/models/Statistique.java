package ma.rak.ov.models;

public class Statistique {
}
