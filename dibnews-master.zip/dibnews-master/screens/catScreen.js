import React, { Component, useState, useEffect, useRef  } from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    ImageBackground,
    ActivityIndicator,
    Button, Dimensions,
    TouchableOpacity,
    Animated, AppState, SafeAreaView,ScrollView,
    BackHandler,Alert
} from "react-native";

import HTMLView from 'react-native-htmlview';
import YoutubePlayer from "react-native-youtube-iframe";
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {updateData} from "../redux/actions/dataAction";
import TopHeader from "../componants/TopHeader";
import css, {colors, sizes} from "../global/GlobalStyle";
import Carousel from 'react-native-snap-carousel';
import GestureRecognizer from 'react-native-swipe-gestures';
import Loader from "./_loader";
import {AntDesign, FontAwesome5, FontAwesome, MaterialIcons} from '@expo/vector-icons';
import news from "../data/newsDemo";


const win = Dimensions.get('screen');
const ofHeight = (p)=> p * win.height / 100;
const ofWidth = (p)=> p * win.width / 100;


class catScreen extends Component {

    state = {
        scrolled : false,
    };


    componentDidMount() {

    }

    logoPressed = ()=>{
        const {navigation} = this.props;

        navigation.navigate('news');
    };
    menuPressed = ()=>{
        const {navigation} = this.props;

        navigation.toggleDrawer();
    };

    viewItem = (item, isVideo)=>{
        const {navigation} = this.props;

        navigation.navigate('display', {item, isVideo});
    };

    _renderItem = (item, isVideo, id) => {
        let image = {uri:item.image};
        return (

            <View key={id} style={[styles.ci]}>
                <ImageBackground style={[styles.ci_bg]} source={image}>

                    <TouchableOpacity onPress={()=>{this.viewItem(item, isVideo)}} style={[styles.ci_inner]}>
                        {
                            (!isVideo) ? (null) : (
                                <View style={[styles.ci_play]}>
                                    <FontAwesome5 style={[styles.ci_play_icon]} name="play" size={24} />
                                </View>
                            )
                        }
                        <View style={[styles.ci_inner_h]}>
                            <View style={[styles.ci_title_holder]}>
                                <Text style={[styles.ci_title]}>{item.title}</Text>
                            </View>
                            <View style={[styles.ci_foot]}>
                                <Text style={[styles.ci_foot_txt]}>{item.date}</Text>
                            </View>
                        </View>
                    </TouchableOpacity>


                </ImageBackground>
            </View>


        );

    };
    _renderVideo = (item,id) => {
        let image = {uri:item.image};
        return (

            <TouchableOpacity key={id} onPress={()=>{this.viewItem(item, true)}} style={[styles.vi]}>

                <ImageBackground style={[styles.vi_img]} source={image}>
                    <FontAwesome5 style={[styles.vi_play_icon]} name="play" size={24} />
                </ImageBackground>

                <Text style={[styles.vi_title]}>{item.title}</Text>
                <Text style={[styles.vi_foot_txt]}>Aujourd'hui</Text>
            </TouchableOpacity>


        );
    };


    render() {

        let cat = {},
            params = this.props.route.params,
            items = params.items,
            name = params.name;

        return (

            <View style={[css.background, {height:'100%', position:'relative',}]}>
                <TopHeader transparent={!this.state.scrolled} semi_transparent={false} floatable={true} title={this.state.scrolled ? name : ''} onMenu={this.menuPressed} onUser={this.logoPressed}/>

                <SafeAreaView style={[styles.scrollholder]}>
                    <ScrollView onScroll={(e)=>{this.setState({scrolled : e.nativeEvent.contentOffset.y > 200})}} style={[styles.sections]}>

                        <SafeAreaView>
                            <View style={[styles.cat_head]}>
                                <ImageBackground resizeMode={'repeat'} source={require('../assets/bg-syno-shape-300x214.png')} style={[styles.cat_bg]}>
                                    <View style={[styles.cat_head_in]}>
                                        <View style={[styles.cat_head_dep]}/>
                                        <Text style={[styles.cat_head_txt]}>{name}</Text>
                                    </View>
                                </ImageBackground>

                            </View>
                            {
                                (!items) ? (<Loader/>) : (
                                    <View>
                                        {(()=>{
                                            let list = [];

                                            items.map((item, i)=>{
                                                list.push(name === 'Vidéos' ? this._renderVideo(item, i) : this._renderItem(item, false,i));
                                            });

                                            return list;
                                        })()}
                                    </View>
                                )
                            }
                        </SafeAreaView>

                    </ScrollView>
                </SafeAreaView>






            </View>

        );
    }

}

const styles = StyleSheet.create({
    sections : {
        flex:1,
    },
    section : {
        marginTop: 22,
        padding: 12,
    },
    section_head : {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 12,
    },
    section_title : {
        flex:1,
        color : "#fff",
        fontSize: sizes.lg,
        paddingHorizontal: 12,
    },
    section_action : {
        flexDirection: 'row',
        alignItems: 'center',
    },
    section_atext : {
        color:colors.front,
        padding: 4,
    },
    section_aicon : {},
    section_ind : {
        height: 4,
        width: 4,
        borderRadius: 2,
        marginRight: 12,
    },
    section_icon : {
        color:'#fff',
    },

    ci : {
        borderRadius: 6,
        //overflow:'hidden',
        elevation: 16,
        height: (ofWidth(90) / 1.61803398875),
        position:'relative',
        //maxWidth: 400,
        margin: 12,
    },
    ci_bg : {
        height:'100%',
        width:'100%',
    },
    ci_inner : {
        width:'100%',
        height:'100%',
        justifyContent: 'flex-end',
    },
    ci_inner_h : {
        backgroundColor: 'rgba(0,0,0,0.68)',
        paddingHorizontal: 12,
        paddingVertical: 8,
    },
    ci_title_holder : {},
    ci_title : {
        color: colors.front,
        fontWeight: 'bold',
        fontSize: sizes.md,
    },
    ci_foot : {},
    ci_foot_txt : {
        color: 'rgba(255,255,255,0.69)',
        padding: 12,
    },
    scrollholder : {
        flex:1,
    },
    ci_play: {
        position: 'absolute',
        left:0,
        top:0,
        right:0,
        bottom : 0,
        zIndex: 8,
        alignItems: 'center',
        justifyContent: 'center',
    },
    ci_play_icon: {
        color : '#fff',
        fontSize: 42,
        elevation: 12,
        textShadowColor: '#000',
        textShadowOffset: {width: 2, height: 2},
    },
    cat_head: {
        height: 250,
        backgroundColor: '#000',
        justifyContent: 'flex-end',
    },
    cat_bg: {
        flex:1,
        width:'100%',
        resizeMode: 'cover',
        justifyContent: 'flex-end',
    },
    cat_head_in: {},
    cat_head_dep: {},
    cat_head_txt: {
        color : '#fff',
        fontSize: 40,
        fontWeight: 'bold',
        padding: 32,
    },

    vi : {
        borderRadius: 6,
        //overflow:'hidden',
        position:'relative',
        //maxWidth: 400,
        margin: 12,
    },
    vi_img : {
        height : ofWidth(100) / 1.61803398875,
        elevation: 17,
        position: 'relative',
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 12,
        overflow: 'hidden',
        marginBottom: 12,

    },
    vi_title : {
        color: colors.front,
        fontWeight: 'bold',
        fontSize: sizes.md,
    },
    vi_play_icon: {
        color : '#fff',
        fontSize: 42,
        elevation: 12,
        textShadowColor: '#000',
        textShadowOffset: {width: 2, height: 2},
    },
    vi_foot_txt : {
        color: 'rgba(255,255,255,0.69)',
        padding: 12,
    },

});

const mapDispatchToProps = dispatch => (
    bindActionCreators({
        updateData: updateData,
    }, dispatch)
);

const mapStateToProps = (state) => {
    const { data } = state;
    return { data }
};

export default connect(mapStateToProps, mapDispatchToProps)(catScreen);
