import {

    PENDING_FETCH_COMMENT,
    SET_COMMENT,
    SUCCESS_FETCH_COMMENT,

} from "../actions/types";

export default function(
    state = { isLoadingData: false, isDoSearch: false, data: [], keyword: null },
    action
) {

    console.log("Log_action_LOGIN => ", action.type);

    switch (action.type) {
        case PENDING_FETCH_COMMENT:
            return {
                ...state,
                isLoadingData: true
            };

        case SET_COMMENT:
            return { ...state, data: action.payload };

        case SUCCESS_FETCH_COMMENT:
            return {
                ...state,
                isLoadingData: false
            };

        default:
            return state;
    }

}
