class Fleet {
  int driverId;
  int vehicleCategory;
  int vehicleSubtype;
  int country;
  double adminfees;
  double taxFees;
  double gatewayFee;
  double fleetfees;
  double fleettax;
  int agentfees;
  int royalityFees;
  int candytechmarkup;
  int candytechtax;
  int agentId;
  double driverfees;
  String fleetId;
  double fare;
  int bookType;
  String fleetnamne;
  String fleetlogo;
  int surge;
  double charterTimeCharge;

  Fleet(
      {this.driverId,
      this.vehicleCategory,
      this.vehicleSubtype,
      this.country,
      this.adminfees,
      this.taxFees,
      this.gatewayFee,
      this.fleetfees,
      this.fleettax,
      this.agentfees,
      this.royalityFees,
      this.candytechmarkup,
      this.candytechtax,
      this.agentId,
      this.driverfees,
      this.fleetId,
      this.fare,
      this.bookType,
      this.fleetnamne,
      this.fleetlogo,
      this.surge,
      this.charterTimeCharge});

  Fleet.fromJson(Map<String, dynamic> json) {
    driverId = json['driver_id'];
    vehicleCategory = int.parse(json['vehicle_category'].toString());
    vehicleSubtype = int.parse(json['vehicle_subtype'].toString());
    country = json['country'];
    adminfees = double.parse(json['adminfees'].toString());
    taxFees = double.parse(json['tax_fees'].toString());
    gatewayFee = double.parse(json['gateway_fee'].toString());
    fleetfees = double.parse(json['fleetfees'].toString());
    fleettax = double.parse(json['fleettax'].toString());
    agentfees = json['agentfees'];
    royalityFees = json['royality_fees'];
    candytechmarkup = json['candytechmarkup'];
    candytechtax = json['candytechtax'];
    agentId = json['agent_id'];
    driverfees = double.parse(json['driverfees'].toString());
    fleetId = json['fleet_id'];
    fare = double.parse(json['fare'].toString());
    bookType = json['book_type'];
    fleetnamne = json['fleetnamne'];
    fleetlogo = json['fleetlogo'];
    surge = json['surge'];
    charterTimeCharge = double.parse(json['charter_time_charge'].toString());
  }
}
