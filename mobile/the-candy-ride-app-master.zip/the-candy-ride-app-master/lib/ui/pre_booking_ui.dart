import 'dart:ffi';

import 'package:dartz/dartz_unsafe.dart';
import 'package:flutter/material.dart';
import 'package:rider_app/constants/constants.dart';
import 'package:get/get.dart';
import 'package:rider_app/controllers/controllers.dart';
import 'package:rider_app/controllers/pre_booking_controller.dart';
import 'package:rider_app/helpers/helpers.dart';
import 'package:rider_app/models/booking.dart';

import 'components/components.dart';

void main() {
  runApp(MaterialApp(
    title: 'Navigation Basics',
    home: PreBookingUiBar(),
  ));
}

class PreBookingUiBar extends StatelessWidget {
  double height, width;
  @override
  Widget build(BuildContext context) {
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      body: SafeArea(
        child: Container(
          child: Column(
            children: [appbar(context)],
          ),
        ),
      ),
    );
  }

  appbar(context) => Container(
        width: width,
        margin: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        color: AppThemes.lightPinkBackGroundColor,
        child: Stack(
          children: [
            Center(
                child: Text(
              "Pre Bookings".tr,
              style: Theme.of(context).textTheme.subtitle1.copyWith(
                  fontSize: 20,
                  fontFamily: 'NunitoSans',
                  fontWeight: FontWeight.w700),
            )),
            GestureDetector(
              onTap: () => Get.back(),
              child: Image.asset(
                AllImages.backIcon,
                height: 25,
                width: 25,
                color: AppThemes.lightWhitebackGroundColor,
              ),
            ),
          ],
        ),
      );
}

class PreBookingUI extends StatefulWidget {
  @override
  _PreBookingUIState createState() => _PreBookingUIState();
}

class _PreBookingUIState extends State<PreBookingUI> {
  double height, width;
  DateTime selectedDate;
  int listLength;
  static PreBookingController to = Get.put(PreBookingController());

  @override
  void initState() {
    to.bookings.clear();
    selectedDate = DateTime.now();
    to.getBookings().then((value) {
      setState(() {});
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    listLength = to.bookings.length;
    // to.bookings.forEach((element) {
    //   preBook(context, element);
    // });
    //listingBuild(context, to.bookings);

    return Scaffold(
      appBar: AppBar(
        title: Text('Pre Bookings'),
        backgroundColor: AppThemes.lightPinkBackGroundColor,
      ),

      body: SingleChildScrollView(
        child: Container(
          child: Column(
            children: [
              //appbar(context),
              //listingBuild(context),
              //if (to.bookings.length > 0) preBook(context, to.bookings[0]),
              for (int i = 0; i < listLength; i++)
                preBook(context, to.filterBookings[i])

              //preBook(context, )
              // to.bookings.forEach((element) {
              //   preBook(context, element);
              // }),
            ],
          ),
        ),
      ),
      // body: SingleChildScrollView(

      // ),
    );
  }

  // listingBuild(context) {
  //   to.bookings.forEach((element) {
  //     if (element != null) {
  //       print(element.id);
  //       preBook(context, element);
  //     }
  //   });
  // }

  preBook(context, Booking booking) => Container(
        width: width,
        margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        color: AppThemes.lightBoxshadow,
        child: Stack(
          children: [
            Center(
              child: Stack(
                children: [
                  Text(
                    "Booking number: " + booking.id.tr,
                    style: Theme.of(context).textTheme.subtitle1.copyWith(
                        fontSize: 20,
                        fontFamily: 'NunitoSans',
                        fontWeight: FontWeight.normal),
                  ),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Stack(
                      children: [
                        Container(
                          margin: EdgeInsets.only(top: 25),
                          child: Text(
                            "Date: " + booking.bookingDate.tr,
                            style:
                                Theme.of(context).textTheme.subtitle1.copyWith(
                                      fontSize: 12,
                                      fontFamily: 'NunitoSans',
                                      fontWeight: FontWeight.bold,
                                    ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(top: 40),
                          child: Text(
                            "Pickup: " + booking.pickupAddress.tr,
                            style:
                                Theme.of(context).textTheme.subtitle1.copyWith(
                                      fontSize: 10,
                                      fontFamily: 'NunitoSans',
                                      fontWeight: FontWeight.bold,
                                    ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(top: 50),
                          child: Text(
                            "Drop: " + booking.dropAddress.tr,
                            style:
                                Theme.of(context).textTheme.subtitle1.copyWith(
                                      fontSize: 10,
                                      fontFamily: 'NunitoSans',
                                      fontWeight: FontWeight.bold,
                                    ),
                          ),
                        ),

                        // Text(
                        //   booking.dropAddress.tr,
                        //   style: Theme.of(context).textTheme.subtitle1.copyWith(
                        //         fontSize: 10,
                        //         fontFamily: 'NunitoSans',
                        //         fontWeight: FontWeight.bold,
                        //       ),
                        // ),
                      ],
                    ),
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton(
                        style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all<Color>(
                              AppThemes.lightPinkBackGroundColor),
                        ),
                        onPressed: () {
                          to.cancelbooking(booking.id, booking.countryId);
                        },
                        child: Stack(
                          children: [
                            Text(
                              'Cancel',
                              style: Theme.of(context)
                                  .textTheme
                                  .subtitle1
                                  .copyWith(
                                    fontSize: 15,
                                    fontFamily: 'NunitoSans',
                                    fontWeight: FontWeight.bold,
                                  ),
                            ),
                          ],
                        )),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
  appbar(context) => Container(
        width: width,
        margin: EdgeInsets.symmetric(horizontal: 20, vertical: 30),
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        color: AppThemes.lightPinkBackGroundColor,
        child: Stack(
          children: [
            Center(
                child: Text(
              "Pre Bookings".tr,
              style: Theme.of(context).textTheme.subtitle1.copyWith(
                  fontSize: 20,
                  fontFamily: 'NunitoSans',
                  fontWeight: FontWeight.w700),
            )),
            GestureDetector(
              onTap: () => Get.back(),
              child: Image.asset(
                AllImages.backIcon,
                height: 25,
                width: 25,
                color: AppThemes.lightWhitebackGroundColor,
              ),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: GestureDetector(
                onTap: () async {
                  final date = await selectAllDate(context);
                  if (date != null) {
                    setState(() {
                      to.selectedDate = date;
                      to.filterDate();
                    });
                  }
                },
                child: Image.asset(
                  AllImages.calender,
                  height: 30,
                  width: 30,
                  color: AppThemes.lightWhitebackGroundColor,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ],
        ),
      );
}
