import "package:latlong/latlong.dart";

class Tracepoints {
  int matchingsIndex;
  int waypointIndex;
  int alternativesCount;
  double distance;
  String name;
  LatLng location;

  Tracepoints(
      {this.matchingsIndex,
      this.waypointIndex,
      this.alternativesCount,
      this.distance,
      this.name,
      this.location});

  Tracepoints.fromJson(Map<String, dynamic> json) {
    if (json != null) {
      matchingsIndex = json['matchings_index'] ?? 0;
      waypointIndex = json['waypoint_index'] ?? 0;
      alternativesCount = json['alternatives_count'] ?? 0;
      distance = json['distance'] ?? 0.0;
      name = json['name'] ?? '';
      location = LatLng(json['location'].cast<double>()[1],
          json['location'].cast<double>()[0]);
    }
  }
}
