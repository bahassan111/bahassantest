<?php
addJS([
    'assets/js/views/runs.js',
]);

viewHeader(
    'Test Runs',
    'Run Tests and manage Run Reports',
    [
        (object) ['name' => 'Dashboard', 'url' => site_url()],
        (object) ['name' => 'Projects', 'url' => site_url('projects')],
        (object) ['name' => $project->name, 'url' => getProjectUrl($project)],
        (object) ['name' => 'Test Runs', 'url' => ''],
    ], true);

projectMenu('test_runs', $project);
?>



<div class="project_runs_body n_menu">

    <div class="runs_list">

    </div>



</div>



<script>
    var project_id = <?= $project->id ?: 0; ?>;
</script>
