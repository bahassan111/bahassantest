import 'package:flutter/material.dart';
import 'package:rider_app/constants/constants.dart';

class TripDetail extends StatelessWidget {
  final String distance;
  final String time;
  final String destination;
  TripDetail({this.destination, this.distance, this.time});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 3 * MediaQuery.of(context).size.width / 5,
      margin: EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppThemes.lightWhitebackGroundColor,
        border: Border.all(color: AppThemes.lightpauaBackGroundColor),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            color: AppThemes.lightpauaBackGroundColor,
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  time,
                  style: Theme.of(context).textTheme.subtitle1.copyWith(
                        fontSize: 13,
                      ),
                ),
                Text(
                  distance,
                  style: Theme.of(context).textTheme.subtitle1.copyWith(
                        fontSize: 13,
                      ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                destination,
                style: Theme.of(context).textTheme.headline4.copyWith(
                      fontSize: 13,
                    ),
                maxLines: 1,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
