package ma.rak.ov.ui.main;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProviders;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import io.realm.Realm;
import io.realm.exceptions.RealmException;
import ma.rak.ov.R;
import ma.rak.ov.api.RetrofitClient;
import ma.rak.ov.bodyResponse.OperationResponse;
import ma.rak.ov.bodyResponse.SettingsResponse;
import ma.rak.ov.models.Categorie;
import ma.rak.ov.models.Dossier;
import ma.rak.ov.models.Emplacement;
import ma.rak.ov.models.Nature;
import ma.rak.ov.models.PendingOperation;
import ma.rak.ov.storage.SharedPrefManager;
import ma.rak.ov.utils.ImageUtils;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ExecutionFragmentBranchement extends FragmentActivity implements AdapterView.OnItemSelectedListener {

    String token = SharedPrefManager.getInstance(this).getToken();

    private DropDownAlert downAlertImage;
    private DropDownAlert downAlertNoImage;

    ImageView ivImage;
    Integer REQUEST_CAMERA = 1, SELECT_FILE = 0;

    private int devis = 0;

    private Spinner nature_installation, categorie_Abonnement, dossier_resiler, emplacement;
    private Button cancelButton;
    private View saveButton;
    private TextView typeAction, client;
    private EditText nature_lot;
    private RadioGroup adevis;

    private DemandViewModel demandViewModel;
    Realm realm;

    SettingsResponse newSettingsResponse = null;

    ProgressButton progressButton;

    OperationResponse operationResponse = null;

    ArrayList<Dossier> dossierArrayList;

    HashMap<String ,String> naturesIDS = new HashMap<String,String>();
    HashMap<String ,String> catsIDS = new HashMap<String,String>();
    HashMap<String ,String> empIDS = new HashMap<String,String>();


    private String base64Image, adreloca, doss_annee, doss_numm, num_operation, gerance, etage, nature_install, observation = "Observation : Execution ", date, natureValue, categoryValue, dossierValue, emplacementValue, lotValue, status = "3";

    public static ExecutionFragmentBranchement newInstance() {
        return new ExecutionFragmentBranchement();
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_fragment);
        progressButton = new ProgressButton(ExecutionFragmentBranchement.this, R.string.enregistrer, "Enregistrer");

        realm = Realm.getDefaultInstance();

        demandViewModel = ViewModelProviders.of(this).get(DemandViewModel.class);
        demandViewModel.getSettings(token, this, this.getIntent().getExtras().getString("gerance"));


        nature_installation = (Spinner) findViewById(R.id.nature_installation);
        categorie_Abonnement = (Spinner) findViewById(R.id.categorie_Abonnement);
        dossier_resiler = (Spinner) findViewById(R.id.dossier_resiler);
        emplacement = (Spinner) findViewById(R.id.emplacement);
        nature_lot = (EditText) findViewById(R.id.nature_lot);

        cancelButton = (Button) findViewById(R.id.cancel_button);
        saveButton = findViewById(R.id.save_button);
        client = (TextView) findViewById(R.id.adrelocaClient);
        typeAction = (TextView) findViewById(R.id.typeAction);


        downAlertImage = new DropDownAlert(this, this.getWindow().getContext(), true);
        downAlertNoImage = new DropDownAlert(this, this.getWindow().getContext(), false);

        ivImage = (ImageView) findViewById(R.id.ivImage);

        ivImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SelectImage();
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ExecutionFragmentBranchement.super.onBackPressed();
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                progressButton.buttonActivated();

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (status.equals("2")) {
                            if (status == null || date == null || natureValue == null || emplacementValue == null || dossier_resiler == null) {
                                downAlertNoImage.setTitle(getString(R.string.dropdown_error));
                                downAlertNoImage.setContent(getString(R.string.required_form_data));
                                downAlertNoImage.show();
                                progressButton.buttonCancled(R.string.enregistrer);
                                return;
                            }
                        } else if (status.equals("3")) {
                            if (status == null || observation == null) {
                                downAlertNoImage.setTitle(getString(R.string.dropdown_error));
                                downAlertNoImage.setContent(getString(R.string.required_form_data));
                                downAlertNoImage.show();
                                progressButton.buttonCancled(R.string.enregistrer);
                                return;
                            }
                        }


                        lotValue = nature_lot.getText().toString();
                        /*Call<OperationResponse> call = RetrofitClient.getApi(token)
                                .executer(*//*"XDEBUG_SESSION=XDEBUG_ECLIPSE",*//* status,observation, date, natureValue,emplacementValue, etage, doss_annee, doss_numm,num_operation,gerance,lotValue, String.valueOf(devis),"", base64Image);


                        PendingOperation pendingOperation = new PendingOperation(num_operation, status, observation, "Motif", date, natureValue, emplacementValue, "", etage, doss_annee, doss_numm, gerance, natureValue, base64Image, "");

                        call.enqueue(new Callback<OperationResponse>() {
                            @Override
                            public void onResponse(Call<OperationResponse> call, Response<OperationResponse> response) {
                                operationResponse = response.body();
                                if (response.body() != null && response.code() == 200) {
                                    downAlertNoImage.setTitle(getString(R.string.dropdown_info));
                                    downAlertNoImage.setContent(response.body().getMsg());
                                    downAlertNoImage.show();
                                    progressButton.buttonFinished();
                                    Handler handler1 = new Handler();
                                    handler1.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            ExecutionFragmentBranchement.super.onBackPressed();
                                        }
                                    }, 1000);
                                }

                            }

                            @Override
                            public void onFailure(Call<OperationResponse> call, Throwable t) {
                                downAlertNoImage.setTitle(getString(R.string.dropdown_error));
                                downAlertNoImage.setContent(t.getMessage());
                                downAlertNoImage.show();
                                progressButton.buttonCancled(R.string.enregistrer);
                                Handler handler1 = new Handler();
                                handler1.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        ExecutionFragmentBranchement.super.onBackPressed();
                                    }
                                }, 1000);
                                try {
                                    realm.executeTransaction(realm -> {
                                        realm.copyToRealmOrUpdate(pendingOperation);
                                    });
                                } catch (RealmException realmException) {
                                    Log.e("settingsResponse", realmException.getMessage());
                                } finally {
                                }

                            }
                        });*/
                    }
                }, 2000);


            }
        });

        ArrayList<String> naturee = new ArrayList<>();
        ArrayAdapter nature = new ArrayAdapter(this, android.R.layout.simple_spinner_item, naturee);
        nature.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        ArrayList<String> category = new ArrayList<>();
        ArrayAdapter categorie = new ArrayAdapter(this, android.R.layout.simple_spinner_item, category);
        categorie.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        ArrayList<String> dossierr = new ArrayList<>();
        ArrayAdapter dossier = new ArrayAdapter(this, android.R.layout.simple_spinner_item, dossierr);
        dossier.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        ArrayList<String> emplace = new ArrayList<>();
        ArrayAdapter empl = new ArrayAdapter(this, android.R.layout.simple_spinner_item, emplace);
        empl.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        ArrayList<String> lott = new ArrayList<>();
        ArrayAdapter lot = new ArrayAdapter(this, android.R.layout.simple_spinner_item, lott);
        lot.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);





        nature_installation.setOnItemSelectedListener(this);
        categorie_Abonnement.setOnItemSelectedListener(this);
        dossier_resiler.setOnItemSelectedListener(this);
        emplacement.setOnItemSelectedListener(this);
        //nature_lot.setOnItemSelectedListener(this);

        newSettingsResponse = new SettingsResponse();
        demandViewModel.SettingsMutableLiveData.observe(this, settingsResponse -> {
            newSettingsResponse = settingsResponse;

            if (newSettingsResponse != null) {
                if (newSettingsResponse.getNature() != null) {
                    for (Nature label : newSettingsResponse.getNature()) {
                        naturee.add(label.getLabel());
                        naturesIDS.put(label.getLabel(), String.valueOf(label.getID()));
                    }
                    nature.notifyDataSetChanged();
                    nature_installation.setAdapter(nature);
                }

                if (newSettingsResponse.getCategorie()!= null) {
                    for (Categorie label : newSettingsResponse.getCategorie()) {
                        category.add(label.getLabel());
                        catsIDS.put(label.getLabel(), String.valueOf(label.getID()));
                    }

                    categorie.notifyDataSetChanged();
                    categorie_Abonnement.setAdapter(categorie);
                }
                if (newSettingsResponse.getEmplacement()!= null) {
                    for (Emplacement label : newSettingsResponse.getEmplacement()) {
                        emplace.add(label.getLabel());
                        empIDS.put(label.getLabel(), String.valueOf(label.getID()));
                    }

                    empl.notifyDataSetChanged();
                    emplacement.setAdapter(empl);
                }

//                if (!newSettingsResponse.getDossier().equals(null)) {
//                    for (Dossier label : newSettingsResponse.getDossier()) {
//                        dossierr.add(label.getAdresse() + "/"+ label.getID());
//                    }
//
//                    dossier.notifyDataSetChanged();
//                    dossier_resiler.setAdapter(dossier);
//                }


                // TODO: Switch to real EMPL
                /*if (newSettingsResponse.getEmplacement()!= null) {
                    for (Emplacement label : newSettingsResponse.getEmplacement()) {
                        emplace.add(label.getLabel());
                    }

                    empl.notifyDataSetChanged();
                    emplacement.setAdapter(empl);
                }


                if (newSettingsResponse.getEmplacement() != null) {
                    for (Lot label : newSettingsResponse.getLot()) {
                        lott.add(label.getLabel());
                    }

                    lot.notifyDataSetChanged();
                    nature_lot.setAdapter(lot);
                }*/
            }

        });



        Intent intent = getIntent();
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            if (bundle.getString("date") != null) {
                this.doss_annee = bundle.getString("doss_annee");
                this.gerance = bundle.getString("gerance");
                this.doss_numm = bundle.getString("doss_numm");
                this.date = bundle.getString("date");
                this.num_operation = bundle.getString("num_operation");
                this.status = bundle.getString("status");
                this.date = bundle.getString("date");
                this.adreloca = bundle.getString("adreloca");
                this.nature_install = bundle.getString("nature_install");
                this.etage = bundle.getString("etage");
                client.setText(bundle.getString("adreloca"));
                typeAction.setText(typeAction.getText() + " Exécutions");
                this.dossierArrayList = intent.getParcelableArrayListExtra("dossier");

                dossierr.add("<Aucun>");
                if (this.dossierArrayList != null)
                    for (Dossier label : dossierArrayList) {
                        dossierr.add(label.getNUM());
                        //emplace.add(label.getADRESSE());
                    }
                dossier.notifyDataSetChanged();
                dossier_resiler.setAdapter(dossier);
                empl.notifyDataSetChanged();
                emplacement.setAdapter(empl);


            }
        }

    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch (view.getId()) {
            case R.id.radio_pirates:
                if (checked)
                    this.devis = 1;
//                Toast.makeText(this, "Avis devis " + this.devis, Toast.LENGTH_SHORT).show();
                break;
            case R.id.radio_ninjas:
                if (checked)
                    // Ninjas rule
                    this.devis = 0;
//                Toast.makeText(this, "Sans Devis " + this.devis, Toast.LENGTH_SHORT).show();
                break;
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Spinner spinner = (Spinner) parent;

        if (spinner.getId() == R.id.nature_installation) {

            String nv = spinner.getItemAtPosition(position).toString();
            natureValue = naturesIDS.get(nv);

        } else if (spinner.getId() == R.id.categorie_Abonnement) {

            String catv = spinner.getItemAtPosition(position).toString();
            categoryValue = catsIDS.get(catv);

        } else if (spinner.getId() == R.id.dossier_resiler) {

            dossierValue = spinner.getItemAtPosition(position).toString();

        } else if (spinner.getId() == R.id.emplacement) {

            String emplv = spinner.getItemAtPosition(position).toString();
            emplacementValue = empIDS.get(emplv);

        } else if (spinner.getId() == R.id.nature_lot) {

            lotValue = spinner.getItemAtPosition(position).toString();

        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    private void SelectImage() {

        final CharSequence[] items = {"Camera", "Gallery", "Cancel"};

        AlertDialog.Builder builder = new AlertDialog.Builder(ExecutionFragmentBranchement.this);
        builder.setTitle("Add Image");

        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {
                if (items[i].equals("Camera")) {

                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(intent, REQUEST_CAMERA);

                } else if (items[i].equals("Gallery")) {

                    Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    intent.setType("image/*");
                    //startActivityForResult(intent.createChooser(intent, "Select File"), SELECT_FILE);
                    startActivityForResult(intent, SELECT_FILE);

                } else if (items[i].equals("Cancel")) {
                    dialog.dismiss();
                }
            }

        });
        builder.show();

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {

            if (requestCode == REQUEST_CAMERA) {

                Bundle bundle = data.getExtras();
                final Bitmap bitmap = (Bitmap) bundle.get("data");
                ivImage.setImageBitmap(bitmap);
                base64Image = ImageUtils.getBase64Image(bitmap);

                Log.i("Camera-base64", base64Image);

            } else if (requestCode == SELECT_FILE) {

                Uri selectedImageUri = data.getData();
                Bitmap bitmap = null;
                if (selectedImageUri != null) {
                    try {
                        bitmap = ImageUtils.getBitmapFormUri(this, selectedImageUri);
                        base64Image = ImageUtils.getBase64Image(bitmap);
                        ivImage.setImageURI(selectedImageUri);
                        Log.i("File-base64", base64Image);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }


                }

            }

        }
    }

}