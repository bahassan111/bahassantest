class Waypoints {
  double distance;
  String name;
  List<double> location;

  Waypoints({this.distance, this.name, this.location});

  Waypoints.fromJson(Map<String, dynamic> json) {
    distance = double.parse(json['distance'].toString());
    name = json['name'];
    location = json['location'].cast<double>();
  }
}
