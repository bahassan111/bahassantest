package ma.rak.ov.ui.main;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProviders;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;

import io.realm.Realm;
import ma.rak.ov.R;
import ma.rak.ov.api.TwDatabase;
import ma.rak.ov.api.TwHelper;
import ma.rak.ov.bodyResponse.OperationResponse;
import ma.rak.ov.bodyResponse.SettingsResponse;
import ma.rak.ov.models.Categorie;
import ma.rak.ov.models.CategorieBr;
import ma.rak.ov.models.Dossier;
import ma.rak.ov.models.Emplacement;
import ma.rak.ov.models.Nature;
import ma.rak.ov.models.NatureBr;
import ma.rak.ov.storage.SharedPrefManager;
import ma.rak.ov.utils.ImageUtils;

public class ExecutionFragment extends FragmentActivity implements AdapterView.OnItemSelectedListener {

    String token = SharedPrefManager.getInstance(this).getToken();
    ImageView ivImage;
    Integer REQUEST_CAMERA = 1, SELECT_FILE = 0;
    Realm realm;
    SettingsResponse newSettingsResponse = null;
    ProgressButton progressButton;
    OperationResponse operationResponse = null;
    ArrayList<Dossier> dossierArrayList;
    HashMap<String, String> naturesIDS = new HashMap<String, String>();
    HashMap<String, String> catsIDS = new HashMap<String, String>();
    HashMap<String, String> empIDS = new HashMap<String, String>();
    private DropDownAlert downAlertImage;
    private DropDownAlert downAlertNoImage;
    private int devis = 0;
    private Spinner nature_installation, categorie_Abonnement, dossier_resiler, emplacement;
    private Button cancelButton;
    private View saveButton;
    private TextView typeAction, client;
    private EditText nature_lot, obs, disj;
    private RadioGroup adevis;
    private DemandViewModel demandViewModel;
    private String base64Image, adreloca, doss_annee, doss_numm, num_operation, gerance, etage, nature_install, observation = "", disjan = "", date, natureValue, categoryValue, dossierValue, emplacementValue, lotValue, status = "3";
    public boolean isBR = false;
    LinearLayout for_ab;
    HashMap<String, String> row = new HashMap<>();

    public static ExecutionFragment newInstance() {
        return new ExecutionFragment();
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_fragment);
        progressButton = new ProgressButton(ExecutionFragment.this, R.string.enregistrer, "Enregistrer");

        isBR = getIntent().getExtras().getBoolean("br");

        realm = Realm.getDefaultInstance();

        row = (HashMap<String, String>) getIntent().getExtras().getSerializable("ITEM");

        demandViewModel = ViewModelProviders.of(this).get(DemandViewModel.class);
        demandViewModel.getSettings(token, this, row.get("CODEGERA"));
        obs = findViewById(R.id.obs);
        disj = findViewById(R.id.disj);
        for_ab = findViewById(R.id.for_ab);


        nature_installation = (Spinner) findViewById(R.id.nature_installation);
        categorie_Abonnement = (Spinner) findViewById(R.id.categorie_Abonnement);
        dossier_resiler = (Spinner) findViewById(R.id.dossier_resiler);
        emplacement = (Spinner) findViewById(R.id.emplacement);
        nature_lot = (EditText) findViewById(R.id.nature_lot);

        cancelButton = (Button) findViewById(R.id.cancel_button);
        saveButton = findViewById(R.id.save_button);
        client = (TextView) findViewById(R.id.adrelocaClient);
        typeAction = (TextView) findViewById(R.id.typeAction);


        downAlertImage = new DropDownAlert(this, this.getWindow().getContext(), true);
        downAlertNoImage = new DropDownAlert(this, this.getWindow().getContext(), false);

        ivImage = (ImageView) findViewById(R.id.ivImage);

        ivImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SelectImage();
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ExecutionFragment.super.onBackPressed();
            }
        });

        if (getIntent().getExtras().getBoolean("CONSULT")) {
            saveButton.setVisibility(View.INVISIBLE);
            nature_installation.setEnabled(false);
            categorie_Abonnement.setEnabled(false);
            dossier_resiler.setEnabled(false);
            emplacement.setEnabled(false);
            nature_lot.setEnabled(false);
            //adevis.setEnabled(false);

            cancelButton.setText(R.string.goback);
        }

        if (!isBR) { // ABONNEMEN?T
            nature_lot.setText(row.get("NATU_LOT"));
            for_ab.setVisibility(View.VISIBLE);
            obs.setText(row.get(TwDatabase.ABDemandes.RESTRAOP));
        } else { // BRANCHEMENT
            emplacement.setVisibility(View.INVISIBLE);
            for_ab.setVisibility(View.GONE);
            obs.setText(row.get(TwDatabase.BRDemandes.OBSEVEDE));
            client.setText(row.get(TwDatabase.BRDemandes.ADRESDEVI));
        }

        View.OnClickListener save = null;

        if (isBR) {
            save = new View.OnClickListener() {

                @Override
                public void onClick(View v) {


                    if (status.equals("2")) {
                        if (status == null || natureValue == null || categorie_Abonnement == null) {
                            downAlertNoImage.setTitle(getString(R.string.dropdown_error));
                            downAlertNoImage.setContent(getString(R.string.required_form_data));
                            downAlertNoImage.show();
                            progressButton.buttonCancled(R.string.enregistrer);
                            return;
                        }
                    } else if (status.equals("3")) {
                        if (status == null) {
                            downAlertNoImage.setTitle(getString(R.string.dropdown_error));
                            downAlertNoImage.setContent(getString(R.string.required_form_data));
                            downAlertNoImage.show();
                            progressButton.buttonCancled(R.string.enregistrer);
                            return;
                        }
                    }

                    if ((natureValue != null) && (categoryValue != null)) {
                        progressButton.buttonActivated();
                        TwDatabase.TwDatabaseHelper.ExecuterBranchement(
                                ExecutionFragment.this,
                                false,
                                row.get("ANNDEMDE"),
                                row.get("NUMDEMDE"),
                                row.get("NUMOPEDE"),
                                row.get("CODEGERA"),
                                row.get("CATEDEVI"),
                                obs.getText().toString(),
                                "",
                                natureValue,
                                categoryValue,
                                row.get("NUMDEVTA"),
                                base64Image,
                                SharedPrefManager.getInstance(getApplicationContext()).getPos().get("lat").toString(),
                                SharedPrefManager.getInstance(getApplicationContext()).getPos().get("lng").toString(),
                                new Runnable() { // SUCCESS
                                    @Override
                                    public void run() {

                                        downAlertNoImage.setTitle(getString(R.string.dropdown_info));
                                        downAlertNoImage.setContent("Toutes les données ont été bien enregistrées");
                                        downAlertNoImage.show();
                                        progressButton.buttonFinished();
                                        Handler handler1 = new Handler();
                                        handler1.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                ExecutionFragment.super.onBackPressed();
                                            }
                                        }, 1000);

                                    }
                                },
                                new Runnable() { // STORED OFFLINE ONLY
                                    @Override
                                    public void run() {

                                    }
                                },
                                new Runnable() { // FAIL
                                    @Override
                                    public void run() {

                                        downAlertNoImage.setTitle(getString(R.string.dropdown_error));
                                        downAlertNoImage.setContent("Erreur lors de l'enregistrement des données");
                                        downAlertNoImage.show();
                                        progressButton.buttonCancled(R.string.enregistrer);
                                        Handler handler1 = new Handler();
                                        handler1.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                //ExecutionFragment.super.onBackPressed();
                                            }
                                        }, 1000);

                                    }
                                });
                    } else {
                        downAlertNoImage.setTitle(getString(R.string.dropdown_info));
                        downAlertNoImage.setContent(getString(R.string.metadata_requis_message));
                        downAlertNoImage.show();
                    }
                }
            };
        } else {
            save = new View.OnClickListener() {

                @Override
                public void onClick(View v) {


                    if (status.equals("2")) {
                        if (status == null || date == null || natureValue == null || emplacementValue == null) {
                            downAlertNoImage.setTitle(getString(R.string.dropdown_error));
                            downAlertNoImage.setContent(getString(R.string.required_form_data));
                            downAlertNoImage.show();
                            progressButton.buttonCancled(R.string.enregistrer);
                            return;
                        }
                    } else if (status.equals("3")) {
                        if (status == null) {
                            downAlertNoImage.setTitle(getString(R.string.dropdown_error));
                            downAlertNoImage.setContent(getString(R.string.required_form_data));
                            downAlertNoImage.show();
                            progressButton.buttonCancled(R.string.enregistrer);
                            return;
                        }
                    }

                    lotValue = nature_lot.getText().toString();

                    progressButton.buttonActivated();
                    TwDatabase.TwDatabaseHelper.ExecuterAbonnement(
                            ExecutionFragment.this,
                            false,
                            doss_annee,
                            doss_numm,
                            num_operation,
                            gerance,
                            obs.getText().toString(),
                            "",
                            natureValue,
                            categoryValue,
                            emplacementValue,
                            lotValue,
                            dossierValue,
                            String.valueOf(devis),
                            base64Image,
                            SharedPrefManager.getInstance(getApplicationContext()).getPos().get("lat").toString(),
                            SharedPrefManager.getInstance(getApplicationContext()).getPos().get("lng").toString(),
                            disj.getText().toString(),
                            new Runnable() { // SUCCESS
                                @Override
                                public void run() {

                                    downAlertNoImage.setTitle(getString(R.string.dropdown_info));
                                    //downAlertNoImage.setContent(response.body().getMsg());
                                    downAlertNoImage.show();
                                    progressButton.buttonFinished();
                                    Handler handler1 = new Handler();
                                    handler1.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            ExecutionFragment.super.onBackPressed();
                                        }
                                    }, 1000);

                                }
                            },
                            new Runnable() { // STORED OFFLINE ONLY
                                @Override
                                public void run() {

                                }
                            },
                            new Runnable() { // FAIL
                                @Override
                                public void run() {

                                    downAlertNoImage.setTitle(getString(R.string.dropdown_error));
                                    //downAlertNoImage.setContent(t.getMessage());
                                    downAlertNoImage.show();
                                    progressButton.buttonCancled(R.string.enregistrer);
                                    Handler handler1 = new Handler();
                                    handler1.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            //ExecutionFragment.super.onBackPressed();
                                        }
                                    }, 1000);

                                }
                            });


                }
            };
        }

        saveButton.setOnClickListener(save);

        ArrayList<String> naturee = new ArrayList<>();
        ArrayAdapter nature = new ArrayAdapter(this, android.R.layout.simple_spinner_item, naturee);
        nature.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        ArrayList<String> category = new ArrayList<>();
        ArrayAdapter categorie = new ArrayAdapter(this, android.R.layout.simple_spinner_item, category);
        categorie.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        ArrayList<String> dossierr = new ArrayList<>();
        ArrayAdapter dossier = new ArrayAdapter(this, android.R.layout.simple_spinner_item, dossierr);
        dossier.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        ArrayList<String> emplace = new ArrayList<>();
        ArrayAdapter empl = new ArrayAdapter(this, android.R.layout.simple_spinner_item, emplace);
        empl.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        ArrayList<String> lott = new ArrayList<>();
        ArrayAdapter lot = new ArrayAdapter(this, android.R.layout.simple_spinner_item, lott);
        lot.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        nature_installation.setOnItemSelectedListener(this);
        categorie_Abonnement.setOnItemSelectedListener(this);
        dossier_resiler.setOnItemSelectedListener(this);
        emplacement.setOnItemSelectedListener(this);
        //nature_lot.setOnItemSelectedListener(this);

        newSettingsResponse = new SettingsResponse();
        demandViewModel.SettingsMutableLiveData.observe(this, settingsResponse -> {
            newSettingsResponse = settingsResponse;

            if (newSettingsResponse != null && !isBR) {
                if (newSettingsResponse.getNature() != null) {

                    naturee.clear();
                    naturesIDS.clear();
                    naturee.add("<VIDE>");

                    for (Nature label : newSettingsResponse.getNature()) {
                        if (label.getCODCATAB().equals(categoryValue)) {
                            naturee.add(label.getLabel());
                            naturesIDS.put(label.getLabel(), String.valueOf(label.getID()));
                        }
                    }
                    nature.notifyDataSetChanged();
                    nature_installation.setAdapter(nature);

                    String nv = TwHelper.getKeyOf(naturesIDS, natureValue == null ? row.get("CODNATIN") : natureValue, "");
                    int p = nature.getPosition(nv);
                    nature_installation.setSelection(p);

                }
                if (newSettingsResponse.getCategorie() != null) {

                    categorie.clear();
                    catsIDS.clear();
                    category.clear();
                    category.add("<VIDE>");

                    for (Categorie label : newSettingsResponse.getCategorie()) {
                        category.add(label.getLabel());
                        catsIDS.put(label.getLabel(), String.valueOf(label.getID()));
                    }

                    categorie.notifyDataSetChanged();
                    categorie_Abonnement.setAdapter(categorie);

                    String cv = TwHelper.getKeyOf(catsIDS, categoryValue == null ? row.get("CODCATAB") : categoryValue, "");
                    int pc = categorie.getPosition(cv);
                    categorie_Abonnement.setSelection(pc);
                }
                if (newSettingsResponse.getEmplacement() != null) {
                    for (Emplacement label : newSettingsResponse.getEmplacement()) {
                        if (emplace.contains(label.getLabel())) continue;
                        emplace.add(label.getLabel());
                        empIDS.put(label.getLabel(), String.valueOf(label.getID()));
                    }

                    empl.notifyDataSetChanged();
                    emplacement.setAdapter(empl);

                    String ce = TwHelper.getKeyOf(empIDS, row.get("CODEMPCO"), "");
                    int pe = empl.getPosition(ce);
                    emplacement.setSelection(pe);

                }
            } else if (newSettingsResponse != null) {
                if (newSettingsResponse.getBranchement().getNature() != null) {


                    naturee.clear();
                    naturesIDS.clear();
                    naturee.add("<VIDE>");

                    for (NatureBr label : newSettingsResponse.getBranchement().getNature()) {

                        if (label.getCODCATAB().equals(categoryValue)) {
                            naturee.add(label.getLabel());
                            naturesIDS.put(label.getLabel(), String.valueOf(label.getID()));
                        }

                    }
                    nature.notifyDataSetChanged();
                    nature_installation.setAdapter(nature);

                    String nv = TwHelper.getKeyOf(naturesIDS, natureValue == null ? row.get("CODNATIN") : natureValue, "");
                    int p = nature.getPosition(nv);
                    nature_installation.setSelection(p);
                }
                if (newSettingsResponse.getBranchement().getCategorie() != null) {

                    categorie.clear();
                    catsIDS.clear();
                    category.clear();
                    category.add("<VIDE>");


                    for (CategorieBr label : newSettingsResponse.getBranchement().getCategorie()) {
                        category.add(label.getLabel());
                        catsIDS.put(label.getLabel(), String.valueOf(label.getID()));
                    }

                    categorie.notifyDataSetChanged();
                    categorie_Abonnement.setAdapter(categorie);

                    String cv = TwHelper.getKeyOf(catsIDS, categoryValue == null ? row.get("CODCATAB") : categoryValue, "");
                    int pc = categorie.getPosition(cv);
                    categorie_Abonnement.setSelection(pc);
                }
            }

        });


        Intent intent = getIntent();
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            if (bundle.getString("date") != null && !isBR) {
                this.doss_annee = bundle.getString("doss_annee");
                this.gerance = bundle.getString("gerance");
                this.doss_numm = bundle.getString("doss_numm");
                this.date = bundle.getString("date");
                this.num_operation = bundle.getString("num_operation");
                this.status = bundle.getString("status");
                this.date = bundle.getString("date");
                this.adreloca = bundle.getString("adreloca");
                this.nature_install = bundle.getString("nature_install");
                this.etage = bundle.getString("etage");
                client.setText(bundle.getString("adreloca"));
                typeAction.setText(typeAction.getText() + " Exécutions");
                this.dossierArrayList = intent.getParcelableArrayListExtra("dossier");

                dossierr.add("<Aucun>");
                if (this.dossierArrayList != null)
                    for (Dossier label : dossierArrayList) {
                        dossierr.add(label.getNUM());
                        //emplace.add(label.getADRESSE());
                    }
                dossier.notifyDataSetChanged();
                dossier_resiler.setAdapter(dossier);
                empl.notifyDataSetChanged();
                emplacement.setAdapter(empl);


            }
        }

    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch (view.getId()) {
            case R.id.radio_pirates:
                if (checked)
                    this.devis = 1;
//                Toast.makeText(this, "Avis devis " + this.devis, Toast.LENGTH_SHORT).show();
                break;
            case R.id.radio_ninjas:
                if (checked)
                    // Ninjas rule
                    this.devis = 0;
//                Toast.makeText(this, "Sans Devis " + this.devis, Toast.LENGTH_SHORT).show();
                break;
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Spinner spinner = (Spinner) parent;

        if (spinner.getId() == R.id.nature_installation) {

            String nv = spinner.getItemAtPosition(position).toString();
            natureValue = naturesIDS.get(nv);

        } else if (spinner.getId() == R.id.categorie_Abonnement) {

            String bef = categoryValue;
            String catv = spinner.getItemAtPosition(position).toString();
            categoryValue = catsIDS.get(catv);

            if (bef != categoryValue) {
                natureValue = null;
                SettingsResponse s = demandViewModel.SettingsMutableLiveData.getValue();
                s.setId(s.getId() + 1);
                demandViewModel.SettingsMutableLiveData.setValue(s);
            }


        } else if (spinner.getId() == R.id.dossier_resiler) {

            dossierValue = spinner.getItemAtPosition(position).toString();

        } else if (spinner.getId() == R.id.emplacement) {

            String emplv = spinner.getItemAtPosition(position).toString();
            emplacementValue = empIDS.get(emplv);

        } else if (spinner.getId() == R.id.nature_lot) {

            lotValue = spinner.getItemAtPosition(position).toString();

        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    private void SelectImage() {

        final CharSequence[] items = {"Camera", "Gallery", "Cancel"};

        AlertDialog.Builder builder = new AlertDialog.Builder(ExecutionFragment.this);
        builder.setTitle("Add Image");

        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {
                if (items[i].equals("Camera")) {

                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(intent, REQUEST_CAMERA);

                } else if (items[i].equals("Gallery")) {

                    Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    intent.setType("image/*");
                    //startActivityForResult(intent.createChooser(intent, "Select File"), SELECT_FILE);
                    startActivityForResult(intent, SELECT_FILE);

                } else if (items[i].equals("Cancel")) {
                    dialog.dismiss();
                }
            }

        });
        builder.show();

    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {

            if (requestCode == REQUEST_CAMERA) {

                Bundle bundle = data.getExtras();
                Bitmap bitmap = (Bitmap) bundle.get("data");
                ivImage.setImageBitmap(bitmap);

                ByteArrayOutputStream stream = new ByteArrayOutputStream();

                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);

                byte[] byteArray = stream.toByteArray();

                if (false && bitmap != null && !bitmap.isRecycled()) {
                    bitmap.recycle();
                    bitmap = null;
                }

                final Base64.Encoder encoder = Base64.getEncoder();
                base64Image = encoder.encodeToString(byteArray);


                Log.i("Camera-base64", base64Image);

            } else if (requestCode == SELECT_FILE) {

                Uri selectedImageUri = data.getData();
                Bitmap bitmap = null;
                if (selectedImageUri != null) {
                    try {
                        bitmap = ImageUtils.getBitmapFormUri(this, selectedImageUri);
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();

                        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                        ivImage.setImageBitmap(bitmap);

                        byte[] byteArray = stream.toByteArray();

                        if (false && bitmap != null && !bitmap.isRecycled()) {
                            bitmap.recycle();
                            bitmap = null;
                        }

                        final Base64.Encoder encoder = Base64.getEncoder();
                        base64Image = encoder.encodeToString(byteArray);
                        Log.i("File-base64", base64Image);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }


                }

            }

        }
    }

}