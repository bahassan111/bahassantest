import 'package:driver/constants/constants.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'upcoming_item.dart';

class UpbookingJobsUI extends StatefulWidget {
  @override
  _UpbookingJobsUIState createState() => _UpbookingJobsUIState();
}

class _UpbookingJobsUIState extends State<UpbookingJobsUI> {
  double height, width;

  static PreBookingController to = Get.find();

  @override
  void initState() {
    to.upComingRides = null;
    to.getUpbookings().then((value) {
      if (mounted) setState(() {});
      to.upComingRides.forEach((element) {
        to.driverPrebookingstatusChange(rideDetailModel: element);
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Colors.white, //AppThemes.pauaBorderColor
      body: SafeArea(
        child: Container(
          width: width,
          child: Column(
            children: [
              appbar(context),
              to.upComingRides != null
                  ? Expanded(
                      child: ListView.builder(
                      itemCount: to.upComingRides.length,
                      itemBuilder: (context, index) {
                        return UpcomingItem(
                          rideDetailModel: to.upComingRides[index],
                        );
                      },
                    ))
                  : Expanded(
                      child: Center(
                        child: CircularProgressIndicator(),
                      ),
                    )
            ],
          ),
        ),
      ),
    );
  }

  appbar(context) => Container(
        width: width,
        margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        color: AppThemes.pauaBorderColor,
        child: Stack(
          children: [
            Center(
                child: Text(
              "upcoming_jobs".tr,
              style: Theme.of(context).textTheme.subtitle1.copyWith(
                    fontSize: 20,
                    fontFamily: "NunitoSans",
                    fontWeight: FontWeight.w800,
                  ),
            )),
            GestureDetector(
              onTap: () => Get.back(),
              child: Image.asset(
                AllImages.backIcon,
                height: 25,
                width: 25,
                color: AppThemes.lightBackButtonColor,
              ),
            ),
          ],
        ),
      );
}
