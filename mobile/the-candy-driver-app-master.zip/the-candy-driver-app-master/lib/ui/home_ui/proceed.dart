import 'dart:async';
import 'dart:convert';
import 'package:audioplayers/audio_cache.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:bot_toast/bot_toast.dart';
import 'package:driver/constants/constants.dart';
import 'package:driver/constants/helpers/helpers.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:driver/models/instant_booking_ride.dart';
import 'package:driver/ui/components/components.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:wakelock/wakelock.dart';

class Proceed extends StatefulWidget {
  @override
  _ProceedState createState() => _ProceedState();
}

class _ProceedState<state> extends State<Proceed> {
  static HomeController to = Get.find();
  static AuthController authTo = Get.find();
  static MyMapController mapTo = Get.find();
  static PreBookingController preTo = Get.find();
  final store = GetStorage();

  Timer _timer;
  int _start = 10;
  AudioCache cache = AudioCache();
  AudioPlayer player;
  @override
  void initState() {
    super.initState();
    startTimer();
    Wakelock.enable();
  }

  startTone() async {
    player = await cache.play(Tones.bookingCancel).onError((error, stackTrace) {
      return null;
    }).whenComplete(() {});
  }

  void startTimer() async {
    const oneSec = const Duration(seconds: 30);
    _timer = new Timer.periodic(
      oneSec,
      (Timer timer) async {
        if (_start == 0) {
          setState(() {
            timer.cancel();
          });
        } else {
          checkRideIsCancelOrNot();
        }
      },
    );
  }

  checkRideIsCancelOrNot() async {
    final status = await to.driverAlreadyassignRide();
    if (int.tryParse(status.toString()) >= 2) {
      startTone();
      _timer.cancel();
      BotToast.showWidget(
        toastBuilder: (_) => SuccessDialog(
          title: "alert".tr,
          message: "ride_cancel".tr,
          ontap: () {
            to.rideDetail = null;
            mapTo.mapMatchingModel = null;
            mapTo.routeDetail.value = null;
            to.homeScreenStatus.value = HomeScreenStatus.None;
            player.stop();
            store.remove("current_ride");
            BotToast.cleanAll();
          },
        ),
      );
      return true;
    }
    return false;
  }

  @override
  void dispose() {
    _timer?.cancel();
    player?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          SizedBox(
            height: 20,
          ),
          displayDetail(
              title: "booking_date".tr + ": ",
              value: datedayddMMMyyyy(strinToDateTime(to.rideDetail.bookDate))),

          SizedBox(
            height: 5,
          ),
          displayDetail(
              title: "booking_number".tr + ": ",
              value: getBookType(to.rideDetail.bookType) +
                  to.rideDetail.id +
                  to.rideDetail.categoryCode), //
          Divider(
            thickness: 1,
            color: Colors.black,
          ),
          SizedBox(
            height: 10,
          ),
          Center(
            child: Text(
              "picking_up".tr + " :",
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
            ),
          ),
          SizedBox(
            height: 10,
          ),

          tripDetail(context,
              name: to.rideDetail.fullname,
              number: to.rideDetail.mobile, onTap: () async {
            String url = 'tel:' + to.rideDetail.mobile.toString();
            if (await canLaunch(url)) {
              await launch(url);
            }
          }),
          SizedBox(
            height: 15,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                Text(
                  "remark".tr + ": ",
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                ),
                Expanded(
                  child: Text(
                    to.rideDetail.note,
                    style: TextStyle(fontSize: 14),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: RoundButton(
              text: "i_have_arrived".tr,
              // onTap: (DateTime.now().isAfter(DateTime.parse(
              //                     preTo?.selectedPreBooking?.prebookingdate ??
              //                         DateTime.now().toString())
              //                 .subtract(Duration(minutes: 10))) &&
              //             to.selectedJobType == "PB") ||
              //         to.selectedJobType == "IB"
              //     ?
              //
              onTap: () async {
                var prebook = to.rideDetail;
                print("WHY" + prebook.bookType.toString());
                if ((strinToDateTime(prebook.bookDate)  )
                        .difference(DateTime.now())
                        .inMinutes >
                    0 && prebook.bookType.toString() != '1' ) {
                  print(strinToDateTime(prebook.bookDate)
                      .difference(DateTime.now())
                      .inMinutes
                      .toString());
                  BotToast.showWidget(
                    toastBuilder: (_) => ErrorDialog(
                      title: "alert".tr,
                      message: "Please Wait for PickUp Time",
                    ),
                  );
                  return;
                }
                BotToast.showLoading();
                final bool isRideCancel = await checkRideIsCancelOrNot();

                if (!isRideCancel) {
                  BotToast.cleanAll();
                  final double distanceInMeters = Geolocator.distanceBetween(
                    to.currentLocation.latitude,
                    to.currentLocation.longitude,
                    double.tryParse(to.rideDetail.pickuplat),
                    double.tryParse(to.rideDetail.pickuplong),
                  );
                  print("distanceInMeters $distanceInMeters");
                  if (distanceInMeters > 500) {
                    BotToast.showWidget(
                      toastBuilder: (_) => ErrorDialog(
                        title: "alert".tr,
                        message: "far_away_pick_up_location".tr,
                      ),
                    );
                  } else {
                    await to.iHaveArrived(
                      rideId: int.tryParse(to.rideDetail.id),
                      statusType: 1,
                      bookType: int.tryParse(to.rideDetail.bookType),
                      driverId: int.tryParse(authTo.userModel.id),
                      startTime: null,
                      driverArrivaltime: DateTime.now(),
                      navigateTo: HomeScreenStatus.IhaveArrived,
                    );
                    to.rideDetail.driverArrivaltime =
                        formatehhmmss(DateTime.now());

                    store.write(
                      "current_ride",
                      json.encode(
                        to.rideDetail.toJson(),
                      ),
                    );
                  }
                } else {
                  store.remove("current_ride");
                }
              },

              textStyle: AppThemes.lightTheme.textTheme.headline1
                  .copyWith(fontSize: 15, fontWeight: FontWeight.w600),
            ),
          ),
          SizedBox(
            height: 15,
          ),
        ],
      ),
    );
  }

  tripDetail(context, {String name, String number, Function onTap}) {
    return GestureDetector(
      onTap: onTap != null ? onTap : () {},
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 20),
        child: Row(
          children: [
            Image.asset(
              AllImages.passangerIcon,
              height: 35,
              fit: BoxFit.cover,
            ),
            SizedBox(
              width: 10,
            ),
            Expanded(
              child: Text(
                name,
                style: AppThemes.lightTheme.textTheme.headline1
                    .copyWith(fontSize: 15),
                maxLines: 1,
              ),
            ),
            SizedBox(
              width: 10,
            ),
            Image.asset(
              AllImages.callIcon,
              height: 35,
            ),
            SizedBox(
              width: 10,
            ),
            Expanded(
              child: Text(
                number,
                style: AppThemes.lightTheme.textTheme.headline5
                    .copyWith(fontSize: 15),
                maxLines: 1,
              ),
            ),
            SizedBox(
              width: 10,
            ),
          ],
        ),
      ),
    );
  }

  displayDetail({String title, String value}) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          Text(
            title,
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(fontSize: 14),
              maxLines: 1,
            ),
          ),
        ],
      ),
    );
  }

  alreadyAssignToSomeOneElseCheck() async {
    final status = await to.driverAlreadyassignRide();
    print("to.rideDetail.rideStatus $status ${status.runtimeType}");
    if (int.tryParse(status.toString()) >= 1) {
      _timer?.cancel();
      startTone();
      BotToast.showWidget(
        toastBuilder: (_) => SuccessDialog(
          title: "alert".tr,
          message: "This ride is already assigned to another driver",
          ontap: () {
            to.rideDetail = null;
            mapTo.mapMatchingModel = null;
            mapTo.routeDetail.value = null;
            to.homeScreenStatus.value = HomeScreenStatus.None;
            store.remove("current_ride");
            player.stop();
            BotToast.cleanAll();
          },
        ),
      );
      return true;
    }
    return false;
  }
}
