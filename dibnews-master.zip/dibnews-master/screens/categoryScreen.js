import React, { Component, useState, useEffect, useRef  } from "react";
import {
    View,
    Text,
    StyleSheet,
    Image,
    ImageBackground,
    ActivityIndicator,
    Button, Dimensions,
    TouchableOpacity,
    Animated, AppState, SafeAreaView,ScrollView,
    BackHandler,Alert
} from "react-native";

import HTMLView from 'react-native-htmlview';
import YoutubePlayer from "react-native-youtube-iframe";
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {updateData} from "../redux/actions/dataAction";
import TopHeader from "../componants/TopHeader";
import css from "../global/GlobalStyle";
import Carousel from 'react-native-snap-carousel';
import GestureRecognizer from 'react-native-swipe-gestures';
import Loader from "./_loader";
import { AntDesign, FontAwesome5 } from '@expo/vector-icons';
import news from "../data/newsDemo";
import storage from "../storage/TwStorage";
import {fetchNewsData} from "../data/NewsData";
import NewsObject from "../data/NewsObject";
import SliderIndicator from "../componants/SliderIndicator";
import modernHome from "../componants/views/modernHome"
import NewsSlider from "../componants/NewsSlider";
import { CommonActions } from '@react-navigation/native';

const win = Dimensions.get('window');
const ofHeight = (p)=> p * win.height / 100;
const ofWidth = (p)=> p * win.width / 100;




class categoryScreen extends Component {


    state = {
        category : null
    };

    error = error = (err_type)=>{
        const { navigation } = this.props;
        navigation.dispatch(
            CommonActions.reset({
                index: 1,
                routes: [
                    { name: 'error', params : {err_type : err_type} },
                ],
            })
        );
    };



    componentDidUpdate(nextProps, nextState, nextContext) {
        let params = this.props.route.params;
        if(params.item !== this.state.category || (params.item && this.state.category && (params.item.id !== this.state.category.id))){

            this.setState({category : params.item});
        }
    }

    componentDidMount() {
        let params = this.props.route.params;
        this.setState({category : params.item});

    }

    logoPressed = ()=>{
        const {navigation} = this.props;

        navigation.navigate('news');
    };
    menuPressed = ()=>{
        const {navigation} = this.props;

        navigation.toggleDrawer();
    };


    render() {


        return (

            <ImageBackground source={require('../assets/bg-syno-shape-300x214.png')} resizeMode={'contain'} style={[this.props.data.theme !== 'dark' ? css.background_fordark : css.background]}>
                {(this.state.modalVisible ? (null) : (<TopHeader transparent={true} floatable={true} title={''} onMenu={this.menuPressed} onUser={this.logoPressed}/>))}


                {!this.state.category ? (<Loader/>) : (<NewsSlider onModal={(visible)=>{

                    this.setState({modalVisible : visible})


                }} err={this.error} cat={this.state.category}/>)}


            </ImageBackground>

        );
    }

}

const styles = StyleSheet.create({

    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    box: {
        backgroundColor: '#61dafb',
        width: 80,
        height: 80,
        borderRadius: 4,
    },


});

const mapDispatchToProps = dispatch => (
    bindActionCreators({
        updateData: updateData,
    }, dispatch)
);

const mapStateToProps = (state) => {
    const { data } = state;
    return { data }
};

export default connect(mapStateToProps, mapDispatchToProps)(categoryScreen);
