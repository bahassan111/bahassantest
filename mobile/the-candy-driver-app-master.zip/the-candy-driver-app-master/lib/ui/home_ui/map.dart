import 'dart:async';
import 'dart:math' as math;
import 'package:bot_toast/bot_toast.dart';
import 'package:driver/constants/constants.dart';
import 'package:driver/constants/helpers/helpers.dart';
import 'package:driver/constants/urls.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:driver/ui/components/components.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:vector_math/vector_math.dart' as vm;

import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import "package:latlong/latlong.dart";
import 'package:logger/logger.dart';
import 'package:url_launcher/url_launcher.dart';

class ShowMap extends StatefulWidget {
  @override
  _ShowMapState createState() => _ShowMapState();
}

class _ShowMapState extends State<ShowMap> with TickerProviderStateMixin {
  double height, width;
  final HomeController to = HomeController.to;
  final MyMapController mapTo = MyMapController.to;

  final MapController mapController = MapController();
  bool isLocationPermission = false;
  Timer _timer;
  AnimationController _controller;
  LatLng lovalLtnLng;
  double bearing;
  bool loadedPosition = false;
  String buildTime(int time) {
    // return "$minutesToPrint:$secondsToPrint:$millisecondsToPrint";

    // final timeLeft = widget.challengeData.time - time;
    final hoursStr = ((time / 3600) % 60).floor().toString().padLeft(2, '0');
    final minutesStr = ((time / 60) % 60).floor().toString().padLeft(2, '0');
    final secondsStr = (time % 60).floor().toString().padLeft(2, '0');

    return '$hoursStr:$minutesStr:$secondsStr';
  }

  StreamSubscription _location;
  Animation<double> _animation;
  @override
  void initState() {
    super.initState();
    locationPermissioncheck().then((value) {
      if (value) {
        setState(() {
          isLocationPermission = value;
        });
        Geolocator.getCurrentPosition().then((pos) {
          to.currentLocation = LatLng(pos.latitude, pos.longitude);
          setState(() {
            loadedPosition = true;
          });
          print("WWWWWWWWWWW");
          // mapController.move(to.currentLocation, 17.0);
        });
        _location = Geolocator.getPositionStream(
          distanceFilter: 20,
        ).listen((value) {
          to.updateDriverLocation();
          if (value == null) {
            return;
          }

          if (lovalLtnLng != null) {
            if ((lovalLtnLng.latitude - value.latitude).abs() > 0.00001000 &&
                (lovalLtnLng.longitude - value.longitude).abs() > 0.00001000) {
              reCenterMapPosition(currentZoom: mapController.zoom);
            }
            final calculatedBearing = Geolocator.bearingBetween(
              lovalLtnLng.latitude,
              lovalLtnLng.longitude,
              value.latitude,
              value.longitude,
            );
            bearing = calculatedBearing != 0 ? calculatedBearing : bearing ?? 0;
          }

          Logger().wtf(bearing);
          to.currentLocation = LatLng(value.latitude, value.longitude);
          to.bearing = bearing;
          lovalLtnLng = to.currentLocation;
          if (mounted) {
            setState(() {});
          }
        });

        mapTo.getAllDriverFromFirebase().then((value) {
          if (mounted) setState(() {});
        });

        print("map listner intialize");
        if (to.homeScreenStatus.value != HomeScreenStatus.None) {
          mapTo.getRouteBetweenPath().then((value) {
            if (mounted) {
              setState(() {});
            }
          });
        }
        to.homeScreenStatus.addListener(() {
          if (to.homeScreenStatus.value != HomeScreenStatus.None) {
            mapTo.getRouteBetweenPath().then((value) {
              if (mounted) {
                setState(() {});
              }
            });
          }
        });

        mapTo.routeDetail.addListener(() {
          if (mounted) {
            setState(() {});
          }
        });
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _location?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return isLocationPermission
        ? AnimatedContainer(
            duration: Duration(milliseconds: 500),
            child: !loadedPosition
                ? Center(
                    child: CircularProgressIndicator(),
                  )
                : Stack(
                    children: [
                      FlutterMap(
                        mapController: mapController,
                        options: MapOptions(
                          center: to.currentLocation,
                          zoom: 17.0,
                          onPositionChanged: (MapPosition mapPosition, b) {
                            //  print("value ${mapPosition.center} b $b");
                          },
                        ),
                        layers: [
                          TileLayerOptions(
                            urlTemplate: Urls.mapBoxThirPartyUrl,
                            additionalOptions: {
                              'accessToken': ProjectKeys.mapBoxKey,
                              "id": "mapbox.mapbox-streets-v8",
                            },
                          ),
                          PolylineLayerOptions(
                            polylines: mapTo?.routeDetail?.value?.code == 'Ok'
                                ? [
                                    Polyline(
                                      points: [
                                        ...mapTo
                                                .mapMatchingModel
                                                ?.matchings
                                                ?.first
                                                ?.geometry
                                                ?.coordinates ??
                                            []
                                      ],
                                      strokeWidth: 5,
                                      color: AppThemes.pauaBorderColor,
                                    )
                                  ]
                                : [],
                            polylineCulling: true,
                          ),
                          MarkerLayerOptions(
                            markers: [
                              Marker(
                                width: 30.0,
                                height: 30.0,
                                point: to.currentLocation,
                                builder: (ctx) => Transform.rotate(
                                  angle: vm.radians(bearing ?? 0),
                                  child: Image.asset(
                                    AllImages.taxi,
                                    width: 30.0,
                                    height: 30.0,
                                  ),
                                ),
                              ),
                              for (int i = 0;
                                  i < mapTo.onlineDrivers.length;
                                  i++)
                                Marker(
                                  width: 30.0,
                                  height: 30.0,
                                  point: LatLng(
                                    mapTo?.onlineDrivers[i]?.lat ?? 0.0 ,
                                    mapTo?.onlineDrivers[i]?.lng ?? 0.0  ,
                                  ),
                                  builder: (ctx) => Image.asset(
                                    AllImages.taxi,
                                    width: 30.0,
                                    height: 30.0,
                                  ),
                                ),
                              if (to.rideDetail != null)
                                Marker(
                                  width: 30.0,
                                  height: 30.0,
                                  point: LatLng(
                                    double.tryParse(to.rideDetail.pickuplat),
                                    double.tryParse(to.rideDetail.pickuplong),
                                  ),
                                  builder: (ctx) => Image.asset(
                                    AllImages.pinGreen,
                                  ),
                                ),
                              if (to.rideDetail != null)
                                Marker(
                                  width: 30.0,
                                  height: 30.0,
                                  point: LatLng(
                                    double.tryParse(to.rideDetail.droplat),
                                    double.tryParse(to.rideDetail.droplong),
                                  ),
                                  builder: (ctx) => Image.asset(AllImages.pin),
                                )
                            ],
                          ),
                        ],
                      ),
                      GetBuilder<HomeController>(builder: (_) {
                        return to.charterTimeToShow > 0 && !to.canFinishTrip
                            ? Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Align(
                                  alignment: Alignment.bottomLeft,
                                  child: Opacity(
                                    opacity: 0.5,
                                    child: Container(
                                      decoration: BoxDecoration(
                                          color: Colors.black,
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(10))),
                                      height: 50,
                                      child: Center(
                                          child: Text(
                                              buildTime(to.charterTimeToShow),
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 20,
                                                  fontWeight:
                                                      FontWeight.bold))),
                                      width: 150,
                                    ),
                                  ),
                                ),
                              )
                            : SizedBox();
                      }),
                      Align(
                        alignment: Alignment.bottomRight,
                        child: RelocationIcon(
                          onTap: reCenterMapPosition,
                        ),
                      ),
                      showLocationOnTop(),
                    ],
                  ))
        : Container();
  }

  reCenterMapPosition({double currentZoom}) async {
    await Future.delayed(Duration(milliseconds: 500));
    setState(() {
      mapController.move(to.currentLocation, currentZoom ?? 18);
      mapController.rotate(0);
    });
  }

  showLocationOnTop() {
    return ValueListenableBuilder(
        valueListenable: to.homeScreenStatus,
        builder: (context, value, child) {
          if (value == HomeScreenStatus.None ||
              value == HomeScreenStatus.TripDetail) {
            return Container();
          }
          return Align(
            alignment: Alignment.topCenter,
            child: SafeArea(
              child: GestureDetector(
                onTap: () {
                  BotToast.showWidget(
                    toastBuilder: (ctx) {
                      return NavigationOptions(
                        lat: double.tryParse(
                            value == HomeScreenStatus.StartTrip ||
                                    value == HomeScreenStatus.IhaveArrived
                                ? to.rideDetail.droplat
                                : to.rideDetail.pickuplat),
                        lng: double.tryParse(
                            value == HomeScreenStatus.StartTrip ||
                                    value == HomeScreenStatus.IhaveArrived
                                ? to.rideDetail.droplong
                                : to.rideDetail.pickuplong),
                      );
                    },
                  );
                },
                child: Container(
                  margin: EdgeInsets.only(left: 60, right: 60, top: 20),
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(50),
                  ),
                  child: Row(
                    children: [
                      Image.asset(
                        AllImages.pin,
                        height: 20,
                        width: 20,
                        fit: BoxFit.cover,
                      ),
                      SizedBox(
                        width: 15,
                      ),
                      Expanded(
                        child: Text(
                          value == HomeScreenStatus.IhaveArrived ||
                                  value == HomeScreenStatus.StartTrip
                              ? to.rideDetail.dropaddress
                              : to.rideDetail.pickupaddress,
                          style: TextStyle(fontSize: 15),
                          maxLines: 1,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        });
  }

  void navigateToGoogle(double lat, double lng) async {
    String googleUrl =
        'https://www.google.com/maps/search/?api=1&query=$lat,$lng';

    if (await canLaunch(googleUrl)) {
      await launch(googleUrl);
    } else {
      throw 'Could not launch ${googleUrl}';
    }
  }

  void navigateToWaze(double lat, double lng) async {
    var url = 'waze://?ll=${lat.toString()},${lng.toString()}';
    var fallbackUrl =
        'https://waze.com/ul?ll=${lat.toString()},${lng.toString()}&navigate=yes';
    try {
      bool launched =
          await launch(url, forceSafariVC: false, forceWebView: false);
      if (!launched) {
        await launch(fallbackUrl, forceSafariVC: false, forceWebView: false);
      }
    } catch (e) {
      await launch(fallbackUrl, forceSafariVC: false, forceWebView: false);
    }
  }
}
