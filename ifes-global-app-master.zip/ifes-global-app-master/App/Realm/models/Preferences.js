import Model from '../model'
export default class Preferences extends Model {
  static schema = {
    name: 'Preferences',
    primaryKey: 'id',
    properties: {
      id: 'int',
      value: 'int'
    }
  }
}