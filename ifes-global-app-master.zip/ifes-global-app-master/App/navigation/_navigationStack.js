import "react-native-gesture-handler";
import React, { Component } from "react";
import {
  createBottomTabNavigator,
  createDrawerNavigator,
  createStackNavigator,
  createSwitchNavigator,
  createAppContainer,
} from "react-navigation";

import HomeScreen from "../screens/HomeScreen";
import SettingsScreen from "../screens/SettingsScreen";
import IntroScreen from "../screens/IntroScreen";
import SousChapitresScreen from "../screens/SousChapitresScreen";
import DetailScreen from "../screens/DetailScreen";
import DrawerScreen from "./DrawerScreen";
import SearchScreen from "../screens/SearchScreen";
import ScreenCountries from "../screens/ScreenCountries";
import ChangeCountries from "../screens/ChangeCountries";

import Colors from "../constants/Colors";
import Icon from "../constants/Icons";

import { Button, TouchableOpacity, View, Text } from "react-native-ui-lib";
import SearchBar from "../components/SearchBar";
import DownloadScreen from "../screens/DownloadScreen";
import I18n from "../commons/i18n";

const menuIcon = (navigation) => {
  return (
    <Icon
      onPress={() => navigation.openDrawer()}
      name="menu"
      iconSize={50}
      color={Colors.green}
    />
  );
};

const headerTitle = (navigation) => {
  return <SearchBar navigation={navigation} />;
};
const headerTitleDetail = () => {
  return (
    <View flex column center>
      <Text center style={{ color: "#253e6e" }}>
        {" "}
        {I18n.t("Commons.infromation", { locale: "fr" })}{" "}
      </Text>
    </View>
  );
};
const headerRight = (navigation) => {
  return (
    <Button
      size="small"
      label={navigation.getParam("lang")}
      avoidMinWidth
      avoidInnerPadding
      bg-green20
      marginH-10
      style={{
        paddingHorizontal: 5,
        fontSize: 10,
      }}
      onPress={navigation.getParam("changeLanguage")}
    />
  );
};

const HomeStack = createStackNavigator(
  {
    Home: {
      screen: HomeScreen,
      navigationOptions: ({ navigation }) => {
        return {
          headerLeft: menuIcon(navigation),
          headerTitle: headerTitle(navigation),
        };
      },
    },
    SousChapitre: {
      screen: SousChapitresScreen,
      navigationOptions: ({ navigation }) => {
        return {
          headerLeft: menuIcon(navigation),
          headerTitle: headerTitle(navigation),
          headerRight: headerRight(navigation),
        };
      },
    },
    DetailChapitre: {
      screen: DetailScreen,
      navigationOptions: ({ navigation }) => {
        return {
          headerLeft: menuIcon(navigation),
          headerTitle: headerTitle(navigation),
          headerRight: headerRight(navigation),
        };
      },
    },
    Search: {
      screen: SearchScreen,
      navigationOptions: ({ navigation }) => {
        return {
          headerLeft: menuIcon(navigation),
          headerTitle: headerTitle(navigation),
          headerRight: headerRight(navigation),
        };
      },
    },
    Countries: {
      screen: ScreenCountries,
      navigationOptions: ({ navigation }) => {
        return {
          headerLeft: menuIcon(navigation),
          headerTitle: headerTitle(navigation),
          headerRight: headerRight(navigation),
        };
      },
    },
    ChangeCountries: {
      screen: ChangeCountries,
      navigationOptions: ({ navigation }) => {
        return {
          headerLeft: menuIcon(navigation),
          headerTitle: headerTitle(navigation),
          headerRight: headerRight(navigation),
        };
      },
    },
    DownloadImage: {
      screen: DownloadScreen,
      navigationOptions: ({ navigation }) => {
        return {
          headerLeft: menuIcon(navigation),
          headerTitle: headerTitle(navigation),
          headerRight: headerRight(navigation),
        };
      },
    },
  },
  {
    navigationOptions: ({ navigation }) => {
      return {
        tabBarVisible: false,
        tabBarLabel: ({ tintColor }) => null,
        tabBarIcon: (focused) => (
          <Icon
            focused={focused}
            name={"home"}
            iconSize={45}
            color={focused ? Colors.white : Colors.gray}
          />
        ),
      };
    },
  }
);

const SettingsStack = createStackNavigator(
  {
    Settings: {
      screen: SettingsScreen,
      navigationOptions: ({ navigation }) => {
        return {
          headerLeft: menuIcon(navigation),
          headerTitle: "Settings",
          headerRight: headerRight(navigation),
        };
      },
    },
  },
  {
    navigationOptions: ({ navigation }) => {
      return {
        tabBarLabel: ({ tintColor }) => null,
        tabBarIcon: (focused) => (
          <TouchableOpacity
            style={{
              width: "100%",
              flex: 1,
              alignItems: "center",
              justifyContent: "center",
            }}
            onPress={() => navigation.goBack(null)}
          >
            <Icon
              focused={focused}
              name={"precedent"}
              iconSize={35}
              color={focused ? Colors.white : Colors.gray}
            />
          </TouchableOpacity>
        ),
        tabBarVisible: false,
      };
    },
  }
);

const mainTabs = {
  HomeStack,
  SettingsStack,
};

const TabRoot = createBottomTabNavigator(mainTabs, {
  navigationOptions: ({ navigation }) => {
    const { routeName } = navigation.state.routes[navigation.state.index];
    return {
      header: null,
      headerTitle: null,
      tabBarOptions: {
        showLabel: true,
        activeTintColor: "#F8F8F8",
        inactiveTintColor: "#CCC",
        style: {
          backgroundColor: "#1a3156",
        },
        tabStyle: { paddingTop: 5 },
      },
    };
  },

  tabBarOptions: {
    showLabel: false,
    activeTintColor: "#F8F8F8",
    inactiveTintColor: Colors.gray,
    style: {
      backgroundColor: Colors.tabBar,
    },
    tabStyle: { paddingTop: 5 },
    onTabPress: (tab) => {
      navigation.goBack();
    },
  },
});

const MainApp = createDrawerNavigator(
  { MainAppTabs: { screen: TabRoot } },
  {
    contentComponent: DrawerScreen,
    drawerWidth: 250,
    drawerBackgroundColor: "transparent",
  }
);

const AppStack = createStackNavigator(
  {
    Main: { screen: MainApp },
  },
  { navigationOptions }
);

const IntroStack = createStackNavigator(
  {
    Intro: {
      screen: IntroScreen,
      navigationOptions: ({ navigation }) => {
        return {
          header: null,
        };
      },
    },
    Main: { screen: MainApp },
  },
  {
    navigationOptions: () => {
      return {
        tabBarVisible: true,
      };
    },
  }
);

MainApp.navigationOptions = { header: null };
const AppNavigator = createSwitchNavigator(
  {
    App: AppStack,
    Intro: IntroStack,
  },
  {
    initialRouteName: "Intro",
  }
);

const navigationOptions = {
  headerTintColor: "#fff",
  // headerForceInset: true,
  tabBarVisible: true,
  mode: "modal",
  headerBackTitleVisible: true,
  headerBackTitle: null,
};

const AppContainer = createAppContainer(AppNavigator);

export default AppContainer;
