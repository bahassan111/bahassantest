package ma.rak.ov.models;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Handler;
import android.util.Log;

import com.google.gson.annotations.SerializedName;

import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.exceptions.RealmException;
import ma.rak.ov.R;
import ma.rak.ov.api.RetrofitClient;
import ma.rak.ov.api.TwDatabase;
import ma.rak.ov.bodyResponse.OperationResponse;
import ma.rak.ov.storage.SharedPrefManager;
import ma.rak.ov.ui.main.ExecutionFragment;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Abonnement extends RealmObject {

    private String CODUTIEX;
    private String CODNATOP;
    private String STATOPER;
    private String NOM;
    private String CIN;
    private String CODE_CLIENT;
    private String CODNATCL;
    private String LIBNATCL;
    private String RAISSOCI;
    private String ADRECORR;
    private String NUMEDOSS;
    private String ANNEDOSS;
    private String NUMEPOLI;
    private String TELECLIE;
    private String NOMPRERE;
    private String DATDEMAB;
    private String DATCREAB;
    private String IDENLOCA;
    private String LIBEGERA;
    private String CODECLAB;
    private String TYPECLIE;
    private String ADRELOCA;
    private String CODEAGEN;
    private String LIBEAGEN;
    private String CODELOCA;
    private String LIBELOCA;
    private String CODESECT;
    private String CODEGERA;
    private String CODTAREA;
    private String CODCATAB;
    private String CODNATIN;
    private String DATESAIS;
    private String RESTRAOP;
    private String DATTRAOP;
    private String CODUTIMA;
    private String CODEMPCO;
    private String NATU_LOT;
    private String NIVEALIM;
    private String CODEETAG;
    private String ANDORESI;
    private String NUDORESI;
    private String AVESANDE;
    private String COMOSTOP;
    private String NUMETOUR;
    private String NUMOPRAB;
    private String LONGITUDE;
    private String LATITUDE;
    private String IMAGE;


    @SerializedName("DOSSIERS")
    private RealmList<Dossier> DOSSIERS;

    public Abonnement() {
    }

    public Abonnement(String CODUTIEX, String CODNATOP, String STATOPER, String NOM, String CIN, String CODE_CLIENT, String CODNATCL, String LIBNATCL, String RAISSOCI, String ADRECORR, String NUMEDOSS, String ANNEDOSS, String NUMEPOLI, String TELECLIE, String NOMPRERE, String DATDEMAB, String DATCREAB, String IDENLOCA, String LIBEGERA, String CODECLAB, String TYPECLIE, String ADRELOCA, String CODEAGEN, String LIBEAGEN, String CODELOCA, String LIBELOCA, String CODESECT, String CODEGERA, String CODTAREA, String CODCATAB, String CODNATIN, String DATESAIS, String RESTRAOP, String DATTRAOP, String CODUTIMA, String CODEMPCO, String NATU_LOT, String NIVEALIM, String CODEETAG, String ANDORESI, String NUDORESI, String AVESANDE, String COMOSTOP, String NUMETOUR, String NUMOPRAB, String LONGITUDE, String LATITUDE, RealmList<Dossier> DOSSIERS, String IMAGE) {
        this.CODUTIEX = CODUTIEX;
        this.CODNATOP = CODNATOP;
        this.STATOPER = STATOPER;
        this.NOM = NOM;
        this.CIN = CIN;
        this.CODE_CLIENT = CODE_CLIENT;
        this.CODNATCL = CODNATCL;
        this.LIBNATCL = LIBNATCL;
        this.RAISSOCI = RAISSOCI;
        this.ADRECORR = ADRECORR;
        this.NUMEDOSS = NUMEDOSS;
        this.ANNEDOSS = ANNEDOSS;
        this.NUMEPOLI = NUMEPOLI;
        this.TELECLIE = TELECLIE;
        this.NOMPRERE = NOMPRERE;
        this.DATDEMAB = DATDEMAB;
        this.DATCREAB = DATCREAB;
        this.IDENLOCA = IDENLOCA;
        this.LIBEGERA = LIBEGERA;
        this.CODECLAB = CODECLAB;
        this.TYPECLIE = TYPECLIE;
        this.ADRELOCA = ADRELOCA;
        this.CODEAGEN = CODEAGEN;
        this.LIBEAGEN = LIBEAGEN;
        this.CODELOCA = CODELOCA;
        this.LIBELOCA = LIBELOCA;
        this.CODESECT = CODESECT;
        this.CODEGERA = CODEGERA;
        this.CODTAREA = CODTAREA;
        this.CODCATAB = CODCATAB;
        this.CODNATIN = CODNATIN;
        this.DATESAIS = DATESAIS;
        this.RESTRAOP = RESTRAOP;
        this.DATTRAOP = DATTRAOP;
        this.CODUTIMA = CODUTIMA;
        this.CODEMPCO = CODEMPCO;
        this.NATU_LOT = NATU_LOT;
        this.NIVEALIM = NIVEALIM;
        this.CODEETAG = CODEETAG;
        this.ANDORESI = ANDORESI;
        this.NUDORESI = NUDORESI;
        this.AVESANDE = AVESANDE;
        this.COMOSTOP = COMOSTOP;
        this.NUMETOUR = NUMETOUR;
        this.NUMOPRAB = NUMOPRAB;
        this.LONGITUDE = LONGITUDE;
        this.LATITUDE = LATITUDE;
        this.DOSSIERS = DOSSIERS;
        this.IMAGE = IMAGE;
    }

    public String getCODUTIEX() {
        return CODUTIEX;
    }

    public void setCODUTIEX(String CODUTIEX) {
        this.CODUTIEX = CODUTIEX;
    }

    public String getCODNATOP() {
        return CODNATOP;
    }

    public void setCODNATOP(String CODNATOP) {
        this.CODNATOP = CODNATOP;
    }

    public String getNUMOPRAB() {
        return NUMOPRAB;
    }

    public void setNUMOPRAB(String NUMOPRAB) {
        this.NUMOPRAB = NUMOPRAB;
    }

    public String getSTATOPER() {
        return STATOPER;
    }

    public void setSTATOPER(String STATOPER) {
        this.STATOPER = STATOPER;
    }

    public String getNUDORESI() {
        return NUDORESI;
    }

    public void setNUDORESI(String NUDORESI) {
        this.NUDORESI = NUDORESI;
    }

    public String getNOM() {
        return NOM;
    }

    public void setNOM(String NOM) {
        this.NOM = NOM;
    }

    public String getCIN() {
        return CIN;
    }

    public void setCIN(String CIN) {
        this.CIN = CIN;
    }

    public String getCODE_CLIENT() {
        return CODE_CLIENT;
    }

    public void setCODE_CLIENT(String CODE_CLIENT) {
        this.CODE_CLIENT = CODE_CLIENT;
    }

    public String getCODNATCL() {
        return CODNATCL;
    }

    public void setCODNATCL(String CODNATCL) {
        this.CODNATCL = CODNATCL;
    }

    public String getLIBNATCL() {
        return LIBNATCL;
    }

    public void setLIBNATCL(String LIBNATCL) {
        this.LIBNATCL = LIBNATCL;
    }

    public String getRAISSOCI() {
        return RAISSOCI;
    }

    public void setRAISSOCI(String RAISSOCI) {
        this.RAISSOCI = RAISSOCI;
    }

    public String getADRECORR() {
        return ADRECORR;
    }

    public void setADRECORR(String ADRECORR) {
        this.ADRECORR = ADRECORR;
    }

    public String getNUMEDOSS() {
        return NUMEDOSS;
    }

    public void setNUMEDOSS(String NUMEDOSS) {
        this.NUMEDOSS = NUMEDOSS;
    }

    public String getANNEDOSS() {
        return ANNEDOSS;
    }

    public void setANNEDOSS(String ANNEDOSS) {
        this.ANNEDOSS = ANNEDOSS;
    }

    public String getNUMEPOLI() {
        return NUMEPOLI;
    }

    public void setNUMEPOLI(String NUMEPOLI) {
        this.NUMEPOLI = NUMEPOLI;
    }

    public String getTELECLIE() {
        return TELECLIE;
    }

    public void setTELECLIE(String TELECLIE) {
        this.TELECLIE = TELECLIE;
    }

    public String getNOMPRERE() {
        return NOMPRERE;
    }

    public void setNOMPRERE(String NOMPRERE) {
        this.NOMPRERE = NOMPRERE;
    }

    public String getDATDEMAB() {
        return DATDEMAB;
    }

    public void setDATDEMAB(String DATDEMAB) {
        this.DATDEMAB = DATDEMAB;
    }

    public String getDATCREAB() {
        return DATCREAB;
    }

    public void setDATCREAB(String DATCREAB) {
        this.DATCREAB = DATCREAB;
    }

    public String getIDENLOCA() {
        return IDENLOCA;
    }

    public void setIDENLOCA(String IDENLOCA) {
        this.IDENLOCA = IDENLOCA;
    }

    public String getLIBEGERA() {
        return LIBEGERA;
    }

    public void setLIBEGERA(String LIBEGERA) {
        this.LIBEGERA = LIBEGERA;
    }

    public String getCODECLAB() {
        return CODECLAB;
    }

    public void setCODECLAB(String CODECLAB) {
        this.CODECLAB = CODECLAB;
    }

    public String getTYPECLIE() {
        return TYPECLIE;
    }

    public void setTYPECLIE(String TYPECLIE) {
        this.TYPECLIE = TYPECLIE;
    }

    public String getADRELOCA() {
        return ADRELOCA;
    }

    public void setADRELOCA(String ADRELOCA) {
        this.ADRELOCA = ADRELOCA;
    }

    public String getCODEAGEN() {
        return CODEAGEN;
    }

    public void setCODEAGEN(String CODEAGEN) {
        this.CODEAGEN = CODEAGEN;
    }

    public String getLIBEAGEN() {
        return LIBEAGEN;
    }

    public void setLIBEAGEN(String LIBEAGEN) {
        this.LIBEAGEN = LIBEAGEN;
    }

    public String getCODELOCA() {
        return CODELOCA;
    }

    public void setCODELOCA(String CODELOCA) {
        this.CODELOCA = CODELOCA;
    }

    public String getLIBELOCA() {
        return LIBELOCA;
    }

    public void setLIBELOCA(String LIBELOCA) {
        this.LIBELOCA = LIBELOCA;
    }

    public String getCODESECT() {
        return CODESECT;
    }

    public void setCODESECT(String CODESECT) {
        this.CODESECT = CODESECT;
    }

    public String getCODEGERA() {
        return CODEGERA;
    }

    public void setCODEGERA(String CODEGERA) {
        this.CODEGERA = CODEGERA;
    }

    public String getCODTAREA() {
        return CODTAREA;
    }

    public void setCODTAREA(String CODTAREA) {
        this.CODTAREA = CODTAREA;
    }

    public String getCODCATAB() {
        return CODCATAB;
    }

    public void setCODCATAB(String CODCATAB) {
        this.CODCATAB = CODCATAB;
    }

    public String getCODNATIN() {
        return CODNATIN;
    }

    public void setCODNATIN(String CODNATIN) {
        this.CODNATIN = CODNATIN;
    }

    public String getDATESAIS() {
        return DATESAIS;
    }

    public void setDATESAIS(String DATESAIS) {
        this.DATESAIS = DATESAIS;
    }

    public String getRESTRAOP() {
        return RESTRAOP;
    }

    public void setRESTRAOP(String RESTRAOP) {
        this.RESTRAOP = RESTRAOP;
    }

    public String getDATTRAOP() {
        return DATTRAOP;
    }

    public void setDATTRAOP(String DATTRAOP) {
        this.DATTRAOP = DATTRAOP;
    }

    public String getCODUTIMA() {
        return CODUTIMA;
    }

    public void setCODUTIMA(String CODUTIMA) {
        this.CODUTIMA = CODUTIMA;
    }

    public String getCODEMPCO() {
        return CODEMPCO;
    }

    public void setCODEMPCO(String CODEMPCO) {
        this.CODEMPCO = CODEMPCO;
    }

    public String getNATU_LOT() {
        return NATU_LOT;
    }

    public void setNATU_LOT(String NATU_LOT) {
        this.NATU_LOT = NATU_LOT;
    }

    public String getNIVEALIM() {
        return NIVEALIM;
    }

    public void setNIVEALIM(String NIVEALIM) {
        this.NIVEALIM = NIVEALIM;
    }

    public String getCODEETAG() {
        return CODEETAG;
    }

    public void setCODEETAG(String CODEETAG) {
        this.CODEETAG = CODEETAG;
    }

    public String getANDORESI() {
        return ANDORESI;
    }

    public void setANDORESI(String ANDORESI) {
        this.ANDORESI = ANDORESI;
    }

    public String getAVESANDE() {
        return AVESANDE;
    }

    public void setAVESANDE(String AVESANDE) {
        this.AVESANDE = AVESANDE;
    }

    public String getCOMOSTOP() {
        return COMOSTOP;
    }

    public void setCOMOSTOP(String COMOSTOP) {
        this.COMOSTOP = COMOSTOP;
    }

    public String getNUMETOUR() {
        return NUMETOUR;
    }

    public void setNUMETOUR(String NUMETOUR) {
        this.NUMETOUR = NUMETOUR;
    }

    public String getLONGITUDE() {
        return LONGITUDE;
    }

    public void setLONGITUDE(String LONGITUDE) {
        this.LONGITUDE = LONGITUDE;
    }

    public String getLATITUDE() {
        return LATITUDE;
    }

    public void setLATITUDE(String LATITUDE) {
        this.LATITUDE = LATITUDE;
    }

    public RealmList<Dossier> getDOSSIERS() {
        return DOSSIERS;
    }

    public String getDossiersJSON(){
        String str = "[";

        for (Dossier dos :
                this.getDOSSIERS()) {
            str += dos.json() + ",";
        }

        str = str.substring(0, str.length() - 1);
        return str + "]";
    }

    public void setDOSSIERS(RealmList<Dossier> DOSSIERS) {
        this.DOSSIERS = DOSSIERS;
    }

    public String getIMAGE() {
        return IMAGE;
    }

    public void setIMAGE(String IMAGE) {
        this.IMAGE = IMAGE;
    }

    @Override
    public String toString() {
        return "Abonnement{" +
                "CODUTIEX='" + CODUTIEX + '\'' +
                ", CODNATOP='" + CODNATOP + '\'' +
                ", STATOPER='" + STATOPER + '\'' +
                ", NOM='" + NOM + '\'' +
                ", CIN='" + CIN + '\'' +
                ", CODE_CLIENT='" + CODE_CLIENT + '\'' +
                ", CODNATCL='" + CODNATCL + '\'' +
                ", LIBNATCL='" + LIBNATCL + '\'' +
                ", RAISSOCI='" + RAISSOCI + '\'' +
                ", ADRECORR='" + ADRECORR + '\'' +
                ", NUMEDOSS='" + NUMEDOSS + '\'' +
                ", ANNEDOSS='" + ANNEDOSS + '\'' +
                ", NUMEPOLI='" + NUMEPOLI + '\'' +
                ", TELECLIE='" + TELECLIE + '\'' +
                ", NOMPRERE='" + NOMPRERE + '\'' +
                ", DATDEMAB='" + DATDEMAB + '\'' +
                ", DATCREAB='" + DATCREAB + '\'' +
                ", IDENLOCA='" + IDENLOCA + '\'' +
                ", LIBEGERA='" + LIBEGERA + '\'' +
                ", CODECLAB='" + CODECLAB + '\'' +
                ", TYPECLIE='" + TYPECLIE + '\'' +
                ", ADRELOCA='" + ADRELOCA + '\'' +
                ", CODEAGEN='" + CODEAGEN + '\'' +
                ", LIBEAGEN='" + LIBEAGEN + '\'' +
                ", CODELOCA='" + CODELOCA + '\'' +
                ", LIBELOCA='" + LIBELOCA + '\'' +
                ", CODESECT='" + CODESECT + '\'' +
                ", CODEGERA='" + CODEGERA + '\'' +
                ", CODTAREA='" + CODTAREA + '\'' +
                ", CODCATAB='" + CODCATAB + '\'' +
                ", CODNATIN='" + CODNATIN + '\'' +
                ", DATESAIS='" + DATESAIS + '\'' +
                ", RESTRAOP='" + RESTRAOP + '\'' +
                ", DATTRAOP='" + DATTRAOP + '\'' +
                ", CODUTIMA='" + CODUTIMA + '\'' +
                ", CODEMPCO='" + CODEMPCO + '\'' +
                ", NATU_LOT='" + NATU_LOT + '\'' +
                ", NIVEALIM='" + NIVEALIM + '\'' +
                ", CODEETAG='" + CODEETAG + '\'' +
                ", ANDORESI='" + ANDORESI + '\'' +
                ", NUDORESI='" + NUDORESI + '\'' +
                ", AVESANDE='" + AVESANDE + '\'' +
                ", COMOSTOP='" + COMOSTOP + '\'' +
                ", NUMETOUR='" + NUMETOUR + '\'' +
                ", NUMOPRAB='" + NUMOPRAB + '\'' +
                ", LONGITUDE='" + LONGITUDE + '\'' +
                ", LATITUDE='" + LATITUDE + '\'' +
                ", IMAGE='" + IMAGE + '\'' +
                ", DOSSIERS=" + DOSSIERS +
                '}';
    }
}
