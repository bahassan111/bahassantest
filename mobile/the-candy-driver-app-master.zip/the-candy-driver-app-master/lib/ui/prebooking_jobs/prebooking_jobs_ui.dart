import 'package:driver/constants/constants.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'prebooking_item.dart';

class PrebookingJobsUI extends StatefulWidget {
  @override
  _PrebookingJobsUIState createState() => _PrebookingJobsUIState();
}

class _PrebookingJobsUIState extends State<PrebookingJobsUI> {
  double height, width;

  static PreBookingController to = Get.find();

  @override
  void initState() {
    to.preBookingJobs = null;
    to.getPrebookings().then((value) {
      setState(() {});
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: AppThemes.pauaBorderColor,
      body: SafeArea(
        child: Container(
          width: width,
          child: Column(
            children: [
              appbar(context),
              to.preBookingJobs != null
                  ? Expanded(
                      child: ListView.builder(
                      itemCount: to.preBookingJobs.length,
                      itemBuilder: (context, index) {
                        return PrebookingItem(
                          preBookingModel: to.preBookingJobs[index],
                        );
                      },
                    ))
                  : Expanded(
                      child: Center(
                        child: CircularProgressIndicator(),
                      ),
                    )
            ],
          ),
        ),
      ),
    );
  }

  appbar(context) => Container(
        width: width,
        margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        color: AppThemes.pauaBorderColor,
        child: Stack(
          children: [
            Center(
                child: Text(
              "prebooking_jobs".tr,
              style: Theme.of(context).textTheme.subtitle1.copyWith(
                    fontSize: 20,
                    fontFamily: "NunitoSans",
                    fontWeight: FontWeight.w800,
                  ),
            )),
            GestureDetector(
              onTap: () => Get.back(),
              child: Image.asset(
                AllImages.backIcon,
                height: 25,
                width: 25,
                color: AppThemes.lightBackButtonColor,
              ),
            ),
          ],
        ),
      );
}
