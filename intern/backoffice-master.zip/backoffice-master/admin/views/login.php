<?php
defined('BASE') OR die('Direct access is not allowed');
?>
<!doctype html>
<html class="no-js" lang="">

<head>

    <link rel="stylesheet" type="text/css" href="../../assets/css/login.css"/>
    <meta charset="utf-8">
    <title>MTIP - Administration Space</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?= site_url('images/logo_sm.png'); ?>">

    <!--<link rel="manifest" href="site.webmanifest">-->

    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700&display=swap" rel="stylesheet">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= site_url('assets/css/normalize.css'); ?>">
    <link rel="stylesheet" href="<?= site_url('assets/css/standard.css'); ?>">
    <link rel="stylesheet" href="<?= site_url('assets/css/login.css'); ?>">

    <link rel="stylesheet" href="<?= site_url('assets/css/default.css'); ?>">
    <link rel="stylesheet" href="<?= site_url('assets/css/mobile.css'); ?>">


    <meta name="theme-color" content="#fafafa">

    <script>
        var ifes = {
            url : '<?= site_url('admin') ?>',
            language : {
                loading : 'Loading',
            },
        };


    </script>
</head>
<body>

<div class="loading"><div class="loader"><span><i></i></span> <b><?= lang('loading') ?> ..</b></div></div>

<div id="login" class="">

    <div class="login_view">

        <div class="login_form">
            <form>
                <div class="lgf_header">
                    <h3>Espace d'administration</h3>
                    <h6>Connectez-vous avec votre email et votre mot de passe.</h6>
                </div>
                <div class="lgf_inner">
                    <div class="lgf_item">
                        <label for="login_email">Votre e-mail</label>
                        <input autocomplete="login_email" type="email" id="login_email" name="login_email" placeholder="name@domaine.com">
                    </div>
                    <div class="lgf_item">
                        <label for="login_password">Votre mot de passe</label>
                        <input autocomplete="login_password" type="password" id="login_password" name="login_password" placeholder="">
                    </div>
                </div>
                <div class="ifg_buttons">
                    <button type="submit">Se connecter<i class="fa fa-angle-right"></i></button>
                </div>
            </form>
        </div>

        <div class="login_details">
            <span class="lgf_logo">
                <img src="<?= site_url('images/logo_square.jpg'); ?>" alt="">
            </span>
        </div>

    </div>

</div>



<script src="<?= site_url('assets/js/vendor/modernizr-3.7.1.min.js'); ?>"></script>
<script src="<?= site_url('assets/js/vendor/jquery-3.4.1.min.js'); ?>"></script>
<script src="<?= site_url('assets/js/vendor/Tocca.min.js'); ?>"></script>
<script src="<?= site_url('assets/js/plugins.js'); ?>"></script>
<script src="<?= site_url('assets/js/login.js?v='.rand(0,99999)); ?>"></script>
</body>
</html>
