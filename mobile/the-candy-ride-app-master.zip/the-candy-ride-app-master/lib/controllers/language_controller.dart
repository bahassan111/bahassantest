import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:rider_app/models/models.dart';
import 'package:rider_app/home.dart';

class LanguageController extends GetxController {
  static LanguageController to = Get.find();
  final store = GetStorage();
  final List<LanguageModel> languages = [
    LanguageModel(
        name: "Bahasa", country: 'US', language: 'en', lname: "en_US"),
    LanguageModel(
        name: "English", country: 'US', language: 'en', lname: "en_US"),
    LanguageModel(
        name: "French", country: 'US', language: 'en', lname: "en_US"),
    LanguageModel(
        name: "Italian", country: 'US', language: 'en', lname: "en_US")
  ];

  @override
  void onReady() {
    super.onReady();
    //Home();
    getDefaultLanguages();
  }

  getDefaultLanguages() async {
    String language = await store.read('language');
    String country = await store.read('country');

    Get.updateLocale(Locale(language ?? 'en', country ?? 'US'));
    update();
  }

  setDefaultLanguage(String language, String country) async {
    Get.updateLocale(Locale(language, country));
    await store.write('language', language);
    await store.write('country', country);
    update();
  }
}
