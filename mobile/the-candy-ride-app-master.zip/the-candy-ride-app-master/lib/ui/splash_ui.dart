import 'package:flutter/material.dart';
import 'package:rider_app/constants/images.dart';
import 'package:get/get.dart';
import 'package:rider_app/controllers/controllers.dart';

class SplashUI extends StatefulWidget {
  @override
  _SplashUIState createState() => _SplashUIState();
}

class _SplashUIState extends State<SplashUI> {
  double height, width;
  final AuthController languageController = AuthController.to;

  @override
  Widget build(BuildContext context) {
    //createAlertDialouge(context);
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;

    return Scaffold(
      body: SafeArea(
        child: Container(
          width: width,
          child: Column(
            children: [
              SizedBox(
                height: 50,
              ),
              Image.asset(
                AllImages.theCandy,
                width: (3 * width) / 4,
              ),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage(
                        AllImages.digitalNomad,
                      ),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              getAboutApp(context),
              SizedBox(
                height: 50,
              ),
              getSupportText(context),
              //createAlertDialouge(context),
              SizedBox(
                height: 20,
              )
            ],
          ),
        ),
      ),
    );
  }

  getSupportText(context) => Container(
        child: Column(
          children: [
            Text(
              "inCaseOfAnyAssistancePleaseGetIn".tr,
              style:
                  Theme.of(context).textTheme.headline3.copyWith(fontSize: 14),
            ),
            RichText(
              text: TextSpan(
                text: "touchAt".tr,
                style: Theme.of(context)
                    .textTheme
                    .headline3
                    .copyWith(height: 1, fontSize: 14),
                children: [
                  TextSpan(
                    text: ' ' + "support@thecandytech.com".tr,
                    style: Theme.of(context)
                        .textTheme
                        .headline4
                        .copyWith(height: 1, fontSize: 14),
                  )
                ],
              ),
            ),
          ],
        ),
      );

  getAboutApp(context) => Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            RichText(
              text: TextSpan(
                  text: "anAppWithout".tr,
                  style: Theme.of(context).textTheme.headline4.copyWith(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                  children: [
                    TextSpan(
                      text: ' ' + "boundries".tr + ',',
                      style: Theme.of(context).textTheme.headline5.copyWith(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                    )
                  ]),
            ),
            SizedBox(
              height: 5,
            ),
            RichText(
              text: TextSpan(
                text: "rideWithUSNoMatterWhereYou".tr,
                style: Theme.of(context).textTheme.headline4.copyWith(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                children: [
                  TextSpan(
                      text: ' ' + "go".tr,
                      style: Theme.of(context).textTheme.headline5.copyWith(
                            fontWeight: FontWeight.w900,
                            fontSize: 16,
                          )),
                  TextSpan(
                    text: "!",
                    style: Theme.of(context).textTheme.headline4.copyWith(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
}
