import 'package:driver/constants/constants.dart';
import 'package:driver/constants/helpers/helpers.dart';
import 'package:driver/controllers/controllers.dart';
import 'package:driver/models/models.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class MyWalletItem extends StatelessWidget {
  final DriverEwalletModel driverEwalletModel;
  static AuthController authTo = Get.find();
  const MyWalletItem({Key key, this.driverEwalletModel}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      margin: EdgeInsets.symmetric(horizontal: 20),
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.all(3),
            decoration: BoxDecoration(
              color: AppThemes.lightdeepPinkDropDownIconColor,
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.star,
              color: Colors.white,
              size: 35,
            ),
          ),
          SizedBox(
            width: 10,
          ),
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          driverEwalletModel.fullname,
                          style: Theme.of(context).textTheme.headline1.copyWith(
                              fontSize: 15, fontWeight: FontWeight.w600),
                        ),
                        SizedBox(
                          height: 3,
                        ),
                        Text(
                          getBookType(driverEwalletModel.bookType) +
                              driverEwalletModel.rideid +
                              driverEwalletModel.categoryCode,
                          style: Theme.of(context).textTheme.headline1.copyWith(
                              fontSize: 15, fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                    Spacer(),
                    Text(
                      authTo.userModel.currency +
                          " " +
                          numberFormating.format(
                            driverEwalletModel.driverfees +
                                driverEwalletModel.tolltaxamount -
                                driverEwalletModel.adminfees,
                          ),
                      style: Theme.of(context)
                          .textTheme
                          .headline1
                          .copyWith(fontSize: 15, fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
                Divider(
                  color: AppThemes.lightDividerColor,
                  height: 0,
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
