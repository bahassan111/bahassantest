package ma.rak.ovr.adapter;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import ma.rak.ovr.R;
import ma.rak.ovr.api.TwDatabase;
import ma.rak.ovr.models.Dossier;
import ma.rak.ovr.storage.SharedPrefManager;
import ma.rak.ovr.ui.main.AffecterFragment;
import ma.rak.ovr.ui.main.ExecutionFragment;
import ma.rak.ovr.ui.main.RejectFragment;

import static ma.rak.ovr.R.drawable.bg_electricite;
import static ma.rak.ovr.R.drawable.gradient_background2;
import static ma.rak.ovr.R.drawable.gradient_background4;
import static ma.rak.ovr.R.drawable.item_assi;
import static ma.rak.ovr.R.drawable.item_button_bg;

public class DemandesAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;

    private FragmentActivity mContext;
    private ArrayList<HashMap<String, String>> branchementList;
    private ArrayList<HashMap<String, String>> abonnementList;
    private final String TAG = getClass().getSimpleName();
    public boolean isBR;

    private PopupWindow mPopupWindow;


    public DemandesAdapter(FragmentActivity mContext, ArrayList<HashMap<String, String>> branchementList, ArrayList<HashMap<String, String>> abonnementList) {
        this.mContext = mContext;
        this.branchementList = branchementList;
        this.abonnementList = abonnementList;
        isBR = SharedPrefManager.getInstance(mContext).getMode() == 1;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_pending_list, parent, false);
            return new DemandesAdapter.ItemViewHolder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_loading, parent, false);
            return new DemandesAdapter.LoadingViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int position) {

        if (viewHolder instanceof ItemViewHolder) {

            populateItemRows((ItemViewHolder) viewHolder, position);
        } else if (viewHolder instanceof LoadingViewHolder) {
            showLoadingView((LoadingViewHolder) viewHolder, position);
        }

    }

    @Override
    public int getItemCount() {
        if (branchementList != null)
            return branchementList.size();
        else if (abonnementList != null)
            return abonnementList.size();
        else
            return 0;
    }

    public void addAllAb(List<HashMap<String, String>> items) {
        for (HashMap<String, String> item : items)
            addAb(item);
    }

    public void addAb(HashMap<String, String> item) {
        abonnementList.add(item);
        notifyItemInserted(abonnementList.size() - 1);
    }

    public void addAllBr(List<HashMap<String, String>> items) {
        for (HashMap<String, String> item : items)
            addBr(item);
    }

    public void addBr(HashMap<String, String> item) {
        branchementList.add(item);
        notifyItemInserted(branchementList.size() - 1);
    }

    public void setList(ArrayList<HashMap<String, String>> branchementList, ArrayList<HashMap<String, String>> abonnementList) {
        this.branchementList = branchementList;
        this.abonnementList = abonnementList;
        notifyDataSetChanged();
    }

    public void clear(){
        this.branchementList = null;
        this.abonnementList = null;
        notifyDataSetChanged();
    }

    /**
     * The following method decides the type of ViewHolder to display in the RecyclerView
     *
     * @param position
     * @return
     */
    @Override
    public int getItemViewType(int position) {
        if (branchementList != null) {
            return branchementList.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
        } else if (abonnementList != null) {
            return abonnementList.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
        }

        return VIEW_TYPE_ITEM;
    }


    private class ItemViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView tvItem;
        public final View mView;
        public final TextView mContentView, mAddressView, mSectorView, mLIBEGERA, clientdoss, lblv, pending;
        ArrayList<HashMap<String, String>> pendings;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            mView = itemView;
            mContentView = (TextView) itemView.findViewById(R.id.client_name);
            mAddressView = (TextView) itemView.findViewById(R.id.client_address);
            mSectorView = (TextView) itemView.findViewById(R.id.client_sector);
            mLIBEGERA = (TextView) itemView.findViewById(R.id.LIBEGERA);
            clientdoss = (TextView) itemView.findViewById(R.id.clientdoss);
            lblv = (TextView) itemView.findViewById(R.id.lblv);
            pending = (TextView) itemView.findViewById(R.id.pending);
            itemView.setOnClickListener(this);

            TwDatabase.TwDatabaseHelper dbh = new TwDatabase.TwDatabaseHelper(itemView.getContext());
            pendings = dbh.query(TwDatabase.Pending.TABLE_NAME, null, null, null);
        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            Log.d(TAG, "Clicked!" + position);
            final View customView = LayoutInflater.from(mContext).inflate(R.layout.custom_layout, null);
            final View otherView = LayoutInflater.from(mContext).inflate(R.layout.popmenu_view, null);
            String scoop = SharedPrefManager.getInstance(mContext).getScoop();

            TextView client_name = customView.findViewById(R.id.client_name);
            TextView dossier_id = customView.findViewById(R.id.dossier_id);
            TextView client_address = customView.findViewById(R.id.client_address);
            TextView date_operation = customView.findViewById(R.id.date_reclamation);
            TextView type_id = customView.findViewById(R.id.destinataire);
            TextView emetteur = customView.findViewById(R.id.emetteur);
            TextView agence = customView.findViewById(R.id.agence);
            TextView num_compteur = customView.findViewById(R.id.num_compteur);
            TextView reclamation_adresse = customView.findViewById(R.id.reclamation_adresse);
            TextView nature_operation = customView.findViewById(R.id.gerance);
            Button operationExecute = customView.findViewById(R.id.btn_traiter);
            Button other_actions = customView.findViewById(R.id.btn_others);
//            Button operationReject = customView.findViewById(R.id.operationReject);
//            Button operationNoExecution = customView.findViewById(R.id.operationNoExecution);
//            Button operationReaf = customView.findViewById(R.id.operationReaf);

            Button opt = otherView.findViewById(R.id.cancel_btn);
            Button reaff = otherView.findViewById(R.id.affecter);
            Button histoop = otherView.findViewById(R.id.histo_op);
            Button histoco = otherView.findViewById(R.id.histo_consom);

            Intent execution = new Intent(mContext, ExecutionFragment.class);
            Intent reject = new Intent(mContext, RejectFragment.class);
            Intent noExecution = new Intent(mContext, RejectFragment.class);
            Intent affecter = new Intent(mContext, AffecterFragment.class);

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String currentDateandTime = sdf.format(new Date());




            if (false) {

                lblv.setText("BR");
                HashMap<String, String> clickerItem = branchementList.get(position);

                client_name.setText(clickerItem.get("NOM"));
                dossier_id.setText(clickerItem.get("NUMDEMDE"));
                client_address.setText(clickerItem.get(TwDatabase.Demandes.LIBEAGEN));
                date_operation.setText(clickerItem.get("DATSAIDE"));

                type_id.setText(clickerItem.get("STATDEVI"));
                nature_operation.setText(clickerItem.get("CATEDEVI"));

                boolean inHisto = !(clickerItem.get("STATDEVI").equals("2") || clickerItem.get("STATDEVI").equals("1"));
                operationExecute.setVisibility(inHisto ? View.INVISIBLE : View.VISIBLE);
                other_actions.setVisibility(inHisto ? View.INVISIBLE : View.VISIBLE);
//                operationNoExecution.setVisibility(inHisto ? View.INVISIBLE : View.VISIBLE);
//                operationReject.setVisibility(inHisto ? View.INVISIBLE : View.VISIBLE);
//                operationReaf.setVisibility(inHisto ? View.INVISIBLE : (scoop.equals("Superviseur") ? View.VISIBLE : View.INVISIBLE));





            }
            else if (SharedPrefManager.getInstance(mContext).getMode() == 1) {
                HashMap<String, String> clickerItem = branchementList.get(position);
                lblv.setText("BR");
                client_name.setText(clickerItem.get("NOMPRECL"));
                dossier_id.setText(clickerItem.get("ANNEDOSS") + "/" + clickerItem.get("NUMEDOSS"));
                client_address.setText(clickerItem.get("ADRECLIE"));
                date_operation.setText(clickerItem.get("DATCREDO"));
                type_id.setText(clickerItem.get("DESNATRE"));
                nature_operation.setText(clickerItem.get("LIBEGERA"));
                emetteur.setText(clickerItem.get("LIBEEMET"));
                agence.setText(clickerItem.get("LIBEAGEN"));
                num_compteur.setText(clickerItem.get("REFECOMP"));
                reclamation_adresse.setText(clickerItem.get("ADRERECL"));



                boolean inHisto = clickerItem.get("STATUS") != null && Integer.valueOf(clickerItem.get("STATUS")) > 1;
                operationExecute.setVisibility(inHisto ? View.INVISIBLE : View.VISIBLE);
                other_actions.setVisibility(inHisto ? View.INVISIBLE : View.VISIBLE);
//                operationNoExecution.setVisibility(inHisto ? View.INVISIBLE : View.VISIBLE);
//                operationReject.setVisibility(inHisto ? View.INVISIBLE : View.VISIBLE);
//                operationReaf.setVisibility(inHisto ? View.INVISIBLE : (scoop.equals("Superviseur") ? View.VISIBLE : View.INVISIBLE));

                execution.putExtra("CONSULT", false);
                reject.putExtra("CONSULT", false);
                noExecution.putExtra("CONSULT", false);

                if(inHisto){
                    if(clickerItem.get("STATOPER").equals("2")){

                        operationExecute.setVisibility(View.VISIBLE);
                        operationExecute.setText(R.string.consult);
                        execution.putExtra("CONSULT", true);

                    }else if(clickerItem.get("STATOPER").equals("3")){

//                        operationReject.setVisibility(View.VISIBLE);
//                        operationReject.setText(R.string.consult);
                        reject.putExtra("CONSULT", true);

                    }else if(clickerItem.get("STATOPER").equals("4")){

//                        operationNoExecution.setVisibility(View.VISIBLE);
//                        operationNoExecution.setText(R.string.consult);
                        noExecution.putExtra("CONSULT", true);

                    }
                }


                execution.putExtra("br", true);
                execution.putExtra("status", "3");
                execution.putExtra("date", currentDateandTime);
                execution.putExtra("ITEM", clickerItem);


                reject.putExtra("br", true);
                reject.putExtra("status", "3");
                reject.putExtra("date", currentDateandTime);
                reject.putExtra("ITEM", clickerItem);

                noExecution.putExtra("br", true);
                noExecution.putExtra("status", "4");
                noExecution.putExtra("date", currentDateandTime);
                noExecution.putExtra("ITEM", clickerItem);

                affecter.putExtra("br", true);
                affecter.putExtra("status", "4");
                affecter.putExtra("date", currentDateandTime);
                affecter.putExtra("ITEM", clickerItem);

            }
            else {
                HashMap<String, String> clickerItem = abonnementList.get(position);
                lblv.setText("AB");
                client_name.setText(clickerItem.get("NOM"));
                dossier_id.setText(clickerItem.get("NUMEDOSS") + "/" + clickerItem.get("ANNEDOSS"));
                client_address.setText(clickerItem.get("ADRECLIE"));
                date_operation.setText(clickerItem.get("DATDEMAB"));

                type_id.setText(clickerItem.get("TYPECLIE"));
                nature_operation.setText(clickerItem.get("CODNATCL"));

                String dosss = clickerItem.get("DOSSIERS");
                ArrayList<Dossier> arrayList = new ArrayList<>();
                if(dosss != null){
                try {
                    JSONArray jdossiers = new JSONArray(dosss);
                    for (int i = 0; i < jdossiers.length(); i++) {
                        JSONObject doss = jdossiers.getJSONObject(i);
                        arrayList.add(new Dossier(doss.getString("GERANCE"), doss.getString("NUM"), doss.getString("ADRESSE")));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                }

                boolean inHisto = false; //Integer.valueOf(clickerItem.get("STATOPER")) > 1;
                operationExecute.setVisibility(inHisto ? View.INVISIBLE : View.VISIBLE);
//                operationNoExecution.setVisibility(inHisto ? View.INVISIBLE : View.VISIBLE);
//                operationReject.setVisibility(inHisto ? View.INVISIBLE : View.VISIBLE);
//                operationReaf.setVisibility(inHisto ? View.INVISIBLE : (scoop.equals("Superviseur") ? View.VISIBLE : View.INVISIBLE));

                execution.putExtra("CONSULT", false);
                reject.putExtra("CONSULT", false);
                noExecution.putExtra("CONSULT", false);

                if(inHisto){
                    if(clickerItem.get("STATOPER").equals("2")){

                        operationExecute.setVisibility(View.VISIBLE);
                        operationExecute.setText(R.string.consult);
                        execution.putExtra("CONSULT", true);

                    }else if(clickerItem.get("STATOPER").equals("3")){

//                        operationReject.setVisibility(View.VISIBLE);
//                        operationReject.setText(R.string.consult);
                        reject.putExtra("CONSULT", true);

                    }else if(clickerItem.get("STATOPER").equals("4")){

//                        operationNoExecution.setVisibility(View.VISIBLE);
//                        operationNoExecution.setText(R.string.consult);
                        noExecution.putExtra("CONSULT", true);

                    }
                }


                execution.putExtra("br", false);
                execution.putExtra("status", "2");
                execution.putExtra("date", currentDateandTime);
                execution.putExtra("doss_annee", clickerItem.get("ANNEDOSS"));
                execution.putExtra("doss_numm", clickerItem.get("NUMEDOSS"));
                execution.putExtra("num_operation", clickerItem.get("NUMOPRAB"));
                execution.putExtra("gerance", clickerItem.get("CODEGERA"));
                execution.putExtra("adreloca", clickerItem.get("ADRELOCA"));
                execution.putExtra("nature_install", clickerItem.get("NATU_LOT"));
                execution.putExtra("etage", clickerItem.get("CODEETAG"));
                execution.putParcelableArrayListExtra("dossier", arrayList);

                execution.putExtra("ITEM", clickerItem);

                reject.putExtra("br", false);
                reject.putExtra("status", "3");
                reject.putExtra("date", currentDateandTime);
                reject.putExtra("doss_annee", clickerItem.get("ANNEDOSS"));
                reject.putExtra("doss_numm", clickerItem.get("NUMEDOSS"));
                reject.putExtra("num_operation", clickerItem.get("NUMOPRAB"));
                reject.putExtra("gerance", clickerItem.get("CODEGERA"));
                reject.putExtra("adreloca", clickerItem.get("ADRELOCA"));
                reject.putParcelableArrayListExtra("dossier", arrayList);
                reject.putExtra("ITEM", clickerItem);

                noExecution.putExtra("br", false);
                noExecution.putExtra("status", "4");
                noExecution.putExtra("date", currentDateandTime);
                noExecution.putExtra("doss_annee", clickerItem.get("ANNEDOSS"));
                noExecution.putExtra("doss_numm", clickerItem.get("NUMEDOSS"));
                noExecution.putExtra("num_operation", clickerItem.get("NUMOPRAB"));
                noExecution.putExtra("gerance", clickerItem.get("CODEGERA"));
                noExecution.putExtra("adreloca", clickerItem.get("ADRELOCA"));
                noExecution.putParcelableArrayListExtra("dossier", arrayList);
                noExecution.putExtra("ITEM", clickerItem);

                affecter.putExtra("br", false);
                affecter.putExtra("status", "4");
                affecter.putExtra("date", currentDateandTime);
                affecter.putExtra("doss_annee", clickerItem.get("ANNEDOSS"));
                affecter.putExtra("doss_numm", clickerItem.get("NUMEDOSS"));
                affecter.putExtra("num_operation", clickerItem.get("NUMOPRAB"));
                affecter.putExtra("gerance", clickerItem.get("CODEGERA"));
                affecter.putExtra("AGENT", clickerItem.get("CODUTIEX"));
                affecter.putExtra("ITEM", clickerItem);
            }

            operationExecute.setOnClickListener(v3 -> {
                mContext.startActivity(execution);
                mPopupWindow.dismiss();
            });

            other_actions.setOnClickListener(v3 -> {
                PopupWindow popup = new PopupWindow(otherView,
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        true);

                popup.setBackgroundDrawable(new ColorDrawable(Color.argb(80, 59, 59, 59)));

                popup.showAtLocation(otherView, Gravity.BOTTOM, 0, 0);

                opt.setOnClickListener(v4 -> {
                    popup.dismiss();
                });




            });

            // Initialize a new instance of popup window
            mPopupWindow = new PopupWindow(
                    customView,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    true
            );

            // Set an elevation value for popup window
            // Call requires API level 21
            if (Build.VERSION.SDK_INT >= 21) {
                mPopupWindow.setElevation(100);
            }

            // Get a reference for the custom view close button
            ImageButton closeButton = (ImageButton) customView.findViewById(R.id.ib_close);

            // Set a click listener for the popup window close button
            closeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // Dismiss the popup window
                    mPopupWindow.dismiss();
                }
            });

            mPopupWindow.setBackgroundDrawable(new ColorDrawable(Color.argb(80, 59, 59, 59)));

            ConstraintLayout constraintLayout = (ConstraintLayout) mContext.findViewById(R.id.constraintLayoutMap);
            mPopupWindow.showAtLocation(customView, Gravity.BOTTOM, 0, 0);
        }
    }

    private class LoadingViewHolder extends RecyclerView.ViewHolder {

        ProgressBar progressBar;

        public LoadingViewHolder(@NonNull View itemView) {
            super(itemView);
            progressBar = itemView.findViewById(R.id.progressBar);
        }
    }

    private void showLoadingView(LoadingViewHolder viewHolder, int position) {
        //ProgressBar would be displayed

    }

    private void populateItemRows(ItemViewHolder viewHolder, int position) {

//        String item = mItemList.get(position);
//        viewHolder.tvItem.setText(item);
        viewHolder.mLIBEGERA.setBackground(ContextCompat.getDrawable(this.mContext, item_button_bg));




        if (branchementList != null) {
            HashMap<String, String> branchement = branchementList.get(position);

            boolean isPending = false;
            for (HashMap<String, String> p: viewHolder.pendings){
                if(p.get("NUMDOSRE").equals(branchement.get("NUMDOSRE"))){
                    isPending = true;
                    break;
                }
            }


            //viewHolder.mContentView.setText(branchement.get("ANNEDOSS") + "/" + branchement.get("NUMEDOSS"));
            viewHolder.mContentView.setText("N°: " + branchement.get("NUMDOSRE"));
            viewHolder.mAddressView.setText(branchement.get("ADRERECL"));
            viewHolder.mLIBEGERA.setText(branchement.get("LIBEGERA"));
            if (branchement.get("CODEGERA").equals("2")) {
                viewHolder.mLIBEGERA.setBackground(ContextCompat.getDrawable(this.mContext, bg_electricite));
            }
            else if (branchement.get("CODEGERA").equals("3")){
                viewHolder.mLIBEGERA.setBackground(ContextCompat.getDrawable(this.mContext, item_assi));
            }

            if(isPending){
                viewHolder.pending.setVisibility(View.VISIBLE);
            }else{
                viewHolder.pending.setVisibility(View.INVISIBLE);
            }

            viewHolder.mSectorView.setText(branchement.get("OBJECT_VERIF"));
            viewHolder.lblv.setText("RE");
            viewHolder.lblv.setBackground(ContextCompat.getDrawable(this.mContext, gradient_background4));
//            notifyItemChanged(holder.getAdapterPosition());

        }

        if (abonnementList != null) {
            HashMap<String, String> abonnement = abonnementList.get(position);

            boolean isPending = false;
            for (HashMap<String, String> p: viewHolder.pendings){
                if(p.get("ANNEDOSS").equals(abonnement.get("ANNEDOSS")) && p.get("NUMEDOSS").equals(abonnement.get("NUMEDOSS")) && p.get("NUMOPRAB").equals(abonnement.get("NUMOPRAB"))){
                    isPending = true;
                    break;
                }
            }


            viewHolder.mContentView.setText(abonnement.get("NOM") + " #" + abonnement.get("NUMOPRAB"));
            viewHolder.mAddressView.setText(abonnement.get("ADRELOCA"));
            viewHolder.mLIBEGERA.setText(abonnement.get("LIBEGERA"));
            viewHolder.clientdoss.setText("DOSSIER : " + abonnement.get("ANNEDOSS") + "/" + abonnement.get("NUMEDOSS"));

            if (abonnement.get("CODEGERA").equals("2")){

                viewHolder.mLIBEGERA.setBackground(ContextCompat.getDrawable(this.mContext, bg_electricite));
            }
            else if (abonnement.get("CODEGERA").equals("3")){
                viewHolder.mLIBEGERA.setBackground(ContextCompat.getDrawable(this.mContext, item_assi));
            }

            if(isPending){
                viewHolder.pending.setVisibility(View.VISIBLE);
            }else{
                viewHolder.pending.setVisibility(View.INVISIBLE);
            }
            viewHolder.mSectorView.setText("Secteur : " + abonnement.get("CODESECT") + " | Tournée: " + abonnement.get("NUMETOUR") + " | Ordre: 0  ");
            viewHolder.lblv.setText("AB");
            viewHolder.lblv.setBackground(ContextCompat.getDrawable(this.mContext, gradient_background2));
//            notifyItemChanged(holder.getAdapterPosition());

        }

    }


}
