<div id="config_lang_view">
    <div class="dt_section">
        <div class="dt_head">
            <div class="t">
                <h3>Language</h3>
            </div>
            <div class="a">
                <button class="button default" data-table="languages_tbl" id="reload_table"><i class="fas fa-sync-alt"></i> </button>
            </div>
        </div>
        <div class="dt_inner">
            <?= datatable('languages_tbl', 4); ?>
        </div>
    </div>
</div>

