import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rider_app/controllers/controllers.dart';
import '../../constants/app_themes.dart';

class VehicleCategory extends StatelessWidget {
  const VehicleCategory(
      {this.onVehicleCategorySelected, this.onClosrButtonClick});
  final Function onVehicleCategorySelected;
  final Function onClosrButtonClick;
  static HomeController to = Get.find();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 230,
      margin: EdgeInsets.symmetric(horizontal: 50),
      decoration: BoxDecoration(
          color: AppThemes.lightWhitebackGroundColor,
          borderRadius: BorderRadius.all(
            Radius.circular(15),
          ),
          boxShadow: [
            BoxShadow(
                color: AppThemes.lightBlackbackGroundColor.withOpacity(0.3),
                offset: Offset(0, 3),
                blurRadius: 0,
                spreadRadius: 3)
          ]),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: [
          Align(
            alignment: Alignment.centerRight,
            child: GestureDetector(
              onTap: onClosrButtonClick,
              child: Container(
                padding: EdgeInsets.only(top: 5, right: 10),
                child: Icon(
                  Icons.close,
                  size: 20,
                ),
              ),
            ),
          ),
          Text(
            "vehicleCategory".tr,
            style: Theme.of(context)
                .textTheme
                .headline2
                .copyWith(fontSize: 16, fontWeight: FontWeight.w700),
          ),
          Divider(
            color: AppThemes.lightPinkBackGroundColor,
            thickness: 3,
          ),
          ListView.builder(
            shrinkWrap: true,
            padding: EdgeInsets.zero,
            itemCount: to.subtypeOfVehicles.length,
            itemBuilder: (context, index) {
              return GestureDetector(
                onTap: () {
                  to.selectedSubTypeOfVehicle = to.subtypeOfVehicles[index];
                  onVehicleCategorySelected();
                },
                child: Container(
                  padding: EdgeInsets.only(
                    left: 15,
                    top: 8,
                    bottom: 8,
                  ),
                  decoration: BoxDecoration(
                      border: Border(
                    bottom: BorderSide(
                      color: AppThemes.lightDividerColor,
                    ),
                  )),
                  child: Text(
                    to.subtypeOfVehicles[index].categoryName,
                    style: Theme.of(context)
                        .textTheme
                        .headline2
                        .copyWith(fontSize: 14, fontWeight: FontWeight.w700),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
