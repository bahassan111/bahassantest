import {

    PENDING_SAVE_COMMENT,
    SET_COMMENTS_ALL,
    COMMENT_SAVE_SUCCESS

} from "../actions/types";

export default function(
    state = { isLoadingData: false, isDoSearch: false, data: [], keyword: null },
    action
) {

    console.log("Log_action_LOGIN => ", action.type);

    switch (action.type) {
        case PENDING_SAVE_COMMENT:
            return {
                ...state,
                isLoadingData: true
            };

        case SET_COMMENTS_ALL:
            return { ...state, data: action.payload };

        case COMMENT_SAVE_SUCCESS:
            return {
                ...state,
                isLoadingData: false
            };

        default:
            return state;
    }

}
