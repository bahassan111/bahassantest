<?php

$projects = get_instance()->alpha->get_user_projects(null, 'date_modified', 'DESC', 6);

?>

<header class="main_nav">
    <div class="logo">
        <a href="<?= site_url(); ?>">
            <span>tw</span>
            <b>Project Manager</b>
        </a>
    </div>
    <div class="nav">
       <div class="nav_inner">
           <div>
               <a href="<?= site_url(''); ?>">Dashboard</a>
           </div>
           <div>
               <a href="#">Projects <i class="fas fa-caret-down"></i></a>

               <ul>
                   <?php foreach($projects as $project){ ?>
                       <li><a href="<?= getProjectUrl($project); ?>"><i style="background-color: <?= $project->color ?>"><?= name_abbr($project->name); ?></i> <span><?= $project->name; ?></span></a></li>
                   <?php } ?>
                   <li class="b">
                       <span>Or</span>
                       <a href="<?= site_url('projects'); ?>">See all projects</a>
                   </li>
               </ul>
           </div>
           <?php if(userInfo()->is_admin){?>
               <div>
                   <a href="#">Settings <i class="fas fa-caret-down"></i></a>

                   <ul>
                       <li><a href="<?= site_url('settings/users'); ?>"><i class="fas fa-users"></i> Manage users</a></li>

                   </ul>
               </div>
           <?php } ?>
       </div>
    </div>
    <div class="user_nav">
        <div class="un_notif">
            <a href="javascript:void(0);" class="h"><i class="far fa-envelope"></i><small></small></a>
            <ul>
                <li class="msg">
                    <span class="i"><i class="fas fa-user"></i></span>
                    <span class="d"><b>Title of the message</b><small>here is the detais</small></span>
                </li>
                <li class="a">
                    <a href="#">View all</a>
                </li>
            </ul>
        </div>
        <div class="un_notif">
            <a href="javascript:void(0);" class="h"><i class="far fa-bell"></i><small></small></a>
            <ul>
                <li class="msg">
                    <span class="i"><i class="fas fa-user"></i></span>
                    <span class="d"><b>User has added a new whatever</b><small>here is the detais</small></span>
                </li>
                <li class="a">
                    <a href="#">View all</a>
                </li>
            </ul>
        </div>
        <div class="un_user">
            <a href="javascript:void(0);" class="t"><span><i class="fas fa-user"></i></span></a>
            <div class="m">
                <div class="h">
                    <a href="javascript:void(0);"><span>Username here</span></a>
                </div>
                <div class="t">
                    <a href="#">
                        <span class="i"><i class="far fa-user"></i></span>
                        <span class="d"><b>My Profile</b><small>Manage my personal infos</small></span>
                    </a>
                    <a href="#">
                        <span class="i"><i class="fas fa-wrench"></i></span>
                        <span class="d"><b>Preferences</b><small>Your app preferences in one place</small></span>
                    </a>
                    <a data-own href="<?= site_url('auth/logout'); ?>">
                        <span class="i"><i class="fas fa-sign-out-alt"></i></span>
                        <span class="d"><b>Log out</b></span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</header>


